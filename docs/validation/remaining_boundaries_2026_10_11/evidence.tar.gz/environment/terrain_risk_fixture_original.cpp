#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "path_manager/path_manager.h"

using path_manager::TerrainData;
namespace {
std::ofstream output;
std::uint64_t values=0, queries=0, masks=0;
template <class T> void write(const T &value) {
  output.write(reinterpret_cast<const char *>(&value),sizeof(T)); ++values;
}
TerrainData terrain(int variant) {
  TerrainData t;
  t.cols=variant==6?30:20; t.rows=variant==6?18:20;
  t.resolution=variant==6?0.7:1.; t.origin_x=-0.5*t.rows*t.resolution;
  t.origin_y=-0.5*t.cols*t.resolution; t.length_x=t.rows*t.resolution;
  t.length_y=t.cols*t.resolution; t.generation=1; t.valid=variant!=0;
  t.elevation.resize(t.rows*t.cols,0.f);
  for(int c=0;c<t.cols;++c) for(int r=0;r<t.rows;++r) {
    auto p=t.terrainToWorld(c,r,0.f);
    float h=variant==2?3.f:0.f;
    if(variant==3 || variant==4 || variant==5) h=r==6?4.f:0.f;
    if(variant==3 && c<4) h=std::numeric_limits<float>::quiet_NaN();
    if(variant==6) h=static_cast<float>(2.+0.11*p.x()-0.07*p.y());
    if(variant==7) h=std::numeric_limits<float>::quiet_NaN();
    t.elevation[c*t.rows+r]=h;
  }
  return t;
}
}
int main(int argc, char **argv) {
  if(argc!=2) return 2;
  output.open(argv[1],std::ios::binary);
  rclcpp::init(argc,argv);
  auto node=std::make_shared<rclcpp::Node>("terrain_risk_extraction_fixture");
  node->declare_parameter("drone_id",1);
  path_manager::PathManager pm(node,false);
  pm.log_manager_.reset();
  for(int variant=0;variant<8;++variant) {
    pm.terrain_data_=terrain(variant);
    pm.risk_terrain_mask_enable_=variant!=1;
    pm.risk_grounded_=variant!=4;
    pm.risk_mask_radial_step_=variant==5?10.:0.;
    pm.risk_mask_softness_=variant==6?0.17:0.1;
    pm.opt_obstacle_clearance_=variant==6?0.31:0.15;
    pm.risk_zones_={path_manager::RiskZone{Eigen::Vector3d(.5,.5,2.),10.,.8},
      path_manager::RiskZone{Eigen::Vector3d(3.5,.5,.5),10.,.7},
      path_manager::RiskZone{Eigen::Vector3d(-.4,.7,.1),.2,.9},
      path_manager::RiskZone{Eigen::Vector3d::Zero(),0.,.8},
      path_manager::RiskZone{Eigen::Vector3d::Zero(),-1.,.8}};
    pm.rebuildTerrainRiskMasks();
    write(variant);
    for(const auto &m:pm.terrain_risk_masks_) {
      ++masks; write(m.valid); write(m.source.x());write(m.source.y());write(m.source.z());
      write(m.max_range);write(m.radial_step);write(m.radial_count);write(m.angular_count);
      write(static_cast<std::uint64_t>(m.shadow_ceiling.size()));
      for(float v:m.shadow_ceiling) write(v);
    }
    std::vector<Eigen::Vector3d> positions;
    for(int xi=-24;xi<=24;xi+=2) for(int yi=-20;yi<=20;yi+=2)
      for(double z:{-10.,0.,.1,1.,2.,4.,8.,12.}) positions.emplace_back(xi*.5,yi*.5,z);
    for(const auto &z:pm.risk_zones_) {
      positions.push_back(z.center);
      positions.push_back(z.center+Eigen::Vector3d(1e-10,0.,0.));
      positions.push_back(z.center+Eigen::Vector3d(z.reach*1.05,0.,0.));
      positions.push_back(z.center+Eigen::Vector3d(z.reach*1.05+1e-8,0.,0.));
      for(double a:{-1e-12,1e-12,3.141592653589793,-3.141592653589793})
        positions.push_back(z.center+Eigen::Vector3d(std::cos(a)*z.reach*.7,std::sin(a)*z.reach*.7,.11));
    }
    write(static_cast<std::uint64_t>(positions.size()));
    for(const auto &p:positions) {
      double dz=0.; write(pm.riskGroundedZ(p,&dz));write(dz);
      for(std::size_t i=0;i<=pm.risk_zones_.size();++i) {
        Eigen::Vector3d g; const double v=pm.riskVisibility(i,p,&g);
        write(pm.riskShadowCeiling(i,p));write(pm.riskVisibilityValue(i,p));write(v);
        write(g.x());write(g.y());write(g.z());write(pm.getEffectiveRisk(i,p));++queries;
      }
    }
  }
  output.close(); rclcpp::shutdown();
  std::cout << "{\"cases\":8,\"masks\":"<<masks<<",\"queries\":"<<queries<<",\"values\":"<<values<<"}\n";
}

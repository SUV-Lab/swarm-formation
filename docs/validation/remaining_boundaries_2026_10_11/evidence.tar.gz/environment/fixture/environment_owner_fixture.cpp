#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "path_manager/planning_environment_store.h"
#include <rclcpp/rclcpp.hpp>

using path_manager::TerrainData;
namespace {
std::ofstream output;
std::uint64_t values=0, queries=0, masks=0;
template <class T> void write(const T &value) {
  output.write(reinterpret_cast<const char *>(&value),sizeof(T)); ++values;
}
TerrainData terrain(int variant) {
  TerrainData t;
  t.cols=variant==6?30:20; t.rows=variant==6?18:20;
  t.resolution=variant==6?0.7:1.; t.origin_x=-0.5*t.rows*t.resolution;
  t.origin_y=-0.5*t.cols*t.resolution; t.length_x=t.rows*t.resolution;
  t.length_y=t.cols*t.resolution; t.generation=1; t.valid=variant!=0;
  t.elevation.resize(t.rows*t.cols,0.f);
  for(int c=0;c<t.cols;++c) for(int r=0;r<t.rows;++r) {
    auto p=t.terrainToWorld(c,r,0.f);
    float h=variant==2?3.f:0.f;
    if(variant==3 || variant==4 || variant==5) h=r==6?4.f:0.f;
    if(variant==3 && c<4) h=std::numeric_limits<float>::quiet_NaN();
    if(variant==6) h=static_cast<float>(2.+0.11*p.x()-0.07*p.y());
    if(variant==7) h=std::numeric_limits<float>::quiet_NaN();
    t.elevation[c*t.rows+r]=h;
  }
  return t;
}
}
int main(int argc, char **argv) {
  if(argc!=2) return 2;
  output.open(argv[1],std::ios::binary);
  rclcpp::init(argc,argv);
  for(int variant=0;variant<8;++variant) {
    const double clearance=variant==6?0.31:0.15;
    path_manager::PlanningEnvironmentOptions opts{1.,.1,false,3.,true,42,
        false,.35,variant!=1,variant==5?10.:0.,variant==6?0.17:0.1,variant!=4};
    auto log=std::make_shared<swarm_formation::LogManager>(
        "environment_owner_fixture", "/tmp/mmp_environment_owner_fixture_logs",
        swarm_formation::LogManager::WARN);
    path_manager::PlanningEnvironmentStore pm(opts,log);
    pm.log_manager_.reset();
    pm.terrain_data_=terrain(variant);
    pm.risk_zones_={path_manager::RiskZone{Eigen::Vector3d(.5,.5,2.),10.,.8},
      path_manager::RiskZone{Eigen::Vector3d(3.5,.5,.5),10.,.7},
      path_manager::RiskZone{Eigen::Vector3d(-.4,.7,.1),.2,.9},
      path_manager::RiskZone{Eigen::Vector3d::Zero(),0.,.8},
      path_manager::RiskZone{Eigen::Vector3d::Zero(),-1.,.8}};
    pm.rebuildTerrainRiskMasks();
    write(variant);
    for(const auto &m:pm.terrain_risk_masks_) {
      ++masks; write(m.valid); write(m.source.x());write(m.source.y());write(m.source.z());
      write(m.max_range);write(m.radial_step);write(m.radial_count);write(m.angular_count);
      write(static_cast<std::uint64_t>(m.shadow_ceiling.size()));
      for(float v:m.shadow_ceiling) write(v);
    }
    std::vector<Eigen::Vector3d> positions;
    for(int xi=-24;xi<=24;xi+=2) for(int yi=-20;yi<=20;yi+=2)
      for(double z:{-10.,0.,.1,1.,2.,4.,8.,12.}) positions.emplace_back(xi*.5,yi*.5,z);
    for(const auto &z:pm.risk_zones_) {
      positions.push_back(z.center);
      positions.push_back(z.center+Eigen::Vector3d(1e-10,0.,0.));
      positions.push_back(z.center+Eigen::Vector3d(z.reach*1.05,0.,0.));
      positions.push_back(z.center+Eigen::Vector3d(z.reach*1.05+1e-8,0.,0.));
      for(double a:{-1e-12,1e-12,3.141592653589793,-3.141592653589793})
        positions.push_back(z.center+Eigen::Vector3d(std::cos(a)*z.reach*.7,std::sin(a)*z.reach*.7,.11));
    }
    write(static_cast<std::uint64_t>(positions.size()));
    for(const auto &p:positions) {
      double dz=0.; write(pm.groundedZ(p,clearance,&dz));write(dz);
      for(std::size_t i=0;i<=pm.risk_zones_.size();++i) {
        Eigen::Vector3d g; const double v=pm.visibility(i,p,clearance,&g);
        write(pm.shadowCeiling(i,p));write(pm.visibilityValue(i,p,clearance));write(v);
        write(g.x());write(g.y());write(g.z());write(pm.riskValue(i,p,clearance));++queries;
      }
    }
  }
  output.close(); rclcpp::shutdown();
  std::cout << "{\"cases\":8,\"masks\":"<<masks<<",\"queries\":"<<queries<<",\"values\":"<<values<<"}\n";
}

#include <rclcpp/rclcpp.hpp>
#include <fstream>
#include <iostream>
#include <cmath>
#ifdef OWNER
#include "path_manager/planning_environment_store.h"
#else
#include "path_manager/path_manager.h"
#endif
namespace pm = path_manager;
std::ofstream out;
template<class T> void put(const T &v) { out.write(reinterpret_cast<const char *>(&v),sizeof(v)); }
void vec(const Eigen::Vector3d &v) { for(int j=0;j<3;++j) put(v[j]); }
grid_map_msgs::msg::GridMap::SharedPtr map(float h,double res=1.) {
 auto m=std::make_shared<grid_map_msgs::msg::GridMap>();
 m->info.resolution=res;m->info.length_x=m->info.length_y=20*res;
 m->layers={"elevation"};m->data.resize(1);m->data[0].layout.dim.resize(2);
 m->data[0].layout.dim[0].size=m->data[0].layout.dim[1].size=20;
 m->data[0].data.assign(400,h);return m;
}
struct Engine {
#ifdef OWNER
 std::shared_ptr<swarm_formation::LogManager> log=std::make_shared<swarm_formation::LogManager>("env_lifecycle_fixture", "/tmp/mmp_environment_lifecycle_logs", swarm_formation::LogManager::WARN);
 pm::PlanningEnvironmentStore env{{0.,.1,false,3.,true,42,true,.35,true,0.,.1,true},log};
 void terrain(const grid_map_msgs::msg::GridMap::SharedPtr &m) {
  auto u=env.ingestTerrain(m);if(!u.accepted())return;
  if(u.kind==pm::TerrainUpdateKind::REPLACED && env.ensureTerrainDistanceField())
   for(const auto &p:env.takePendingObstacles()) { if(p.is_box)box(p.center,p.size);else sphere(p.center,p.radius); }
  env.refreshRisk();
 }
 int sphere(const Eigen::Vector3d &c,double r){return env.addSphere(c,r);}
 int box(const Eigen::Vector3d &c,const Eigen::Vector3d &s){return env.addBox(c,s);}
 void clear(){env.clearObstacles();}
 bool zones(const std::vector<pm::RiskZone>&z){return env.setRiskZones(z);}
 const auto &sdf()const{return env.distanceField();}
 const auto &dem()const{return env.terrain();}
 const auto &zones()const{return env.riskZones();}
 uint64_t revision()const{return env.revision();}
 uint64_t fingerprint()const{return env.riskZoneFingerprint();}
 double risk(size_t i,const Eigen::Vector3d&p)const{return env.riskValue(i,p,.7);}
#else
 std::shared_ptr<rclcpp::Node> node;
 std::unique_ptr<pm::PathManager> manager;
 Engine(){rclcpp::NodeOptions opts;opts.parameter_overrides({rclcpp::Parameter("manager/sdf_voxel_size",0.),rclcpp::Parameter("manager/risk_zone_agl",true)});node=std::make_shared<rclcpp::Node>("environment_lifecycle_fixture",opts);node->declare_parameter("drone_id",1);manager=std::make_unique<pm::PathManager>(node,false);}
 void terrain(const grid_map_msgs::msg::GridMap::SharedPtr&m){manager->setTerrainData(m);}
 int sphere(const Eigen::Vector3d &c,double r){return manager->addDynamicSphere(c,r);}
 int box(const Eigen::Vector3d &c,const Eigen::Vector3d &s){return manager->addDynamicBox(c,s);}
 void clear(){manager->clearDynamicObstacles();}
 bool zones(const std::vector<pm::RiskZone>&z){return manager->setRiskZonesRuntime(z);}
 const auto &sdf()const{return manager->sdf_manager_;}
 const auto &dem()const{return manager->terrain_data_;}
 const auto &zones()const{return manager->riskZones();}
 uint64_t revision()const{return manager->environmentRevision();}
 uint64_t fingerprint()const{return manager->riskZoneFingerprint();}
 double risk(size_t i,const Eigen::Vector3d&p)const{return manager->getEffectiveRisk(i,p);}
#endif
 void snapshot(int phase){
  put(phase);put(revision());put(fingerprint());put(dem().generation);put(dem().valid);
  put(sdf().revision());put(sdf().isInitialized());put(sdf().hasData());put(sdf().numActiveObstacles());
  vec(sdf().origin());vec(sdf().voxelSizes());for(int j=0;j<3;++j)put(sdf().shape()[j]);
  put(zones().size());for(const auto&z:zones()){vec(z.center);put(z.reach);put(z.peak);}
  for(int x=-12;x<=12;++x)for(int y=-12;y<=12;++y)for(double z:{-.3,.2,1.,2.5,4.,7.,15.}) {
   Eigen::Vector3d p(x*.9,y*.9,z);float h=0,gx=0,gy=0,d=0;Eigen::Vector3d g=Eigen::Vector3d::Zero();
   put(dem().getElevation(p.x(),p.y()));put(dem().getElevationAndGrad(p.x(),p.y(),&h,&gx,&gy));put(h);put(gx);put(gy);
   put(sdf().getDistance(p));put(sdf().getDynamicDistance(p));put(sdf().getDistanceAndGradient(p,&d,&g));put(d);vec(g);
   for(size_t i=0;i<=zones().size();++i)put(risk(i,p));
  }
 }
};
int main(int argc,char**argv){
 if(argc!=2)return 2;out.open(argv[1],std::ios::binary);rclcpp::init(argc,argv);
 {Engine e;e.snapshot(0);put(e.sphere({0,0,99},.5));put(e.box({3,-2,99},{2,1,3}));e.snapshot(1);
  e.terrain(map(2));e.snapshot(2);put(e.sphere({-4,2,-99},1.));put(e.box({5,3,-99},{4,2,1}));e.snapshot(3);
  auto m=map(3);for(size_t j=0;j<m->data[0].data.size();++j)m->data[0].data[j]+=float(j%20)*.02f;e.terrain(m);e.snapshot(4);
  put(e.zones({{{.5,.5,2},10,.8},{{-4,2,1},5,.6}}));e.snapshot(5);
  e.terrain(map(1,.7));e.snapshot(6);put(e.box({1,2,5},{2,2,2}));e.snapshot(7);
  auto bad=map(10,.5);bad->layers={"missing"};e.terrain(bad);e.snapshot(8);
  e.terrain(std::make_shared<grid_map_msgs::msg::GridMap>());e.snapshot(9);
  put(e.sphere({0,0,0},.6));e.clear();e.terrain(map(4,1.));e.snapshot(10);
 }
 out.close();rclcpp::shutdown();std::cout<<"11 lifecycle phases, 48125 query points\n";
}

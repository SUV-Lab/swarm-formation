set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_finish_modularization_20261011/install/setup.bash
export ROS_DOMAIN_ID=94
python3 /tmp/mmp_finish_modularization_20261011/run_installed_runtime.py /tmp/mmp_finish_modularization_20261011/runtime

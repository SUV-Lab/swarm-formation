#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
cd /ws
export CMAKE_BUILD_PARALLEL_LEVEL=3
colcon --log-base /tmp/mmp_finish_modularization_20261011/colcon_log build \
  --base-paths /ws/src/mmp_vehicle_dynamics /ws/src/mmp_path_planning/src/path_optimizer /ws/src/mmp_path_planning/src/path_manager \
  --packages-select mmp_vehicle_dynamics path_optimizer path_manager \
  --build-base /tmp/mmp_finish_modularization_20261011/build \
  --install-base /tmp/mmp_finish_modularization_20261011/install \
  --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON

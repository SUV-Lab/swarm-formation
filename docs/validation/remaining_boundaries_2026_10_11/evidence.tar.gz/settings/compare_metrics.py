#!/usr/bin/env python3
"""Compare stable printed flight metrics in two flat chain-variant log dirs.

No directory recursion. Timing, ROS stamps and assertion prose are excluded;
solver envelope, terrain/cap records and numeric harness output are compared
as multisets to allow worker logging interleaving. Exact printed agreement is
not a coefficient-level proof: retain separate exact-trajectory tests too.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

FORBIDDEN = {'reports', 'experiments'}
ROS_ANY = re.compile(r'\[(?:INFO|WARN|ERROR|DEBUG|FATAL)\] \[[^]]+\] \[[^]]+\]: ?')
ROS = re.compile('^' + ROS_ANY.pattern)
TAGS = ('[TERRAIN-PROFILE]', '[ALT-CAP]', '[TERRAIN]')
NUMERIC = re.compile(r'\d')


def safe(path):
    path = Path(path).resolve()
    if FORBIDDEN.intersection(path.parts):
        raise ValueError('forbidden path component: ' + str(path))
    return path


def records(path):
    values = []
    for line in path.read_text(errors='replace').splitlines():
        line = line.strip()
        if ROS.match(line):
            line = ROS.sub('', line)
            if '[DYNAMICS] envelope(' in line:
                values.append(line[line.index('[DYNAMICS]'):])
            else:
                for tag in TAGS:
                    if tag in line:
                        values.append(line[line.index(tag):])
                        break
        elif line and NUMERIC.search(line) and not line.startswith(
                ('[OK]', '[FAIL]', 'PASS:', 'FAIL:', '[RUN]', '[OK ]')):
            # Free-form harness numeric observations, excluding backtraces.
            if not re.search(r'0x[0-9a-fA-F]+|time\(ms\)|elapsed|wall.time', line):
                # stdout and the ROS stderr stream may interleave mid-line.
                # Strip ROS metadata wherever embedded, preserving metric text.
                values.append(ROS_ANY.sub('', line))
    return Counter(values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before', type=safe)
    parser.add_argument('after', type=safe)
    parser.add_argument('--expect-common', type=int)
    parser.add_argument('--output', type=safe)
    args = parser.parse_args()
    before = {p.name: p for p in args.before.glob('*.log') if p.is_file()}
    after = {p.name: p for p in args.after.glob('*.log') if p.is_file()}
    common = sorted(before.keys() & after.keys())
    results = {}
    for name in common:
        left, right = records(before[name]), records(after[name])
        results[name] = {
            'equal': left == right,
            'records_before': sum(left.values()),
            'records_after': sum(right.values()),
            'removed': list((left - right).elements()),
            'added': list((right - left).elements()),
        }
    result = {
        'before': str(args.before), 'after': str(args.after),
        'compared': len(common),
        'exact_printed_match': sum(v['equal'] for v in results.values()),
        'only_before': sorted(before.keys() - after.keys()),
        'only_after': sorted(after.keys() - before.keys()),
        'results': results,
    }
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'results'}, indent=2))
    for name, r in results.items():
        if not r['equal']:
            print(name, 'removed', len(r['removed']), 'added', len(r['added']))
            for kind in ('removed', 'added'):
                for line in r[kind][:4]:
                    print(' ', kind, line)
    valid_count = args.expect_common is None or len(common) == args.expect_common
    return 0 if valid_count and all(v['equal'] for v in results.values()) else 1

if __name__ == '__main__':
    raise SystemExit(main())

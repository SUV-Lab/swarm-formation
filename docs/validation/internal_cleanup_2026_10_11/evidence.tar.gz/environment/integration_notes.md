# Terrain-risk computation extraction

Apply `pm_changes.patch` (against planner b14dd9d; does not touch optimizer factory) and copy four new files from the frozen overlay manifest. Integrate CMake according to `cmake_integration.txt`. No live source was edited by this agent.

- `TerrainData` is moved verbatim to its own public, ROS-free header. Its existing mirrored bilinear terrain sampler, NaN/water behavior, analytic gradient and thread-local memo identity remain unchanged.
- `terrain_risk::buildMask(zone, terrain, settings[, std::move(old_mask)])` returns an owned polar horizon and source-height diagnostics. It borrows the same terrain synchronously. The optional owned mask allows rebuild to reuse its sample-vector capacity.
- `shadowCeiling`, `groundedZ`, `visibilityValue`, `visibility` borrow the existing mask/terrain and explicit settings. They use the old arithmetic and ordering, with no new cache, snapshot or callable dispatch in the hot loop.
- `PathManager` keeps its vector, resets it in exactly the old place, moves one slot through the builder, and handles logs/publication. Warning and ready records remain in the same order; the warning is emitted after that zone's arithmetic returns instead of before its loop. No environment generations, SDF, obstacle/RNG, execution storage or ROS callback behavior is moved.
- Existing parameter defaults remain in the ROS manager; Settings is a projection, with no default-value authority of its own.
- Public calculation clients must supply the same validated geometry/settings as the manager, finite query points and unmodified builder-produced masks. This is an extraction, not a new malformed-input policy.

The final helper test passes 34/34 without any ROS include/link settings. The original installed manager fixture owns 8 cases, 40 masks and 203520 queries (1520610 binary scalar records). Recompile the same source against the final integrated manager with a final access-only header, then compare all result bytes. Root coordinates build and runtime timing windows.

This removes about 407 physical lines from PathManager's header/source while giving the terrain sampler and terrain-risk computation usable public functions. Full environment ownership/SDF-versus-execution separation remains outside this bounded change.

## Final integrated verification

Final installed PM+calculations fixture matches original on all 12053232 bytes (8 terrain/settings cases, 40 masks, 203520 queries, 1520610 scalar records). No tolerance/normalization was applied. Both hashes are `50aec6ca0e14e6235ca3cbba74ea3bf1156024130c83f86b2b4fdbafa81f3d03`.

Quiet alternating five-run comparisons after one warmup each: whole-process median wall 0.135456205 s -> 0.136463305 s (+0.74%, ~1 ms), median user CPU 0.029034 s -> 0.028036 s, median peak RSS 22964 KiB -> 22708 KiB. All twelve outputs matched and both binaries stayed unchanged. Scope includes PM/ROS construction, eight field builds, queries, serialization and teardown; this is evidence of no material regression in these cases, not an isolated algorithm timing or universal guarantee.

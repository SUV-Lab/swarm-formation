#!/usr/bin/env python3
"""Whole fixture comparison; run only in the coordinator's quiet window."""
from pathlib import Path
import hashlib,json,os,platform,statistics,subprocess,time
base=Path('/tmp/mmp_internal_cleanup_20261011/environment')
out=base/'fixture_timing';out.mkdir(exist_ok=True)
executables={label:base/f'{label}_fixture/build/terrain_risk_fixture' for label in ('baseline','after')}
expected='50aec6ca0e14e6235ca3cbba74ea3bf1156024130c83f86b2b4fdbafa81f3d03'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
binaries={k:sha(v) for k,v in executables.items()}
records=[]
def run(label,index,warmup=False):
 work=out/f'{label}_{"warmup" if warmup else index}';work.mkdir(exist_ok=True)
 env=dict(os.environ,ROS_DOMAIN_ID='91');data=work/'result.bin'
 with (work/'run.log').open('wb') as log:
  start=time.perf_counter()
  proc=subprocess.Popen([str(executables[label]),str(data)],stdout=log,stderr=subprocess.STDOUT,cwd=work,env=env)
  _,status,usage=os.wait4(proc.pid,0)
  elapsed=time.perf_counter()-start
  proc.returncode=os.waitstatus_to_exitcode(status)
 digest=sha(data) if data.exists() else None
 row={'label':label,'index':index,'warmup':warmup,'exit_code':proc.returncode,'wall_s':elapsed,'user_cpu_s':usage.ru_utime,'system_cpu_s':usage.ru_stime,'max_rss_kib':usage.ru_maxrss,'output_bytes':data.stat().st_size if data.exists() else None,'output_sha256':digest,'exact_original':digest==expected}
 records.append(row);(work/'measurement.json').write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if proc.returncode or digest!=expected:raise RuntimeError('fixture refused or numerical difference')
 data.unlink() # Original and final canonical result files are already retained.
run('baseline',0,True);run('after',0,True)
for i in range(1,6):
 for label in (('baseline','after') if i%2 else ('after','baseline')):run(label,i)
summary={}
for label in executables:
 rows=[r for r in records if r['label']==label and not r['warmup']]
 summary[label]={'runs':len(rows)}
 for name in ('wall_s','user_cpu_s','system_cpu_s','max_rss_kib'):
  values=[r[name] for r in rows];summary[label][name]={'median':statistics.median(values),'min':min(values),'max':max(values)}
summary['after_over_baseline']={name:summary['after'][name]['median']/summary['baseline'][name]['median'] for name in ('wall_s','user_cpu_s','max_rss_kib')}
result={'scope':'Whole subprocess: ROS/PM construction, eight synthetic terrain cases, forty masks, 203520 risk queries and binary serialization; not isolated hot-loop timing or full mission benchmarking.','ordering':'One warmup each excluded; five each paired with alternating first process.','host':platform.node(),'platform':platform.platform(),'binaries_sha256':binaries,'binaries_unchanged':{k:sha(executables[k])==v for k,v in binaries.items()},'expected_output_sha256':expected,'all_results_exact':all(r['exact_original'] and r['exit_code']==0 for r in records),'summary':summary,'records':records}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary,indent=2))

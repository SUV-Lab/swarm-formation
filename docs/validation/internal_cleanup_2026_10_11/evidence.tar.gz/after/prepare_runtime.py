from pathlib import Path
import os,json,hashlib,shutil,datetime
BASE=Path('/tmp/mmp_internal_cleanup_20261011/after')
OLD=BASE.parent/'baseline'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def capture():
 entries={key:v['path'] for key,v in json.loads((OLD/'identity_comparison.json').read_text())['checks'].items()}
 # Entire explicit allowed source roots, with denied directory names pruned before descent.
 spec=json.loads((OLD/'stage6_sources_expected.json').read_text())
 for relative in spec['allowed_roots']:
  p=Path('/ws')/relative
  assert not {'reports','experiments'}&set(p.parts)
  if p.is_file():entries['source:'+relative]=str(p);continue
  if not p.exists():continue
  for root,dirs,names in os.walk(p):
   dirs[:]=[n for n in dirs if n not in {'reports','experiments','.git','__pycache__'}]
   for name in names:
    child=Path(root)/name
    if child.is_file():entries['source:'+str(child.relative_to('/ws'))]=str(child)
 extra=[
 '/ws/install/path_manager/lib/path_manager/path_manager_node',
 '/ws/install/path_manager/include/path_manager/path_manager.h',
 '/ws/install/path_manager/include/path_manager/segment_chain_planner.h',
 '/ws/install/path_manager/include/path_manager/optimizer_worker_profile.h',
 '/ws/install/path_manager/include/path_manager/terrain_data.h',
 '/ws/install/path_manager/include/path_manager/terrain_risk.h',
 '/ws/install/path_optimizer/include/path_optimizer/ros_parameter_view.h',
 '/ws/install/path_optimizer/include/path_optimizer/poly_traj_optimizer.h',
 '/ws/src/mmp_path_planning/src/path_manager/src/terrain_risk.cpp',
 '/ws/src/mmp_path_planning/src/path_manager/test/terrain_risk_calculation_test.cpp',
 '/ws/src/mmp_path_planning/src/path_optimizer/test/optimizer_configuration_test.cpp',
 '/ws/src/mmp_path_planning/src/path_manager/CMakeLists.txt',
 '/ws/src/mmp_path_planning/src/path_optimizer/CMakeLists.txt',
 '/ws/src/mmp_path_planning/src/path_manager/test/chain_experiment_test.cpp',
 '/ws/src/mmp_path_planning/src/path_manager/test/route_slice_solver_test.cpp']
 for name in extra:entries['explicit:'+name]=name
 for package in ['path_manager','path_optimizer','mmp_vehicle_dynamics']:
  directory=Path('/ws/install')/package/'share'/package/'cmake'
  for root,dirs,names in os.walk(directory):
   dirs[:]=[n for n in dirs if n not in {'reports','experiments','.git','__pycache__'}]
   for name in names:
    child=Path(root)/name
    if child.is_file():entries['installed_cmake:'+str(child)]=str(child)
 result={}
 for key,name in sorted(entries.items()):
  p=Path(name);assert not {'reports','experiments'}&set(p.parts)
  assert p.is_file(),str(p)
  result[key]={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
 return {'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':result,'count':len(result),'pruned_directories':['reports','experiments','.git','__pycache__'],'explicit_source_roots':spec['allowed_roots']}
if __name__=='__main__':
 before=capture();(BASE/'inputs_before.json').write_text(json.dumps(before,indent=2)+'\n')
 project=BASE/'project';project.mkdir(exist_ok=False)
 for n in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']:shutil.copy2(OLD/'project'/n,project/n)
 (BASE/'measurement_source_manifest.json').write_text(json.dumps({n:sha(project/n) for n in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']},indent=2)+'\n')
 print('FINAL_SNAPSHOT_COUNT',before['count'],flush=True)

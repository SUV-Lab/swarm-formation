from pathlib import Path
import os,sys,json,time,hashlib,subprocess,signal,statistics,datetime
BASE=Path(sys.argv[1]).resolve()
BINARY=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else BASE/'build/r2_external_consumer'
assert os.environ.get('ROS_DOMAIN_ID')=='84'
ENV=dict(os.environ)
for k in ['MMP_VALUE_INPUT','MMP_VISUALIZATION_OFF','MMP_REUSE_CONNECTED_COMPLETE']:ENV.pop(k,None)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def stop(p):
 if p is None or p.poll() is not None:return
 os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=15)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
def load():return {'loadavg':list(os.getloadavg()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
ref=Path('/tmp/mmp_next_modularization_20261010/stage6/consumer/r2/result.json')
reference=json.loads(ref.read_text())
summary={'scope':{'plan_wall_cpu':'steady_clock/getrusage immediately around exactly one MissionPlanner::plan(input); fresh planner process every run, excludes ROS node startup, Python terrain loading, terrain installation and result serialization','memory':'current client RSS immediately before/after plan and entire client process peak RSS from wait4. Includes retained terrain/planner initialization; Python terrain service memory excluded; peak before/after getrusage is lifetime high water, not interval allocation peak','process_wall':'entire client lifecycle including terrain service request, excludes Python loader startup/teardown outside the client; main comparison uses plan wall/CPU','warmup':'run_00 excluded; five measured fresh processes run_01..05, serial','terrain':'new actual Python loader world=none per run; same R2 full_map request and 30m raster','visualization':'existing default attached; no RViz; no field normalization in owned result comparison'},'reference':str(ref),'reference_sha256':sha(ref),'binary':str(BINARY),'binary_sha256':sha(BINARY),'platform':{'uname':list(os.uname()),'cpu_affinity':sorted(os.sched_getaffinity(0)),'thread_environment':{k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','ROS_DOMAIN_ID')}},'runs':[]}
terrain=None;client=None
try:
 for index in range(6):
  folder=BASE/('run_%02d'%index);folder.mkdir(exist_ok=False)
  result=folder/'result.json';entry={'index':index,'warmup':index==0,'before':load()}
  with (folder/'terrain.log').open('w') as tl,(folder/'client.log').open('w') as cl:
   terrain=subprocess.Popen(['ros2','run','mmp_terrain','terrain_publisher','--ros-args','-p','world:=none'],cwd=folder,env=ENV,stdout=tl,stderr=subprocess.STDOUT,start_new_session=True)
   command=[str(BINARY),'/ws/install/path_manager/share/path_manager/config/optimizer_params.yaml','/ws/install/path_manager/share/path_manager/config/drone_hardware.yaml','/ws/src/mmp_terrain/data/scenarios/missions/r2_ridge_crossing.yaml',str(result)]
   started=time.monotonic();client=subprocess.Popen(command,cwd=folder,env=ENV,stdout=cl,stderr=subprocess.STDOUT,start_new_session=True)
   while True:
    pid,status,usage=os.wait4(client.pid,os.WNOHANG)
    if pid:break
    if time.monotonic()-started>600:raise TimeoutError('R2 client exceeded 600s')
    time.sleep(.05)
   client.returncode=os.waitstatus_to_exitcode(status)
   entry.update({'command':command,'exit_code':client.returncode,'client_process_wall_s':time.monotonic()-started,'client_process_user_cpu_s':usage.ru_utime,'client_process_system_cpu_s':usage.ru_stime,'client_process_peak_rss_kb':usage.ru_maxrss})
   if client.returncode:raise RuntimeError('client failed')
   current=json.loads(result.read_text());entry['field_exact']={k:v==current.get(k) for k,v in reference.items()};entry['keys_equal']=set(reference)==set(current);entry['numeric_exact']=entry['keys_equal'] and all(entry['field_exact'].values());entry['result_sha256']=sha(result)
   entry.update(json.loads(Path(str(result)+'.metrics.json').read_text()))
   if not entry['numeric_exact']:raise RuntimeError('result differs from original stage6')
   stop(terrain);terrain=None
  entry['after']=load();summary['runs'].append(entry);(folder/'summary.json').write_text(json.dumps(entry,indent=2)+'\n')
  print('RUN',index,'warmup' if index==0 else 'measured','plan',entry['plan_wall_s'],'cpu',entry['plan_user_cpu_s']+entry['plan_system_cpu_s'],'rssKB',entry['client_process_peak_rss_kb'],'exact',entry['numeric_exact'],flush=True)
 for key in ['plan_wall_s','plan_user_cpu_s','plan_system_cpu_s','client_process_wall_s','client_process_peak_rss_kb','resident_before_plan_kb','resident_after_plan_kb','process_peak_rss_before_plan_kb','process_peak_rss_after_plan_kb']:
  values=[v[key] for v in summary['runs'][1:]];summary.setdefault('statistics',{})[key]={'median':statistics.median(values),'min':min(values),'max':max(values),'mean':statistics.mean(values),'stdev':statistics.stdev(values)}
 summary['pass']=len(summary['runs'])==6 and all(x['numeric_exact'] and x['exit_code']==0 for x in summary['runs'])
except Exception as e:summary['error']=repr(e);summary['pass']=False
finally:
 stop(client);stop(terrain)
 (BASE/'benchmark_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('BENCHMARK_PASS',summary['pass'],flush=True)
raise SystemExit(0 if summary['pass'] else 1)

from pathlib import Path
import json,hashlib,shutil
B=Path('/tmp/mmp_internal_cleanup_20261011/baseline')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
manifest=json.loads((B/'identity_comparison.json').read_text())
changes=[]
for k,v in manifest['checks'].items():
 p=Path(v['path']);assert not {'reports','experiments'}&set(p.parts)
 if sha(p)!=v['sha256']:changes.append(str(p))
 if k.startswith('full_source:'):
  target=B/'source_snapshot'/p.relative_to('/ws');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
compile=json.loads((B/'build/compile_commands.json').read_text())
assert all('/ws/src/' not in v['command'] for v in compile)
result={'source_install_changes':changes,'source_install_unchanged':not changes,'installed_only_compile':True,'measured_binary_sha256':sha(B/'build/r2_external_consumer')}
(B/'freeze.json').write_text(json.dumps(result,indent=2)+'\n')
assert not changes
# Preserve the measurement binary itself: later alternating A/B needs no original relink.
shutil.copy2(B/'build/r2_external_consumer',B/'preserved/r2_measurement_consumer')
print(json.dumps(result,indent=2))

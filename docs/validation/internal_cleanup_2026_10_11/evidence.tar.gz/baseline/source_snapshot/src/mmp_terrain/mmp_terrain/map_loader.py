"""ROS-independent terrain loading with the existing MMP numerical contract.

``load_map(MapLoadInput(...))`` returns an owned float32 grid in frame units,
its exact loaded bounds, and the optional coherent mission/frame snapshot.
The function reads rasters and mission files; it creates no node, parameters,
messages or publishers and reads no process environment. Callers supply the
already effective settings. ``world='none'`` is an explicit empty result.

Native raster order is retained (row zero north, column zero west). Grid rows
span frame X and columns span frame Y; all X/Y/Z grid units are 100 metres.
Mission Z remains metres AGL, as defined in mission.py. No flight-command
policy is imposed here: startup historically resolves geometry only; a
service adapter calls mission.command_fields BEFORE requesting raster data.

An optional synchronous ``diagnostic(level, message)`` receives unchanged
legacy messages as they occur, including messages before a refused load.
Exceptions propagate to the caller. Inputs and any supplied mission snapshot
must stay stable for the call; no dataset/file handle is retained in results.
"""

from dataclasses import dataclass, replace
from collections import namedtuple
from typing import Callable, Optional, Tuple
import math
import os

import numpy as np
import rasterio

from .frame import (TARGET_CELL_SIZE_M, en_to_frame, frame_bbox_to_en,
                    read_frame_snapshot)

DEFAULT_CORRIDOR_HALFWIDTH_U = 200.0
DEFAULT_CORRIDOR_RES_M = 0.0
CORRIDOR_CELL_BUDGET = 16_000_000
CORRIDOR_RES_LADDER = (30, 40, 50, 60, 80, 100, 120, 160, 200, 250)
Diagnostic = Optional[Callable[[str, str], None]]


@dataclass(frozen=True)
class MapLoadInput:
    """Effective inputs, without ROS parameter or environment semantics.

    ``data_dir`` holds world rasters. ``full_map_override`` is the explicit
    staging anchor, paired with a nondefault ``dem_path`` under the existing
    pin_pair provenance contract. Omitted ``dem_path`` selects the shipped DEM
    beneath data_dir. ``vrt_resolution`` is the explicit warp-grid override;
    otherwise the pinned anchor's tag retains precedence over automatic GDAL
    selection. Numeric zero resolution selects the existing budget ladder.
    Live coverage tuples are copied so later topic-list edits cannot change
    an in-progress request. Empty YAML coverage still falls back to these.
    """
    world: str
    data_dir: str
    mission_path: str = ''
    halfwidth_u: float = DEFAULT_CORRIDOR_HALFWIDTH_U
    resolution_m: float = DEFAULT_CORRIDOR_RES_M
    dem_path: Optional[str] = None
    full_map_override: Optional[str] = None
    vrt_resolution: Optional[str] = None
    live_zones: Tuple[Tuple[float, float, float], ...] = ()
    live_obstacles: Tuple[Tuple[float, float, float, float], ...] = ()
    cell_budget: int = CORRIDOR_CELL_BUDGET
    resolution_ladder: Tuple[float, ...] = CORRIDOR_RES_LADDER

    def __post_init__(self):
        object.__setattr__(self, 'live_zones', tuple(tuple(z) for z in self.live_zones))
        object.__setattr__(self, 'live_obstacles', tuple(tuple(o) for o in self.live_obstacles))
        object.__setattr__(self, 'resolution_ladder', tuple(self.resolution_ladder))

    @property
    def effective_dem_path(self):
        return (os.path.join(self.data_dir, 'full_map_dem30.tif')
                if self.dem_path is None else self.dem_path)


# Frame, mission, tags and warnings are loaded from one pinned snapshot.
# It owns ordinary Python values and CRS metadata, never open raster handles.
ResolvedMapMission = namedtuple('ResolvedMapMission', [
    'anchor_path', 'dem_path', 'frame', 'mission', 'mission_sha',
    'frame_digest', 'anchor_tags', 'warnings'])


@dataclass(frozen=True)
class MapLoadResult:
    """Owned normalized terrain and its actual geometry, not requested bounds.

    ``elevation_u`` is a newly allocated float32 ndarray, or None for clear.
    The array is writable by its owner; it does not alias raster buffers or
    caller input arrays. No raw elevation duplicate is retained. The optional
    mission snapshot is self-contained; a supplied snapshot is reused intact.
    """
    elevation_u: Optional[np.ndarray]
    resolution_m: float
    min_bound_u: Tuple[float, float]
    max_bound_u: Tuple[float, float]
    mission: Optional[ResolvedMapMission] = None
    source_paths: Tuple[str, ...] = ()

    @property
    def resolution_u(self):
        return float(self.resolution_m / TARGET_CELL_SIZE_M)

    @property
    def length_x_u(self):
        return 0.0 if self.elevation_u is None else float(self.elevation_u.shape[0] * self.resolution_u)

    @property
    def length_y_u(self):
        return 0.0 if self.elevation_u is None else float(self.elevation_u.shape[1] * self.resolution_u)

    @property
    def center_u(self):
        return (float(self.min_bound_u[0]) + self.length_x_u / 2.0,
                float(self.min_bound_u[1]) + self.length_y_u / 2.0)

    @property
    def load_metadata(self):
        return self.resolution_m, self.min_bound_u, self.max_bound_u


def _emit(diagnostic, level, message):
    if diagnostic is not None:
        diagnostic(level, message)


def resolve_map_mission(request: MapLoadInput, diagnostic: Diagnostic = None):
    """Pin the anchor+DEM pair once and resolve the exact mission bytes.

    The adapter supplies its MMP_FULL_MAP override explicitly. Unset =
    exactly the shipped path. The pair is pinned to ONE asset version — resolving the two
    consumer symlinks independently could straddle an installer's
    assets/current swap (v1 anchor + v2 DEM, measured).
    """
    from .asset_paths import pin_pair
    mission_path = request.mission_path
    dem_path = request.effective_dem_path
    full_map_path = (os.path.join(request.data_dir, 'full_map.tif')
                     if request.full_map_override is None else request.full_map_override)
    # Staging is ALL-or-nothing across the pair: overriding only the
    # anchor while the DEM silently stays on the shipped default (or the
    # reverse) is exactly the half-configuration that once let a bench
    # "pass" against the wrong elevation. Both must be stated.
    anchor_overridden = bool(request.full_map_override)
    dem_overridden = dem_path != os.path.join(request.data_dir,
                                              'full_map_dem30.tif')
    if anchor_overridden != dem_overridden:
        raise ValueError(
            'staging override is half-configured: '
            f'anchor {"overridden" if anchor_overridden else "default"} '
            f'but DEM {"overridden" if dem_overridden else "default"} — '
            'set BOTH (MMP_FULL_MAP + MMP_DEM/corridor_dem) or neither.')
    full_map_path, dem_path = pin_pair(
        full_map_path, dem_path, require_build=anchor_overridden)

    # Canonical frame anchor: the full-map raster's own georeference, so
    # the crop stays a sub-rectangle of the full-map frame. The
    # [TERRAIN-FRAME] convention and its mirrored axes live in frame.py.
    # Spec, digest AND tags come from ONE open — separate load_frame /
    # frame_digest / tags() calls could straddle an in-place file replace
    # and pair frame A coordinates with frame B identity (or warp knobs).
    frame, fdigest, anchor_tags = read_frame_snapshot(full_map_path)

    # lon/lat is the authored truth; the frame fields are a cache derived
    # for ONE map. mmp_terrain.mission owns the whole resolution — derive
    # when only lon/lat is authored, compare when both are present, refuse
    # frame numbers that have no authored truth to check them against.
    # A map swap without a re-derive would otherwise fly the corridor
    # somewhere else entirely, in silence. The file is read ONCE: parse,
    # sha and (via the caller) the corridor bbox all come from the same
    # bytes, and warnings are collected so the response can carry them to
    # the operator, not just this node's log.
    from .mission import load_bytes as _load_mission_bytes
    with open(mission_path, 'rb') as fp:
        data = fp.read()
    warnings = []

    def _warn(msg):
        warnings.append(msg)
        _emit(diagnostic, 'warn', msg)

    mission, mission_sha = _load_mission_bytes(
        data, frame.crs, frame.anchor, warn=_warn, name=mission_path)
    if mission.derived_keys:
        _emit(diagnostic, 'info',
            f'[mission] derived frame coordinates from lon/lat for: '
            f'{", ".join(mission.derived_keys)}')
    return ResolvedMapMission(full_map_path, dem_path, frame, mission,
                          mission_sha, fdigest, anchor_tags, warnings)


def _load_corridor(request, ctx, diagnostic):
    from rasterio.enums import Resampling
    from rasterio.vrt import WarpedVRT
    from rasterio.windows import from_bounds

    mission_path, halfwidth_u, res_m = (request.mission_path,
                                       request.halfwidth_u, request.resolution_m)
    if ctx is None:
        ctx = resolve_map_mission(request, diagnostic)
    full_map_path, dem_path = ctx.anchor_path, ctx.dem_path
    frame = ctx.frame
    anchor = frame.anchor
    Lx, Ly = anchor.Lx, anchor.Ly
    mission = ctx.mission
    m = mission.raw
    pts = mission.points_xy()
    # [CORRIDOR-COVER] The crop must enclose more than the mission line.
    # A risk zone whose risk footprint falls outside the crop has its
    # terrain-based viewshed mask clipped at the boundary (shadow ceiling
    # reads -inf where there is no DEM), AND the trajectory cannot route
    # around it because outside the crop there is no terrain to fly over —
    # so it gets pinned against the crop edge (observed: zone at x+180 past
    # a crop ending 66 u short, trajectory grazing the rim at moat 0.084).
    # Enclose each zone to 1.05*reach (the viewshed's own max_range) and
    # each obstacle to its half-extent + margin. Obstacles are analytic and
    # avoided even off-grid, but the detour still needs the room. The
    # per-element halfwidth berth is added by the min/max +- halfwidth below,
    # so this only has to seed the union with the elements themselves.
    # Zones/obstacles come from the mission yaml if present (harness /
    # explicit authoring), else from the live topics mirrored above (the
    # RViz flow: zones loaded via the panel, then Run). An obstacle margin
    # of 0 in the topic path falls back to the dyn-obstacle berth below.
    yaml_zones = m.get('risk_zones', []) or []
    yaml_obs = m.get('obstacles', []) or []
    obs_margin = 0.10  # frame units (~10 m) detour berth for topic obstacles
    nz = no = 0; src = 'yaml'
    if yaml_zones:
        zone_iter = ((z['center'][0], z['center'][1], float(z.get('reach', 0.0)))
                     for z in yaml_zones)
    else:
        zone_iter = iter(request.live_zones); src = 'live topics'
    for cx, cy, reach in zone_iter:
        r = reach * 1.05
        if r > 0.0:
            pts.append([cx - r, cy - r]); pts.append([cx + r, cy + r]); nz += 1
    if yaml_obs:
        for o in yaml_obs:
            c = o['center']
            hx = float(o.get('half_x', 0.0)) + float(o.get('margin', 0.0))
            hy = float(o.get('half_y', 0.0)) + float(o.get('margin', 0.0))
            if hx > 0.0 or hy > 0.0:
                pts.append([c[0] - hx, c[1] - hy]); pts.append([c[0] + hx, c[1] + hy]); no += 1
    else:
        for cx, cy, hx0, hy0 in request.live_obstacles:
            hx = hx0 + obs_margin; hy = hy0 + obs_margin
            pts.append([cx - hx, cy - hy]); pts.append([cx + hx, cy + hy]); no += 1
    if nz or no:
        _emit(diagnostic, 'info',
            f'[corridor] bbox union includes {nz} risk zone(s) + {no} '
            f'obstacle(s) beyond the mission line (source: {src})')
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]

    dem_src = dem_path if os.path.exists(dem_path) else full_map_path
    if dem_src != dem_path:
        # Known limit: this fallback reopens the anchor for PIXEL data,
        # so an in-place overwrite after the ctx snapshot could serve
        # frame-A identity with frame-B elevations (geometry stays
        # frame-A-placed via the reopened raster's own transform). The
        # versioned install path never hits this — same-file overwrites
        # of live rasters are outside the deployment contract.
        _emit(diagnostic, 'warn', f'[corridor] fine DEM missing ({dem_path}); '
                               f'falling back to full_map.tif 250 m elevation')
    with rasterio.open(dem_src) as src:
        # Exclude nodata from the bilinear resample kernel. Without this, an
        # UNDECLARED large-magnitude sentinel (exactly the class the
        # `< -9000` guard in build_grid_map catches) gets blended with real
        # elevation during the CRS warp + out_shape resize into plausible
        # POSITIVE junk that passes both the <-9000 and <=0 guards (which
        # run AFTER the resample). Declare the source nodata if present,
        # else the project's <-9000 sentinel convention, and emit NaN so
        # build_grid_map masks it as water. (Shipped DEMs are nodata=None
        # with min ~ -146, so -9999 excludes nothing there — behaviour is
        # unchanged on current maps; the guard only bites future sentinels.)
        src_nodata = src.nodata if src.nodata is not None else -9999.0
        # The frame's CRS comes from the anchor raster — naming one here
        # would silently reproject a corridor into the wrong grid the
        # day the map moves to another projection.
        #
        # MMP_DEM_VRT_RES pins the warped grid's resolution (metres).
        # Left alone, WarpedVRT derives it from the SOURCE'S WHOLE
        # EXTENT, so the same corridor pays more warp work under a
        # larger map: the east-asia DEM's extent yields a 26.2 m grid
        # where Korea's yields 28.2 m — +16% pixels for identical
        # ground (measured on mission r5). Pinned, the warp cost is a
        # property of the corridor, not of the map size. Unset =
        # exactly the old behaviour; the shipped Korea map runs
        # untouched.
        vrt_kw = {}
        res_env = request.vrt_resolution
        if not res_env:
            # The map carries its own runtime knowledge: an east-asia
            # anchor is stamped with MMP_DEM_VRT_RES by its build recipe,
            # so nobody has to remember an environment variable. The
            # shipped Korea anchor has no tag and keeps the automatic
            # grid exactly as before. An explicit env still wins. Read
            # from ctx (same open as spec/digest) — a reopen here could
            # straddle an in-place replace and warp frame A with map B's
            # pinned resolution.
            res_env = ctx.anchor_tags.get('MMP_DEM_VRT_RES')
        if res_env:
            from rasterio.warp import calculate_default_transform
            r = float(res_env)
            vtf, vw, vh = calculate_default_transform(
                src.crs, frame.crs, src.width, src.height,
                *src.bounds, resolution=(r, r))
            vrt_kw = {'transform': vtf, 'width': vw, 'height': vh}
        with WarpedVRT(src, crs=frame.crs,
                       src_nodata=src_nodata, nodata=float('nan'),
                       resampling=Resampling.bilinear, **vrt_kw) as vrt:
            # The warped fine DEM is slightly SMALLER than the full-map frame
            # (~150 m slivers at the E/S edges). Clamp the corridor to the
            # DATA bounds, not just the frame bounds: rasterio silently
            # clips an overflowing window to the dataset and then
            # stretches the clipped data across out_shape — a frame-edge
            # mission distorted the WHOLE crop by up to ~5 cells.
            vb = vrt.bounds
            # Mirrored axes: the data's SOUTH-EAST corner (bottom, right)
            # is the frame minimum, its NORTH-WEST corner the maximum.
            dx0_d, dy0_d = en_to_frame(vb.right, vb.bottom, anchor)
            dx1_d, dy1_d = en_to_frame(vb.left, vb.top, anchor)
            dx0 = max(0.0, dx0_d)
            dx1 = min(Lx, dx1_d)
            dy0 = max(0.0, dy0_d)
            dy1 = min(Ly, dy1_d)
            wx0 = max(dx0, min(xs) - halfwidth_u)
            wx1 = min(dx1, max(xs) + halfwidth_u)
            wy0 = max(dy0, min(ys) - halfwidth_u)
            wy1 = min(dy1, max(ys) + halfwidth_u)
            if wx1 - wx0 < 1.0 or wy1 - wy0 < 1.0:
                raise ValueError(
                    f'corridor degenerate: mission outside full-map frame? '
                    f'bbox u=({wx0:.0f},{wy0:.0f})..({wx1:.0f},{wy1:.0f})')

            # Finest resolution whose cell count fits the budget.
            span_x_m = (wx1 - wx0) * TARGET_CELL_SIZE_M
            span_y_m = (wy1 - wy0) * TARGET_CELL_SIZE_M
            if res_m <= 0.0:
                res_m = next(
                    (r for r in request.resolution_ladder
                     if (span_x_m / r) * (span_y_m / r) <= request.cell_budget),
                    request.resolution_ladder[-1])
            # SNAP the bbox to an integer cell grid, shrinking (never
            # growing past the data bounds). Without this the effective
            # pitch is span/round(span/res) != res: the published
            # resolution then disagrees with the sampled grid and the
            # misregistration grows to res/2 at the far corner.
            rows = int(span_x_m // res_m)
            cols = int(span_y_m // res_m)
            if rows < 8 or cols < 8:
                raise ValueError(
                    f'corridor too small for res={res_m}m '
                    f'({rows}x{cols} cells) — lower corridor_res_m')
            # The auto-ladder above already fits the budget, but an EXPLICIT
            # corridor_res_m bypasses it — a too-fine res over a wide bbox
            # (e.g. 10 m over a 300 km leg) would build a >100 M-cell grid
            # and OOM RViz/planner. Enforce the same ceiling here.
            if rows * cols > request.cell_budget:
                raise ValueError(
                    f'corridor grid {rows}x{cols} = {rows*cols/1e6:.1f}M cells '
                    f'exceeds budget {request.cell_budget/1e6:.0f}M @ '
                    f'res={res_m}m — raise corridor_res_m')
            wx1 = wx0 + rows * res_m / TARGET_CELL_SIZE_M
            wy1 = wy0 + cols * res_m / TARGET_CELL_SIZE_M
            _emit(diagnostic, 'info',
                f'[corridor] {mission_path}: bbox u=({wx0:.1f},{wy0:.1f})..'
                f'({wx1:.1f},{wy1:.1f}) -> {rows}x{cols} cells @ {res_m:.0f}m '
                f'({rows*cols/1e6:.1f}M)')

            # Crop bounds in EPSG:5179 (both frame axes are mirrored, so
            # the corner pairing flips — frame_bbox_to_en owns that).
            e_min, n_min, e_max, n_max = frame_bbox_to_en(
                wx0, wy0, wx1, wy1, anchor)

            win = from_bounds(e_min, n_min, e_max, n_max, vrt.transform)
            elevation = vrt.read(1, window=win, out_shape=(rows, cols),
                                 resampling=Resampling.bilinear
                                 ).astype(np.float32)

    # Frame origin of the crop in full-map world units — the one line that
    # makes mission/zone/tile coordinates line up without translation.
    origin_u = (wx0, wy0)
    result = normalize_elevation(elevation, res_m, origin_u, diagnostic)
    # Keep the corridor's exact snapped bounds rather than recomputing them
    # through grid lengths, matching the existing service receipt.
    return replace(result, min_bound_u=(float(wx0), float(wy0)),
                   max_bound_u=(float(wx1), float(wy1)), mission=ctx,
                   source_paths=(full_map_path, dem_src))


def _load_world(request, diagnostic):
    world_name = request.world
    tif_name = f'{world_name}.tif'
    tif_path = os.path.join(request.data_dir, tif_name)
    if world_name == 'full_map' and request.full_map_override:
        # staging override, same contract as the corridor anchor above
        tif_path = request.full_map_override
    # Single-file load, but pin the resolved path anyway so the whole
    # read happens inside one version even if an install swaps current
    # mid-load (old versions stay on disk).
    tif_path = os.path.realpath(tif_path)

    if not os.path.exists(tif_path):
        error_msg = f"""
        ================================================================================
        ERROR: Terrain data file not found!
        Path: {tif_path}

        Place {tif_name} under src/mmp_terrain/data/ — read directly, no
        rebuild needed. The generic downloader's merged.tif is an
        extraction source and does not create this runtime asset.

        For more information, see src/mmp_terrain/README.md.
        ================================================================================
        """
        _emit(diagnostic, 'error', error_msg)
        raise FileNotFoundError(f"Terrain data not found at {tif_path}")

    _emit(diagnostic, 'info', f'Opening {tif_path}...')
    with rasterio.open(tif_path) as src:
        _emit(diagnostic, 'info', f'TIF shape: {src.width} x {src.height}')
        _emit(diagnostic, 'info', f'CRS: {src.crs}')
        # Band 1 only: the /terrain/grid_map message carries just the
        # elevation layer (visualization moved to TerrainTiles, which
        # reads the tif's baked hillshade/RGB bands via globe/server.py —
        # make_dem_mosaic.py still bakes them INTO the tif for that).
        #
        # The SAME cell budget corridor mode enforces, because this path
        # had none: the east-asia frame is 142.8M cells — a ~571 MB
        # float32 array, a second copy during scaling, and a ~571 MB
        # single DDS message. Reading it whole is refused; the raster is
        # coarsened through the overviews to fit the budget and the
        # ACTUAL resolution goes into the message and the log. Korea
        # (13.4M cells) stays under the budget and is read unchanged.
        total = src.width * src.height
        if total > request.cell_budget:
            from rasterio.enums import Resampling as _Rs
            k = math.ceil(math.sqrt(total / request.cell_budget))
            out_h = math.ceil(src.height / k)
            out_w = math.ceil(src.width / k)
            _emit(diagnostic, 'warn',
                f'full-world {src.width}x{src.height} = {total/1e6:.1f}M '
                f'cells exceeds the {request.cell_budget/1e6:.0f}M '
                f'budget — coarsening x{k} to {out_w}x{out_h}; mission '
                f'work belongs in corridor mode')
            elevation = src.read(1, out_shape=(out_h, out_w),
                                 resampling=_Rs.average
                                 ).astype(np.float32)
            transform = src.transform * rasterio.Affine.scale(
                src.width / out_w, src.height / out_h)
        else:
            elevation = src.read(1).astype(np.float32)
            transform = src.transform

        # Cell size in METRES. Two cases:
        #  - PROJECTED CRS (metric, e.g. EPSG:5179):
        #    transform.a IS the cell size in metres. Cells are truly
        #    square, so there is no latitude distortion at all. This is
        #    the correct source form for large maps (a geographic grid
        #    spanning 33-43N stretches ~14% more N-S at the top than the
        #    bottom, and our square-cell grid_map cannot express that).
        #  - GEOGRAPHIC CRS (EPSG:4326, degrees): approximate with the
        #    cos(latitude) factor at the map centre. Fine for a small
        #    map, increasingly wrong the taller the map — reproject to a
        #    metric CRS instead (see tools/make_dem_mosaic.py).
        if src.crs is not None and src.crs.is_projected:
            resolution_m = abs(transform.a)
            _emit(diagnostic, 'info',
                f'Resolution: {resolution_m:.2f}m (projected CRS, square cells)')
        else:
            resolution_deg = transform.a
            bounds = src.bounds
            lat_center = (bounds.top + bounds.bottom) / 2.0
            resolution_m = resolution_deg * math.pi / 180.0 * 6371000 * math.cos(math.radians(lat_center))
            _emit(diagnostic, 'warn',
                f'Geographic CRS: {resolution_deg}deg -> {resolution_m:.2f}m at '
                f'lat_center={lat_center:.2f} (N-S distortion grows with map height; '
                f'reproject to a metric CRS for large maps)')

    return replace(normalize_elevation(elevation, resolution_m, diagnostic=diagnostic),
                   source_paths=(tif_path,))


def normalize_elevation(elevation, actual_cell_size, origin_u=(0.0, 0.0),
                        diagnostic: Diagnostic = None):
    """Copy metres to the existing NaN mask and 100 m float32 frame units."""
    # Mask before scaling, preserving the original operation and dtype order.
    elevation_raw = np.where(elevation < -9000, np.nan, elevation).astype(np.float32)
    elevation = np.where(elevation_raw <= 0, np.nan, elevation_raw)
    rows, cols = elevation.shape
    _emit(diagnostic, 'info', f'Cropped shape: {rows} x {cols}')
    _emit(diagnostic, 'info', f'Elevation range: {np.nanmin(elevation):.1f}m ~ {np.nanmax(elevation):.1f}m')
    _emit(diagnostic, 'info', f'NaN count: {np.isnan(elevation).sum()}')
    scale_factor = actual_cell_size / TARGET_CELL_SIZE_M
    _emit(diagnostic, 'info', f'Actual cell size: {actual_cell_size:.1f}m | Target cell size: {TARGET_CELL_SIZE_M}m | Scale factor: {scale_factor:.4f}')
    length_x = float(rows * float(scale_factor))
    length_y = float(cols * float(scale_factor))
    _emit(diagnostic, 'info', f'Map size (grid): {cols} x {rows} cells')
    _emit(diagnostic, 'info', f'Map size (actual): {rows * actual_cell_size / 1000:.1f}km x {cols * actual_cell_size / 1000:.1f}km (X x Y)')
    elevation_scaled = elevation / TARGET_CELL_SIZE_M
    return MapLoadResult(elevation_scaled, float(actual_cell_size),
                         (float(origin_u[0]), float(origin_u[1])),
                         (float(origin_u[0]) + length_x,
                          float(origin_u[1]) + length_y))


def load_map(request: MapLoadInput, *, mission_snapshot=None,
             diagnostic: Diagnostic = None) -> MapLoadResult:
    """Load the effective request without modifying any caller/ROS state.

    A service may resolve_map_mission first, validate command_fields, then
    pass that SAME snapshot here to avoid reopening mission/anchor metadata.
    Such a snapshot must belong to this request's mission and asset pair.
    Without it, corridor loads resolve for themselves (startup semantics).
    Other worlds ignore the mission with the existing diagnostic; 'none'
    explicitly clears terrain. Refused loads raise, leaving adoption to the
    caller. Sources are pinned before raster reads as in the original loader.
    """
    if request.mission_path and request.world != 'none':
        if request.world == 'full_map':
            return _load_corridor(request, mission_snapshot, diagnostic)
        _emit(diagnostic, 'error',
              f'[corridor] corridor_mission is set but world="{request.world}" '
              f'(corridor crops are full-map-frame only) — IGNORING corridor '
              f'mode and loading the full {request.world} map')
    if request.world == 'none':
        _emit(diagnostic, 'info', 'World is set to "none", skipping terrain loading')
        return MapLoadResult(None, 0.0, (0.0, 0.0), (0.0, 0.0))
    return _load_world(request, diagnostic)

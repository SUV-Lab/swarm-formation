"""ROS message adapter for an already loaded MapLoadResult.

No raster/mission reads, environment settings or parameter writes belong here.
The caller supplies the timestamp; serialization preserves the legacy column-
major float32 bytes and matrix-row-X / matrix-column-Y geometry.
"""
import array
import numpy as np
from grid_map_msgs.msg import GridMap
from std_msgs.msg import Float32MultiArray, MultiArrayDimension, Header


def to_grid_map(result, stamp):
    msg = GridMap()
    msg.header = Header()
    msg.header.frame_id = 'map'
    msg.header.stamp = stamp
    if result.elevation_u is None:
        return msg
    rows, cols = result.elevation_u.shape
    msg.info.resolution = result.resolution_u
    msg.info.length_x = result.length_x_u
    msg.info.length_y = result.length_y_u
    msg.info.pose.position.x, msg.info.pose.position.y = result.center_u
    msg.info.pose.orientation.w = 1.0
    msg.layers = ['elevation']
    layer = Float32MultiArray()
    layer.layout.dim.append(MultiArrayDimension(
        label='column_index', size=cols, stride=cols * rows))
    layer.layout.dim.append(MultiArrayDimension(
        label='row_index', size=rows, stride=rows))
    flat = np.ascontiguousarray(result.elevation_u.flatten(order='F'), dtype=np.float32)
    layer.data = array.array('f', flat.tobytes())
    msg.data = [layer]
    return msg

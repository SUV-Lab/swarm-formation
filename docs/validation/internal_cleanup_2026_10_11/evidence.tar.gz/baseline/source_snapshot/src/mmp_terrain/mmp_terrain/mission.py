"""Resolve a mission's geometry, with lon/lat as the authored truth.

Missions used to carry frame units only. Frame units move whenever the map's
frame moves — the last map migration rewrote 191 numbers — so the geodetic
position is what a mission actually means and the frame numbers are a cache
derived for one particular map.

This module owns that resolution so there is exactly one implementation of it.
The [TERRAIN-FRAME] convention it depends on (mirrored, axis-swapped: wx tracks
northing, wy tracks easting) lives in frame.py and is not restated here.

Per point, for `start`, `goal`, and each entry of `waypoints`:

    <key>_lonlat   <key>      behaviour
    ------------   -------    ----------------------------------------------
    present        absent     DERIVE — this is what makes lon/lat authorable
    present        present    COMPARE — disagreement beyond PAIR_TOL_U raises
    absent         present    REFUSE — frame numbers with no authored truth
                              cannot be checked against anything, and a map
                              swap would fly them somewhere else in silence
    absent         absent     REFUSE, naming the field

`z` is metres AGL. It is never geodetic, is never scaled here, and passes
through untouched.
"""
import hashlib
import math

from .frame import en_to_frame

# Authored truth vs derived cache. 0.02 frame units = 2 m.
#
# One definition: map/mission_lonlat.py imports this rather than keeping its
# own copy. Two copies of a tolerance drift, and nothing would compare them.
PAIR_TOL_U = 0.02

# Slack on the frame bounds, in frame units. 1e-6 u is 0.1 mm — far too small
# to admit a point that is genuinely off the map, and necessary because the
# authored box is INSCRIBED in the frame: its corners land on Lx / Ly exactly,
# and the lon/lat -> projected -> frame round trip lands them a few ulps over.
# Measured: an exact corner overshot by ~1e-10 u and was refused.
BOUND_EPS_U = 1e-6


class MissionError(ValueError):
    """A mission cannot be resolved. The message names the field."""


class Mission:
    """Resolved mission geometry, all in frame units with z in metres AGL."""

    __slots__ = ("start", "goal", "waypoints", "raw", "derived_keys")

    def __init__(self, start, goal, waypoints, raw, derived_keys):
        self.start = start
        self.goal = goal
        self.waypoints = waypoints
        self.raw = raw
        self.derived_keys = derived_keys

    def points_xy(self):
        """start, goal and every waypoint as [wx, wy] — the corridor seed."""
        return ([self.start[:2], self.goal[:2]] +
                [w[:2] for w in self.waypoints])


def _to_frame(lon, lat, crs, anchor):
    from rasterio.warp import transform as rio_transform
    xs, ys = rio_transform("EPSG:4326", crs, [lon], [lat])
    return en_to_frame(xs[0], ys[0], anchor)


def _check_bounds(key, wx, wy, anchor):
    # Inclusive on purpose. The mission box the map was built for is inscribed
    # in the frame and its corners land EXACTLY on Lx / Ly, so an exclusive
    # bound would reject a legal corner.
    if not (-BOUND_EPS_U <= wx <= anchor.Lx + BOUND_EPS_U and
            -BOUND_EPS_U <= wy <= anchor.Ly + BOUND_EPS_U):
        raise MissionError(
            "mission %s at frame (%.4f, %.4f) is outside the map frame "
            "0..%.1f x 0..%.1f — check the lon/lat, or use a map that "
            "covers it" % (key, wx, wy, anchor.Lx, anchor.Ly))


def _finite(seq):
    return all(isinstance(v, (int, float)) and math.isfinite(float(v))
               for v in seq)


def resolve_point(key, ll, frame_xyz, crs, anchor, warn=None):
    """One point. Returns (xyz, was_derived); see the module table."""
    if ll is not None:
        if len(ll) < 2 or not _finite(ll[:2]):
            raise MissionError(
                "mission %s_lonlat must be [lon, lat] or [lon, lat, z_agl] "
                "with finite values" % key)
        wx, wy = _to_frame(float(ll[0]), float(ll[1]), crs, anchor)
        _check_bounds(key, wx, wy, anchor)

    if ll is None and frame_xyz is None:
        raise MissionError(
            "mission has no %s: author %s_lonlat as [lon, lat, z_agl]" %
            (key, key))

    if ll is None:
        # Frame numbers with no authored truth. Refusing is the whole point:
        # there is nothing to check them against, so a map swap silently flies
        # them somewhere else. This inverts the old opt-in skip.
        raise MissionError(
            "mission %s has frame values but no %s_lonlat — the authored "
            "truth is missing, so a map change could not be detected. Run "
            "map/mission_lonlat.py --add to record it." % (key, key))

    if frame_xyz is None:
        if len(ll) < 3:
            if warn:
                warn("mission %s_lonlat has no z; using 0 m AGL. State it "
                     "explicitly as [lon, lat, z_agl]." % key)
            z = 0.0
        else:
            z = float(ll[2])
        return [wx, wy, z], True

    # Both present: the frame value is what every consumer reads, so return it
    # VERBATIM rather than the re-derived one. Re-deriving here would silently
    # move a mission by the round-trip residual on every load.
    if len(frame_xyz) != 3 or not _finite(frame_xyz):
        raise MissionError(
            "mission %s must be [x, y, z] with finite values" % key)
    d = max(abs(wx - float(frame_xyz[0])), abs(wy - float(frame_xyz[1])))
    if d > PAIR_TOL_U:
        raise MissionError(
            "mission %s is %.3f u away from its authored lonlat — the frame "
            "fields were not re-derived for this map (run "
            "map/mission_lonlat.py --derive)" % (key, d))
    return [float(v) for v in frame_xyz], False


def resolve(m, crs, anchor, warn=None):
    """Resolve the `mission:` mapping. Raises MissionError, never KeyError."""
    derived = []
    start, d0 = resolve_point("start", m.get("start_lonlat"), m.get("start"),
                              crs, anchor, warn)
    if d0:
        derived.append("start")
    goal, d1 = resolve_point("goal", m.get("goal_lonlat"), m.get("goal"),
                             crs, anchor, warn)
    if d1:
        derived.append("goal")

    wps_ll = m.get("waypoints_lonlat") or []
    wps_fr = m.get("waypoints") or []
    if wps_ll and wps_fr and len(wps_ll) != len(wps_fr):
        raise MissionError(
            "mission has %d waypoints_lonlat but %d waypoints — they must "
            "pair one to one" % (len(wps_ll), len(wps_fr)))
    n = max(len(wps_ll), len(wps_fr))
    waypoints = []
    for i in range(n):
        p, dd = resolve_point(
            "waypoints[%d]" % i,
            wps_ll[i] if i < len(wps_ll) else None,
            wps_fr[i] if i < len(wps_fr) else None,
            crs, anchor, warn)
        waypoints.append(p)
        if dd:
            derived.append("waypoints[%d]" % i)

    return Mission(start, goal, waypoints, m, derived)


def load_bytes(data, crs, anchor, warn=None, name="<mission bytes>"):
    """Parse + resolve a mission from exact bytes -> (Mission, sha256 hex).

    The digest is computed from ``data`` itself, so what was HASHED is what
    was PARSED. A caller that needs both a corridor bbox and a resolver
    response must read the file ONCE and call this once — a second open() of
    the same path is the TOCTOU that lets a mid-flight rewrite split the two
    into different missions.
    """
    import yaml
    doc = yaml.safe_load(data)
    if not isinstance(doc, dict) or "mission" not in doc:
        raise MissionError("%s has no top-level `mission:` section" % name)
    return (resolve(doc["mission"], crs, anchor, warn),
            hashlib.sha256(data).hexdigest())


def load(path, crs, anchor, warn=None):
    """Read a mission yaml (one read) and resolve it."""
    with open(path, "rb") as fp:
        data = fp.read()
    return load_bytes(data, crs, anchor, warn, name=path)[0]


def _cmd_number(key, v):
    # bool is an int subclass; `formation_scale: true` must not become 1.0.
    if isinstance(v, bool) or not isinstance(v, (int, float)) \
            or not math.isfinite(float(v)):
        raise MissionError("mission.%s must be a finite number" % key)
    return float(v)


def command_fields(m):
    """Validate the non-geometric command fields of a `mission:` mapping.

    This policy lived in the RViz panel's C++ yaml parser while the corridor
    path ignored the fields entirely — two readers, one contract, no test on
    either. It now has ONE implementation, and the panel consumes the typed
    result over /terrain/load_map instead of parsing yaml.

    Values travel VERBATIM: the vectors are frame-axis components exactly as
    authored, checked for finiteness and flag coherence only — never clamped
    (a clamped -5 and a stated rest start become the same wire message and
    mean opposite things) and never re-projected (no ENU claim; that would
    be new *_enu_* keys).

    Returns a dict shaped like ResolvedMission's non-geometric half, plus
    ``warnings``: findings that must be surfaced but do not refuse the
    mission (an authored vector whose use_* flag is not true is IGNORED, and
    that ignore must never be silent).
    """
    out = {
        "formation_type": "none",
        "formation_scale": 0.0,
        "initial_speed_mps": 0.0,
        "use_initial_speed": False,
        "use_initial_velocity": False,
        "initial_velocity_mps": [0.0, 0.0, 0.0],
        "use_initial_acceleration": False,
        "initial_acceleration_mps2": [0.0, 0.0, 0.0],
        "use_final_velocity": False,
        "final_velocity_mps": [0.0, 0.0, 0.0],
        "use_final_acceleration": False,
        "final_acceleration_mps2": [0.0, 0.0, 0.0],
        "warnings": [],
    }

    def vec3(key):
        v = m.get(key)
        if v is None:
            return None
        if not isinstance(v, (list, tuple)) or len(v) != 3:
            raise MissionError("mission.%s must be [x, y, z]" % key)
        return [_cmd_number(key, c) for c in v]

    def flag(key):
        v = m.get(key)
        if v is None:
            return False
        if not isinstance(v, bool):
            raise MissionError("mission.%s must be true or false" % key)
        return v

    if "formation_type" in m:
        if not isinstance(m["formation_type"], str):
            raise MissionError("mission.formation_type must be a string")
        out["formation_type"] = m["formation_type"]
    if "formation_scale" in m:
        out["formation_scale"] = _cmd_number("formation_scale",
                                             m["formation_scale"])

    if "initial_speed_mps" in m:
        # Key PRESENCE is the claim — a separate use_initial_speed yaml key
        # would only add a way for the two to disagree. A negative value
        # travels intact and is refused by name downstream.
        out["initial_speed_mps"] = _cmd_number("initial_speed_mps",
                                               m["initial_speed_mps"])
        out["use_initial_speed"] = True

    # EXPLICIT OPT-IN: a vector's mere presence must not enable it — a
    # leftover initial_velocity_mps: [0,0,0] once silently commanded a rest
    # start. The vector applies only when its use_* flag is true.
    vel = vec3("initial_velocity_mps")
    acc = vec3("initial_acceleration_mps2")
    if vel is not None:
        out["initial_velocity_mps"] = vel
    if acc is not None:
        out["initial_acceleration_mps2"] = acc
    out["use_initial_velocity"] = flag("use_initial_velocity")
    out["use_initial_acceleration"] = flag("use_initial_acceleration")
    if out["use_initial_velocity"] and vel is None:
        raise MissionError(
            "use_initial_velocity: true but initial_velocity_mps is missing")
    if out["use_initial_acceleration"] and acc is None:
        raise MissionError("use_initial_acceleration: true but "
                           "initial_acceleration_mps2 is missing")
    if out["use_initial_speed"] and out["use_initial_velocity"]:
        raise MissionError(
            "both initial_speed_mps and use_initial_velocity: true are set "
            "— one quantity, one claim. Delete whichever line is not the "
            "intended start state.")
    if not out["use_initial_speed"] and not out["use_initial_velocity"]:
        raise MissionError(
            "no initial state stated. Add ONE of:\n"
            "    initial_speed_mps: 200.0        # level, aimed along the "
            "first leg\n"
            "  or\n"
            "    use_initial_velocity: true\n"
            "    initial_velocity_mps: [200.0, 0.0, 0.0]\n"
            "The planner refuses to invent a start state.")

    fvel = vec3("final_velocity_mps")
    facc = vec3("final_acceleration_mps2")
    if fvel is not None:
        out["final_velocity_mps"] = fvel
    if facc is not None:
        out["final_acceleration_mps2"] = facc
    out["use_final_velocity"] = flag("use_final_velocity")
    out["use_final_acceleration"] = flag("use_final_acceleration")
    if out["use_final_velocity"] and fvel is None:
        raise MissionError(
            "use_final_velocity: true but final_velocity_mps is missing")
    if out["use_final_acceleration"] and facc is None:
        raise MissionError("use_final_acceleration: true but "
                           "final_acceleration_mps2 is missing")

    # The panel only surfaced the initial-velocity ignore; all four
    # authored-but-flagless vectors are the same silent-ignore hazard.
    for key, applied in (("initial_velocity_mps", out["use_initial_velocity"]),
                         ("initial_acceleration_mps2",
                          out["use_initial_acceleration"]),
                         ("final_velocity_mps", out["use_final_velocity"]),
                         ("final_acceleration_mps2",
                          out["use_final_acceleration"])):
        if key in m and not applied:
            out["warnings"].append(
                "%s IGNORED (use_%s not true)" %
                (key, key.rsplit("_mps", 1)[0]))
    return out

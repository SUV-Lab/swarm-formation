"""[TERRAIN-FRAME] The one implementation of the planner world frame.

Everything downstream of the terrain — missions, risk zones, the grid_map
pose, the /ftile tile quadtree — is expressed in FRAME UNITS (u), where
1 u = 100 m (TARGET_CELL_SIZE_M).

The frame is anchored to ``full_map.tif``'s own georeference, and to nothing
else. That anchor is what makes a corridor crop a sub-rectangle of the SAME
frame as the full map, so missions / risk zones / TerrainTiles need no
coordinate translation when the loaded map changes. The raster's
georeference is used rather than, say, a rounded origin constant because it
is the only definition every producer can recompute from a shipped file
alone — there is no shared magic number to drift out of sync.

Convention (projected easting E / northing N, metres — the CRS is whatever
the anchor raster declares, read via load_frame):

    E = E0 + 100 * (Ly - wy)          wy = Ly - (E - E0) / 100
    N = N0 - 100 * (Lx - wx)          wx = Lx - (N0 - N) / 100

where (E0, N0) is the anchor raster's top-left corner and (Lx, Ly) its
north-south / east-west extent in frame units.

BOTH axes are mirrored with respect to the raster's array indices: wx is Lx
at row 0 (the north edge) and falls to 0 at the south edge; wy is Ly at
column 0 (the west edge) and falls to 0 at the east edge. So frame +x points
NORTH and frame +y points WEST, and any block read in native raster order
has to be flipped on both axes to come out wx/wy ascending (the ``::-1,
::-1`` in tiles/server.py::_read_5179).

The mirroring also flips which frame corner is which in E/N: the minimum-E
corner sits at MAXIMUM wy and the minimum-N corner at MINIMUM wx. Getting
that pairing wrong yields a bbox that is inside-out on one axis, so use
``frame_bbox_to_en`` instead of hand-pairing the corners.

This module is imported both as part of the ament package
(``mmp_terrain.frame``) and, via a sys.path fallback, by the standalone tile
server — so it must stay dependency-light (rasterio + stdlib only) and free
of any rclpy import.
"""

import hashlib
import json
import math
from typing import NamedTuple

import rasterio

# World unit: 1 u = 100 m. Also the grid_map z-unit, kept ISOTROPIC with the
# xy frame unit so no consumer has to undo a DEM-dependent vertical scale.
TARGET_CELL_SIZE_M = 100.0

# ---- tile quadtree, derived from the frame (never hand-set) ---------------
# The /ftile pyramid is a quadtree over the frame itself, so its three
# constants are properties of the anchor raster, not numbers to maintain:
# hand-setting them is how a bigger frame ends up pasting 10 m granules onto
# 400 m/px tiles. Each level's tile covers ROOT/2^z frame units, drawn on a
# TILE_PX texture.
TILE_PX = 256
MAX_TILE_SPAN_U = 32        # finest level -> 12.5 m/px (the 10 m source limit)
DEEP_TILE_SPAN_U = 256      # at or below 100 m/px, cut RGB from the granules


class FrameAnchor(NamedTuple):
    """Frame anchor read off the full-map raster.

    Unpacks as ``(E0, N0, Lx, Ly)`` and also serialises straight to the
    /ftile/meta JSON via ``._asdict()``.
    """

    E0: float   # anchor easting  (raster top-left corner), metres
    N0: float   # anchor northing (raster top-left corner), metres
    Lx: float   # north-south extent, frame units
    Ly: float   # east-west  extent, frame units


class FrameSpec(NamedTuple):
    """Anchor + the CRS it is expressed in.

    Kept separate from FrameAnchor on purpose: the 4-field anchor is a
    published contract (``/ftile/meta`` ships it via ``._asdict()``, and this
    tree unpacks it as a 4-tuple in places), so widening it would break
    callers that have nothing to do with projections.
    """

    anchor: "FrameAnchor"
    crs_wkt: str        # WKT2 of the anchor raster's CRS
    crs: object         # the rasterio CRS object, for WarpedVRT/transform_*


def _frame_spec(base):
    """FrameSpec from an OPEN dataset — shared by the loaders below."""
    tf = base.transform
    return FrameSpec(
        anchor=FrameAnchor(
            E0=tf.c,
            N0=tf.f,
            Lx=base.height * abs(tf.e) / TARGET_CELL_SIZE_M,
            Ly=base.width * tf.a / TARGET_CELL_SIZE_M,
        ),
        crs_wkt=base.crs.to_wkt(),
        crs=base.crs,
    )


def _identity_digest(base):
    """Frame-identity sha256 from an OPEN dataset (see frame_digest)."""
    tf = base.transform
    ident = {"crs_wkt": base.crs.to_wkt(),
             "transform": [tf.a, tf.b, tf.c, tf.d, tf.e, tf.f],
             "width": base.width, "height": base.height}
    blob = json.dumps(ident, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode()).hexdigest()


def load_frame(full_map_path):
    """Read the [TERRAIN-FRAME] anchor AND its CRS -> FrameSpec.

    Nothing downstream should name a projection: the anchor raster carries
    the one this map was built in, and reading it here is what lets the frame
    move to a different CRS without a string edit in ten call sites.
    """
    with rasterio.open(full_map_path) as base:
        return _frame_spec(base)


def read_frame_snapshot(full_map_path):
    """ONE open -> (FrameSpec, frame-identity digest, dataset tags).

    Separate load_frame() / frame_digest() / tags() calls each reopen the
    file; an in-place replace between any two pairs frame A values with
    frame B values. Callers that need more than one of these must use this.
    """
    with rasterio.open(full_map_path) as base:
        return _frame_spec(base), _identity_digest(base), dict(base.tags())


def load_frame_digested(full_map_path):
    """ONE open -> (FrameSpec, frame-identity digest)."""
    spec, digest, _ = read_frame_snapshot(full_map_path)
    return spec, digest


def load_anchor(full_map_path):
    """Read the [TERRAIN-FRAME] anchor from a full-map raster -> FrameAnchor.

    Compatibility wrapper over load_frame() — the 4-field shape and its
    ``(E0, N0, Lx, Ly)`` unpacking are unchanged. Opens the file on every
    call; callers that need it per request (the tile server) cache it.
    """
    return load_frame(full_map_path).anchor


def frame_digest(full_map_path):
    """Identity of the frame an anchor raster defines -> sha256 hex.

    Canonical JSON over {crs_wkt, transform, width, height}. Everything that
    defines [TERRAIN-FRAME] derives from these four fields (E0/N0/Lx/Ly are
    functions of them), and nothing else is hashed — a content-only re-bake
    with an identical georeference keeps its identity, while any move,
    re-projection or resize is a DIFFERENT frame. Consumers compare two
    responses' digests for equality instead of trusting that no install
    swapped the map between their calls; the digest proves same-frame, a
    file sha would only prove same-bytes.
    """
    with rasterio.open(full_map_path) as base:
        return _identity_digest(base)


def crs_digest(crs_wkt):
    """Short, stable id for a CRS. Baked into the tile-cache fingerprint so a
    cache can PROVE which projection produced it — a code-version number says
    what the baker was, not what the pixels are."""
    return hashlib.sha256(crs_wkt.encode()).hexdigest()


def next_power_of_two(v):
    p = 1
    while p < v:
        p *= 2
    return p


def quadtree_levels(anchor):
    """(FRAME_ROOT, FDEEP_ZOOM_MIN, FMAXZ) for this frame.

    Derived so the physical thresholds survive a frame change: the finest
    level is always MAX_TILE_SPAN_U (12.5 m/px) and deep zoom always starts
    at DEEP_TILE_SPAN_U (100 m/px), whatever the frame's size. Hand-setting
    the root alone moves both thresholds by the same factor.
    """
    # Floor at the deep-zoom span: a frame smaller than one 100 m/px tile
    # would otherwise produce NEGATIVE zoom levels, and every consumer indexes
    # the pyramid from 0.
    root = float(max(next_power_of_two(math.ceil(max(anchor.Lx, anchor.Ly))),
                     DEEP_TILE_SPAN_U))
    return (root,
            int(round(math.log2(root / DEEP_TILE_SPAN_U))),
            int(round(math.log2(root / MAX_TILE_SPAN_U))))


def tile_bbox_to_en(z, x, y, root, anchor):
    """Frame tile (z, x, y) -> projected bbox ``(Emin, Nmin, Emax, Nmax)``.

    The one place the mirrored-axis pairing meets the quadtree. It was
    open-coded in the tile server, in both prewarm scripts, in the baker and
    in repair_sea.py — five copies of a formula whose only warning sign, when
    the frame moves, is that the picture is subtly wrong.
    """
    S = root / (1 << z)
    return frame_bbox_to_en(x * S, y * S, (x + 1) * S, (y + 1) * S, anchor)


def frame_to_en(wx, wy, anchor):
    """Frame units -> projected (E, N) metres, in the anchor raster's CRS."""
    return (anchor.E0 + TARGET_CELL_SIZE_M * (anchor.Ly - wy),
            anchor.N0 - TARGET_CELL_SIZE_M * (anchor.Lx - wx))


def en_to_frame(E, N, anchor):
    """Projected (E, N) metres -> frame units (wx, wy)."""
    return (anchor.Lx - (anchor.N0 - N) / TARGET_CELL_SIZE_M,
            anchor.Ly - (E - anchor.E0) / TARGET_CELL_SIZE_M)


def frame_bbox_to_en(wx0, wy0, wx1, wy1, anchor):
    """Frame bbox -> projected bbox ``(Emin, Nmin, Emax, Nmax)``.

    Owns the mirrored-axis corner pairing described in the module docstring:
    the E/N minimum corner is (min wx, MAX wy), the maximum corner is
    (max wx, MIN wy).
    """
    e_min, n_min = frame_to_en(wx0, wy1, anchor)
    e_max, n_max = frame_to_en(wx1, wy0, anchor)
    return e_min, n_min, e_max, n_max

"""Source-coverage preflight and planner for the sealed east-asia grid.

`make_dem_mosaic.py` grew from a directory glob: every .tif in --tiles is an
input, whatever is missing simply is not there, and gaps are filled with sea
level AFTER reprojection. For the shipped Korea map that was survivable. For
the east-asia grid it is the exact defect the coverage pipeline exists to
stop: the average resampler drops NaN sources and happily returns a finite,
wrong number on every land/ocean boundary — 100 m where the answer is 50 —
and no post-hoc NaN gate can ever see it.

So the sources are not a directory. They are a PLAN, proved before a single
pixel moves:

  * the sealed target profile is re-derived, never trusted;
  * the coverage manifest must be schema 2, ready, and sealed to the same
    grid, and the lock chosen by the manifest's OWN sha must vouch for it;
  * every file is re-hashed on disk against that lock — the latest audit
    report is somebody else's claim, not this gate's evidence;
  * every real tile is opened and held to one global PixelIsPoint grid;
  * ocean cells become constant-0 descriptors on that SAME derived grid —
    a nominal [lon, lon+1] Area transform is half a pixel of lie;
  * the plan carries descriptors only. Arrays are materialized per window,
    later, by whoever asks — building 396 synthetic tiles up front would
    recreate the memory problem the windowed mosaic exists to avoid.

The one thing this module never does is recompute the output grid. The
profile's transform/width/height ARE the map; widening coverage and calling
calculate_default_transform again is the recursion the seal was built to
stop.

Dependency-light on purpose: stdlib + numpy at import time. rasterio is
imported inside the functions that actually open rasters, so the preflight
bookkeeping stays importable everywhere the tools run.
"""
import concurrent.futures as cf
import hashlib
import json
import os

import numpy as np

COVERAGE_SCHEMAS = (2,)
SUPPORT_POLICY_SCHEMAS = (1,)
GRADES = ("glo30", "glo90_fallback", "ocean", "unknown")
REAL_GRADES = ("glo30", "glo90_fallback")
CHUNK = 1 << 20
# Alignment tolerances. Degrees for absolute placement (1e-9 deg ~ 0.1 mm),
# relative for the cell size itself.
TOL_DEG = 1e-9
TOL_RES = 1e-12
# How a glo90 source is brought onto the canonical grid: an EXPLICIT
# upsample, cubic — the same rule the shipped mosaic recipe uses for
# upsampling (average/bilinear flatten the very relief a fallback tile
# exists to contribute). Cubic needs two source samples beyond every
# destination point, which is what the neighbour margin provides.
GLO90_RESAMPLING = "cubic"
FALLBACK_MARGIN = 2


class PreflightError(RuntimeError):
    """The gate's no. Carries every problem found, not just the first."""

    def __init__(self, problems):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems))


def _fail(problems):
    if problems:
        raise PreflightError(problems)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical(obj):
    """Must match build_target_grid.canonical exactly, or a re-derived digest
    would never equal the sealed one. Copied rather than imported to keep
    this module free of the map/ tool tree; a test compares the two."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def digest(obj):
    return hashlib.sha256(canonical(obj).encode()).hexdigest()


def cell_key(la, lo):
    return "%d%s_%d%s" % (abs(la), "N" if la >= 0 else "S",
                          abs(lo), "E" if lo >= 0 else "W")


def read_profile(path):
    """The sealed grid, re-derived. Both digests are recomputed from the
    content; a hand-edited cell list does not pass because the digest field
    beside it was left alone."""
    problems = []
    if not os.path.exists(path):
        raise PreflightError([f"no sealed target grid at {path}"])
    try:
        p = json.load(open(path))
    except ValueError as ex:
        raise PreflightError([f"{path} is not readable JSON: {ex}"])
    grid = p.get("target_grid")
    support = p.get("support") or {}
    if not isinstance(grid, dict) or not isinstance(support.get("cells"),
                                                    list):
        raise PreflightError([f"{path} is not a target-grid profile"])
    tgd = p.get("target_grid_digest")
    if digest(grid) != tgd:
        problems.append("target_grid does not match target_grid_digest")
    if digest({"target_grid": tgd, "support": support}) \
            != p.get("source_support_digest"):
        problems.append("support does not match source_support_digest")
    schema = (support.get("policy") or {}).get("schema")
    if schema not in SUPPORT_POLICY_SCHEMAS:
        problems.append(f"support policy schema {schema!r} is unknown")
    cells = [tuple(c) for c in support["cells"]]
    if not cells or len(set(cells)) != len(cells):
        problems.append("sealed support cells empty or duplicated")
    for k in ("transform", "width", "height", "crs_wkt", "name"):
        if not grid.get(k):
            problems.append(f"target_grid has no {k}")
    _fail(problems)
    return {"path": os.path.realpath(path),
            "name": grid["name"],
            "target_grid_digest": tgd,
            "source_support_digest": p["source_support_digest"],
            "target": {"crs_wkt": grid["crs_wkt"],
                       "transform": tuple(grid["transform"]),
                       "width": grid["width"], "height": grid["height"],
                       "resolution_m": grid.get("resolution_m")},
            "cells": sorted(cells)}


def _contained_ref(mans, ref, what):
    """A filename taken from JSON, or why it is not usable.

    The reference is data; joined blindly it is a path traversal. It must
    be a bare filename that resolves inside manifests/.
    """
    if not ref or not isinstance(ref, str) \
            or os.path.basename(ref) != ref or ref in (".", ".."):
        return None, f"{what} {ref!r} is not a bare filename"
    p = os.path.realpath(os.path.join(mans, ref))
    if os.path.dirname(p) != os.path.realpath(mans):
        return None, f"{what} {ref!r} escapes {mans}"
    return p, None


def _contained_profile_ref(mans, ref):
    return _contained_ref(mans, ref, "grid.profile")


def _check_manifest(manifest, sealed, mans):
    problems = []
    if manifest.get("schema") not in COVERAGE_SCHEMAS:
        # Nothing else in a schema-1 manifest can be trusted to mean what
        # this code thinks it means. Say only this.
        return [f"coverage schema {manifest.get('schema')!r} is not one of "
                f"{COVERAGE_SCHEMAS}"]
    if manifest.get("problems") or not manifest.get("ready_to_download"):
        problems.append(f"coverage is not ready: {manifest.get('problems')}")
    g = manifest.get("grid") or {}
    if g.get("target_grid_digest") != sealed["target_grid_digest"]:
        problems.append("coverage target_grid_digest does not match the "
                        "sealed profile")
    if g.get("source_support_digest") != sealed["source_support_digest"]:
        problems.append("coverage source_support_digest does not match the "
                        "sealed profile")
    if g.get("name") != sealed["name"]:
        problems.append(f"coverage grid name {g.get('name')!r} != profile "
                        f"{sealed['name']!r}")
    ref, why = _contained_profile_ref(mans, g.get("profile"))
    if why:
        problems.append(why)
    elif ref != sealed["path"]:
        problems.append(f"coverage names profile {g.get('profile')!r}, the "
                        f"gate was armed with {sealed['path']}")
    counts = manifest.get("counts") or {}
    if counts.get("unknown"):
        problems.append(f"{counts['unknown']} cell(s) unknown")
    cells = manifest.get("cells") or {}
    # counts is a CLAIM; the cells dict is the decision. They must agree,
    # grade by grade — a manifest that disagrees with itself is not
    # evidence, and anything downstream that trusts the cheap field (the
    # glo90 pin does, deliberately, to fail before the expensive re-hash)
    # would otherwise be steerable by editing one number.
    tally = {g: 0 for g in GRADES}
    for c in cells.values():
        g_ = c.get("grade") if isinstance(c, dict) else None
        if g_ in tally:
            tally[g_] += 1
    for g_ in GRADES:
        if counts.get(g_, 0) != tally[g_]:
            problems.append(f"counts.{g_} claims {counts.get(g_, 0)}, the "
                            f"cells themselves tally {tally[g_]} — the "
                            f"manifest disagrees with itself")
    want = {cell_key(*c) for c in sealed["cells"]}
    have = set(cells)
    for missing in sorted(want - have)[:3]:
        problems.append(f"sealed cell {missing} missing from coverage")
    for extra in sorted(have - want)[:3]:
        problems.append(f"coverage cell {extra} is not in the sealed support")
    if len(want - have) > 3 or len(have - want) > 3:
        problems.append(f"...cell set differs by "
                        f"{len(want ^ have)} total")
    return problems


def _check_objects(manifest, sealed):
    """Cells and objects must agree in BOTH directions: a graded land cell
    with no object is a future 0 m hole; an object no cell claims is bytes
    nobody vouched a decision for."""
    problems = []
    cells = manifest["cells"]
    objs = manifest["objects"]
    by_name = {}
    for o in objs:
        if o["name"] in by_name:
            problems.append(f"object {o['name']} listed twice")
        by_name[o["name"]] = o
    claimed = {}
    for key, c in cells.items():
        grade, oname = c.get("grade"), c.get("object")
        if grade not in GRADES or grade == "unknown":
            problems.append(f"{key}: grade {grade!r} cannot be mosaicked")
            continue
        if grade == "ocean":
            if oname:
                problems.append(f"{key}: ocean cell claims object {oname}")
            continue
        if not oname or oname not in by_name:
            problems.append(f"{key}: {grade} cell has no listed object")
            continue
        if oname in claimed:
            problems.append(f"object {oname} claimed by {claimed[oname]} "
                            f"and {key}")
        claimed[oname] = key
        o = by_name[oname]
        if o.get("grade") != grade:
            problems.append(f"{key}: cell grade {grade}, object grade "
                            f"{o.get('grade')}")
        if cell_key(*o.get("cell", (999, 999))) != key:
            problems.append(f"{key}: claims {oname}, whose own cell is "
                            f"{o.get('cell')}")
    for name in sorted(set(by_name) - set(claimed))[:3]:
        problems.append(f"object {name} is claimed by no cell")
    return problems


def _check_lock(mans, cov_sha, manifest, sealed):
    """The lock chosen by the manifest's OWN sha, held to it in full."""
    lock_name = f"download_lock_{cov_sha[:12]}.json"
    lock_path = os.path.join(mans, lock_name)
    if not os.path.exists(lock_path):
        return None, [f"no lock for this coverage decision ({lock_name}) — "
                      f"run audit_dem_tiles.py to establish the baseline"]
    try:
        lock = json.load(open(lock_path))
    except ValueError as ex:
        return None, [f"{lock_name}: unreadable ({ex})"]
    problems = []
    if lock.get("manifest_sha256") != cov_sha:
        problems.append(f"{lock_name}: manifest_sha256 does not match "
                        f"coverage.json ({cov_sha[:12]}...)")
    for k in ("target_grid_digest", "source_support_digest"):
        if lock.get(k) != sealed[k]:
            problems.append(f"{lock_name}: {k} does not match the sealed "
                            f"profile")
    sha = lock.get("sha256")
    if not isinstance(sha, dict):
        problems.append(f"{lock_name}: sha256 is "
                        f"{type(sha).__name__}, not a name->digest map")
        return None, problems
    names = {o["name"] for o in manifest["objects"]}
    if set(sha) != names:
        problems.append(f"{lock_name}: locks {len(sha)} file(s), the "
                        f"manifest lists {len(names)} — sets differ by "
                        f"{len(set(sha) ^ names)}")
    problems += _check_lock_chain(mans, lock_name, lock)
    return {"name": lock_name, "path": lock_path, "sha256": sha}, problems


def _hash_manifests(mans):
    """{sha256: filename} for coverage.json and every archived coverage."""
    out = {}
    for f in sorted(os.listdir(mans)):
        if f == "coverage.json" or (f.startswith("coverage_")
                                    and f.endswith(".json")):
            out[sha256_file(os.path.join(mans, f))] = f
    return out


def _check_lock_chain(mans, first_name, first_body):
    """Inherited locks are evidence only while they still prove out.

    The audit held the current lock to its ancestors when it was written;
    this gate runs later, on a directory anything may have touched since.
    So the whole chain is walked again: every reference stays inside
    manifests/, never revisits a lock, is a name->digest map, agrees on
    every shared file, and anchors to a coverage manifest that still
    exists and still hashes to what the lock recorded.
    """
    problems = []
    anchors = _hash_manifests(mans)
    merged = {n: (d, first_name) for n, d in first_body["sha256"].items()}
    seen = {first_name}
    queue = [(first_name, r) for r in (first_body.get("inherits") or [])]
    while queue:
        parent, ref = queue.pop(0)
        path, why = _contained_ref(mans, ref, f"{parent} inherits")
        if why:
            problems.append(why)
            continue
        if ref in seen:
            problems.append(f"lock inheritance revisits {ref} — a chain "
                            f"never loops")
            continue
        seen.add(ref)
        try:
            body = json.load(open(path))
        except (OSError, ValueError) as ex:
            problems.append(f"{ref}: unreadable ancestor lock ({ex})")
            continue
        sha = body.get("sha256") if isinstance(body, dict) else None
        if not isinstance(sha, dict):
            problems.append(f"{ref}: sha256 is {type(sha).__name__}, "
                            f"not a name->digest map")
            continue
        drift = sorted(n for n, d in sha.items()
                       if n in merged and merged[n][0] != d)
        if drift:
            problems.append(f"{len(drift)} file(s) differ between {ref} "
                            f"and {merged[drift[0]][1]}, e.g. {drift[:3]}")
        for n, d in sha.items():
            merged.setdefault(n, (d, ref))
        man_sha = body.get("manifest_sha256")
        if not isinstance(man_sha, str) or man_sha not in anchors:
            problems.append(f"{ref}: its coverage manifest "
                            f"({str(man_sha)[:12]}...) is neither "
                            f"coverage.json nor any archived "
                            f"coverage_*.json — the decision it proved "
                            f"can no longer be read")
        queue += [(ref, r) for r in (body.get("inherits") or [])]
    return problems


def _identity(path):
    """What `stat` can say about whether a file is still the same one."""
    st = os.stat(path)
    return (st.st_ino, st.st_size, st.st_mtime_ns)


def _check_disk(root, manifest, lock_sha, workers, progress):
    """Re-hash every object on disk against the lock. The latest audit says
    it already did this; the gate does not act on somebody else's claim.

    Returns (problems, {name: identity}) — the identity each file had WHEN
    it hashed clean, so a later materialization can tell whether it is
    still reading the proven bytes.
    """
    problems = []
    stats = {}

    def one(o):
        path = os.path.join(root, o["grade"], o["name"] + ".tif")
        if not os.path.exists(path):
            return f"{o['name']}: missing on disk", None
        size = os.path.getsize(path)
        if size != int(o["content_length"]):
            return f"{o['name']}: {size} B on disk, manifest says " \
                   f"{o['content_length']}", None
        st0 = _identity(path)
        d = sha256_file(path)
        if _identity(path) != st0:
            return f"{o['name']}: changed while being hashed", None
        if d != lock_sha.get(o["name"]):
            return f"{o['name']}: sha {d[:12]} does not match the lock", None
        return None, st0

    objs = manifest["objects"]
    with cf.ThreadPoolExecutor(workers) as ex:
        for i, (o, (r, st)) in enumerate(zip(objs, ex.map(one, objs)), 1):
            if r:
                problems.append(r)
            else:
                stats[o["name"]] = st
            if progress and i % 100 == 0:
                progress(f"[gate ] re-hashed {i}/{len(objs)}")
    # Stray bytes: a .part or an unlisted .tif in a grade directory is a
    # download this decision never authorised.
    want = {}
    for o in objs:
        want.setdefault(o["grade"], set()).add(o["name"] + ".tif")
    for grade in REAL_GRADES:
        d = os.path.join(root, grade)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if f.endswith(".part"):
                problems.append(f"{grade}/{f}: leftover partial download")
            elif f.endswith(".tif") and f not in want.get(grade, set()):
                problems.append(f"{grade}/{f}: not in the manifest")
    return problems, stats


def _tile_spec(path):
    """(spec, problems) for one real tile, in this module's terms."""
    import rasterio
    with rasterio.open(path) as s:
        t = s.transform
        return {"crs": str(s.crs), "width": s.width, "height": s.height,
                "transform": (t.a, t.b, t.c, t.d, t.e, t.f),
                "area_or_point": s.tags().get("AREA_OR_POINT"),
                "count": s.count, "dtype": s.dtypes[0],
                "nodata": s.nodata}


def _check_tiles(root, manifest, workers, progress):
    """Every real tile held to ONE global PixelIsPoint grid per product.

    GLO tiles register their SAMPLES on integer-degree corners: the first
    pixel's CENTER sits at (lon, lat+1), so the transform's corner origin is
    (lon - res/2, lat+1 + res/2). A tile that says anything else — an Area
    registration, a shifted origin, a different cell size — would smear the
    whole mosaic by up to half a pixel, and nothing downstream could tell.
    """
    problems = []
    specs = {}

    def one(o):
        return o["name"], _tile_spec(
            os.path.join(root, o["grade"], o["name"] + ".tif"))

    real = [o for o in manifest["objects"] if o["grade"] in REAL_GRADES]
    with cf.ThreadPoolExecutor(workers) as ex:
        for i, (name, spec) in enumerate(ex.map(one, real), 1):
            specs[name] = spec
            if progress and i % 200 == 0:
                progress(f"[gate ] inspected {i}/{len(real)} tiles")

    grids = {}
    for o in real:
        s = specs[o["name"]]
        la, lo = o["cell"]
        n = o["name"]
        if s["crs"] != "EPSG:4326":
            problems.append(f"{n}: CRS {s['crs']}, expected EPSG:4326")
            continue
        if s["area_or_point"] != "Point":
            problems.append(f"{n}: AREA_OR_POINT={s['area_or_point']!r}, "
                            f"the GLO grid registers Points")
            continue
        if s["count"] != 1 or s["dtype"] != "float32":
            problems.append(f"{n}: {s['count']} band(s) of {s['dtype']}, "
                            f"this profile takes exactly one float32 band")
            continue
        if s["nodata"] is not None:
            # np.isfinite(-9999) is true: a finite sentinel would sail
            # straight through every completeness check and average itself
            # into the coast. In this profile sea is a real 0 m sample.
            problems.append(f"{n}: declares nodata={s['nodata']!r}; this "
                            f"profile forbids a nodata sentinel")
            continue
        a, b, c, d, e, f = s["transform"]
        if b or d or a <= 0 or e >= 0:
            problems.append(f"{n}: rotated or flipped transform")
            continue
        res = a
        if abs(-e - res) > TOL_RES * res:
            problems.append(f"{n}: anisotropic cells ({a} x {-e})")
            continue
        if abs(c - (lo - res / 2.0)) > TOL_DEG or \
                abs(f - (la + 1 + res / 2.0)) > TOL_DEG:
            problems.append(f"{n}: origin ({c}, {f}) is not the PixelIsPoint "
                            f"corner for cell ({la}, {lo}) at res {res}")
            continue
        g = grids.setdefault(o["grade"], {"res": res, "width": s["width"],
                                          "height": s["height"], "by": n})
        if abs(g["res"] - res) > TOL_RES * res or g["width"] != s["width"] \
                or g["height"] != s["height"]:
            problems.append(f"{n}: grid {s['width']}x{s['height']}@{res} "
                            f"disagrees with {g['by']} "
                            f"({g['width']}x{g['height']}@{g['res']})")
        if abs(s["width"] * res - 1.0) > 1e-6 or \
                abs(s["height"] * res - 1.0) > 1e-6:
            problems.append(f"{n}: {s['width']}x{s['height']} samples at "
                            f"{res} deg do not span one degree")
    return grids, problems


def _canonical_cell_transform(la, lo, res):
    return (res, 0.0, lo - res / 2.0, 0.0, -res, la + 1 + res / 2.0)


def build_plan(root, sealed, manifest, cov_sha, lock, grids, stats):
    """Descriptors only. The ocean grid is DERIVED from the proven real
    tiles — same size, same sample registration — never written down as a
    nominal degree box. Real descriptors carry the lock sha and the stat
    identity preflight proved, so a materialization can tell a still-proven
    file from one that moved underneath it."""
    if "glo30" not in grids:
        raise PreflightError(
            ["no verified glo30 tile to derive the source grid from"])
    g30 = grids["glo30"]
    src = {"crs": "EPSG:4326", "res_deg": g30["res"],
           "width": g30["width"], "height": g30["height"]}
    g90 = grids.get("glo90_fallback")
    by_cell = {}
    for o in manifest["objects"]:
        by_cell[tuple(o["cell"])] = o
    cells = {}
    for la, lo in sealed["cells"]:
        info = manifest["cells"][cell_key(la, lo)]
        grade = info["grade"]
        desc = {"cell": (la, lo), "grade": grade,
                "transform": _canonical_cell_transform(la, lo, g30["res"]),
                "width": g30["width"], "height": g30["height"]}
        if grade == "ocean":
            desc["constant"] = 0.0
        else:
            o = by_cell[(la, lo)]
            desc["path"] = os.path.join(root, grade, o["name"] + ".tif")
            desc["sha256"] = lock["sha256"][o["name"]]
            desc["stat"] = stats[o["name"]]
            if grade == "glo30":
                desc["src_transform"] = desc["transform"]
                desc["src_width"], desc["src_height"] = \
                    g30["width"], g30["height"]
            else:
                desc["src_transform"] = _canonical_cell_transform(
                    la, lo, g90["res"])
                desc["src_width"], desc["src_height"] = \
                    g90["width"], g90["height"]
                desc["resampling"] = GLO90_RESAMPLING
        cells[(la, lo)] = desc
    plan = {"root": os.path.abspath(root),
            "grid_name": sealed["name"],
            "target": sealed["target"],
            "target_grid_digest": sealed["target_grid_digest"],
            "source_support_digest": sealed["source_support_digest"],
            "coverage_sha256": cov_sha,
            "lock": lock["name"],
            "source": src,
            "cells": cells}
    if g90:
        plan["source_glo90"] = {"crs": "EPSG:4326", "res_deg": g90["res"],
                                "width": g90["width"],
                                "height": g90["height"]}
    return plan


def preflight(root, grid_name, profile_path=None, workers=8, progress=None,
              max_glo90_fallback=None):
    """Run every check, in fail-fast order, and return the plan.

    Cheap seals first, 18 GiB of hashing last — a digest mismatch should
    not cost twenty minutes to hear about. `max_glo90_fallback` is the
    caller's pin (see the production grids table): it is judged from the
    manifest counts BEFORE the expensive re-hash, for the same reason.
    """
    root = os.path.abspath(root)
    mans = os.path.join(root, "manifests")
    sealed = read_profile(profile_path or os.path.join(
        mans, f"target_grid_{grid_name}.json"))
    if sealed["name"] != grid_name:
        raise PreflightError([f"profile is sealed as {sealed['name']!r}, "
                              f"the gate was armed for {grid_name!r}"])
    cov_path = os.path.join(mans, "coverage.json")
    if not os.path.exists(cov_path):
        raise PreflightError([f"no coverage manifest at {cov_path}"])
    try:
        manifest = json.load(open(cov_path))
    except ValueError as ex:
        raise PreflightError([f"{cov_path} is not readable JSON: {ex}"])
    cov_sha = sha256_file(cov_path)

    _fail(_check_manifest(manifest, sealed, mans))
    # The pin reads the CELLS, not the counts field: _check_manifest just
    # proved the cell set equals the sealed support and that counts agrees
    # with it, but the tally is the grounded number — a lying counts field
    # alone must not be able to steer a production pin.
    n90 = sum(1 for c in (manifest.get("cells") or {}).values()
              if isinstance(c, dict) and c.get("grade") == "glo90_fallback")
    if max_glo90_fallback is not None and n90 > max_glo90_fallback:
        raise PreflightError(
            [f"this grid is pinned to glo90_fallback<={max_glo90_fallback} "
             f"and the coverage has {n90} — mixed-grade margins (glo90 "
             f"beside ocean or glo30) are not yet proven against a "
             f"full-source reference; that work item must land first"])
    _fail(_check_objects(manifest, sealed))
    lock, lock_problems = _check_lock(mans, cov_sha, manifest, sealed)
    _fail(lock_problems)
    if progress:
        progress(f"[gate ] seal {sealed['target_grid_digest'][:12]}  "
                 f"coverage {cov_sha[:12]}  lock {lock['name']}  "
                 f"{len(manifest['objects'])} objects")
    disk_problems, stats = _check_disk(root, manifest, lock["sha256"],
                                       workers, progress)
    _fail(disk_problems)
    grids, tile_problems = _check_tiles(root, manifest, workers, progress)
    _fail(tile_problems)
    return build_plan(root, sealed, manifest, cov_sha, lock, grids, stats)


# --------------------------------------------------------------------------
# Materialization: per cell, on request. This is the seam the windowed
# mosaic builds on; nothing here allocates more than one cell.

def _read_tile_guarded(desc):
    """Open, hold to the contract, and return the samples — or refuse.

    The plan proved the world once; the file on disk is the thing being
    read NOW. So every read re-checks: the fixed profile contract (one
    float32 band, no nodata sentinel, the exact georeferencing preflight
    saw), the stat identity captured when the file hashed clean, and — if
    that identity moved — the bytes themselves, re-hashed against the lock
    after the read. Identity must also hold ACROSS the read; a file that
    changes mid-read is refused, not returned.
    """
    import rasterio
    path = desc["path"]
    try:
        st0 = _identity(path)
    except OSError as ex:
        raise PreflightError([f"{path}: {ex}"])
    with rasterio.open(path) as s:
        problems = []
        if s.count != 1 or s.dtypes[0] != "float32":
            problems.append(f"{path}: {s.count} band(s) of {s.dtypes[0]}, "
                            f"this profile takes exactly one float32 band")
        if s.nodata is not None:
            problems.append(f"{path}: declares nodata={s.nodata!r}; this "
                            f"profile forbids a nodata sentinel")
        t = s.transform
        got = (t.a, t.b, t.c, t.d, t.e, t.f)
        want = tuple(desc["src_transform"])
        if any(abs(g - x) > TOL_DEG for g, x in zip(got, want)) \
                or (s.width, s.height) != (desc["src_width"],
                                           desc["src_height"]):
            problems.append(f"{path}: georeferencing moved since preflight "
                            f"({got} != {want})")
        if problems:
            raise PreflightError(problems)
        band = s.read(1, masked=True)
    st1 = _identity(path)
    if st1 != st0:
        raise PreflightError([f"{path}: changed while being read"])
    if st0 != tuple(desc["stat"]) and sha256_file(path) != desc["sha256"]:
        raise PreflightError(
            [f"{path}: changed since preflight and no longer matches the "
             f"locked sha — refusing to serve unproven bytes"])
    invalid = int(np.count_nonzero(np.ma.getmaskarray(band)))
    if invalid:
        raise PreflightError(
            [f"{path}: {invalid} masked/invalid sample(s) — source "
             f"coverage must be complete BEFORE reprojection"])
    arr = np.asarray(band.filled(0), dtype=np.float32)
    bad = int(np.count_nonzero(~np.isfinite(arr)))
    if bad:
        raise PreflightError(
            [f"{path}: {bad} non-finite sample(s) — source coverage must "
             f"be complete BEFORE reprojection"])
    return arr


def materialize_cell(plan, cell):
    """The cell's samples on the canonical grid, float32, fully finite."""
    desc = plan["cells"][tuple(cell)]
    h, w = desc["height"], desc["width"]
    if desc["grade"] == "ocean":
        return np.full((h, w), np.float32(desc["constant"]), dtype=np.float32)
    if desc["grade"] == "glo30":
        return _read_tile_guarded(desc)
    return _materialize_fallback(plan, tuple(cell))


def _materialize_fallback(plan, cell):
    """glo90 onto the canonical cell grid — neighbours first, then cubic.

    A tile's own samples stop half a COARSE pixel short of the cell edge
    (the next tile's first sample continues the grid), so the finest
    canonical samples near an edge interpolate across it. Where the plan
    HAS a glo90 neighbour, its true margin is used; only where the grid
    ends (ocean, glo30, the map edge) is the tile's own edge held. The
    margin is FALLBACK_MARGIN samples because cubic reaches two source
    samples past every destination point — with it, a per-cell
    materialization is sample-identical to warping the combined array.

    KNOWN LIMIT: at a glo90<->ocean boundary the true source is an
    explicit 0 m, and at glo90<->glo30 it is real finer terrain — both
    are edge-held here instead. Proving those margins against a
    full-source reference is a separate work item; until it lands, the
    production gate pins coverages to glo90_fallback=0.
    """
    import rasterio
    from rasterio.warp import reproject, Resampling
    la, lo = cell
    desc = plan["cells"][cell]
    h, w = desc["src_height"], desc["src_width"]
    K = FALLBACK_MARGIN
    center = _read_tile_guarded(desc)

    def neighbour(dla, dlo):
        nd = plan["cells"].get((la + dla, lo + dlo))
        if not nd or nd["grade"] != "glo90_fallback":
            return None
        return _read_tile_guarded(nd)

    # Band indices: [Nm | C | Sm] rows x [Wm | C | Em] cols.
    C_r, C_c = slice(K, K + h), slice(K, K + w)
    Nm, Sm = slice(0, K), slice(K + h, K + h + K)
    Wm, Em = slice(0, K), slice(K + w, K + w + K)
    block = np.empty((h + 2 * K, w + 2 * K), dtype=np.float32)
    block[C_r, C_c] = center
    n, s = neighbour(1, 0), neighbour(-1, 0)
    e_, w_ = neighbour(0, 1), neighbour(0, -1)
    # Sides: the true neighbour's facing margin, else the centre's own edge
    # held — exactly what padding the combined array would produce where the
    # grid simply ends.
    block[Nm, C_c] = n[h - K:h, :] if n is not None else center[0:1, :]
    block[Sm, C_c] = s[0:K, :] if s is not None else center[h - 1:h, :]
    block[C_r, Wm] = w_[:, w - K:w] if w_ is not None else center[:, 0:1]
    block[C_r, Em] = e_[:, 0:K] if e_ is not None else center[:, w - 1:w]
    # Corners: the true diagonal if the plan has one; otherwise extend the
    # side that exists (row-clip past a vertical edge, column-clip past a
    # horizontal one), and only with no neighbour at all hold the centre's
    # corner sample. This matches np.pad(combined, edge) wherever the
    # neighbourhood forms a rectangle.
    for rows, cols, dla, dlo, rc, cc in (
            (Nm, Wm, 1, -1, slice(0, K), slice(0, K)),
            (Nm, Em, 1, 1, slice(0, K), slice(w + K, w + 2 * K)),
            (Sm, Wm, -1, -1, slice(h + K, h + 2 * K), slice(0, K)),
            (Sm, Em, -1, 1, slice(h + K, h + 2 * K),
             slice(w + K, w + 2 * K))):
        diag = neighbour(dla, dlo)
        if diag is not None:
            r0 = h - K if dla == 1 else 0
            c0 = w - K if dlo == -1 else 0
            block[rows, cols] = diag[r0:r0 + K, c0:c0 + K]
        elif (e_ if dlo == 1 else w_) is not None:
            edge_row = K if dla == 1 else K + h - 1
            block[rows, cols] = block[edge_row:edge_row + 1, cc]
        elif (n if dla == 1 else s) is not None:
            edge_col = K if dlo == -1 else K + w - 1
            block[rows, cols] = block[rc, edge_col:edge_col + 1]
        else:
            block[rows, cols] = center[0 if dla == 1 else h - 1,
                                       0 if dlo == -1 else w - 1]
    t = desc["src_transform"]
    padded = rasterio.Affine(t[0], t[1], t[2] - K * t[0],
                             t[3], t[4], t[5] - K * t[4])
    out = np.full((desc["height"], desc["width"]), np.nan, dtype=np.float32)
    reproject(source=block, destination=out,
              src_transform=padded, src_crs="EPSG:4326",
              dst_transform=rasterio.Affine(*desc["transform"]),
              dst_crs="EPSG:4326",
              resampling=Resampling[desc["resampling"]])
    bad = int(np.count_nonzero(~np.isfinite(out)))
    if bad:
        raise PreflightError(
            [f"{desc['path']}: {bad} non-finite sample(s) after fallback "
             f"resampling"])
    return out


def assemble(plan, cells):
    """(array, transform) for a rectangular block of cells.

    Every cell must land on an EXACT pixel offset of the block grid — a
    half-pixel-shifted descriptor is refused here, not blurred in.
    """
    cells = [tuple(c) for c in cells]
    res = plan["source"]["res_deg"]
    w, h = plan["source"]["width"], plan["source"]["height"]
    las = sorted({c[0] for c in cells})
    los = sorted({c[1] for c in cells})
    if [tuple(c) for c in sorted(cells)] != \
            sorted((la, lo) for la in las for lo in los):
        raise PreflightError(["assemble needs a full rectangle of cells"])
    top, left = max(las) + 1, min(los)
    origin = (res, 0.0, left - res / 2.0, 0.0, -res, top + res / 2.0)
    out = np.empty((h * len(las), w * len(los)), dtype=np.float32)
    for c in cells:
        d = plan["cells"][c]
        t = d["transform"]
        col = (t[2] - origin[2]) / res
        row = (origin[5] - t[5]) / res
        if abs(col - round(col)) > 1e-6 or abs(row - round(row)) > 1e-6:
            raise PreflightError(
                [f"cell {c}: descriptor is off the block grid by "
                 f"({col - round(col):+.3f}, {row - round(row):+.3f}) px — "
                 f"a shifted source would smear every boundary it touches"])
        r, q = int(round(row)), int(round(col))
        out[r:r + h, q:q + w] = materialize_cell(plan, c)
    return out, origin

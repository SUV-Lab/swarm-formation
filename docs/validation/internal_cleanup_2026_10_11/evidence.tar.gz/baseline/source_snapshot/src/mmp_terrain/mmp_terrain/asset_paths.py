"""Atomic anchor+DEM path pinning against the installer's version swap.

The asset installer promotes a whole SET (anchor, DEM, tile cache) by
retargeting the single assets/current symlink, and the consumer paths
(data/full_map.tif, data/full_map_dem30.tif) route through it. A loader
that resolves those two links INDEPENDENTLY can straddle a swap and end up
reading a v1 anchor with a v2 DEM (measured on the real symlink layout) —
frame and elevation from two different bakes, silently.

pin_pair() closes that: when both paths route through the SAME
assets/current link, the version root is resolved ONCE and both files are
derived from that one snapshot — a concurrent swap lands entirely before or
entirely after, never between. Explicit staging paths (MMP_FULL_MAP /
MMP_DEM / a corridor_dem parameter) resolve individually, but if both land
inside a versioned asset store with DIFFERENT version components the pair
is refused instead of silently mixed.

Explicit plain staging pairs are additionally bound through their build
sidecars: windowed_mosaic/full_map_assembler stamp every staging raster with
a `<path>.build.json` carrying `coverage_sha256` — the digest of the sealed
coverage manifest both products derive from. Two staging rasters with
DIFFERENT coverage digests are from different pipelines and refuse; rasters
without sidecars (synthetic fixtures, legacy files) pass through untouched.

stdlib-only so the behavior tests run everywhere (no rasterio/rclpy).
"""
import json
import os

_CUR = os.sep + os.path.join("assets", "current") + os.sep
_VER = os.sep + "versions" + os.sep


class MixedAssetVersions(RuntimeError):
    pass


def _route(path):
    """(current_link, remainder) when `path` is a symlink whose target goes
    through .../assets/current/..., else (None, path)."""
    if not os.path.islink(path):
        return None, path
    tgt = os.path.normpath(
        os.path.join(os.path.dirname(path), os.readlink(path)))
    i = tgt.find(_CUR)
    if i < 0:
        return None, tgt
    return tgt[:i + len(_CUR) - 1], tgt[i + len(_CUR):]


def pin_pair(anchor_path, dem_path, require_build=False):
    """Resolve (anchor, dem) for ONE load operation. Returns real paths that
    are guaranteed to come from the same asset version whenever the layout
    makes versions distinguishable; raises MixedAssetVersions otherwise."""
    a_cur, a_rest = _route(anchor_path)
    d_cur, d_rest = _route(dem_path)
    if a_cur and a_cur == d_cur:
        ver = os.path.realpath(a_cur)          # ONE snapshot for the pair
        return os.path.join(ver, a_rest), os.path.join(ver, d_rest)
    a_real = os.path.realpath(anchor_path)
    d_real = os.path.realpath(dem_path)
    a_versioned, d_versioned = _VER in a_real, _VER in d_real
    if a_versioned and d_versioned:
        a_ver = a_real.split(_VER, 1)[1].split(os.sep)[0]
        d_ver = d_real.split(_VER, 1)[1].split(os.sep)[0]
        if a_ver != d_ver:
            raise MixedAssetVersions(
                f"anchor and DEM resolve into DIFFERENT asset versions "
                f"({a_ver} vs {d_ver}) — refusing the mixed set. Re-run the "
                f"load after the install settles, or point MMP_FULL_MAP/"
                f"MMP_DEM (or corridor_dem) at ONE version.")
    elif a_versioned != d_versioned:
        # One side from the versioned store, the other from somewhere else:
        # that is a recipe mix by construction (a versioned raster only
        # belongs with its set-mates).
        which = "anchor" if a_versioned else "DEM"
        raise MixedAssetVersions(
            f"only the {which} resolves into the versioned asset store "
            f"({a_real if a_versioned else d_real}) while its partner is a "
            f"plain path — refusing the half-versioned pair. Point BOTH at "
            f"the installed set, or BOTH at one staging build.")
    else:
        _check_build_pair(a_real, d_real, require_build)
    return a_real, d_real


def _coverage_digest(path):
    """coverage_sha256 from `<path>.build.json`, or None when the sidecar or
    the field is absent (synthetic fixtures, legacy rasters)."""
    try:
        with open(path + ".build.json") as fp:
            return json.load(fp).get("coverage_sha256")
    except (OSError, ValueError):
        return None


def _check_build_pair(a_real, d_real, require_build=False):
    a_cov, d_cov = _coverage_digest(a_real), _coverage_digest(d_real)
    if require_build and not (a_cov and d_cov):
        # Explicit staging overrides must PROVE the pair belongs together —
        # a missing sidecar is not a pass, it is an unverifiable pair (the
        # exact fail-open codex demonstrated: v-versioned anchor aside, any
        # sidecar-less file slipped through the binding).
        missing = [p + ".build.json" for p, c in
                   ((a_real, a_cov), (d_real, d_cov)) if not c]
        raise MixedAssetVersions(
            f"explicit staging override without build provenance: no "
            f"readable coverage_sha256 in {missing} — the pair cannot be "
            f"proven to describe one map. Stage with the pipeline (which "
            f"writes the sidecars) or restore them.")
    if a_cov and d_cov and a_cov != d_cov:
        raise MixedAssetVersions(
            f"anchor and DEM staging builds carry DIFFERENT coverage "
            f"digests ({a_cov[:12]}… vs {d_cov[:12]}…) — they come from "
            f"different pipelines and do not describe one map. Pick the "
            f"matching pair from one staging run.")

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from grid_map_msgs.msg import GridMap

# The library owns raster math and defaults; this node owns ROS state.
from .map_loader import (TARGET_CELL_SIZE_M, CORRIDOR_CELL_BUDGET,
                         CORRIDOR_RES_LADDER, DEFAULT_CORRIDOR_HALFWIDTH_U,
                         DEFAULT_CORRIDOR_RES_M, MapLoadInput,
                         ResolvedMapMission, resolve_map_mission,
                         load_map, normalize_elevation)
from .ros_terrain import to_grid_map

import os

# Data is read from the SOURCE tree, never from the install share: map and
# scenario edits take effect without a rebuild, and setup.py installs no
# data at all (see the data_files comment there). The workspace root comes
# from MMP_WS (container default /ws) so a native checkout can override it;
# same contract as tiles/server.py and the corridor DEM default below.
_WS = os.environ.get('MMP_WS', '/ws')
DATA_DIR = f'{_WS}/src/mmp_terrain/data'

# Mission messages: the RiskZone/DynamicObstacle mirrors ([CORRIDOR-COVER],
# see load_corridor) and the typed LoadMap service. Optional import: if
# mmp_mission_msgs isn't built, terrain still runs off its startup parameters
# — only the /terrain/load_map service and topic-driven corridor coverage are
# skipped (the mission-yaml risk_zones path still works).
try:
    from mmp_mission_msgs.msg import (RiskZoneArray, DynamicObstacleArray,
                                      DynamicObstacleSpec)
    from mmp_mission_msgs.srv import LoadMap
    _HAVE_MISSION_MSGS = True
except Exception:
    _HAVE_MISSION_MSGS = False


class TerrainPublisher(Node):
    def __init__(self):
        super().__init__('terrain_publisher')
        self.get_logger().info('Terrain publisher initializing...')

        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            depth=1
        )
        self.pub = self.create_publisher(GridMap, '/terrain/grid_map', qos)
        self.get_logger().info('Publisher created on /terrain/grid_map with TRANSIENT_LOCAL QoS')

        # [LOAD-RESULT] What the LAST load actually produced, for the LoadMap
        # response: (resolution_m, min_bound_u, max_bound_u). Neither is
        # knowable from the request — the auto ladder may coarsen the
        # resolution, and the crop is clamped to the DEM data bounds.
        # build_grid_map fills it generically from the published geometry; the
        # corridor path overwrites it with its own exact snapped bbox.
        self._last_load = (0.0, (0.0, 0.0), (0.0, 0.0))

        # Typed atomic (re)load. One call carries world + mission + corridor
        # knobs, one response reports what actually loaded — replacing the old
        # /terrain/change_map dance (pre-set parameters, fire a payload-free
        # Trigger, read the log to find out what happened).
        if _HAVE_MISSION_MSGS:
            self.load_map_srv = self.create_service(
                LoadMap, '/terrain/load_map', self.load_map_callback)
            self.get_logger().info('Service created on /terrain/load_map')
        else:
            self.get_logger().warn(
                'mmp_mission_msgs unavailable — /terrain/load_map is NOT '
                'served; terrain runs off its startup parameters only')

        # [CORRIDOR-COVER] Mirror the live zone/obstacle sets. The
        # ObstacleScenario PANEL publishes both RELIABLE + TRANSIENT_LOCAL,
        # so this late subscriber still gets the current set — the crop can
        # enclose zones/obstacles loaded before the mission Run. Mission-yaml
        # risk_zones override these. (The obstacle publisher was VOLATILE
        # until 2026-07 — incompatible with this TL subscription, so no
        # obstacle ever arrived here; fixed panel-side.)
        self._live_zones = []       # [(cx, cy, reach), ...]
        self._live_obstacles = []   # [(cx, cy, half_x, half_y), ...]
        if _HAVE_MISSION_MSGS:
            zqos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE,
                              durability=DurabilityPolicy.TRANSIENT_LOCAL, depth=1)
            self.create_subscription(RiskZoneArray, '/mission/risk_zones',
                                     self._zones_cb, zqos)
            self.create_subscription(DynamicObstacleArray, '/mission/obstacles',
                                     self._obstacles_cb, zqos)
            self.get_logger().info('Subscribed to /mission/risk_zones + '
                                   '/mission/obstacles for corridor coverage')

        self.get_logger().info('Loading terrain data...')
        # A refused startup load (frame-only/stale/out-of-frame mission, a
        # missing raster) must neither KILL the node — dying here took
        # /terrain/load_map down with it, so the session lost the one tool
        # that could fix the input — nor fail OPEN by publishing terrain it
        # does not have. Nothing is published, so every terrain consumer
        # (corridor receipt gate, planner SDF) stays blocked until a
        # corrected /terrain/load_map call succeeds: the same
        # degraded-but-alive contract as a failed service load.
        try:
            grid_map = self.load_tif()
        except Exception as ex:
            grid_map = None
            self.get_logger().error(
                f'startup terrain load REFUSED: {ex}\n'
                f'No terrain is published and terrain-gated planning stays '
                f'blocked. Fix the mission/world and call /terrain/load_map '
                f'— the service is up.')
        if grid_map is not None:
            self.pub.publish(grid_map)
            self.get_logger().info('Terrain GridMap published successfully')
        self.get_logger().info('Node will keep running to serve TRANSIENT_LOCAL subscribers')

    def _zones_cb(self, msg):
        # `replace` semantics must match the planner's, or the mirror drifts
        # from the set actually being planned against: true overwrites the
        # mirror, false extends it. (empty + replace=true is the clear verb.)
        zones = [(z.center.x, z.center.y, z.reach) for z in msg.zones]
        if msg.replace:
            self._live_zones = zones
        else:
            self._live_zones.extend(zones)
        self.get_logger().info(f'[corridor] mirrored {len(self._live_zones)} '
                               f'live risk zone(s) for crop coverage '
                               f'({"replace" if msg.replace else "append"})')

    def _obstacles_cb(self, msg):
        # Kind-aware half-extents: spheres carry their extent in `radius`
        # (size stays zero), cubes in `size`. Reading size for a sphere makes
        # its corridor berth 0x0 — the crop would clip exactly at the sphere.
        obs = []
        for o in msg.obstacles:
            if o.kind == DynamicObstacleSpec.KIND_SPHERE:
                hx = hy = float(o.radius)
            else:
                hx, hy = o.size.x / 2.0, o.size.y / 2.0
            obs.append((o.center.x, o.center.y, hx, hy))
        # Same replace/append contract as the zones above.
        if msg.replace:
            self._live_obstacles = obs
        else:
            self._live_obstacles.extend(obs)
        self.get_logger().info(f'[corridor] mirrored '
                               f'{len(self._live_obstacles)} live '
                               f'obstacle(s) for crop coverage '
                               f'({"replace" if msg.replace else "append"})')

    def load_map_callback(self, request, response):
        """mmp_mission_msgs/LoadMap: apply the request, load, publish, report.

        The request fields drive the SAME load path as startup (they are
        written onto the node's parameters first, so a later parameter-driven
        reload is consistent with what the service just did). Any failure —
        missing tif, degenerate corridor — comes back as success=false with a
        message; the previously published map stays valid.
        """
        world_name = ''
        # Echoed unconditionally — the caller's stale-response discard must
        # work on FAILED responses too, or an old error answer could be
        # mistaken for the newest request's verdict.
        response.request_token = request.request_token
        # Parameter rollback state: values COMMIT only with a successful
        # load. A refused mission must not leave its path/world in the node
        # state — a later parameter-driven reload would replay the failure.
        prev_params = {}
        params_written = False
        # EVERYTHING is inside the try: a service callback that raises takes
        # the executor down and the caller waits forever on a future that is
        # never fulfilled. A failed load must answer, not disappear.
        try:
            # Declares the corridor parameters if this is the first load.
            self._corridor_params()
            if not self.has_parameter('world'):
                self.declare_parameter('world', 'small_island')

            if request.resolve_only:
                # Resolve-only: parse + resolve + answer, changing NOTHING —
                # no request-driven parameter writes, no raster load, no
                # publish. (_corridor_params above only declares defaults;
                # it never applies a request value.) The panel uses this to
                # obtain typed mission coordinates; an actual run still goes
                # through the corridor path below, which resolves and loads
                # from ONE snapshot.
                if not request.mission_path:
                    raise ValueError('resolve_only requires mission_path')
                dem_path = self._corridor_params()[3]
                ctx = self._pin_and_resolve(request.mission_path, dem_path)
                self._fill_mission(response, ctx)
                response.success = True
                response.message = (
                    f'resolved {request.mission_path} against frame '
                    f'{ctx.frame_digest[:12]} — nothing loaded or published')
                self.get_logger().info(f'[load_map] {response.message}')
                return response

            params = [Parameter('corridor_mission', Parameter.Type.STRING,
                                request.mission_path)]
            # An EMPTY world keeps whatever is loaded — "none" is already the
            # explicit clear-the-terrain verb, so blank can only mean
            # "unspecified" and must not become a lookup for ".tif".
            if request.world:
                params.append(Parameter('world', Parameter.Type.STRING,
                                        request.world))
            # 0 = "use the node default" for both numerics (see LoadMap.srv),
            # so only a positive value overrides — the parameter is left
            # untouched, which keeps a launch-file / CLI override in force
            # (and makes an explicit value from an earlier call sticky until
            # the next explicit one). Sent as DOUBLE; the parameters are
            # dynamic-typed and float()-ed in _corridor_params.
            if request.corridor_halfwidth_u > 0.0:
                params.append(Parameter('corridor_halfwidth_u',
                                        Parameter.Type.DOUBLE,
                                        float(request.corridor_halfwidth_u)))
            if request.resolution_m > 0.0:
                params.append(Parameter('corridor_res_m',
                                        Parameter.Type.DOUBLE,
                                        float(request.resolution_m)))
            prev_params = {p.name: self.get_parameter(p.name).value
                           for p in params}
            results = self.set_parameters(params)
            # set_parameters applies one by one; mark written BEFORE the
            # result check so a partial apply still rolls back.
            params_written = True
            rejected = [p.name for p, r in zip(params, results)
                        if not r.successful]
            if rejected:
                raise ValueError(f'parameter write rejected for {rejected}')

            world_name = self.get_parameter(
                'world').get_parameter_value().string_value
            self.get_logger().info(
                f'[load_map] world={world_name} '
                f'mission="{request.mission_path}" '
                f'halfwidth_u={request.corridor_halfwidth_u} '
                f'res_m={request.resolution_m}')

            # Corridor loads resolve HERE, once: the same snapshot fills the
            # typed mission response and seeds the corridor bbox inside
            # load_tif/load_corridor. _fill_mission also runs the
            # command-field policy (no initial state, flag/vector mismatch,
            # non-finite values → the whole call fails) BEFORE anything is
            # loaded or published.
            ctx = None
            if request.mission_path and world_name == 'full_map':
                dem_path = self._corridor_params()[3]
                ctx = self._pin_and_resolve(request.mission_path, dem_path)
                self._fill_mission(response, ctx)

            grid_map = self.load_tif(ctx=ctx)
            self.pub.publish(grid_map)

            res_m, min_u, max_u = self._last_load
            response.success = True
            response.actual_resolution_m = res_m
            response.min_bound_u = [min_u[0], min_u[1]]
            response.max_bound_u = [max_u[0], max_u[1]]
            if world_name == 'none':
                response.message = 'terrain cleared (world=none)'
            elif request.mission_path and world_name == 'full_map':
                response.message = (
                    f'loaded corridor for {request.mission_path} @ '
                    f'{res_m:.0f} m, bbox u=({min_u[0]:.1f},{min_u[1]:.1f})..'
                    f'({max_u[0]:.1f},{max_u[1]:.1f})')
            else:
                response.message = (f'loaded map "{world_name}" @ '
                                    f'{res_m:.1f} m')
                # load_tif only warns about this in the log; the caller asked
                # for a crop and got a full world, so say so in the response.
                if request.mission_path:
                    response.message += (' — corridor mode IGNORED, crops are '
                                         'full-map-frame only')
            self.get_logger().info(f'[load_map] {response.message}')
        except Exception as e:
            response.success = False
            # No half-truths on failure: a load that died AFTER the mission
            # resolved must not ship resolved-looking data next to
            # success=false — a consumer that only checked mission_resolved
            # would fly a mission whose terrain never loaded.
            response.mission_resolved = False
            response.mission = type(response.mission)()
            response.message = f'{type(e).__name__}: {e}'
            if params_written:
                try:
                    restore = self.set_parameters(
                        [Parameter(name, value=value)
                         for name, value in prev_params.items()])
                    # A rejecting parameter callback refuses via the RESULT,
                    # not an exception — an unchecked restore would be the
                    # silent failure this branch exists to report.
                    not_restored = [n for n, r in zip(prev_params, restore)
                                    if not r.successful]
                    if not_restored:
                        raise RuntimeError(
                            f'restore write rejected for {not_restored}')
                except Exception as restore_ex:
                    self.get_logger().error(
                        f'[load_map] parameter ROLLBACK FAILED: {restore_ex} '
                        f'— node parameters may still hold the failed '
                        f'request values {sorted(prev_params)}')
            self.get_logger().error(f'[load_map] failed: {response.message}')

        return response

    # ------------------------------------------------------------------
    # Mission-corridor mode: crop the fine (30 m) DEM around the mission
    # start->goal corridor, KEEPING FULL-MAP-FRAME WORLD COORDINATES (the crop
    # is a sub-rectangle of the full-map frame; only grid_map pose moves).
    # Missions / risk zones / TerrainTiles need no coordinate translation.
    # The planner then sees ~30 m terrain instead of the full 250 m map
    # (a 250 m cell averages away narrow ridges the display clearly shows).
    # ------------------------------------------------------------------
    CORRIDOR_CELL_BUDGET = CORRIDOR_CELL_BUDGET
    CORRIDOR_RES_LADDER = CORRIDOR_RES_LADDER

    def _corridor_params(self):
        # The numeric params default to DOUBLE, so a bare-int CLI override
        # (corridor_halfwidth_u:=40) would raise InvalidParameterType. Declare
        # them dynamic-typed so int OR double is accepted; both are float()-ed
        # below. (grid_map res/halfwidth are floats internally.)
        from rcl_interfaces.msg import ParameterDescriptor
        dyn = ParameterDescriptor(dynamic_typing=True)
        numeric = {'corridor_halfwidth_u', 'corridor_res_m'}
        for name, default in (('corridor_mission', ''),
                              ('corridor_halfwidth_u', DEFAULT_CORRIDOR_HALFWIDTH_U),
                              ('corridor_res_m', DEFAULT_CORRIDOR_RES_M),
                              ('corridor_dem', os.environ.get(
                                  'MMP_DEM',
                                  f'{DATA_DIR}/full_map_dem30.tif'))):
            if not self.has_parameter(name):
                if name in numeric:
                    self.declare_parameter(name, default, dyn)
                else:
                    self.declare_parameter(name, default)
        return (self.get_parameter('corridor_mission').value,
                float(self.get_parameter('corridor_halfwidth_u').value),
                float(self.get_parameter('corridor_res_m').value),
                self.get_parameter('corridor_dem').value)

    _Resolved = ResolvedMapMission  # legacy snapshot name

    def _diagnostic(self, level, message):
        getattr(self.get_logger(), level)(message)

    def _map_input(self, world, mission_path, halfwidth_u, res_m, dem_path):
        # Environment and topic state are sampled once at the ROS boundary.
        return MapLoadInput(
            world=world, data_dir=DATA_DIR, mission_path=mission_path,
            halfwidth_u=halfwidth_u, resolution_m=res_m, dem_path=dem_path,
            full_map_override=os.environ.get('MMP_FULL_MAP'),
            vrt_resolution=os.environ.get('MMP_DEM_VRT_RES'),
            live_zones=self._live_zones, live_obstacles=self._live_obstacles,
            cell_budget=self.CORRIDOR_CELL_BUDGET,
            resolution_ladder=self.CORRIDOR_RES_LADDER)

    def _pin_and_resolve(self, mission_path, dem_path):
        request = self._map_input('full_map', mission_path,
                                  DEFAULT_CORRIDOR_HALFWIDTH_U,
                                  DEFAULT_CORRIDOR_RES_M, dem_path)
        return resolve_map_mission(request, self._diagnostic)

    def _fill_mission(self, response, ctx):
        """Fill response.mission from ONE _Resolved snapshot.

        command_fields is the same authority the panel's C++ yaml parser used
        to duplicate; raising here (no initial state, flag/vector mismatch,
        non-finite values) fails the WHOLE call before anything is loaded or
        published — the caller's except turns it into success=false.
        """
        from geometry_msgs.msg import Point
        from .mission import command_fields
        cmd = command_fields(ctx.mission.raw)
        msn = response.mission
        msn.start.x, msn.start.y, msn.start.z = ctx.mission.start
        msn.goal.x, msn.goal.y, msn.goal.z = ctx.mission.goal
        for w in ctx.mission.waypoints:
            p = Point()
            p.x, p.y, p.z = w
            msn.waypoints.append(p)
        msn.formation_type = cmd['formation_type']
        msn.formation_scale = cmd['formation_scale']
        msn.initial_speed_mps = cmd['initial_speed_mps']
        msn.use_initial_speed = cmd['use_initial_speed']
        msn.use_initial_velocity = cmd['use_initial_velocity']
        msn.use_initial_acceleration = cmd['use_initial_acceleration']
        msn.use_final_velocity = cmd['use_final_velocity']
        msn.use_final_acceleration = cmd['use_final_acceleration']
        for key in ('initial_velocity_mps', 'initial_acceleration_mps2',
                    'final_velocity_mps', 'final_acceleration_mps2'):
            vec = getattr(msn, key)
            vec.x, vec.y, vec.z = cmd[key]
        msn.warnings = list(ctx.warnings) + cmd['warnings']
        msn.mission_sha256 = ctx.mission_sha
        msn.frame_digest = ctx.frame_digest
        response.mission_resolved = True

    def _grid_message(self, result):
        msg = to_grid_map(result, self.get_clock().now().to_msg())
        self._last_load = result.load_metadata
        if result.elevation_u is not None:
            rows, cols = result.elevation_u.shape
            self.get_logger().info(
                f'GridMap created: {rows * cols} data points, '
                f'{len(msg.layers)} layers ({", ".join(msg.layers)})')
        return msg

    def load_corridor(self, mission_path, halfwidth_u, res_m, dem_path,
                      ctx=None):
        request = self._map_input('full_map', mission_path, halfwidth_u,
                                  res_m, dem_path)
        # The service supplies its already validated snapshot; startup asks
        # the library to resolve geometry only, as before.
        result = load_map(request, mission_snapshot=ctx,
                          diagnostic=self._diagnostic)
        return self._grid_message(result)

    def load_tif(self, ctx=None):
        if not self.has_parameter('world'):
            self.declare_parameter('world', 'small_island')
        world = self.get_parameter('world').get_parameter_value().string_value
        mission, halfwidth_u, res_m, dem_path = self._corridor_params()
        request = self._map_input(world, mission, halfwidth_u, res_m, dem_path)
        result = load_map(request, mission_snapshot=ctx,
                          diagnostic=self._diagnostic)
        return self._grid_message(result)

    def build_grid_map(self, elevation, actual_cell_size, origin_u=(0.0, 0.0)):
        """Compatibility wrapper: normalize raw metres, then serialize."""
        result = normalize_elevation(elevation, actual_cell_size, origin_u,
                                     self._diagnostic)
        return self._grid_message(result)


def main():
    print('Initializing rclpy...')
    rclpy.init()

    print('Creating TerrainPublisher node...')
    node = TerrainPublisher()

    print('Spinning node...')
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Load normalized terrain through the public API, without starting ROS."""
import argparse
import json
import sys

import numpy as np
from mmp_terrain.map_loader import MapLoadInput, load_map


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir',required=True)
    parser.add_argument('--world',default='full_map')
    parser.add_argument('--mission',default='')
    parser.add_argument('--halfwidth-u',type=float)
    parser.add_argument('--resolution-m',type=float)
    parser.add_argument('--full-map')
    parser.add_argument('--dem')
    parser.add_argument('--vrt-resolution')
    args=parser.parse_args()
    knobs={}
    for flag,key in [('halfwidth_u','halfwidth_u'),('resolution_m','resolution_m'),
                     ('full_map','full_map_override'),('dem','dem_path'),
                     ('vrt_resolution','vrt_resolution')]:
        value=getattr(args,flag)
        if value is not None:
            knobs[key]=value
    request=MapLoadInput(world=args.world,data_dir=args.data_dir,
                          mission_path=args.mission,**knobs)
    result=load_map(request,diagnostic=lambda level,message:
                    print(f'[{level}] {message}',file=sys.stderr))
    print(json.dumps({
        'shape':None if result.elevation_u is None else list(result.elevation_u.shape),
        'dtype':None if result.elevation_u is None else str(result.elevation_u.dtype),
        'nan_count':0 if result.elevation_u is None else int(np.isnan(result.elevation_u).sum()),
        'resolution_m':result.resolution_m,'min_bound_u':result.min_bound_u,
        'max_bound_u':result.max_bound_u,'source_paths':result.source_paths,
        'mission_sha256':None if result.mission is None else result.mission.mission_sha,
        'frame_digest':None if result.mission is None else result.mission.frame_digest,
    },indent=2))


if __name__=='__main__':
    main()

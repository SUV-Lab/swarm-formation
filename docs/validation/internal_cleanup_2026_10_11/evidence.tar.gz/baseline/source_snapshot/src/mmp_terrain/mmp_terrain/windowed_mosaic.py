"""Windowed DEM + hillshade writer over a proven source plan.

The legacy path merges every source tile into one array; on the sealed
east-asia grid that array alone is tens of GiB before the hillshade
temporaries land on top of it. This writer walks the DESTINATION in
fixed tiles instead, and for each tile materializes only the source
block that tile can see — so peak memory is set by the tile size, not by
the map.

WHAT THE OUTPUT IS, exactly: a pure function of (plan, z_factor) and the
sealed recipe constants below. GDAL's warper approximates the dst->src
transformer with piecewise-linear segments whose layout depends on each
warp call's DESTINATION EXTENT — so "the same map in different windows"
is NOT the same map (measured: cm-median, metre-scale on relief, tens of
metres where an averaging kernel straddles a coast seam). rasterio 1.2 /
GDAL 3.4 offer no working exact-transformer knob. This module therefore
PINS the compute tiling: every warp call uses a grid-aligned WARP_TILE
destination extent, always, so a rerun is bit-identical and there is no
window knob to vary. Where the transform is the identity (tests), the
approximation is exact and any tiling equals the single pass
bit-for-bit; on a projected target the recipe inherits the same
approximate-transformer placement error class as the shipped map's own
single gdalwarp — pinned, not eliminated.

What makes a tile honest:

  * the source block carries a HALO (`SRC_MARGIN_PX` source samples past
    the tile's inverse-projected footprint) so the Horn gradient at
    every contributing sample is the central difference the full array
    would have used, and the average kernel never reaches past what was
    read;
  * the destination tile is warped with its own halo (`DST_HALO_PX`)
    and cropped, so warp-edge behaviour cannot differ between a tile
    interior and a tile boundary;
  * blocks are CLIPPED to the sealed support's bounding box — where the
    world ends, the one-sided gradient lands on exactly the samples the
    single-pass computation would end on;
  * tile COMPLETION is proven by a fingerprinted sidecar journal — one
    row per finished tile, checked against the expected key set (no
    duplicates, no strangers, no gaps) BEFORE promotion. Pixel values
    prove nothing about completion: 0 m is honest sea, and an unwritten
    block reading as NaN is a GDAL default, not a contract;
  * the output file is still born NaN (nodata) as a second, independent
    tripwire, and the verify pass re-reads every sample;
  * the temp file is claimed O_EXCL (a second builder refuses instead of
    truncating the first one's work), its identity is captured when the
    dataset closes, and re-checked after verification — os.replace
    promotes the bytes that were verified, or nothing.

The RSS ceiling is enforced AFTER each tile: it bounds the run, not the
inside of a single tile — a tile's own allocations land before the
check can see them. The target grid comes from the plan (the sealed
profile) and is never recomputed here. RGB bands are somebody else's
decision; this writer produces the staging DEM/hillshade pair, nothing
more.
"""
import json
import math
import os
import resource
import time
from collections import OrderedDict

import numpy as np

from . import source_coverage as SC
from .hillshade import hillshade_geographic

# The sealed recipe. Changing any of these changes the artifact and is a
# deliberate act, recorded in the build fingerprint.
BUILD_SCHEMA = 1
WARP_TILE = 1024         # fixed, grid-aligned destination extent per warp
DST_HALO_PX = 2          # warp margin in destination pixels, cropped after
SRC_MARGIN_PX = 8        # source samples past the tile's inverse bounds
ELEV_SANE_M = (-1000.0, 9000.0)


class WindowedError(RuntimeError):
    def __init__(self, problems):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems))


def _rss_gib():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1 << 20)


class _CellCache:
    """A handful of materialized cells; tiles overlap cell boundaries,
    and re-reading a 50 MB source tile for every neighbouring compute
    tile is wasted I/O the cache cap keeps bounded."""

    def __init__(self, plan, cap):
        self.plan, self.cap, self.d = plan, cap, OrderedDict()

    def get(self, cell):
        if cell in self.d:
            self.d.move_to_end(cell)
            return self.d[cell]
        a = SC.materialize_cell(self.plan, cell)
        self.d[cell] = a
        if len(self.d) > self.cap:
            self.d.popitem(last=False)
        return a


def _support_index_bbox(plan):
    """(kx0, kx1, ky0, ky1) sample-index hull of the sealed support.

    Sample index k means coordinate k * res: the canonical grid puts every
    sample on an integer multiple of the resolution, in both axes.
    """
    W = round(1.0 / plan["source"]["res_deg"])
    los = [c[1] for c in plan["cells"]]
    las = [c[0] for c in plan["cells"]]
    return (min(los) * W, (max(los) + 1) * W - 1,
            (max(las) + 1) * W, min(las) * W + 1)


def _read_block(cache, plan, kx0, kx1, ky0, ky1):
    """Samples kx0..kx1 (west->east) x ky0..ky1 (north->south, ky0 top).

    Cells the plan does not hold are left NaN — legal only outside the
    frame's sealed margin, and the post-warp finite check is the judge of
    that, not this function.
    """
    res = plan["source"]["res_deg"]
    W = round(1.0 / res)
    h, w = ky0 - ky1 + 1, kx1 - kx0 + 1
    out = np.full((h, w), np.nan, dtype=np.float32)
    la0, la1 = (ky1 - 1) // W, (ky0 - 1) // W
    lo0, lo1 = math.floor(kx0 / W), math.floor(kx1 / W)
    for la in range(la0, la1 + 1):
        for lo in range(lo0, lo1 + 1):
            if (la, lo) not in plan["cells"]:
                continue
            cy0, cy1 = (la + 1) * W, la * W + 1      # cell ky range, top/bot
            cx0, cx1 = lo * W, (lo + 1) * W - 1
            iy0, iy1 = min(ky0, cy0), max(ky1, cy1)  # intersection
            ix0, ix1 = max(kx0, cx0), min(kx1, cx1)
            if iy0 < iy1 or ix0 > ix1:
                continue
            arr = cache.get((la, lo))
            out[ky0 - iy0:ky0 - iy1 + 1, ix0 - kx0:ix1 - kx0 + 1] = \
                arr[cy0 - iy0:cy0 - iy1 + 1, ix0 - cx0:ix1 - cx0 + 1]
    tf = (res, 0.0, kx0 * res - res / 2.0, 0.0, -res, ky0 * res + res / 2.0)
    return out, tf


def _src_res_m(plan):
    las = [c[0] for c in plan["cells"]]
    lat_mid = (min(las) + max(las) + 1) / 2.0
    return plan["source"]["res_deg"] * math.pi / 180.0 * 6371000.0 \
        * math.cos(math.radians(lat_mid))


def _dst_res_m(plan):
    """The output cell size in METRES, whatever unit the target CRS uses.

    Comparing the raw transform value against a metre count is only right
    when the target is metric; a degree-unit target would look 'finer'
    by five orders of magnitude and trip the guard for the wrong reason.
    """
    import rasterio
    from rasterio.warp import transform as _transform
    t = plan["target"]
    tf = rasterio.Affine(*t["transform"])
    crs = rasterio.crs.CRS.from_user_input(t["crs_wkt"])
    cx, cy = t["width"] / 2.0, t["height"] / 2.0
    pts = [tf * (cx, cy), tf * (cx + 1, cy), tf * (cx, cy + 1)]
    lons, lats = _transform(crs, "EPSG:4326",
                            [p[0] for p in pts], [p[1] for p in pts])
    m = math.pi / 180.0 * 6371000.0
    dx = abs(lons[1] - lons[0]) * m * math.cos(math.radians(lats[0]))
    dy = abs(lats[2] - lats[0]) * m
    return (dx + dy) / 2.0


def _identity(path):
    st = os.stat(path)
    return (st.st_ino, st.st_size, st.st_mtime_ns)


def _fingerprint(plan, z_factor, dem_vrt_res=None):
    """What this build IS. A journal for a different plan, z, or recipe
    proves nothing about this one."""
    t = plan["target"]
    return {"build_schema": BUILD_SCHEMA,
            "coverage_sha256": plan["coverage_sha256"],
            "target_grid_digest": plan["target_grid_digest"],
            "z_factor": float(z_factor),
            "warp_tile": WARP_TILE, "dst_halo_px": DST_HALO_PX,
            "src_margin_px": SRC_MARGIN_PX, "blocksize": 256,
            "dem_vrt_res": dem_vrt_res,
            "width": t["width"], "height": t["height"], "bands": 2}


def _tile_keys(height, width, tile):
    return [(r0, c0) for r0 in range(0, height, tile)
            for c0 in range(0, width, tile)]


def _create(path, height, width, crs, tf, count=2, nodata=float("nan"),
            bigtiff="IF_SAFER", blocksize=256):
    """The temp file: claimed O_EXCL, then born NaN.

    O_EXCL first — a second builder aimed at the same output must refuse
    loudly, not truncate the bytes the first one is still writing.
    nodata=NaN makes GDAL hand back NaN for every block no tile ever
    wrote, which is a second tripwire behind the completion journal (the
    journal is the proof; pixel values are not, since 0 m is honest sea).
    """
    try:
        os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
    except FileExistsError:
        raise WindowedError(
            [f"{path} already exists — another build may own it; remove "
             f"it explicitly to retry"])
    import rasterio
    return rasterio.open(
        path, "w", driver="GTiff", height=height, width=width, count=count,
        dtype="float32", crs=crs, transform=tf, nodata=nodata,
        compress="deflate", tiled=True, bigtiff=bigtiff,
        blockxsize=blocksize, blockysize=blocksize)


def write_dem(plan, out_path, z_factor, max_rss_gib=None,
              cell_cache=16, progress=None, dem_vrt_res=None):
    """Write the staging DEM (band 1) + hillshade (band 2), atomically.

    Raises WindowedError — leaving `out_path + ".tmp"` and its journal
    behind as evidence — on ANY failure: a tile that errors, a journal
    that does not account for every expected tile exactly once, a
    non-finite sample inside the frame, an out-of-sanity elevation, a
    temp file whose identity moved after verification, or a peak RSS
    above the ceiling.
    """
    import rasterio
    from rasterio.warp import reproject, Resampling
    from rasterio.windows import Window

    if not (z_factor > 0.0):
        raise WindowedError(
            [f"z_factor {z_factor!r} is not positive — a zero or negative "
             f"exaggeration bakes a flat or inverted hillshade"])
    t = plan["target"]
    tf = rasterio.Affine(*t["transform"])
    crs = rasterio.crs.CRS.from_user_input(t["crs_wkt"])
    width, height = t["width"], t["height"]
    res_out = _dst_res_m(plan)
    src_m = _src_res_m(plan)
    if res_out < 0.9 * src_m:
        raise WindowedError(
            [f"output at {res_out:g} m is FINER than the {src_m:.0f} m "
             f"source — this writer is proven for average downsampling "
             f"only"])

    res = plan["source"]["res_deg"]
    sx0, sx1, sy0, sy1 = _support_index_bbox(plan)
    cache = _CellCache(plan, cell_cache)
    fp = _fingerprint(plan, z_factor, dem_vrt_res)
    tmp = out_path + ".tmp"
    journal = tmp + ".journal"
    t_start = time.monotonic()

    def one_tile(r0, r1, c0, c1, ds):
        rh0, rh1 = max(0, r0 - DST_HALO_PX), min(height, r1 + DST_HALO_PX)
        ch0, ch1 = max(0, c0 - DST_HALO_PX), min(width, c1 + DST_HALO_PX)
        wtf = tf * rasterio.Affine.translation(ch0, rh0)
        bounds = rasterio.transform.array_bounds(rh1 - rh0, ch1 - ch0, wtf)
        from rasterio.warp import transform_bounds
        lon0, lat0, lon1, lat1 = transform_bounds(crs, "EPSG:4326", *bounds,
                                                  densify_pts=21)
        kx0 = max(sx0, math.floor(lon0 / res) - SRC_MARGIN_PX)
        kx1 = min(sx1, math.ceil(lon1 / res) + SRC_MARGIN_PX)
        ky0 = min(sy0, math.ceil(lat1 / res) + SRC_MARGIN_PX)
        ky1 = max(sy1, math.floor(lat0 / res) - SRC_MARGIN_PX)
        block, btf = _read_block(cache, plan, kx0, kx1, ky0, ky1)
        hs = hillshade_geographic(block, rasterio.Affine(*btf), z_factor)
        out = {}
        for band, src_arr in ((1, block), (2, hs)):
            d = np.full((rh1 - rh0, ch1 - ch0), np.nan, dtype=np.float32)
            # NO nodata here, deliberately: with src_nodata=NaN the average
            # resampler EXCLUDES NaN sources and returns a finite lie —
            # the exact bias this pipeline exists to stop. Without it a NaN
            # that reaches any destination footprint propagates to NaN
            # output, and the verify pass refuses the file.
            reproject(source=src_arr, destination=d,
                      src_transform=rasterio.Affine(*btf),
                      src_crs="EPSG:4326",
                      dst_transform=wtf, dst_crs=crs,
                      resampling=Resampling.average,
                      num_threads=os.cpu_count() or 4)
            out[band] = d[r0 - rh0:r1 - rh0, c0 - ch0:c1 - ch0]
        del block, hs
        for band in (1, 2):
            ds.write(out[band], band,
                     window=Window(c0, r0, c1 - c0, r1 - r0))

    keys = _tile_keys(height, width, WARP_TILE)
    total = len(keys)
    with _create(tmp, height, width, crs, tf) as ds, \
            open(journal, "w") as jfp:
        if dem_vrt_res is not None:
            # The map carries its own runtime knowledge: terrain_publisher
            # reads this tag and pins the corridor WarpedVRT grid without
            # anyone remembering an environment variable. The Korea anchor
            # has no tag and keeps its automatic grid, exactly as shipped.
            ds.update_tags(MMP_DEM_VRT_RES=repr(float(dem_vrt_res)))
        jfp.write("#" + json.dumps(fp, sort_keys=True) + "\n")
        jfp.flush()
        for done, (r0, c0) in enumerate(keys, 1):
            one_tile(r0, min(height, r0 + WARP_TILE),
                     c0, min(width, c0 + WARP_TILE), ds)
            jfp.write(f"{r0},{c0}\n")
            jfp.flush()
            if max_rss_gib is not None and _rss_gib() > max_rss_gib:
                raise WindowedError(
                    [f"peak RSS {_rss_gib():.2f} GiB exceeded the "
                     f"{max_rss_gib:g} GiB ceiling after window "
                     f"{done}/{total}"])
            if progress and done % 10 == 0:
                progress(f"[write] {done}/{total} windows  "
                         f"rss {_rss_gib():.2f} GiB")
    # Overviews before promotion: a served anchor without them turns every
    # shallow-zoom read into a whole-extent scan (measured 136x wall).
    factors = [f for f in OVERVIEW_FACTORS if min(width, height) // f >= 1]
    if progress:
        progress(f"[write] building overviews {factors} ...")
    with rasterio.open(tmp, "r+") as ds2:
        ds2.build_overviews(factors, Resampling.average)
    ident = _identity(tmp)

    problems = _verify_completion(journal, fp, keys)
    problems += _verify(tmp, plan, factors=factors)
    if problems:
        raise WindowedError(problems + [f"{tmp} NOT promoted"])
    sha = SC.sha256_file(tmp)
    with rasterio.open(tmp) as dso:
        actual_ovr = list(dso.overviews(1))
    st = os.stat(tmp)
    if _identity(tmp) != ident:
        raise WindowedError(
            [f"{tmp} changed between writing and promotion — the verified "
             f"bytes are not the bytes at the name; NOT promoted"])
    os.replace(tmp, out_path)
    # overviews: the REQUESTED factors and what GDAL actually stored are
    # both recorded — on odd dimensions GDAL rounds a factor (128 -> 127),
    # and a provenance manifest must say what a reopen will really see.
    build = dict(fp, tiles=total, sha256=sha,
                 overviews=actual_ovr, overviews_requested=factors,
                 file_bytes=st.st_size, allocated_bytes=st.st_blocks * 512,
                 peak_rss_gib=round(_rss_gib(), 3),
                 elapsed_s=round(time.monotonic() - t_start, 1))
    btmp = out_path + ".build.json.tmp"
    with open(btmp, "w") as fpb:
        json.dump(build, fpb, indent=1)
    os.replace(btmp, out_path + ".build.json")
    os.remove(journal)
    if progress:
        progress(f"[write] verified whole and promoted to {out_path}  "
                 f"sha {sha[:12]}  (peak rss {_rss_gib():.2f} GiB)")


OVERVIEW_FACTORS = (2, 4, 8, 16, 32, 64, 128)
# Imagery resampling contract (bmng-v1). 500 m -> 250 m is an UPSAMPLE:
# average sees at most one source cell per output cell and degenerates to
# 2x2 block replication; cubic rings at hard colour edges. Bilinear, both
# ways. The Sentinel tone curve (0..160 + gamma) is likewise forbidden on
# BMNG. The imagery writer consumes these names; changing them is a recipe
# change, not a tweak.
BMNG_UPSAMPLE_RESAMPLING = "bilinear"
KOREA_RGB_REPROJECT_RESAMPLING = "bilinear"
DEM30_BLOCKSIZE = 512      # the shipped Korea DEM's block size (measured
                           # faster than 256 for corridor reads)


def _dem30_fingerprint(plan):
    """The fine DEM is a SOURCE-space product: it depends on the coverage
    decision and the support, not on the target grid or a z factor."""
    sx0, sx1, sy0, sy1 = _support_index_bbox(plan)
    return {"build_schema": BUILD_SCHEMA, "kind": "dem30",
            "coverage_sha256": plan["coverage_sha256"],
            "source_support_digest": plan["source_support_digest"],
            "res_deg": plan["source"]["res_deg"],
            "bbox_kx": [sx0, sx1], "bbox_ky": [sy1, sy0], "bands": 1,
            # 512 px blocks, matching the shipped Korea DEM: 256 px blocks
            # measured ~20% slower per corridor cell (4x the tiles per
            # read region).
            "blocksize": DEM30_BLOCKSIZE}


def write_dem30(plan, out_path, max_rss_gib=None, progress=None):
    """Write the fine corridor DEM: the canonical source grid itself,
    pasted cell by cell — no warp at all — over the sealed support's
    bounding box, with internal overviews, atomically.

    Contract (what the corridor loader and /ftile/hgt consume): band 1
    only, float32 metres, EPSG:4326, nodata=None with real values
    everywhere — sea is honest 0 m from the completed sources. Cells the
    ragged support does not hold are filled 0.0: they lie beyond the
    sealed margin, no frame-clamped consumer can read them, and finite
    zero compresses to nothing while keeping the blanket verification
    simple. Overviews are built BEFORE promotion — a fine DEM without
    them turns every shallow-zoom read into a whole-extent scan
    (measured: ~136x wall, ~13x RSS on the 250 m anchor alone).
    """
    import rasterio
    from rasterio.enums import Resampling as RioResampling
    from rasterio.warp import transform_bounds
    from rasterio.windows import Window

    res = plan["source"]["res_deg"]
    W = round(1.0 / res)
    sx0, sx1, sy0, sy1 = _support_index_bbox(plan)
    width, height = sx1 - sx0 + 1, sy0 - sy1 + 1
    tf = rasterio.Affine(res, 0.0, sx0 * res - res / 2.0,
                         0.0, -res, sy0 * res + res / 2.0)
    # The warped DEM must COVER the sealed frame: a systematically short
    # DEM silently truncates every mission near the frame edge.
    t = plan["target"]
    dcrs = rasterio.crs.CRS.from_user_input(t["crs_wkt"])
    dtf = rasterio.Affine(*t["transform"])
    fb = rasterio.transform.array_bounds(t["height"], t["width"], dtf)
    flon0, flat0, flon1, flat1 = transform_bounds(dcrs, "EPSG:4326", *fb,
                                                  densify_pts=21)
    ext = rasterio.transform.array_bounds(height, width, tf)
    if not (ext[0] <= flon0 and ext[1] <= flat0
            and ext[2] >= flon1 and ext[3] >= flat1):
        raise WindowedError(
            [f"support bbox {ext} does not cover the sealed frame "
             f"({flon0:.3f},{flat0:.3f})..({flon1:.3f},{flat1:.3f})"])

    la_lo = (sy1 - 1) // W
    la_hi = (sy0 - 1) // W
    lo_lo = sx0 // W
    lo_hi = sx1 // W
    keys = [(la, lo) for la in range(la_hi, la_lo - 1, -1)
            for lo in range(lo_lo, lo_hi + 1)]
    total = len(keys)
    fp = _dem30_fingerprint(plan)
    cache = _CellCache(plan, 4)
    tmp = out_path + ".tmp"
    journal = tmp + ".journal"
    t_start = time.monotonic()

    with _create(tmp, height, width, "EPSG:4326", tf, count=1,
                 nodata=None, bigtiff="YES",
                 blocksize=DEM30_BLOCKSIZE) as ds, \
            open(journal, "w") as jfp:
        jfp.write("#" + json.dumps(fp, sort_keys=True) + "\n")
        jfp.flush()
        for done, (la, lo) in enumerate(keys, 1):
            if (la, lo) in plan["cells"]:
                band = cache.get((la, lo))
            else:
                band = np.zeros((W, W), dtype=np.float32)
            row = sy0 - (la + 1) * W          # cell top sample -> file row
            col = lo * W - sx0
            ds.write(band, 1, window=Window(col, row, W, W))
            jfp.write(f"{la},{lo}\n")
            jfp.flush()
            if max_rss_gib is not None and _rss_gib() > max_rss_gib:
                raise WindowedError(
                    [f"peak RSS {_rss_gib():.2f} GiB exceeded the "
                     f"{max_rss_gib:g} GiB ceiling after window "
                     f"{done}/{total}"])
            if progress and done % 50 == 0:
                progress(f"[dem30] {done}/{total} cells  "
                         f"rss {_rss_gib():.2f} GiB")
    factors = [f for f in OVERVIEW_FACTORS if min(width, height) // f >= 1]
    if progress:
        progress(f"[dem30] building overviews {factors} ...")
    with rasterio.open(tmp, "r+") as ds:
        ds.build_overviews(factors, RioResampling.average)
    ident = _identity(tmp)

    problems = _verify_completion(journal, fp, keys)
    problems += _verify_dem30(tmp, height, width, tf, factors)
    if problems:
        raise WindowedError(problems + [f"{tmp} NOT promoted"])
    sha = SC.sha256_file(tmp)
    with rasterio.open(tmp) as dso:
        actual_ovr = list(dso.overviews(1))
    st = os.stat(tmp)
    if _identity(tmp) != ident:
        raise WindowedError(
            [f"{tmp} changed between writing and promotion — the verified "
             f"bytes are not the bytes at the name; NOT promoted"])
    os.replace(tmp, out_path)
    build = dict(fp, cells=total, sha256=sha,
                 overviews=actual_ovr, overviews_requested=factors,
                 file_bytes=st.st_size, allocated_bytes=st.st_blocks * 512,
                 width=width, height=height,
                 peak_rss_gib=round(_rss_gib(), 3),
                 elapsed_s=round(time.monotonic() - t_start, 1))
    btmp = out_path + ".build.json.tmp"
    with open(btmp, "w") as fpb:
        json.dump(build, fpb, indent=1)
    os.replace(btmp, out_path + ".build.json")
    os.remove(journal)
    if progress:
        progress(f"[dem30] verified whole and promoted to {out_path}  "
                 f"sha {sha[:12]}  (peak rss {_rss_gib():.2f} GiB)")


def _verify_dem30(tmp, height, width, tf, factors, strip=4096):
    import rasterio
    from rasterio.windows import Window
    problems = []
    lo, hi = ELEV_SANE_M
    with rasterio.open(tmp) as ds:
        if (ds.width, ds.height) != (width, height) or ds.count != 1:
            problems.append(f"file is {ds.count}x{ds.width}x{ds.height}, "
                            f"expected 1x{width}x{height}")
        got = tuple(ds.transform)[:6]
        if any(abs(g - x) > 1e-12 for g, x in zip(got, tuple(tf)[:6])):
            problems.append("file transform is not the canonical source "
                            "grid")
        if ds.nodata is not None:
            problems.append(f"nodata={ds.nodata!r}; the fine DEM ships "
                            f"nodata=None with honest values everywhere")
        if len(ds.overviews(1)) != len(factors):
            problems.append(f"overviews {ds.overviews(1)} != expected "
                            f"{list(factors)}")
        for r0 in range(0, ds.height, strip):
            h = min(strip, ds.height - r0)
            band = ds.read(1, window=Window(0, r0, ds.width, h))
            bad = int(np.count_nonzero(~np.isfinite(band)))
            if bad:
                problems.append(f"rows {r0}..{r0 + h}: {bad} non-finite "
                                f"sample(s)")
            wild = int(np.count_nonzero((band < lo) | (band > hi)))
            if wild:
                problems.append(f"rows {r0}..{r0 + h}: {wild} elevation(s) "
                                f"outside {lo:g}..{hi:g} m")
            if len(problems) > 20:
                problems.append("...")
                return problems
    return problems


def _verify_completion(journal, fp, expected_keys):
    """Every expected tile, exactly once, under THIS build's fingerprint.

    This is the completion proof. Pixel checks cannot be: 0 m is honest
    sea, and NaN-on-unwritten is a GDAL default this gate refuses to
    lean on alone.
    """
    if not os.path.exists(journal):
        return ["no completion journal — the write cannot prove which "
                "tiles ran"]
    with open(journal) as fpj:
        lines = fpj.read().splitlines()
    if not lines or not lines[0].startswith("#"):
        return ["completion journal has no fingerprint header"]
    try:
        got_fp = json.loads(lines[0][1:])
    except ValueError:
        return ["completion journal fingerprint is not readable"]
    if got_fp != fp:
        diff = sorted(k for k in set(got_fp) | set(fp)
                      if got_fp.get(k) != fp.get(k))
        return [f"completion journal belongs to a different build "
                f"(differs in: {', '.join(diff)})"]
    problems, seen = [], set()
    want = set(expected_keys)
    for line in lines[1:]:
        try:
            r0, c0 = (int(x) for x in line.split(","))
        except ValueError:
            problems.append(f"malformed journal row {line!r}")
            continue
        key = (r0, c0)
        if key not in want:
            problems.append(f"journal claims tile {key} which this build "
                            f"never planned")
        elif key in seen:
            problems.append(f"journal claims tile {key} twice")
        seen.add(key)
    missing = sorted(want - seen)
    if missing:
        problems.append(f"{len(missing)} tile(s) never completed, "
                        f"e.g. {missing[:3]}")
    return problems


def _verify(tmp, plan, strip=512, factors=None):
    """Read the WHOLE temp file back before it may take the real name.

    NaN anywhere is a tile that never landed or a source hole; both mean
    no promotion. Elevation outside physical sanity is refused the same
    way — a verifier that only checks finiteness would wave through a
    float32 gone wild.
    """
    import rasterio
    from rasterio.windows import Window
    problems = []
    t = plan["target"]
    with rasterio.open(tmp) as ds:
        if (ds.width, ds.height) != (t["width"], t["height"]):
            problems.append(f"file is {ds.width}x{ds.height}, the sealed "
                            f"grid is {t['width']}x{t['height']}")
        got = tuple(ds.transform)[:6]
        if any(abs(g - x) > 1e-6 for g, x in zip(got, t["transform"])):
            problems.append("file transform is not the sealed transform")
        # GDAL stores the ACTUAL decimation ratios, which round away from
        # the requested factors on tiny rasters — the count is the contract.
        if factors is not None and len(ds.overviews(1)) != len(factors):
            problems.append(f"overviews {ds.overviews(1)} != expected "
                            f"{list(factors)}")
        lo, hi = ELEV_SANE_M
        for r0 in range(0, ds.height, strip):
            h = min(strip, ds.height - r0)
            win = Window(0, r0, ds.width, h)
            elev = ds.read(1, window=win)
            hs = ds.read(2, window=win)
            n_nan = int(np.count_nonzero(~np.isfinite(elev)))
            if n_nan:
                problems.append(f"rows {r0}..{r0 + h}: {n_nan} non-finite "
                                f"elevation sample(s) — a window was "
                                f"skipped or a source hole leaked through")
            # NaN compares False on both sides, so the range test already
            # excludes it — subtracting n_nan again would let real wilds
            # hide behind a NaN count in the same strip.
            wild = int(np.count_nonzero((elev < lo) | (elev > hi)))
            if wild > 0:
                problems.append(f"rows {r0}..{r0 + h}: {wild} elevation(s) "
                                f"outside {lo:g}..{hi:g} m")
            bad_hs = int(np.count_nonzero(~np.isfinite(hs) | (hs < 0.0)
                                          | (hs > 255.0)))
            if bad_hs:
                problems.append(f"rows {r0}..{r0 + h}: {bad_hs} hillshade "
                                f"sample(s) outside 0..255")
            if len(problems) > 20:
                problems.append("...")
                return problems
    return problems

"""Assemble the 5-band staging full_map.tif from proven parts.

Inputs, each pinned by sha256 in the build fingerprint:

  * the 2-band staging anchor (band 1 elevation, band 2 hillshade) — its
    georeference IS the sealed grid, and its samples pass through
    untouched: the verify pass re-reads the OUTPUT and holds bands 1-2 to
    the per-band checksums accumulated from the anchor at write time;
  * the BMNG base (500 m RGB) — BILINEAR-upsampled (an average upsample
    is 2x2 block replication; cubic rings at colour edges), no tone curve;
  * the shipped Korea full_map.tif — its RGB is bilinear-reprojected onto
    the sealed grid and its finite core is NEVER overwritten: a
    FEATHER_PX-step erosion ramp (Chebyshev distance) blends the outer
    ring into BMNG, korea-side pixels deeper than the ring stay exactly
    Korea's.

The anchor's runtime metadata rides along: MMP_DEM_VRT_RES is copied to
the output (dropping it would resurrect the r5 corridor regression), the
overview policy is the writers', and the completion journal / O_EXCL /
identity-at-promotion discipline is shared with windowed_mosaic. Boundary
evidence — per-channel |Korea - BMNG| stats over the feather ring and a
seam contact-sheet crop — lands next to the build manifest.
"""
import json
import os
import time

import numpy as np

from . import source_coverage as SC
from .windowed_mosaic import (WARP_TILE, OVERVIEW_FACTORS, WindowedError,
                              BMNG_UPSAMPLE_RESAMPLING,
                              KOREA_RGB_REPROJECT_RESAMPLING,
                              _create, _identity, _rss_gib, _tile_keys,
                              _verify_completion)

BUILD_SCHEMA = 1
FEATHER_PX = 40          # 10 km at 250 m; the ramp the manifest promises
FEATHER_ALGO = "erosion-ramp-chebyshev"


def _feather_alpha(mask, steps):
    """0..1 ramp: how many 3x3 erosions a pixel survives, over `steps`.

    Chebyshev distance by construction, dependency-free, deterministic.
    alpha=1 is the untouched Korea core; alpha=0 is at (and beyond) the
    boundary, so the outermost Korea pixels blend and the core does not.
    """
    alpha = np.zeros(mask.shape, dtype=np.float32)
    cur = mask.copy()
    for _ in range(steps):
        if not cur.any():
            break
        alpha += cur
        er = np.zeros_like(cur)
        er[1:-1, 1:-1] = (
            cur[1:-1, 1:-1]
            & cur[:-2, 1:-1] & cur[2:, 1:-1]
            & cur[1:-1, :-2] & cur[1:-1, 2:]
            & cur[:-2, :-2] & cur[:-2, 2:] & cur[2:, :-2] & cur[2:, 2:])
        cur = er
    return np.clip(alpha / float(steps), 0.0, 1.0)


def _fingerprint(anchor_meta, shas, feather_px):
    return {"build_schema": BUILD_SCHEMA, "kind": "full_map",
            "bands": 5, "warp_tile": WARP_TILE,
            "feather_px": feather_px, "feather_algo": FEATHER_ALGO,
            "bmng_resampling": BMNG_UPSAMPLE_RESAMPLING,
            "korea_resampling": KOREA_RGB_REPROJECT_RESAMPLING,
            "anchor_sha256": shas["anchor"],
            "bmng_sha256": shas["bmng"],
            "korea_sha256": shas["korea"],
            "coverage_sha256": anchor_meta.get("coverage_sha256"),
            "target_grid_digest": anchor_meta.get("target_grid_digest"),
            "dem_vrt_res": anchor_meta.get("dem_vrt_res")}


def write_full_map(anchor_path, bmng_path, korea_path, out_path,
                   bmng_sha=None, feather_px=FEATHER_PX,
                   max_rss_gib=None, progress=None):
    """Write the 5-band staging full_map, atomically, or refuse loudly."""
    import rasterio
    from rasterio.warp import reproject, Resampling
    from rasterio.windows import Window
    import hashlib

    shas = {"anchor": SC.sha256_file(anchor_path),
            "bmng": SC.sha256_file(bmng_path),
            "korea": SC.sha256_file(korea_path) if korea_path else None}
    if bmng_sha is not None and shas["bmng"] != bmng_sha:
        raise WindowedError(
            [f"{bmng_path}: sha {shas['bmng'][:12]} does not match the "
             f"pinned base-imagery manifest ({bmng_sha[:12]}) — refusing "
             f"an unproven base"])
    build_meta = {}
    bj = anchor_path + ".build.json"
    if os.path.exists(bj):
        build_meta = json.load(open(bj))

    with rasterio.open(anchor_path) as a:
        if a.count != 2:
            raise WindowedError(
                [f"{anchor_path}: {a.count} band(s); the staging anchor "
                 f"carries exactly elevation + hillshade"])
        crs, tf = a.crs, a.transform
        width, height = a.width, a.height
        tag = a.tags().get("MMP_DEM_VRT_RES")
    meta = dict(build_meta, dem_vrt_res=tag)
    fp = _fingerprint(meta, shas, feather_px)

    tmp = out_path + ".tmp"
    journal = tmp + ".journal"
    t_start = time.monotonic()
    keys = _tile_keys(height, width, WARP_TILE)
    total = len(keys)
    halo = feather_px + 2
    csums = {1: hashlib.sha256(), 2: hashlib.sha256()}
    ring = {"px": 0, "sum": np.zeros(3), "sumsq": np.zeros(3),
            "max": np.zeros(3)}
    seam_best = {"n": -1, "crop": None}

    import contextlib
    k_ctx = rasterio.open(korea_path) if korea_path else \
        contextlib.nullcontext(None)
    with rasterio.open(anchor_path) as a, \
            rasterio.open(bmng_path) as b, \
            k_ctx as k, \
            _create(tmp, height, width, crs, tf, count=5,
                    nodata=None) as ds, \
            open(journal, "w") as jfp:
        if tag is not None:
            ds.update_tags(MMP_DEM_VRT_RES=tag)
        jfp.write("#" + json.dumps(fp, sort_keys=True) + "\n")
        jfp.flush()
        k_bands = ([3, 4, 5] if k.count >= 5 else [1, 2, 3]) if k else []
        for done, (r0, c0) in enumerate(keys, 1):
            r1, c1 = min(height, r0 + WARP_TILE), min(width, c0 + WARP_TILE)
            rh0, ch0 = max(0, r0 - halo), max(0, c0 - halo)
            rh1, ch1 = min(height, r1 + halo), min(width, c1 + halo)
            wtf = tf * rasterio.Affine.translation(ch0, rh0)
            hh, ww = rh1 - rh0, ch1 - ch0

            for band in (1, 2):
                arr = a.read(band, window=Window(c0, r0, c1 - c0, r1 - r0))
                csums[band].update(arr.tobytes())
                ds.write(arr, band, window=Window(c0, r0, c1 - c0, r1 - r0))

            # Array sources, deliberately: a rasterio.band() source lets
            # the warper INITIALIZE uncovered destination pixels to 0 — a
            # finite lie that erases both the coverage check and the Korea
            # mask. Arrays leave the NaN prefill alone where the source
            # does not reach, and NaN in the source propagates.
            bm = _warp_bands(b, (1, 2, 3), (hh, ww), wtf, crs,
                             Resampling[BMNG_UPSAMPLE_RESAMPLING])
            if k is not None:
                kr = _warp_bands(k, k_bands, (hh, ww), wtf, crs,
                                 Resampling[KOREA_RGB_REPROJECT_RESAMPLING])
                kmask = np.isfinite(kr).all(axis=0)
                alpha = _feather_alpha(kmask, feather_px)
            else:
                # BMNG-only base: one uniform tone everywhere. The Korea
                # deep-zoom quality lives in the live S2 overlay, not here —
                # pasting the old map's pale 250 m base bought a visible
                # tone seam at wide zoom and preserved nothing that shows.
                kr = np.zeros((3, hh, ww), dtype=np.float32)
                kmask = np.zeros((hh, ww), dtype=bool)
                alpha = np.zeros((hh, ww), dtype=np.float32)
            kr_f = np.where(np.isfinite(kr), kr, 0.0)
            rgb = kr_f * alpha + bm * (1.0 - alpha)
            rgb = np.clip(rgb, 0.0, 255.0).astype(np.float32)

            ridx = (alpha > 0.0) & (alpha < 1.0) & np.isfinite(bm[0]) \
                & kmask
            n = int(ridx.sum())
            if n:
                d = np.abs(kr_f[:, ridx] - bm[:, ridx])
                ring["px"] += n
                ring["sum"] += d.sum(axis=1)
                ring["sumsq"] += (d ** 2).sum(axis=1)
                ring["max"] = np.maximum(ring["max"], d.max(axis=1))
                if n > seam_best["n"]:
                    seam_best["n"] = n
                    seam_best["crop"] = rgb[:, :, :].copy() if hh * ww \
                        <= 512 * 512 else rgb[:, :512, :512].copy()
            core = rgb[:, r0 - rh0:r1 - rh0, c0 - ch0:c1 - ch0]
            bad = int(np.count_nonzero(~np.isfinite(core)))
            if bad:
                raise WindowedError(
                    [f"tile ({r0},{c0}): {bad} non-finite RGB sample(s) — "
                     f"the base must cover the whole frame"])
            for i in range(3):
                ds.write(core[i], 3 + i,
                         window=Window(c0, r0, c1 - c0, r1 - r0))
            jfp.write(f"{r0},{c0}\n")
            jfp.flush()
            if max_rss_gib is not None and _rss_gib() > max_rss_gib:
                raise WindowedError(
                    [f"peak RSS {_rss_gib():.2f} GiB exceeded the "
                     f"{max_rss_gib:g} GiB ceiling after window "
                     f"{done}/{total}"])
            if progress and done % 10 == 0:
                progress(f"[rgb  ] {done}/{total} windows  "
                         f"rss {_rss_gib():.2f} GiB")

    from rasterio.enums import Resampling as RioResampling
    factors = [f for f in OVERVIEW_FACTORS if min(width, height) // f >= 1]
    if progress:
        progress(f"[rgb  ] building overviews {factors} ...")
    with rasterio.open(tmp, "r+") as ds2:
        ds2.build_overviews(factors, RioResampling.average)
    ident = _identity(tmp)

    problems = _verify_completion(journal, fp, keys)
    problems += _verify_full_map(tmp, width, height, tf, tag, factors,
                                 {b: h.hexdigest() for b, h in csums.items()})
    if problems:
        raise WindowedError(problems + [f"{tmp} NOT promoted"])
    sha = SC.sha256_file(tmp)
    with rasterio.open(tmp) as dso:
        actual_ovr = list(dso.overviews(1))
    st = os.stat(tmp)
    if _identity(tmp) != ident:
        raise WindowedError(
            [f"{tmp} changed between writing and promotion — NOT promoted"])
    os.replace(tmp, out_path)

    seam_path = None
    if seam_best["crop"] is not None:
        seam_path = out_path + ".seam.png"
        _write_png(seam_best["crop"], seam_path)
    npx = max(1, ring["px"])
    build = dict(fp, tiles=total, sha256=sha,
                 overviews=actual_ovr, overviews_requested=factors,
                 file_bytes=st.st_size, allocated_bytes=st.st_blocks * 512,
                 band_checksums={b: h.hexdigest()
                                 for b, h in csums.items()},
                 seam={"ring_px": ring["px"],
                       "mean_abs_diff": [round(float(x), 3)
                                         for x in ring["sum"] / npx],
                       "max_abs_diff": [round(float(x), 3)
                                        for x in ring["max"]],
                       "contact_sheet": seam_path,
                       "contact_sheet_sha256":
                           SC.sha256_file(seam_path) if seam_path else None},
                 peak_rss_gib=round(_rss_gib(), 3),
                 elapsed_s=round(time.monotonic() - t_start, 1))
    btmp = out_path + ".build.json.tmp"
    with open(btmp, "w") as fpb:
        json.dump(build, fpb, indent=1)
    os.replace(btmp, out_path + ".build.json")
    os.remove(journal)
    if progress:
        progress(f"[rgb  ] verified whole and promoted to {out_path}  "
                 f"sha {sha[:12]}")


def _warp_bands(src, bands, dst_shape, dst_transform, dst_crs, resampling,
                margin_px=4):
    """Warp `bands` of `src` onto the destination grid via a WINDOWED
    array read. Uncovered destination stays NaN; source NaN propagates."""
    import rasterio
    from rasterio.warp import reproject, transform_bounds
    from rasterio.windows import from_bounds
    hh, ww = dst_shape
    out = np.full((len(bands), hh, ww), np.nan, dtype=np.float32)
    dbounds = rasterio.transform.array_bounds(hh, ww, dst_transform)
    try:
        sb = transform_bounds(dst_crs, src.crs, *dbounds, densify_pts=21)
    except Exception:
        return out                                # disjoint: all NaN
    win = from_bounds(*sb, src.transform)
    win = win.round_offsets().round_lengths()
    col0 = max(0, int(win.col_off) - margin_px)
    row0 = max(0, int(win.row_off) - margin_px)
    col1 = min(src.width, int(win.col_off + win.width) + margin_px)
    row1 = min(src.height, int(win.row_off + win.height) + margin_px)
    if col1 <= col0 or row1 <= row0:
        return out                                # no overlap: all NaN
    from rasterio.windows import Window
    swin = Window(col0, row0, col1 - col0, row1 - row0)
    stf = src.window_transform(swin)
    for i, band in enumerate(bands):
        arr = src.read(band, window=swin).astype(np.float32)
        # init_dest_nodata=False, load-bearing: the default has GDAL
        # initialize the whole destination to 0 first, which turns every
        # UNCOVERED pixel into a finite lie — erasing both the coverage
        # check and the Korea mask. False leaves the NaN prefill standing
        # wherever the source does not reach.
        reproject(source=arr, destination=out[i],
                  src_transform=stf, src_crs=src.crs,
                  dst_transform=dst_transform, dst_crs=dst_crs,
                  resampling=resampling, init_dest_nodata=False)
    return out


def _write_png(rgb, path):
    from PIL import Image
    arr = np.clip(rgb, 0, 255).astype(np.uint8).transpose(1, 2, 0)
    Image.fromarray(arr, "RGB").save(path)


def _verify_full_map(tmp, width, height, tf, tag, factors, csums,
                     strip=512):
    """Re-read the WHOLE temp file: bands 1-2 must hash to the anchor's
    accumulated checksums (the assembler may not move one terrain
    sample), bands 3-5 must be finite 0..255 everywhere, the runtime tag
    must have survived, and the grid must be the anchor's."""
    import rasterio
    import hashlib
    from rasterio.windows import Window
    problems = []
    got_c = {1: hashlib.sha256(), 2: hashlib.sha256()}
    with rasterio.open(tmp) as ds:
        if ds.count != 5:
            problems.append(f"{ds.count} band(s), the contract says 5")
            return problems
        if (ds.width, ds.height) != (width, height):
            problems.append("size is not the anchor grid")
        if any(abs(g - x) > 1e-6
               for g, x in zip(tuple(ds.transform)[:6], tuple(tf)[:6])):
            problems.append("transform is not the anchor grid")
        if tag is not None and ds.tags().get("MMP_DEM_VRT_RES") != tag:
            problems.append("MMP_DEM_VRT_RES tag was dropped — the r5 "
                            "corridor regression would come back")
        if len(ds.overviews(1)) != len(factors):
            problems.append(f"overviews {ds.overviews(1)} != expected "
                            f"{list(factors)}")
        # checksum accumulation must walk the SAME tile order as the write
        for r0, c0 in _tile_keys(height, width, WARP_TILE):
            r1, c1 = min(height, r0 + WARP_TILE), min(width, c0 + WARP_TILE)
            for band in (1, 2):
                got_c[band].update(
                    ds.read(band, window=Window(c0, r0, c1 - c0, r1 - r0))
                    .tobytes())
        for band in (1, 2):
            if got_c[band].hexdigest() != csums[band]:
                problems.append(f"band {band} does not hash to the "
                                f"anchor's samples — terrain moved during "
                                f"assembly")
        for r0 in range(0, height, strip):
            h = min(strip, height - r0)
            for band in (3, 4, 5):
                arr = ds.read(band, window=Window(0, r0, width, h))
                bad = int(np.count_nonzero(
                    ~np.isfinite(arr) | (arr < 0.0) | (arr > 255.0)))
                if bad:
                    problems.append(f"rows {r0}..{r0 + h} band {band}: "
                                    f"{bad} RGB sample(s) outside 0..255")
            if len(problems) > 20:
                problems.append("...")
                return problems
    return problems

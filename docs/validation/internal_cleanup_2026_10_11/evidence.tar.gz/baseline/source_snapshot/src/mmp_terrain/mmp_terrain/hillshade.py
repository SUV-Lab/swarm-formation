"""The one hillshade implementation.

Extracted from ``tools/make_dem_mosaic.py`` so the map probe regresses the
SHIPPED shading instead of a second copy of the formula. A copy agrees with
the original only until someone edits one of them, and the failure mode is a
picture that looks fine.

Two things about the production recipe that a naive re-implementation gets
wrong, and that are therefore baked in here:

* the shading is computed at the DEM's SOURCE resolution and only then
  averaged down — computing it on the already-coarse grid flattens every
  slope the averaging would have preserved;
* on a geographic grid the east-west cell size shrinks with cos(lat), so dx
  is per-row. A single mid-map value skews slopes by ~7 % at the north and
  south edges of a map this tall.

Dependency-light on purpose (numpy + stdlib): ``make_dem_mosaic`` runs
straight out of the source tree with no installed package.
"""
import math

import numpy as np

AZIMUTH_DEG = 315.0         # light comes FROM the north-west
ALTITUDE_DEG = 45.0

# Earth radius the geographic-grid cell sizes are derived from. Kept as the
# spherical value the shipped maps were baked with — changing it would move
# every hillshade pixel for no visible gain.
EARTH_R_M = 6371000.0


def geographic_cell_sizes(transform, height):
    """(dx per row, dy) in metres for a lon/lat grid.

    dx is an array: one value per raster row, because a degree of longitude
    is shorter near the poles.
    """
    res_lon_deg = transform.a
    res_lat_deg = -transform.e
    m_per_deg = math.pi / 180.0 * EARTH_R_M
    lats = transform.f - (np.arange(height, dtype=np.float64) + 0.5) * res_lat_deg
    dx_row = (res_lon_deg * m_per_deg * np.cos(np.radians(lats))).astype(np.float32)
    dy = np.float32(res_lat_deg * m_per_deg)
    return dx_row, dy


def hillshade(band, dx, dy, z_factor=1.0,
              az_deg=AZIMUTH_DEG, alt_deg=ALTITUDE_DEG):
    """Horn hillshade, 0..255 float32, NaN wherever `band` is NaN.

    `dx` may be a scalar or one value per row (see geographic_cell_sizes).
    """
    z = band * np.float32(z_factor)
    fy, fx = np.gradient(z)
    del z
    fy = fy / dy
    fx = fx / (dx[:, None] if np.ndim(dx) == 1 else dx)
    slope = np.arctan(np.sqrt(fx * fx + fy * fy))
    aspect = np.arctan2(-fy, fx)
    del fx, fy
    az, alt = np.radians(az_deg), np.radians(alt_deg)
    hs = 255.0 * (np.cos(alt) * np.cos(slope) +
                  np.sin(alt) * np.sin(slope) * np.cos(az - aspect))
    del slope, aspect
    hs = np.clip(hs, 0.0, 255.0).astype(np.float32)
    hs[np.isnan(band)] = np.nan
    return hs


def hillshade_geographic(band, transform, z_factor=1.0,
                         az_deg=AZIMUTH_DEG, alt_deg=ALTITUDE_DEG):
    """hillshade() on a lon/lat grid, with the per-row dx worked out for you."""
    dx_row, dy = geographic_cell_sizes(transform, band.shape[0])
    return hillshade(band, dx_row, dy, z_factor, az_deg, alt_deg)


def facing_brightness(np_mod=np, n=64, res_m=250.0):
    """Mean shade of four uniform ramps, keyed by the direction each FACES.

    A uniform ramp shades uniformly, so comparing two edges of one ramp proves
    nothing. Opposing ramps do: under a light from the north-west the
    west-facing ramp must outshine the east-facing one, and likewise north
    over south. This is the check, in the same module as the thing it checks.
    """
    j = np_mod.arange(n, dtype="float32")[None, :] * np_mod.ones((n, 1), "float32")
    i = np_mod.arange(n, dtype="float32")[:, None] * np_mod.ones((1, n), "float32")
    ramps = {"faces_west": j * 10.0,            # rises toward the east
             "faces_east": (n - 1 - j) * 10.0,
             "faces_north": i * 10.0,           # rises toward the south
             "faces_south": (n - 1 - i) * 10.0}
    return {k: float(np_mod.nanmean(hillshade(v, res_m, res_m)))
            for k, v in ramps.items()}

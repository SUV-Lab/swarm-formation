from setuptools import setup

package_name = 'mmp_terrain'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/examples',
            ['examples/load_map_example.py']),
        ('share/' + package_name + '/docs',
            ['docs/map_loader_api_ko.md']),
        # DATA IS NOT INSTALLED. Every consumer reads the SOURCE tree
        # directly (/ws/src/mmp_terrain/data — same contract as
        # tiles/server.py and the corridor DEM): map/scenario edits need no
        # rebuild, and the ament_python stale-data_files trap (moved or
        # deleted data files break the next build until the package cache
        # is wiped, deleted files linger in install/ as ghosts) is gone
        # by construction.
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='limgyeonghun',
    maintainer_email='mywww5371@naver.com',
    description='Terrain model publisher for MMP (Mission Planning)',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'terrain_publisher = mmp_terrain.terrain_publisher:main',
        ],
    },
)

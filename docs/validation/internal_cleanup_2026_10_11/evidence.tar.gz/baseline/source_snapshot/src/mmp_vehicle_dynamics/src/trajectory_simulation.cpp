#include "mmp_vehicle_dynamics/trajectory_simulation.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>

namespace mmp_vehicle_dynamics {
namespace md = mmp_vehicle_dynamics;

double PolynomialReference::totalDuration() const
{
  double total = 0.0;
  for (double d : durations) total += d;
  return total;
}

void PolynomialReference::validate() const
{
  if (order < 0 || order > 255 || durations.empty() ||
      !std::isfinite(unit_xy_m) || unit_xy_m <= 0.0 ||
      !std::isfinite(unit_z_m) || unit_z_m <= 0.0)
    throw std::invalid_argument("invalid polynomial reference or frame scale");
  const size_t stride = static_cast<size_t>(order) + 1;
  if (durations.size() > static_cast<size_t>(std::numeric_limits<int>::max()) / stride ||
      coefficients_x.size() != durations.size() * stride ||
      coefficients_y.size() != durations.size() * stride ||
      coefficients_z.size() != durations.size() * stride)
    throw std::invalid_argument("invalid polynomial coefficient array size");
  for (float duration : durations)
    if (!std::isfinite(duration) || duration <= 0.0f)
      throw std::invalid_argument("invalid polynomial duration");
  for (const auto *axis : {&coefficients_x, &coefficients_y, &coefficients_z})
    for (float coefficient : *axis)
      if (!std::isfinite(coefficient))
        throw std::invalid_argument("non-finite polynomial coefficient");
  if (!std::isfinite(totalDuration()))
    throw std::invalid_argument("non-finite total polynomial duration");
}

SimulationReference PolynomialReference::sample(double time_s) const
{
  SimulationReference ref;
  if (durations.empty()) return ref;

  const double t = std::max(0.0, std::min(time_s, totalDuration()));
  double accumulated = 0.0;
  size_t piece = 0;
  double local_t = t;
  for (size_t i = 0; i < durations.size(); ++i) {
    if (t <= accumulated + durations[i] || i + 1 == durations.size()) {
      piece = i;
      local_t = t - accumulated;
      break;
    }
    accumulated += durations[i];
  }

  const int stride = order + 1;
  const int offset = static_cast<int>(piece) * stride;
  Eigen::Vector3d position = Eigen::Vector3d::Zero();
  Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
  Eigen::Vector3d acceleration = Eigen::Vector3d::Zero();
  for (int j = 0; j <= order; ++j) {
    const int power = order - j;
    const Eigen::Vector3d coefficient(
        coefficients_x[offset + j], coefficients_y[offset + j],
        coefficients_z[offset + j]);
    position += coefficient * std::pow(local_t, power);
    if (power >= 1) {
      velocity += coefficient *
          (power * std::pow(local_t, power - 1));
    }
    if (power >= 2) {
      acceleration += coefficient *
          (power * (power - 1) * std::pow(local_t, power - 2));
    }
  }
  const Eigen::Vector3d scale = Eigen::Vector3d(unit_xy_m, unit_xy_m, unit_z_m);
  ref.position_m = scale.cwiseProduct(position);
  ref.velocity_mps = scale.cwiseProduct(velocity);
  ref.acceleration_mps2 = scale.cwiseProduct(acceleration);
  return ref;
}

PointMassState simulationPointMassState(const SimulationState &state)
{
  md::PointMassState s;
  s.position_m = state.position_m;
  s.speed_mps = state.speed_mps;
  s.flight_path_angle_rad = state.flight_path_angle_rad;
  s.heading_rad = state.heading_rad;
  return s;
}

ReferenceTrackingController::ReferenceTrackingController(TrackingControllerSettings settings)
    : settings_(std::move(settings))
{
  if (!std::isfinite(settings_.position_gain) || !std::isfinite(settings_.velocity_gain) ||
      !std::isfinite(settings_.max_commanded_acceleration_mps2) ||
      settings_.max_commanded_acceleration_mps2 <= 0.0)
    throw std::invalid_argument("invalid tracking controller settings");
}

Eigen::Vector3d ReferenceTrackingController::commandedAcceleration(
    const SimulationReference &ref, const SimulationState &state,
    const Eigen::Vector3d &velocity) const
{
  Eigen::Vector3d commanded_acceleration = ref.acceleration_mps2 +
      settings_.position_gain * (ref.position_m - state.position_m) +
      settings_.velocity_gain * (ref.velocity_mps - velocity);
  const double acceleration_norm = commanded_acceleration.norm();
  if (acceleration_norm > settings_.max_commanded_acceleration_mps2) {
    commanded_acceleration *=
        settings_.max_commanded_acceleration_mps2 / acceleration_norm;
  }

  return commanded_acceleration;
}

FixedWingMotionModel::FixedWingMotionModel(Parameters parameters)
    : parameters_(std::move(parameters))
{
  if (!parametersAreValid(parameters_))
    throw std::invalid_argument("invalid fixed-wing dynamics parameters");
}
Eigen::Vector3d FixedWingMotionModel::velocity(const SimulationState &state) const
{
  return pointMassVelocity(simulationPointMassState(state));
}
SimulationControl FixedWingMotionModel::realize(const SimulationState &state,
    const Eigen::Vector3d &commanded_acceleration) const
{
  const Eigen::Vector3d velocity = this->velocity(state);
  const double gamma = state.flight_path_angle_rad;
  const double chi = state.heading_rad;
  const Eigen::Vector3d tangent = velocity.normalized();
  const Eigen::Vector3d flight_up(
      -std::sin(gamma) * std::cos(chi),
      -std::sin(gamma) * std::sin(chi), std::cos(gamma));
  const Eigen::Vector3d flight_right(-std::sin(chi), std::cos(chi), 0.0);
  const Eigen::Vector3d gravity(0.0, 0.0, -parameters_.gravity_mps2);
  const Eigen::Vector3d required_specific_force =
      commanded_acceleration - gravity;

  const double tangential_force = required_specific_force.dot(tangent);
  const double vertical_lift_accel = required_specific_force.dot(flight_up);
  const double lateral_lift_accel = required_specific_force.dot(flight_right);
  const double lift_accel =
      std::hypot(vertical_lift_accel, lateral_lift_accel);
  const double requested_bank =
      std::atan2(lateral_lift_accel, vertical_lift_accel);

  // The commanded (CL, thrust, bank) -> realized-forces closure is the
  // SHARED one (point_mass_eom.hpp) — the follower is a caller of the
  // single aero authority, not a second copy of it. A follower riding a
  // limit is normal tracking behaviour, so the saturation flags are
  // accepted silently here; a transition generator must not do that.
  const double rho = md::airDensity(parameters_, state.position_m.z());
  const double q = 0.5 * rho * state.speed_mps * state.speed_mps;
  const double requested_cl = parameters_.mass_kg * lift_accel /
      std::max(q * parameters_.wing_area_m2, 1.0e-6);
  // Thrust request needs the REALIZED drag, which depends on the realized
  // CL — ask the closure twice: once for the aero at the requested CL,
  // then with the drag-aware thrust request. (Same arithmetic as the old
  // inline code, now against the shared formulas.)
  const md::PointMassForceResult aero = md::pointMassForces(
      parameters_, simulationPointMassState(state), requested_cl, 0.0, requested_bank);
  const double requested_thrust =
      aero.inputs.drag_n + parameters_.mass_kg * tangential_force;
  const md::PointMassForceResult closed = md::pointMassForces(
      parameters_, simulationPointMassState(state), requested_cl, requested_thrust,
      requested_bank);
  SimulationControl control;
  // SATURATION is normal tracking behaviour (riding a limit) and stays
  // silent. UNREPRESENTABLE is different — the state sits outside the
  // 3DOF parameterization's validity — and is FLAGGED here but counted
  // in SimulationSession::step, once per integration step (counting
  // in this function tallied controller calls, and RK4 makes four of
  // those per step).
  control.state_representable = closed.state_representable;
  control.bank_rad = closed.inputs.bank_rad;
  control.lift_n = closed.inputs.lift_n;
  control.drag_n = closed.inputs.drag_n;
  control.thrust_n = closed.inputs.thrust_n;

  control.acceleration_mps2 = gravity +
      ((control.thrust_n - control.drag_n) / parameters_.mass_kg) * tangent +
      (control.lift_n / parameters_.mass_kg) *
          (std::cos(control.bank_rad) * flight_up +
           std::sin(control.bank_rad) * flight_right);
  return control;
}

PointMassDerivative FixedWingMotionModel::derivative(const SimulationState &state,
    const SimulationControl &control) const
{
  PointMassInputs u;
  u.thrust_n = control.thrust_n;
  u.lift_n = control.lift_n;
  u.drag_n = control.drag_n;
  u.bank_rad = control.bank_rad;
  return pointMassDerivative(parameters_, simulationPointMassState(state), u);
}
SimulationEnvelopeReading FixedWingMotionModel::audit(const SimulationState &state,
    const SimulationControl &control) const
{
  const auto eval = evaluateInverseDynamics(parameters_, state.position_m,
      velocity(state), control.acceleration_mps2);
  return {envelopeUtilization(parameters_, eval), isWithinEnvelope(parameters_, eval)};
}

SimulationState makeInitialSimulationState(const PolynomialReference &reference,
    double speed_floor_mps, double activation_speed_mps)
{
  reference.validate();
  if (!std::isfinite(speed_floor_mps) || speed_floor_mps <= 0.0 ||
      !std::isfinite(activation_speed_mps) || activation_speed_mps < 0.0)
    throw std::invalid_argument("invalid initial simulation speed limits");
  const double total = reference.totalDuration();
  SimulationReference initial_ref = reference.sample(0.0);
  SimulationReference direction_ref = initial_ref;
  if (direction_ref.velocity_mps.norm() < 1.0) {
    for (double t = 0.1; t <= total; t += 0.1) {
      direction_ref = reference.sample(t);
      if (direction_ref.velocity_mps.norm() >=
          activation_speed_mps) break;
    }
  }
  Eigen::Vector3d direction = direction_ref.velocity_mps;
  if (direction.norm() < 1.0e-6) direction = Eigen::Vector3d::UnitX();
  direction.normalize();

  SimulationState state;
  state.position_m = initial_ref.position_m;
  state.speed_mps = std::max(speed_floor_mps,
                             initial_ref.velocity_mps.norm());
  state.flight_path_angle_rad = std::asin(
      std::clamp(direction.z(), -1.0, 1.0));
  state.heading_rad = std::atan2(direction.y(), direction.x());
  state.bank_rad = 0.0;
  return state;
}

SimulationSession::SimulationSession(SimulationInput input) : input_(std::move(input))
{
  input_.reference.validate();
  const auto &initial = input_.initial_state;
  if (!input_.model || !input_.controller ||
      !std::isfinite(input_.settings.integration_step_s) || input_.settings.integration_step_s <= 0.0 ||
      !std::isfinite(initial.time_s) || initial.time_s < 0.0 ||
      initial.time_s > input_.reference.totalDuration() ||
      !initial.position_m.allFinite() || !std::isfinite(initial.speed_mps) || initial.speed_mps <= 0.0 ||
      !std::isfinite(initial.flight_path_angle_rad) || !std::isfinite(initial.heading_rad) ||
      !std::isfinite(initial.bank_rad))
    throw std::invalid_argument("invalid simulation input/state");
  result_.reference_duration_s = input_.reference.totalDuration();
  const double reserve_count = result_.reference_duration_s / input_.settings.integration_step_s;
  if (!std::isfinite(reserve_count) || reserve_count > static_cast<double>(result_.states.max_size() - 2))
    throw std::invalid_argument("simulation history size is not representable");
  result_.states.reserve(static_cast<size_t>(reserve_count) + 2);
  result_.states.push_back(initial);
}
SimulationReference SimulationSession::sampleReference(double time_s) const
{ return input_.reference.sample(time_s); }
Eigen::Vector3d SimulationSession::stateVelocity(const SimulationState &state) const
{ return input_.model->velocity(state); }
SimulationControl SimulationSession::controller(double time_s, const SimulationState &state) const
{
  const auto ref = sampleReference(time_s);
  const auto velocity = stateVelocity(state);
  const auto command = input_.controller->commandedAcceleration(ref, state, velocity);
  return input_.model->realize(state, command);
}
PointMassDerivative SimulationSession::derivative(double time_s, const SimulationState &state,
                                                 SimulationControl *used) const
{
  const auto control = controller(time_s, state);
  if (used != nullptr) *used = control;
  return input_.model->derivative(state, control);
}
SimulationEnvelopeReading SimulationSession::audit(const SimulationState &state,
                                                   const SimulationControl &control) const
{ return input_.model->audit(state, control); }

SimulationState SimulationSession::shifted(const SimulationState &state, const PointMassDerivative &d, double dt) const
{
  SimulationState out = state;
  out.time_s += dt;
  out.position_m += dt * d.position;
  out.speed_mps = std::max(1.0, state.speed_mps + dt * d.speed);
  out.flight_path_angle_rad = std::clamp(
      state.flight_path_angle_rad + dt * d.flight_path_angle,
      -1.553343034, 1.553343034);
  out.heading_rad = state.heading_rad + dt * d.heading;
  return out;
}

SimulationState SimulationSession::integrateRk4(const SimulationState &state, double dt) const
{
  const PointMassDerivative k1 = derivative(state.time_s, state, nullptr);
  const SimulationState s2 = shifted(state, k1, 0.5 * dt);
  const PointMassDerivative k2 = derivative(s2.time_s, s2, nullptr);
  const SimulationState s3 = shifted(state, k2, 0.5 * dt);
  const PointMassDerivative k3 = derivative(s3.time_s, s3, nullptr);
  const SimulationState s4 = shifted(state, k3, dt);
  const PointMassDerivative k4 = derivative(s4.time_s, s4, nullptr);

  SimulationState out = state;
  out.time_s += dt;
  out.position_m += (dt / 6.0) *
      (k1.position + 2.0 * k2.position + 2.0 * k3.position + k4.position);
  out.speed_mps = std::max(1.0, state.speed_mps + (dt / 6.0) *
      (k1.speed + 2.0 * k2.speed + 2.0 * k3.speed + k4.speed));
  out.flight_path_angle_rad = std::clamp(
      state.flight_path_angle_rad + (dt / 6.0) *
          (k1.flight_path_angle + 2.0 * k2.flight_path_angle +
           2.0 * k3.flight_path_angle + k4.flight_path_angle),
      -1.553343034, 1.553343034);
  out.heading_rad = state.heading_rad + (dt / 6.0) *
      (k1.heading + 2.0 * k2.heading + 2.0 * k3.heading + k4.heading);
  out.heading_rad = std::atan2(std::sin(out.heading_rad),
                              std::cos(out.heading_rad));
  out.bank_rad = controller(out.time_s, out).bank_rad;
  return out;
}

bool SimulationSession::step()
{
  if (result_.status != SimulationStatus::RUNNING) return false;
  SimulationState state = result_.states.back();
  if (!(state.time_s < result_.reference_duration_s - 1.0e-9)) {
    result_.status = SimulationStatus::COMPLETED;
    return false;
  }
  const double dt = std::min(input_.settings.integration_step_s,
                             result_.reference_duration_s - state.time_s);
  state = integrateRk4(state, dt);
  result_.states.push_back(state);
  const auto ref = sampleReference(state.time_s);
  auto &metrics = result_.metrics;
  metrics.peak_tracking_error_m = std::max(metrics.peak_tracking_error_m,
      (state.position_m - ref.position_m).norm());
  SimulationControl applied;
  derivative(state.time_s, state, &applied);
  if (!applied.state_representable) {
    ++metrics.unrepresentable_steps;
  } else {
    const auto reading = audit(state, applied);
    metrics.peak_envelope_utilization = std::max(metrics.peak_envelope_utilization,
                                                reading.utilization);
    if (!reading.within_envelope) ++metrics.violation_steps;
  }
  return true;
}
void SimulationSession::cancel()
{ if (result_.status == SimulationStatus::RUNNING) result_.status = SimulationStatus::CANCELLED; }
SimulationResult SimulationSession::takeResult() &&
{ return std::move(result_); }

size_t SimulationSession::stateIndexAt(double time_s) const
{
  auto it = std::lower_bound(
      result_.states.begin(), result_.states.end(), time_s,
      [](const SimulationState &state, double t) { return state.time_s < t; });
  if (it == result_.states.end()) return result_.states.size() - 1;
  if (it == result_.states.begin()) return 0;
  const size_t upper = static_cast<size_t>(it - result_.states.begin());
  const size_t lower = upper - 1;
  return (time_s - result_.states[lower].time_s <
          result_.states[upper].time_s - time_s) ? lower : upper;
}

SimulationResult simulate(SimulationInput input)
{
  SimulationSession session(std::move(input));
  while (session.step()) {}
  return std::move(session).takeResult();
}
}  // namespace mmp_vehicle_dynamics

#pragma once

#include "mmp_vehicle_dynamics/point_mass_eom.hpp"

#include <cstddef>
#include <memory>
#include <vector>

namespace mmp_vehicle_dynamics {

// Owned reference in the existing planner frame. Float coefficients preserve
// PolyTraj's wire representation; sampling promotes them to double and keeps
// the original term-by-term pow order and previous-piece seam convention.
// The simulation state/control interfaces below are SI, not planner units.
struct SimulationReference {
  Eigen::Vector3d position_m = Eigen::Vector3d::Zero();
  Eigen::Vector3d velocity_mps = Eigen::Vector3d::Zero();
  Eigen::Vector3d acceleration_mps2 = Eigen::Vector3d::Zero();
};

struct PolynomialReference {
  int order{5};
  std::vector<float> coefficients_x, coefficients_y, coefficients_z, durations;
  double unit_xy_m{100.0}, unit_z_m{100.0};
  double totalDuration() const;
  // Precondition: validate() succeeded after the last field mutation. Session
  // and makeInitialSimulationState validate once before their sampling loops.
  SimulationReference sample(double time_s) const;
  // Throws invalid_argument for malformed representation/scale. Does not
  // establish continuous safety or bound overflow for arbitrary polynomials.
  void validate() const;
};

struct SimulationState {
  double time_s{0.0};
  Eigen::Vector3d position_m = Eigen::Vector3d::Zero();
  double speed_mps{0.0};
  double flight_path_angle_rad{0.0};
  double heading_rad{0.0};
  double bank_rad{0.0};
};

PointMassState simulationPointMassState(const SimulationState &state);

struct SimulationControl {
  bool state_representable{true};
  double thrust_n{0.0}, lift_n{0.0}, bank_rad{0.0}, drag_n{0.0};
  Eigen::Vector3d acceleration_mps2 = Eigen::Vector3d::Zero();
};
struct SimulationEnvelopeReading {
  double utilization{0.0};
  bool within_envelope{true};
};

struct TrackingControllerSettings {
  double position_gain{0.04};
  double velocity_gain{0.80};
  double max_commanded_acceleration_mps2{30.0};
};

// Stateless/reentrant const strategies: RK4 asks at intermediate states and
// playback repeats queries. Implementations must not advance hidden state on
// those calls. A different controller with its own dynamic state needs an
// explicit state contract; this interface does not claim to provide one.
class TrackingController {
 public:
  using Ptr = std::shared_ptr<const TrackingController>;
  virtual ~TrackingController() = default;
  virtual Eigen::Vector3d commandedAcceleration(
      const SimulationReference &reference, const SimulationState &state,
      const Eigen::Vector3d &velocity_mps) const = 0;
};
class ReferenceTrackingController final : public TrackingController {
 public:
  explicit ReferenceTrackingController(TrackingControllerSettings settings = {});
  Eigen::Vector3d commandedAcceleration(const SimulationReference &,
      const SimulationState &, const Eigen::Vector3d &) const override;
 private:
  const TrackingControllerSettings settings_;
};

// Forward simulation strategy, distinct from the planner's VehicleModel.
// Commands are SI accelerations; realize closes them into the existing 3DOF
// forces. State representation stays point-mass flight-path/heading, with the
// existing RK4 numerical guards. This is not a general VTOL/6DOF interface.
class SimulationMotionModel {
 public:
  using Ptr = std::shared_ptr<const SimulationMotionModel>;
  virtual ~SimulationMotionModel() = default;
  virtual Eigen::Vector3d velocity(const SimulationState &) const = 0;
  virtual SimulationControl realize(const SimulationState &,
      const Eigen::Vector3d &commanded_acceleration_mps2) const = 0;
  virtual PointMassDerivative derivative(const SimulationState &,
      const SimulationControl &) const = 0;
  virtual SimulationEnvelopeReading audit(const SimulationState &,
      const SimulationControl &) const = 0;
};
class FixedWingMotionModel final : public SimulationMotionModel {
 public:
  explicit FixedWingMotionModel(Parameters parameters);
  Eigen::Vector3d velocity(const SimulationState &) const override;
  SimulationControl realize(const SimulationState &,
      const Eigen::Vector3d &) const override;
  PointMassDerivative derivative(const SimulationState &,
      const SimulationControl &) const override;
  SimulationEnvelopeReading audit(const SimulationState &,
      const SimulationControl &) const override;
 private:
  const Parameters parameters_;
};

// Existing ROS follower initialization, independently reusable. The caller
// explicitly supplies the model's speed floor and activation threshold. The
// state starts at reference time zero; low initial speed uses the old 0.1 s
// direction lookahead. An external caller may instead provide its own state.
SimulationState makeInitialSimulationState(const PolynomialReference &reference,
    double speed_floor_mps, double activation_speed_mps);

struct SimulationSettings { double integration_step_s{0.02}; };
struct SimulationInput {
  PolynomialReference reference;
  SimulationState initial_state;
  SimulationSettings settings;
  SimulationMotionModel::Ptr model;
  TrackingController::Ptr controller;
};
enum class SimulationStatus { RUNNING, COMPLETED, CANCELLED };
struct SimulationMetrics {
  double peak_tracking_error_m{0.0};
  double peak_envelope_utilization{0.0};
  int violation_steps{0};
  int unrepresentable_steps{0};
};
struct SimulationResult {
  SimulationStatus status{SimulationStatus::RUNNING};
  double reference_duration_s{0.0};
  std::vector<SimulationState> states;
  SimulationMetrics metrics;
};

// Owns reference/history/configuration and shared immutable strategies. Calls
// on one session are serialized. No clock, ROS callback, publisher, or borrowed
// external trajectory is retained. Constructor rejects invalid inputs with
// invalid_argument; strategy exceptions propagate unchanged. A completed
// result taken by value survives session destruction. A strategy exception
// may leave an appended state and partially updated metrics: discard that
// session; step() does not offer transactional rollback or resumption.
class SimulationSession {
 public:
  explicit SimulationSession(SimulationInput input);
  // Advances exactly one old integration step and audit; true means a state
  // was appended. Returns false after completion/cancel. Chunking changes no
  // arithmetic or time grid. A caller chooses its own wall-clock budget.
  bool step();
  void cancel();
  SimulationStatus status() const { return result_.status; }
  const std::vector<SimulationState> &states() const { return result_.states; }
  const SimulationMetrics &metrics() const { return result_.metrics; }
  double totalDuration() const { return result_.reference_duration_s; }
  const PolynomialReference &reference() const { return input_.reference; }
  // Playback uses the same controller/model arithmetic as integration.
  SimulationReference sampleReference(double time_s) const;
  Eigen::Vector3d stateVelocity(const SimulationState &state) const;
  SimulationControl controller(double time_s, const SimulationState &state) const;
  PointMassDerivative derivative(double time_s, const SimulationState &state,
                                 SimulationControl *used) const;
  SimulationEnvelopeReading audit(const SimulationState &state,
                                  const SimulationControl &control) const;
  size_t stateIndexAt(double time_s) const;
  // Transfers the owned history. Do not use the session after this call.
  SimulationResult takeResult() &&;
 private:
  SimulationState shifted(const SimulationState &, const PointMassDerivative &,
                           double dt) const;
  SimulationState integrateRk4(const SimulationState &, double dt) const;
  SimulationInput input_;
  SimulationResult result_;
};

// Uses exactly SimulationSession::step, returning an owned completed history.
// Does not consume ROS execution IDs or issue commands to a vehicle.
SimulationResult simulate(SimulationInput input);

}  // namespace mmp_vehicle_dynamics

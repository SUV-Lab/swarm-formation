// Installed-library example: no ROS node, callback or execution ID is needed.
#include "mmp_vehicle_dynamics/trajectory_simulation.hpp"
#include <iostream>
#include <memory>
#include <utility>

int main()
{
  namespace md = mmp_vehicle_dynamics;
  md::Parameters parameters;
  md::SimulationInput input;
  input.reference.order = 1;
  input.reference.durations = {2.0f};
  input.reference.coefficients_x = {2.0f, 0.0f};  // 200 m/s with default scale
  input.reference.coefficients_y = {0.0f, 0.0f};
  input.reference.coefficients_z = {0.0f, 10.0f};
  input.initial_state = md::makeInitialSimulationState(input.reference,
      parameters.speed_min_mps, parameters.model_activation_speed_mps);
  input.model = std::make_shared<md::FixedWingMotionModel>(parameters);
  input.controller = std::make_shared<md::ReferenceTrackingController>();
  const auto result = md::simulate(std::move(input));
  std::cout << "states=" << result.states.size()
            << " peak_tracking_error_m=" << result.metrics.peak_tracking_error_m
            << " utilization_peak=" << result.metrics.peak_envelope_utilization
            << '\n';
  return result.status == md::SimulationStatus::COMPLETED ? 0 : 1;
}

#include "mmp_vehicle_dynamics/trajectory_simulation.hpp"
#include <gtest/gtest.h>
#include <atomic>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace md = mmp_vehicle_dynamics;
namespace {

class ConstantController final : public md::TrackingController {
 public:
  explicit ConstantController(double acceleration = 0.0) : acceleration_(acceleration) {}
  Eigen::Vector3d commandedAcceleration(const md::SimulationReference &,
      const md::SimulationState &, const Eigen::Vector3d &) const override {
    return Eigen::Vector3d(acceleration_, 0.0, 0.0);
  }
 private:
  double acceleration_;
};
class StraightMotion final : public md::SimulationMotionModel {
 public:
  explicit StraightMotion(bool representable = true) : representable_(representable) {}
  Eigen::Vector3d velocity(const md::SimulationState &state) const override {
    return Eigen::Vector3d(state.speed_mps, 0.0, 0.0);
  }
  md::SimulationControl realize(const md::SimulationState &,
      const Eigen::Vector3d &command) const override {
    md::SimulationControl control;
    control.state_representable = representable_;
    control.acceleration_mps2 = command;
    return control;
  }
  md::PointMassDerivative derivative(const md::SimulationState &state,
      const md::SimulationControl &control) const override {
    md::PointMassDerivative value;
    value.position = velocity(state);
    value.speed = control.acceleration_mps2.x();
    return value;
  }
  md::SimulationEnvelopeReading audit(const md::SimulationState &,
      const md::SimulationControl &) const override {
    ++audits;
    return {0.2, true};
  }
  mutable std::atomic<int> audits{0};
 private:
  bool representable_;
};

md::SimulationInput straightInput()
{
  md::SimulationInput input;
  input.reference.order = 1;
  input.reference.durations = {1.0f};
  input.reference.coefficients_x = {2.0f, 0.0f};
  input.reference.coefficients_y = {0.0f, 0.0f};
  input.reference.coefficients_z = {0.0f, 10.0f};
  input.reference.unit_xy_m = input.reference.unit_z_m = 1.0;
  input.initial_state.position_m = Eigen::Vector3d(0.0, 0.0, 20.0);
  input.initial_state.speed_mps = 2.0;
  input.model = std::make_shared<StraightMotion>();
  input.controller = std::make_shared<ConstantController>();
  return input;
}

void equalStates(const std::vector<md::SimulationState> &a,
                 const std::vector<md::SimulationState> &b)
{
  ASSERT_EQ(a.size(), b.size());
  for (size_t i = 0; i < a.size(); ++i) {
    EXPECT_EQ(a[i].time_s, b[i].time_s);
    EXPECT_EQ(a[i].position_m, b[i].position_m);
    EXPECT_EQ(a[i].speed_mps, b[i].speed_mps);
    EXPECT_EQ(a[i].flight_path_angle_rad, b[i].flight_path_angle_rad);
    EXPECT_EQ(a[i].heading_rad, b[i].heading_rad);
    EXPECT_EQ(a[i].bank_rad, b[i].bank_rad);
  }
}

TEST(TrajectorySimulation, InjectedModelAndControllerDrivePhysicalHistory)
{
  auto input = straightInput();
  input.controller = std::make_shared<ConstantController>(1.0);
  const auto result = md::simulate(input);
  ASSERT_EQ(result.status, md::SimulationStatus::COMPLETED);
  ASSERT_EQ(result.states.size(), 51u);
  const auto &last = result.states.back();
  EXPECT_NEAR(last.time_s, 1.0, 1e-14);
  EXPECT_NEAR(last.position_m.x(), 2.5, 1e-13);
  EXPECT_EQ(last.position_m.z(), 20.0);  // explicit initial state, not reference z
  EXPECT_NEAR(last.speed_mps, 3.0, 1e-13);
  EXPECT_EQ(result.metrics.peak_envelope_utilization, 0.2);
  EXPECT_EQ(result.metrics.violation_steps, 0);
  EXPECT_NEAR(result.metrics.peak_tracking_error_m, std::hypot(10.0, 0.5), 1e-13);
}

TEST(TrajectorySimulation, ChunkBoundariesDoNotChangeStateOrMetrics)
{
  auto input = straightInput();
  input.controller = std::make_shared<ConstantController>(1.0);
  const auto all = md::simulate(input);
  md::SimulationSession session(input);
  for (int chunk : {1, 7, 3, 11, 2, 100}) {
    for (int i = 0; i < chunk; ++i) if (!session.step()) break;
  }
  ASSERT_EQ(session.status(), md::SimulationStatus::COMPLETED);
  const auto chunked = std::move(session).takeResult();
  equalStates(all.states, chunked.states);
  EXPECT_EQ(all.metrics.peak_tracking_error_m, chunked.metrics.peak_tracking_error_m);
  EXPECT_EQ(all.metrics.peak_envelope_utilization, chunked.metrics.peak_envelope_utilization);
  EXPECT_EQ(all.metrics.violation_steps, chunked.metrics.violation_steps);
}

TEST(TrajectorySimulation, BorrowedPlaybackAndOwnedResultHaveDistinctLifetimes)
{
  md::SimulationResult retained;
  std::weak_ptr<const md::SimulationMotionModel> model;
  {
    auto input = straightInput();
    model = input.model;
    md::SimulationSession session(input);
    input.reference.coefficients_x[0] = 1000.0f;
    input.model.reset();
    while (session.step()) {}
    EXPECT_NEAR(session.states().back().position_m.x(), 2.0, 1e-13);
    EXPECT_FALSE(model.expired());
    EXPECT_EQ(session.stateIndexAt(0.01), 1u);  // exact nearest-time tie -> upper
    EXPECT_EQ(session.stateIndexAt(-1.0), 0u);
    EXPECT_EQ(session.stateIndexAt(100.0), session.states().size() - 1);
    retained = std::move(session).takeResult();
  }
  EXPECT_TRUE(model.expired());
  ASSERT_EQ(retained.status, md::SimulationStatus::COMPLETED);
  EXPECT_NEAR(retained.states.back().position_m.x(), 2.0, 1e-13);
}

TEST(TrajectorySimulation, UnrepresentableStepsAreExcludedOnlyFromAggregateAudit)
{
  auto input = straightInput();
  const auto model = std::make_shared<StraightMotion>(false);
  input.model = model;
  md::SimulationSession session(input);
  while (session.step()) {}
  EXPECT_EQ(session.metrics().unrepresentable_steps, 50);
  EXPECT_EQ(session.metrics().peak_envelope_utilization, 0.0);
  EXPECT_EQ(session.metrics().violation_steps, 0);
  EXPECT_EQ(model->audits.load(), 0);
  const auto &state = session.states().back();
  // Playback historically publishes this instantaneous reading even though
  // the aggregate excludes an unrepresentable state. Preserve both meanings.
  const auto control = session.controller(state.time_s, state);
  EXPECT_EQ(session.audit(state, control).utilization, 0.2);
  EXPECT_EQ(model->audits.load(), 1);
}

TEST(TrajectorySimulation, ExplicitCancellationRetainsOwnedPartialHistory)
{
  md::SimulationSession session(straightInput());
  ASSERT_TRUE(session.step());
  session.cancel();
  EXPECT_FALSE(session.step());
  const auto result = std::move(session).takeResult();
  EXPECT_EQ(result.status, md::SimulationStatus::CANCELLED);
  EXPECT_EQ(result.states.size(), 2u);
}

TEST(TrajectorySimulation, SamplingKeepsFloatValuesAndPreviousPieceAtSeam)
{
  auto reference = straightInput().reference;
  reference.durations = {0.5f, 0.5f};
  reference.coefficients_x = {2.0f, 0.0f, 3.0f, 1.0f};
  reference.coefficients_y = {0.0f, 0.0f, 0.0f, 0.0f};
  reference.coefficients_z = {0.0f, 10.0f, 0.0f, 10.0f};
  reference.validate();
  EXPECT_EQ(reference.sample(0.5).velocity_mps.x(), 2.0);
  EXPECT_EQ(reference.sample(std::nextafter(0.5, 1.0)).velocity_mps.x(), 3.0);
  EXPECT_EQ(reference.sample(-1.0).position_m.x(), 0.0);
  EXPECT_EQ(reference.sample(2.0).position_m.x(), 2.5);
}

TEST(TrajectorySimulation, InvalidInputIsRejectedBeforeStrategyCalls)
{
  auto input = straightInput();
  input.reference.coefficients_x.pop_back();
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.reference.durations[0] = 0.0f;
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.reference.coefficients_x[0] = std::numeric_limits<float>::quiet_NaN();
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.settings.integration_step_s = 0.0;
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.reference.unit_z_m = -1.0;
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.model.reset();
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.controller.reset();
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
  input = straightInput(); input.initial_state.time_s = -1.0;
  EXPECT_THROW(md::simulate(input), std::invalid_argument);
}

class ThrowingController final : public md::TrackingController {
 public:
  Eigen::Vector3d commandedAcceleration(const md::SimulationReference &,
      const md::SimulationState &, const Eigen::Vector3d &) const override {
    throw std::runtime_error("controller failure");
  }
};
TEST(TrajectorySimulation, StrategyExceptionsPropagateWithoutInventingCompletion)
{
  auto input = straightInput();
  input.controller = std::make_shared<ThrowingController>();
  md::SimulationSession session(input);
  EXPECT_THROW(session.step(), std::runtime_error);
  EXPECT_EQ(session.status(), md::SimulationStatus::RUNNING);
  EXPECT_EQ(session.states().size(), 1u);
}
}  // namespace

"""Message/state adapter tests, separate from the ROS-free loader tests."""
import numpy as np
import pytest

pytest.importorskip('rclpy')
from builtin_interfaces.msg import Time
from mmp_terrain.map_loader import normalize_elevation
from mmp_terrain.ros_terrain import to_grid_map
from test_terrain_publisher_env import _svc, _stateless_copy


def test_serializer_preserves_axis_layout_float_order_and_owned_message():
    result=normalize_elevation(np.array([[100.,200.,300.],[400.,500.,600.]],dtype=np.float32),
                               30.0,(10.0,20.0))
    stamp=Time(sec=123,nanosec=456)
    msg=to_grid_map(result,stamp)
    assert msg.header.stamp==stamp and msg.header.frame_id=='map'
    assert (msg.info.length_x,msg.info.length_y)==(.6,.8999999999999999)
    assert (msg.info.pose.position.x,msg.info.pose.position.y)==(10.3,20.45)
    assert msg.info.resolution==.3 and msg.info.pose.orientation.w==1.
    assert msg.layers==['elevation'] and msg.basic_layers==[]
    assert msg.outer_start_index==0 and msg.inner_start_index==0
    dim=msg.data[0].layout.dim
    assert [(d.label,d.size,d.stride) for d in dim]==[('column_index',3,6),('row_index',2,2)]
    assert msg.data[0].layout.data_offset==0
    assert msg.data[0].data.tobytes()==np.array([1,4,2,5,3,6],dtype=np.float32).tobytes()
    result.elevation_u[:]=999.
    assert list(msg.data[0].data)==[1,4,2,5,3,6]


def test_zero_requests_keep_explicit_sticky_values_blank_world_and_clear(tmp_path,monkeypatch):
    node,LoadMap,_a,_d,mission=_svc(tmp_path,monkeypatch)
    first=LoadMap.Request(world='full_map',mission_path=mission,
                          corridor_halfwidth_u=5.,resolution_m=40.,request_token='one')
    a=node.load_map_callback(first,LoadMap.Response())
    assert a.success,a.message
    second=LoadMap.Request(world='',mission_path=mission,request_token='two')
    b=node.load_map_callback(second,LoadMap.Response())
    assert b.success and b.request_token=='two',b.message
    assert node._params['world']=='full_map'
    assert node._params['corridor_halfwidth_u']==5.
    assert node._params['corridor_res_m']==40.
    assert b.actual_resolution_m==a.actual_resolution_m==40.
    np.testing.assert_array_equal(b.min_bound_u,a.min_bound_u)
    np.testing.assert_array_equal(b.max_bound_u,a.max_bound_u)
    cleared=node.load_map_callback(LoadMap.Request(world='none',mission_path=mission),LoadMap.Response())
    assert cleared.success and not cleared.mission_resolved
    assert cleared.actual_resolution_m==0. and list(cleared.min_bound_u)==[0.,0.]
    assert node.published[-1].data==[]


def test_stateless_startup_geometry_load_but_service_refuses_before_dem_read(tmp_path,monkeypatch):
    node,LoadMap,anchor,dem,mission=_svc(tmp_path,monkeypatch)
    stateless=_stateless_copy(mission)
    node._params['corridor_mission']=stateless
    msg=node.load_tif()
    assert len(msg.data[0].data)>0
    import rasterio,os
    actual=rasterio.open; opens=[]
    def record(path,*a,**kw):
        opens.append(os.path.realpath(path)); return actual(path,*a,**kw)
    monkeypatch.setattr(rasterio,'open',record)
    response=node.load_map_callback(LoadMap.Request(world='full_map',mission_path=stateless),LoadMap.Response())
    assert not response.success and not response.mission_resolved
    assert opens==[os.path.realpath(anchor)]
    assert os.path.realpath(dem) not in opens
    assert node.published==[]

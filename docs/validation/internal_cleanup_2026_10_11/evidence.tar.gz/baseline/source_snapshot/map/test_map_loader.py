"""ROS-free loading contract; synthetic rasters exercise data ownership/geometry."""
import builtins
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
import rasterio

from mmp_terrain import map_loader as ML
from mmp_terrain import mission as MI
from mmp_terrain import frame as FR


def _raster(path, values, transform=None, crs='EPSG:3857'):
    if transform is None:
        transform = rasterio.Affine(100.0, 0.0, 1113194.9, 0.0, -100.0, 1113194.9)
    with rasterio.open(path, 'w', driver='GTiff', count=1, dtype='float32',
                       height=values.shape[0], width=values.shape[1],
                       crs=crs, transform=transform) as dst:
        dst.write(values.astype(np.float32), 1)
    return str(path)


def _corridor(tmp_path, *, initial_state=True, extra=''):
    anchor = _raster(tmp_path/'full_map.tif', np.full((60, 60), 30.0))
    dem = _raster(tmp_path/'full_map_dem30.tif', np.full((200, 200), 50.0),
                  rasterio.Affine(30.0, 0.0, 1113194.9, 0.0, -30.0, 1113194.9))
    fr = FR.load_frame(anchor)
    from rasterio.warp import transform
    points=[]
    for x,y in ((10.0,10.0),(40.0,40.0)):
        e,n=FR.frame_to_en(x,y,fr.anchor)
        lon,lat=transform(fr.crs,'EPSG:4326',[e],[n]); points.append((lon[0],lat[0]))
    mission=tmp_path/'mission.yaml'
    mission.write_text('mission:\n'
        f'  start_lonlat: [{points[0][0]:.10f}, {points[0][1]:.10f}, 100.0]\n'
        f'  goal_lonlat: [{points[1][0]:.10f}, {points[1][1]:.10f}, 120.0]\n'
        + ('  initial_speed_mps: 200.0\n' if initial_state else '') + extra)
    return ML.MapLoadInput(world='full_map', data_dir=str(tmp_path),
                           mission_path=str(mission), halfwidth_u=5.0,
                           resolution_m=30.0)


def test_import_and_load_without_any_ros_import(tmp_path):
    # A clean interpreter blocks accidental transitive ROS imports, even on
    # the ROS development container where those modules are available.
    source = '''import builtins,sys
real=builtins.__import__
def guard(name,*a,**kw):
    if name.split('.')[0] in {'rclpy','grid_map_msgs','std_msgs','geometry_msgs','mmp_mission_msgs'}:
        raise AssertionError('ROS import: '+name)
    return real(name,*a,**kw)
builtins.__import__=guard
from mmp_terrain.map_loader import MapLoadInput,load_map
r=load_map(MapLoadInput(world='none',data_dir='/unused'))
assert r.elevation_u is None and r.load_metadata==(0.0,(0.0,0.0),(0.0,0.0))
print('ROS imports blocked: load_map succeeded')
'''
    result=subprocess.run([sys.executable,'-B','-c',source],capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr


def test_normalization_owns_data_and_preserves_mask_and_units():
    raw=np.array([[-9999.0,-9000.0,-1.0,0.0],[np.nan,0.25,100.0,1234.5]],dtype=np.float32)
    before=raw.copy()
    got=ML.normalize_elevation(raw,30.0,(123.25,456.5))
    want=np.array([[np.nan,np.nan,np.nan,np.nan],[np.nan,.0025,1.0,12.345]],dtype=np.float32)
    np.testing.assert_array_equal(got.elevation_u,want)
    np.testing.assert_array_equal(raw,before)
    assert got.elevation_u.dtype==np.float32 and got.elevation_u.flags.owndata
    assert not np.shares_memory(got.elevation_u,raw)
    raw[:]=888.0
    np.testing.assert_array_equal(got.elevation_u,want)
    assert got.resolution_u==0.3
    assert got.load_metadata==(30.0,(123.25,456.5),(123.85,457.7))
    assert got.center_u==(123.55,457.1)


def test_small_world_is_owned_after_dataset_removed_and_env_ignored(tmp_path,monkeypatch):
    path=_raster(tmp_path/'tiny.tif',np.arange(1,13,dtype=np.float32).reshape(3,4))
    for key in ('MMP_WS','MMP_FULL_MAP','MMP_DEM','MMP_DEM_VRT_RES'):
        monkeypatch.setenv(key,'/a/nonexistent/override')
    got=ML.load_map(ML.MapLoadInput(world='tiny',data_dir=str(tmp_path)))
    Path(path).unlink()
    np.testing.assert_array_equal(got.elevation_u,np.arange(1,13,dtype=np.float32).reshape(3,4)/100)
    assert got.source_paths==(path,) and got.mission is None
    assert got.load_metadata==(100.0,(0.0,0.0),(3.0,4.0))


def test_full_world_budget_and_geographic_resolution(tmp_path):
    tf=rasterio.Affine(.001,0,10,0,-.001,10)
    _raster(tmp_path/'geographic.tif',np.full((20,30),77.0),tf,'EPSG:4326')
    got=ML.load_map(ML.MapLoadInput(world='geographic',data_dir=str(tmp_path),cell_budget=200))
    assert got.elevation_u.shape==(10,15)
    expected=.002*math.pi/180.0*6371000*math.cos(math.radians(9.99))
    assert got.resolution_m==expected
    np.testing.assert_array_equal(got.elevation_u,np.full((10,15),.77,dtype=np.float32))


def test_corridor_snapshot_reuse_owns_mission_and_does_not_reopen_anchor(tmp_path,monkeypatch):
    request=_corridor(tmp_path)
    ctx=ML.resolve_map_mission(request)
    expected_digest=hashlib.sha256(Path(request.mission_path).read_bytes()).hexdigest()
    Path(request.mission_path).unlink()
    actual_open=rasterio.open; opens=[]
    def record(path,*a,**kw):
        opens.append(str(path)); return actual_open(path,*a,**kw)
    monkeypatch.setattr(rasterio,'open',record)
    got=ML.load_map(request,mission_snapshot=ctx)
    assert opens==[str(tmp_path/'full_map_dem30.tif')]
    assert got.mission is ctx and got.mission.mission_sha==expected_digest
    assert got.mission.mission.start[2]==100.0 and got.mission.mission.goal[2]==120.0
    assert got.elevation_u.dtype==np.float32
    np.testing.assert_array_equal(got.elevation_u,np.full(got.elevation_u.shape,.5,dtype=np.float32))


def test_startup_geometry_resolution_still_accepts_stateless_mission(tmp_path):
    request=_corridor(tmp_path,initial_state=False)
    got=ML.load_map(request)
    assert got.elevation_u is not None
    with pytest.raises(MI.MissionError,match='refuses to invent'):
        MI.command_fields(got.mission.mission.raw)


def test_copied_live_coverage_and_empty_yaml_fallback(tmp_path):
    request=_corridor(tmp_path,extra='  risk_zones: []\n  obstacles: []\n')
    base=ML.load_map(request)
    zones=[[50.0,45.0,2.0]]; obstacles=[[4.0,5.0,1.0,2.0]]
    covered=replace(request,live_zones=zones,live_obstacles=obstacles)
    zones[0][0]=50000.0; obstacles.clear()
    got=ML.load_map(covered)
    assert covered.live_zones==((50.0,45.0,2.0),)
    assert covered.live_obstacles==((4.0,5.0,1.0,2.0),)
    assert got.min_bound_u[0]<base.min_bound_u[0]
    assert got.max_bound_u[0]>base.max_bound_u[0]
    assert got.max_bound_u[1]>base.max_bound_u[1]


def test_yaml_coverage_overrides_live_lists_per_kind(tmp_path):
    request=_corridor(tmp_path,extra='  risk_zones:\n    - center: [50.0, 45.0]\n      reach: 2.0\n  obstacles:\n    - center: [4.0, 5.0]\n      half_x: 1.0\n      half_y: 2.0\n      margin: 0.1\n')
    a=ML.load_map(request)
    b=ML.load_map(replace(request,live_zones=((50000.,50000.,500.),),
                         live_obstacles=((50000.,50000.,500.,500.),)))
    assert a.load_metadata==b.load_metadata
    np.testing.assert_array_equal(a.elevation_u,b.elevation_u)


def test_budget_refusal_happens_before_raster_sampling(tmp_path,monkeypatch):
    request=_corridor(tmp_path)
    with pytest.raises(ValueError,match='exceeds budget'):
        ML.load_map(replace(request,cell_budget=100))
    auto=ML.load_map(replace(request,resolution_m=0.,cell_budget=2000))
    assert auto.resolution_m==100.0
    assert auto.elevation_u.size<=2000


def test_fine_dem_fallback_returns_real_source_and_diagnostic(tmp_path):
    request=_corridor(tmp_path)
    (tmp_path/'full_map_dem30.tif').unlink()
    logs=[]
    got=ML.load_map(request,diagnostic=lambda level,msg: logs.append((level,msg)))
    assert got.source_paths==(str(tmp_path/'full_map.tif'),)*2
    np.testing.assert_allclose(got.elevation_u,.3,rtol=0,atol=0)
    assert any(level=='warn' and 'fine DEM missing' in msg for level,msg in logs)


def test_staging_half_pair_refused_without_using_process_env(tmp_path,monkeypatch):
    request=_corridor(tmp_path)
    monkeypatch.setenv('MMP_FULL_MAP',str(tmp_path/'full_map.tif'))
    with pytest.raises(ValueError,match='half-configured'):
        ML.load_map(replace(request,dem_path=str(tmp_path/'other_dem.tif')))


def test_other_world_ignores_mission_and_none_reads_nothing(tmp_path,monkeypatch):
    _raster(tmp_path/'tiny.tif',np.full((8,9),50.))
    logs=[]
    got=ML.load_map(ML.MapLoadInput(world='tiny',data_dir=str(tmp_path),mission_path='/missing'),
                    diagnostic=lambda level,msg: logs.append((level,msg)))
    assert got.elevation_u.shape==(8,9) and got.mission is None
    assert logs[0][0]=='error' and 'IGNORING corridor' in logs[0][1]
    monkeypatch.setattr(rasterio,'open',lambda *a,**kw: pytest.fail('clear read a raster'))
    empty=ML.load_map(ML.MapLoadInput(world='none',data_dir='/missing',mission_path='/missing'))
    assert empty.elevation_u is None


def test_explicit_empty_asset_strings_keep_existing_refusal(tmp_path):
    request=_corridor(tmp_path)
    with pytest.raises(ValueError,match='half-configured'):
        ML.resolve_map_mission(replace(request,dem_path=''))
    with pytest.raises(rasterio.errors.RasterioIOError):
        ML.resolve_map_mission(replace(request,full_map_override=''))

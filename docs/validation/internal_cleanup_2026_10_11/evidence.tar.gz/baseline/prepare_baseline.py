from pathlib import Path
import json,hashlib,shutil,datetime
BASE=Path('/tmp/mmp_internal_cleanup_20261011/baseline')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def allowed(p):
 assert not {'reports','experiments'} & set(p.parts),str(p)
 return p
expected=json.loads((BASE/'stage6_inputs_expected.json').read_text())
checks={}
for key,value in expected.items():
 p=allowed(Path(value['path'])); checks[key]={'path':str(p),'sha256':sha(p),'expected':value['sha256']}
 checks[key]['equal']=checks[key]['sha256']==value['sha256']
for value in json.loads((BASE/'stage6_sources_expected.json').read_text())['files']:
 p=allowed(Path('/ws')/value['path']); checks['full_source:'+value['path']]={'path':str(p),'sha256':sha(p),'expected':value['sha256']}
 checks['full_source:'+value['path']]['equal']=checks['full_source:'+value['path']]['sha256']==value['sha256']
summary={'checks':checks,'pass':all(x['equal'] for x in checks.values()),'count':len(checks),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(BASE/'identity_comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
assert summary['pass'], [k for k,v in checks.items() if not v['equal']]
preserved=BASE/'preserved';preserved.mkdir(exist_ok=True)
paths=['/ws/install/path_manager/lib/libpath_manager_lib.a','/ws/install/path_manager/lib/libpath_manager_calculations.a','/ws/install/path_optimizer/lib/libpath_optimizer_lib.a','/ws/install/mmp_vehicle_dynamics/lib/libmmp_vehicle_dynamics.a','/ws/install/path_manager/lib/path_manager/path_manager_node','/tmp/mmp_next_modularization_20261010/stage6/consumer/r2/build/r2_external_consumer']
snapshot={}
for name in paths:
 p=allowed(Path(name));dest=preserved/p.name;shutil.copy2(p,dest)
 snapshot[name]={'sha256':sha(p),'preserved_path':str(dest),'preserved_sha256':sha(dest),'bytes':p.stat().st_size}
 assert snapshot[name]['sha256']==snapshot[name]['preserved_sha256']
(BASE/'preserved_manifest.json').write_text(json.dumps(snapshot,indent=2)+'\n')
project=BASE/'project';project.mkdir(exist_ok=True)
old=Path('/tmp/mmp_next_modularization_20261010/stage6/consumer/r2/project')
for name in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']:shutil.copy2(old/name,project/name)
p=project/'main.cpp';s=p.read_text();s=s.replace('#include <thread>','#include <thread>\n#include <sys/resource.h>\n#include <unistd.h>')
s=s.replace('    result=planner->plan(input);',r'''    // Measurement-only instrumentation; production and result schema untouched.
    struct rusage before_usage{}, after_usage{};
    auto resident_kb = []() -> long {
      long size = 0, resident = 0;
      std::ifstream statm("/proc/self/statm");
      statm >> size >> resident;
      return resident * sysconf(_SC_PAGESIZE) / 1024;
    };
    const long rss_before_kb = resident_kb();
    getrusage(RUSAGE_SELF, &before_usage);
    const auto plan_started = std::chrono::steady_clock::now();
    result=planner->plan(input);
    const auto plan_finished = std::chrono::steady_clock::now();
    getrusage(RUSAGE_SELF, &after_usage);
    const long rss_after_kb = resident_kb();
    auto seconds = [](const timeval &value) { return static_cast<double>(value.tv_sec) + static_cast<double>(value.tv_usec) / 1e6; };
    std::ofstream metrics(std::string(argv[4]) + ".metrics.json");
    metrics << std::setprecision(17) << "{\"plan_wall_s\":" << std::chrono::duration<double>(plan_finished-plan_started).count()
            << ",\"plan_user_cpu_s\":" << seconds(after_usage.ru_utime)-seconds(before_usage.ru_utime)
            << ",\"plan_system_cpu_s\":" << seconds(after_usage.ru_stime)-seconds(before_usage.ru_stime)
            << ",\"process_peak_rss_before_plan_kb\":" << before_usage.ru_maxrss
            << ",\"process_peak_rss_after_plan_kb\":" << after_usage.ru_maxrss
            << ",\"resident_before_plan_kb\":" << rss_before_kb
            << ",\"resident_after_plan_kb\":" << rss_after_kb
            << ",\"plan_minor_faults\":" << after_usage.ru_minflt-before_usage.ru_minflt
            << ",\"plan_major_faults\":" << after_usage.ru_majflt-before_usage.ru_majflt
            << ",\"plan_voluntary_context_switches\":" << after_usage.ru_nvcsw-before_usage.ru_nvcsw
            << ",\"plan_involuntary_context_switches\":" << after_usage.ru_nivcsw-before_usage.ru_nivcsw << "}\n";''')
assert s.count('result=planner->plan(input);')==1
p.write_text(s)
(BASE/'measurement_source_manifest.json').write_text(json.dumps({n:sha(project/n) for n in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']},indent=2)+'\n')
print('BASELINE_IDENTITIES',len(checks),'match; preserved',sum(x['bytes'] for x in snapshot.values()),'bytes')

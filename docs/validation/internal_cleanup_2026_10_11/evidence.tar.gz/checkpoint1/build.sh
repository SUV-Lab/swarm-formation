#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
cd /ws
export CMAKE_BUILD_PARALLEL_LEVEL=3
colcon build --base-paths /ws/src/mmp_path_planning/src/path_optimizer /ws/src/mmp_path_planning/src/path_manager --packages-select path_optimizer path_manager --executor sequential --cmake-args -DBUILD_TESTING=ON

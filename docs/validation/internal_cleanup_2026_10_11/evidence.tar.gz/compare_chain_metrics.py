from pathlib import Path
import re,json,sys
old=Path('/tmp/mmp_next_modularization_20261010/stage6/after/tests/path_manager/chain_variants')
new=Path(sys.argv[1])/'tests/path_manager/chain_variants'
# Printed numerical diagnostics only: excludes wall-clock stamps and scheduling
# order (parallel workers can log in a different order). This complements,
# and cannot replace, exact owned-trajectory comparisons in the R2 consumer.
tags=['[DYNAMICS] envelope(', '[TERRAIN] min clearance ', '[TERRAIN-PROFILE]', '[ALT-CAP]', '[FINAL-EVAL]']
def metrics(p):
 out=[]
 for line in p.read_text().splitlines():
  for tag in tags:
   i=line.find(tag)
   if i>=0:
    out.append(line[i:]);break
 return sorted(out)
records=[];total=0
for path in sorted(new.glob('*.log')):
 prior=old/path.name;assert prior.is_file()
 a,b=metrics(prior),metrics(path);total+=len(b)
 records.append({'variant':path.stem,'original_metrics':len(a),'current_metrics':len(b),'same_printed_values':a==b})
summary={'scope':'printed numerical diagnostics from identical source-stage6 chain variants; sorted within each variant to permit parallel log scheduling; timestamps excluded; not exact polynomial comparison','variants':len(records),'total_metrics':total,'pass':len(records)==71 and all(x['same_printed_values'] for x in records),'records':records}
p=Path(sys.argv[1])/'chain_metric_comparison.json';p.write_text(json.dumps(summary,indent=2)+'\n')
print({k:v for k,v in summary.items() if k!='records'})
print([x for x in records if not x['same_printed_values']])

set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
export ROS_DOMAIN_ID=93
cmake -S /tmp/mmp_final_review_20261011/before_override_project -B /tmp/mmp_final_review_20261011/before_override_build -DCMAKE_BUILD_TYPE=Release
cmake --build /tmp/mmp_final_review_20261011/before_override_build -j2
timeout 120 /tmp/mmp_final_review_20261011/before_override_build/override_regression /ws/install/path_manager/share/path_manager/config/optimizer_params.yaml

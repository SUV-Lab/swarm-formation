#!/usr/bin/env python3
"""Preload the installed package before legacy tests add source paths."""
import json
import sys
from pathlib import Path
sys.path.insert(0, '/tmp/mmp_next_modularization_20261010/map/after')
from installed_contract import check_all_modules

root = Path(__file__).resolve().parent
before = check_all_modules()
print('Installed package imports verified before collection:')
print(json.dumps(before, indent=2))
import pytest
status = pytest.main([
    '/ws/map/test_terrain_publisher_env.py',
    '/ws/map/test_mission_resolve.py',
    '/ws/map/test_asset_pin.py',
    '/ws/map/test_map_loader.py',
    '/ws/map/test_map_loader_ros.py',
    '-q', '--junitxml=' + str(root/'all_tests.xml'),
    '--basetemp=/tmp/mmp_final_review_20261011/pytest_temp',
    '-o', 'cache_dir=/tmp/mmp_final_review_20261011/pytest_cache',
])
after = check_all_modules()
assert before == after, 'Tests changed installed package identities'
(root/'installed_test_imports.json').write_text(
    json.dumps({'before': before, 'after': after}, indent=2) + '\n')
sys.exit(int(status))

from pathlib import Path
import json,re,shutil
r=Path('/tmp/mmp_final_review_20261011')
p=r/'tests/summary.json'
shutil.copy2(p,r/'tests/summary_initial_71_expectation.json')
s=json.loads(p.read_text())
expected=set(re.findall(r'if \(v == "([a-z0-9_]+)"\)',Path('/ws/src/mmp_path_planning/src/path_manager/test/chain_experiment_test.cpp').read_text()))
assert len(expected)==73
for name,t in s['suites'].items():
    assert t['exit_code']==0 and t['registered_test_count']==t['executed_test_count']==len(t['focused_tests'])
    assert all(v['pass'] for v in t['focused_tests'].values()) and t['last_log_written_after_start'] and t['permission_denied_count']==0
pmt=s['suites']['path_manager']; e=pmt['scenario_evidence']
tally=(r/'tests/path_manager/chain_variants/tally.txt').read_text()
names=set(re.findall(r'^PASS (\S+)$',tally,re.M))
logs={p.stem for p in (r/'tests/path_manager/chain_variants').glob('*.log')}
assert names==logs==expected and e['chain_failure_count']==0 and e['all_chain_logs_written_after_start'] and e['risk_154_0']
e.update(expected_chain_variant_count=len(expected),variant_names_exact=True)
pmt['pass']=True
s['pass']=all(t['pass'] for t in s['suites'].values())
s['summary_correction']='Original summary harness expected the previous 71 variants. Runner discovers variants from source; two new switches add tailcap and prefixfallback, all 73 passed. Re-audited existing raw CTest logs without rerunning tests or changing results.'
p.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({'pass':s['pass'],'ctest':s['total_test_count'],'chain':len(expected),'risk':154,'correction':s['summary_correction']},indent=2))

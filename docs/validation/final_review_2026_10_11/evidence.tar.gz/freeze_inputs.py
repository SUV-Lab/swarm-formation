from pathlib import Path
import datetime, hashlib, json, sys
r=Path('/tmp/mmp_final_review_20261011')
old=json.loads(Path('/tmp/mmp_internal_cleanup_20261011/after/inputs_before.json').read_text())['files']
files={}
for key,entry in old.items():
    name=entry['path']
    for package in ['path_manager','path_optimizer','mmp_vehicle_dynamics']:
        prefix='/ws/install/'+package+'/'
        if name.startswith(prefix):
            name=str(r/'install'/package)+'/'+name[len(prefix):]
            break
    p=Path(name)
    assert not {'reports','experiments'}.intersection(p.parts)
    assert p.is_file(),str(p)
    files[key]={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files}
(r/sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
print('Frozen',len(files),'explicit source/install/input files')
if len(sys.argv)>2:
    assert files==json.loads((r/sys.argv[2]).read_text())['files'],'inputs changed during verification'
    print('Inputs unchanged')

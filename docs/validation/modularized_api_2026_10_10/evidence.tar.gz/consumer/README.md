# Stage 6 installed external API consumers

Four copied installed examples were freshly configured/built in a separate
CMake project and run successfully: planning, evaluation, simulation, and
owned visualization-message preparation. A second fresh external project
reused the already validated stage 4 R2 consumer, with visualization enabled,
against the final exported targets on isolated ROS domain 84.

`examples_summary.json` is the 4/4 result. `r2/owned_comparison.json` compares
every serialized owned-result field exactly with the original stage 1 baseline
at `/tmp/mmp_next_modularization_20261010/baseline/r2_consumer/result.json`.
That schema omits absolute wall-clock start stamps; no other normalization is
applied. The separate wire comparison explicitly narrows the owned doubles
to existing float32 PolyTraj fields, then compares with recorded baseline GUI
wire data. Baseline identities/hashes and exact comparison outcomes are saved.

`inputs_before.json` and `inputs_after.json` list original/resolved installed
paths, archive/export/config/example identities, and involved source hashes.
They are identical across this check. This verifies installed target use in
the current ROS workspace, not a source-removed SDK or clean-machine build.
No workspace package builds, installs, or CTest were performed by this harness.

`build_metadata` contains compile commands and link commands only. Build trees,
object files and executables are intentionally omitted from this compact proof.
The main summary records commands and timings; baseline evidence is referenced
rather than duplicated. Reproduction scripts retain their original `/tmp`
working paths and require the corresponding installed workspace and baseline.

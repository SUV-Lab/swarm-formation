#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil
base=Path(__file__).resolve().parent
summary=json.loads((base/'summary.json').read_text())
if not summary.get('pass'): raise SystemExit('Refuse to package incomplete/failed consumer proof')
out=base/'evidence'
if out.exists(): raise SystemExit('Evidence output already exists')
out.mkdir()
files=['run_installed_consumers.py','package_evidence.py','summary.json','examples_summary.json',
       'inputs_before.json','inputs_after.json',
       'examples/examples_configure.log','examples/examples_build.log',
       'examples/flight_evaluator.log','examples/trajectory_simulation.log',
       'examples/planning_visualization.log','examples/mission_planner.log',
       'examples/build/compile_commands.json',
       'r2/r2_configure.log','r2/r2_build.log','r2/r2_run.log',
       'r2/terrain_loader.log','r2/r2_wire_compare.log','r2/result.json',
       'r2/owned_comparison.json','r2/wire_comparison.json',
       'r2/compare.py','r2/compare_runs.py','r2/build/compile_commands.json']
files += ['examples/project/'+name for name in ('CMakeLists.txt','README.md',
          'mission_planner_example.cpp','flight_evaluator_example.cpp','planning_visualization_example.cpp')]
files += ['r2/project/'+name for name in ('CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h')]
files += ['examples/build/CMakeFiles/'+name+'_client.dir/link.txt' for name in
          ('mission_planner','flight_evaluator','trajectory_simulation','planning_visualization')]
files += ['r2/build/CMakeFiles/r2_external_consumer.dir/link.txt']
manifest={}
for name in files:
    src=base/name
    # Keep command/link metadata, not a misleading partial build tree.
    destname=name.replace('/build/','/build_metadata/')
    dst=out/destname;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    manifest[destname]={'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size}
src=Path('/ws/install/mmp_vehicle_dynamics/share/mmp_vehicle_dynamics/examples/trajectory_simulation_example.cpp')
dst=out/'examples/installed_vehicle/trajectory_simulation_example.cpp'
dst.parent.mkdir(parents=True);shutil.copy2(src,dst)
manifest[str(dst.relative_to(out))]={'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size}
readme='''# Stage 6 installed external API consumers

Four copied installed examples were freshly configured/built in a separate
CMake project and run successfully: planning, evaluation, simulation, and
owned visualization-message preparation. A second fresh external project
reused the already validated stage 4 R2 consumer, with visualization enabled,
against the final exported targets on isolated ROS domain 84.

`examples_summary.json` is the 4/4 result. `r2/owned_comparison.json` compares
every serialized owned-result field exactly with the original stage 1 baseline
at `/tmp/mmp_next_modularization_20261010/baseline/r2_consumer/result.json`.
That schema omits absolute wall-clock start stamps; no other normalization is
applied. The separate wire comparison explicitly narrows the owned doubles
to existing float32 PolyTraj fields, then compares with recorded baseline GUI
wire data. Baseline identities/hashes and exact comparison outcomes are saved.

`inputs_before.json` and `inputs_after.json` list original/resolved installed
paths, archive/export/config/example identities, and involved source hashes.
They are identical across this check. This verifies installed target use in
the current ROS workspace, not a source-removed SDK or clean-machine build.
No workspace package builds, installs, or CTest were performed by this harness.

`build_metadata` contains compile commands and link commands only. Build trees,
object files and executables are intentionally omitted from this compact proof.
The main summary records commands and timings; baseline evidence is referenced
rather than duplicated. Reproduction scripts retain their original `/tmp`
working paths and require the corresponding installed workspace and baseline.
'''
(out/'README.md').write_text(readme)
manifest['README.md']={'sha256':hashlib.sha256((out/'README.md').read_bytes()).hexdigest(),
                       'bytes':(out/'README.md').stat().st_size}
(out/'artifact_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'evidence':str(out),'artifact_count':len(manifest),
                  'bytes':sum(x['bytes'] for x in manifest.values()),'pass':summary['pass']},indent=2))

#!/usr/bin/env python3
"""Final installed-target checks only; never build/install a workspace package."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

BASE=Path(__file__).resolve().parent
INSTALL=Path('/ws/install')
SOURCE=Path('/ws')
STAGE4=Path('/tmp/mmp_stage4_visualization_20261010/r2_consumer')
BASELINE=Path('/tmp/mmp_next_modularization_20261010/baseline')
assert os.environ.get('ROS_DOMAIN_ID') == '84', 'Require isolated ROS domain 84'
ENV=dict(os.environ)
ENV.pop('MMP_VALUE_INPUT',None)
ENV.pop('MMP_VISUALIZATION_OFF',None)
ENV.pop('MMP_REUSE_CONNECTED_COMPLETE',None)
EXAMPLES=BASE/'examples'
R2=BASE/'r2'
for folder in (EXAMPLES,R2): folder.mkdir(parents=True,exist_ok=True)
summary={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'ros_domain_id':84,'checks':{},'examples':{},'r2':{}}


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def capture_inputs():
    installed=[
      'path_manager/lib/libpath_manager_lib.a',
      'path_manager/lib/libpath_manager_calculations.a',
      'path_optimizer/lib/libpath_optimizer_lib.a',
      'mmp_vehicle_dynamics/lib/libmmp_vehicle_dynamics.a',
      'path_manager/share/path_manager/cmake/export_path_managerExport.cmake',
      'path_optimizer/share/path_optimizer/cmake/export_path_optimizerExport.cmake',
      'mmp_vehicle_dynamics/share/mmp_vehicle_dynamics/cmake/export_mmp_vehicle_dynamicsExport.cmake',
      'path_manager/share/path_manager/config/optimizer_params.yaml',
      'path_manager/share/path_manager/config/drone_hardware.yaml',
      'mmp_vehicle_dynamics/share/mmp_vehicle_dynamics/examples/trajectory_simulation_example.cpp',
    ]
    installed += ['path_manager/share/path_manager/examples/library_consumer/'+name for name in
                  ('CMakeLists.txt','README.md','mission_planner_example.cpp',
                   'flight_evaluator_example.cpp','planning_visualization_example.cpp')]
    # Source paths are evidence only: CMake consumes only installed exports.
    sources=[
      'src/mmp_path_planning/src/path_manager/CMakeLists.txt',
      'src/mmp_vehicle_dynamics/CMakeLists.txt',
      'src/mmp_path_planning/src/path_optimizer/CMakeLists.txt',
      'src/mmp_path_planning/src/path_optimizer/src/poly_traj_optimizer.cpp',
      'src/mmp_path_planning/src/path_optimizer/src/route_cost_profile.cpp',
      'src/mmp_path_planning/src/path_optimizer/src/optimizer_session.cpp',
      'src/mmp_vehicle_dynamics/src/flight_dynamics.cpp',
      'src/mmp_vehicle_dynamics/src/vehicle_model.cpp',
      'src/mmp_vehicle_dynamics/src/trajectory_simulation.cpp',
      'src/mmp_vehicle_dynamics/src/dynamics_sim_node.cpp',
      'src/mmp_vehicle_dynamics/include/mmp_vehicle_dynamics/trajectory_simulation.hpp',
      'src/mmp_vehicle_dynamics/include/mmp_vehicle_dynamics/point_mass_eom.hpp',
      'src/mmp_vehicle_dynamics/include/mmp_vehicle_dynamics/vehicle_model.hpp',
      'src/mmp_terrain/mmp_terrain/map_loader.py',
      'src/mmp_terrain/mmp_terrain/ros_terrain.py',
      'src/mmp_terrain/mmp_terrain/terrain_publisher.py',
      'src/mmp_terrain/data/scenarios/missions/r2_ridge_crossing.yaml',
    ]
    computations=['mission_planner','planning_environment','route_slice_solver','route_slice_batch',
                  'flight_assembly','flight_evaluator','direct_trajectory_solver','mission_geometry',
                  'route_postprocessing','mission_route_search','route_search_backend','terminal_phase',
                  'transition_phase','waypoint_eval','path_manager','planning_visualization_data',
                  'ros_planning_visualization','ros_planning_backend','ros_terrain_grid','builtin_route_search',
                  'ros_route_search','trajectory_message','replan_fsm','segment_chain_planner']
    sources += ['src/mmp_path_planning/src/path_manager/src/'+name+'.cpp' for name in computations]
    sources += ['src/mmp_path_planning/src/path_manager/include/path_manager/'+name+'.h' for name in
                ('mission_planner','mission_plan','mission_planning_backend','planning_computation',
                 'plan_settings','planning_environment','flight_evaluator','flight_evaluation',
                 'ros_planning_backend','planning_visualization_data','ros_planning_visualization')]
    values={}
    for category,root,files in (('installed',INSTALL,installed),('source',SOURCE,sources)):
        for relative in files:
            path=root/relative
            if not path.is_file(): raise RuntimeError('Missing required input '+str(path))
            values[category+':'+relative]={'path':str(path),'resolved_path':str(path.resolve()),
                                         'sha256':digest(path),'bytes':path.stat().st_size}
    return values


def run(label,command,folder,timeout=300):
    started=time.monotonic()
    log=folder/(label+'.log')
    with log.open('w') as stream:
        try:
            completed=subprocess.run(command,cwd=folder,env=ENV,stdout=stream,
                                     stderr=subprocess.STDOUT,timeout=timeout)
            code=completed.returncode
        except subprocess.TimeoutExpired:
            code=124
    entry={'command':command,'exit_code':code,'elapsed_s':time.monotonic()-started,'log':str(log)}
    summary['checks'][label]=entry
    print(label,code,flush=True)
    if code: raise RuntimeError(label+' failed; inspect '+str(log))
    return entry


def installed_compile_paths(path):
    commands=json.loads(path.read_text())
    bad=[record['command'] for record in commands if '/ws/src/' in record['command']]
    if bad: raise RuntimeError('External compile command contains source-tree path')
    return {'translation_units':len(commands),'no_source_tree_include_or_source':not bad}


def stop_owned(process):
    if process is None or process.poll() is not None: return
    os.killpg(process.pid,signal.SIGINT)
    try: process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try: process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10)


before=None
terrain=None
try:
    before=capture_inputs()
    (BASE/'inputs_before.json').write_text(json.dumps(before,indent=2)+'\n')
    export=INSTALL/'path_manager/share/path_manager/cmake/export_path_managerExport.cmake'
    if 'path_manager::path_manager_calculations' not in export.read_text():
        raise RuntimeError('Final target export has not been installed')
    project=EXAMPLES/'project'
    if project.exists() or (EXAMPLES/'build').exists():
        raise RuntimeError('Refuse reuse of earlier external example source/build; archive this run first')
    shutil.copytree(INSTALL/'path_manager/share/path_manager/examples/library_consumer',project)
    run('examples_configure',['cmake','-S',str(project),'-B',str(EXAMPLES/'build'),
                             '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],EXAMPLES)
    run('examples_build',['cmake','--build',str(EXAMPLES/'build'),'-j2'],EXAMPLES,600)
    summary['example_compile_paths']=installed_compile_paths(EXAMPLES/'build/compile_commands.json')
    for name in ('flight_evaluator','trajectory_simulation','planning_visualization','mission_planner'):
        command=[str(EXAMPLES/'build'/(name+'_client'))]
        if name=='mission_planner': command.append(str(INSTALL/'path_manager/share/path_manager/config/optimizer_params.yaml'))
        entry=run(name,command,EXAMPLES,600)
        summary['examples'][name]=entry
    summary['examples_pass']=len(summary['examples'])==4 and all(x['exit_code']==0 for x in summary['examples'].values())
    (BASE/'examples_summary.json').write_text(json.dumps({'pass':summary['examples_pass'],
       'count':len(summary['examples']),'examples':summary['examples'],
       'compile_paths':summary['example_compile_paths']},indent=2)+'\n')

    project=R2/'project'
    if project.exists() or (R2/'build').exists():
        raise RuntimeError('Refuse reuse of earlier external R2 source/build; archive this run first')
    project.mkdir()
    for filename in ('CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h'):
        shutil.copy2(STAGE4/filename,project/filename)
    for filename in ('compare.py','compare_runs.py'):
        shutil.copy2(STAGE4/filename,R2/filename)
    summary['r2']['source_origin']=str(STAGE4)
    summary['r2']['source_sha256']={name:digest(project/name) for name in
                                  ('CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h')}
    run('r2_configure',['cmake','-S',str(project),'-B',str(R2/'build'),
                       '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],R2)
    run('r2_build',['cmake','--build',str(R2/'build'),'-j2'],R2,600)
    summary['r2']['compile_paths']=installed_compile_paths(R2/'build/compile_commands.json')
    result=R2/'result.json'
    with (R2/'terrain_loader.log').open('w') as log:
        terrain=subprocess.Popen(['ros2','run','mmp_terrain','terrain_publisher','--ros-args','-p','world:=none'],
                                 cwd=R2,env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        summary['r2']['own_loader_pid']=terrain.pid
        try:
            run('r2_run',[str(R2/'build/r2_external_consumer'),
                         str(INSTALL/'path_manager/share/path_manager/config/optimizer_params.yaml'),
                         str(INSTALL/'path_manager/share/path_manager/config/drone_hardware.yaml'),
                         '/ws/src/mmp_terrain/data/scenarios/missions/r2_ridge_crossing.yaml',str(result)],R2,900)
        finally:
            stop_owned(terrain)
    reference=json.loads((BASELINE/'r2_consumer/result.json').read_text())
    current=json.loads(result.read_text())
    exact={key:reference[key]==current.get(key) for key in reference}
    comparison={'baseline':str(BASELINE/'r2_consumer/result.json'),
                'baseline_sha256':digest(BASELINE/'r2_consumer/result.json'),
                'result':str(result),'result_sha256':digest(result),
                'field_exact':exact,'same_keys':set(reference)==set(current),
                'normalization':'None. Compare every serialized owned-result field exactly; baseline schema does not serialize absolute wall-clock start stamps.',
                'pass':all(exact.values()) and set(reference)==set(current)}
    (R2/'owned_comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
    summary['r2']['owned_comparison']=comparison
    if not comparison['pass']: raise RuntimeError('Fresh installed R2 result differs from original baseline')
    run('r2_wire_compare',['python3',str(R2/'compare.py'),str(BASELINE/'gui/mission.json'),str(result),str(R2/'wire_comparison.json')],R2)
    summary['r2']['wire_pass']=json.loads((R2/'wire_comparison.json').read_text())['pass']
    summary['r2']['pass']=comparison['pass'] and summary['r2']['wire_pass']
except Exception as error:
    summary['error']=str(error)
finally:
    stop_owned(terrain)
    try:
        after=capture_inputs()
        (BASE/'inputs_after.json').write_text(json.dumps(after,indent=2)+'\n')
        summary['frozen_inputs_unchanged']=before is not None and before==after
    except Exception as error:
        summary['snapshot_error']=str(error)
        summary['frozen_inputs_unchanged']=False
    summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary['pass']=('error' not in summary and summary.get('examples_pass',False)
                     and summary['r2'].get('pass',False) and summary['frozen_inputs_unchanged'])
    (BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
raise SystemExit(0 if summary['pass'] else 1)

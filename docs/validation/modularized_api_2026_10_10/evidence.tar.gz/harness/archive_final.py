from pathlib import Path
import datetime,hashlib,json,os,shutil,tarfile
root=Path('/home/suv/ws/temp/MMP_module/MMP')
b=Path('/tmp/mmp_next_modularization_20261010/stage6')
out=root/'src/mmp_path_planning/docs/validation/modularized_api_2026_10_10'
out.mkdir(parents=True,exist_ok=True)
files={}
def add(src,name):
 src=Path(src)
 assert src.is_file() and not {'reports','experiments'}.intersection(src.parts)
 assert name not in files,name
 files[name]=src

def tree(src,dest):
 src=Path(src)
 for dp,dirs,names in os.walk(src,topdown=True,followlinks=False):
  dirs[:]=[d for d in dirs if d not in {'reports','experiments','__pycache__','.git'} and not (Path(dp)/d).is_symlink()]
  for n in sorted(names):
   p=Path(dp)/n
   if p.is_symlink() or p.suffix in {'.pyc','.pid'}: continue
   add(p,str(Path(dest)/p.relative_to(src)))

ct=json.loads((b/'after/tests/summary.json').read_text())
gui=json.loads((b/'after/gui/summary.json').read_text())
consumer=json.loads((b/'consumer/evidence/summary.json').read_text())
assert ct['pass'] and ct['total_test_count']==41
assert gui['pass'] and gui['abort']['numeric_exact']
assert consumer['pass'] and consumer['frozen_inputs_unchanged']
assert len(consumer['examples'])==4 and consumer['r2']['pass']
source=json.loads((b/'after/source_before.json').read_text())
mismatch=[f['path'] for f in source['files'] if hashlib.sha256((root/f['path']).read_bytes()).hexdigest()!=f['sha256']]
assert not mismatch,mismatch
summary={'pass':True,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'build_packages':['mmp_vehicle_dynamics','path_optimizer','path_manager'],
 'build_exit_code':0,'build_scope':'bounded incremental Release build in existing mmp_dev container',
 'ctest':41,'external_cpp_examples':4,'r2_owned_fields_exact':True,'r2_wire_exact':True,
 'rviz_abort_recovery':True,'source_files_unchanged':len(source['files']),
 'external_installed_inputs_unchanged':True,
 'optimizer_and_search_sources_unchanged_from':'57ac7a8',
 'review':'Separate read-only review of ROS reuse, ownership, adoption invalidation, units, 3DOF strategies and ABORT found no blocking issue; retained scope caveats documented.'}
(b/'after/final_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n in ['build.log','test_driver.log','gui_driver.log','run_fresh_tests.py','prior_registered_tests.json','source_before.json','source_after_gui.json','final_summary.json']:
 add(b/'after'/n,'runtime/'+n)
tree(b/'after/tests','runtime/tests');tree(b/'after/gui','runtime/gui');tree(b/'consumer/evidence','consumer')
for n in ['apply_receipt.json','overlay_manifest.json','preparation_checks.json','stage6.patch']:
 add(b/n,'change/'+n)
for f in json.loads((b/'overlay_manifest.json').read_text()):
 p=root/f['path']; assert hashlib.sha256(p.read_bytes()).hexdigest()==f['overlay_sha256']
 add(p,'source/'+f['path'])
base=Path('/tmp/mmp_next_modularization_20261010/baseline')
add(base/'r2_consumer/result.json','baseline/owned_result.json')
add(base/'gui/mission.json','baseline/gui_mission.json')
add(base/'gui/planner.log','baseline/gui_planner.log')
assert (base/'r2_consumer/result.json').read_bytes()==(b/'consumer/evidence/r2/result.json').read_bytes()
add('/tmp/mmp_next_modularization_20261010/after/gui_harness.py','harness/gui_harness.py')
for n in ['gui_isolated.py','record_run.py','compare_runs.py','probe_abort.py','compare_frontend.py']:
 p=Path('/tmp/mmp_next_modularization_20261010/after/harnesses')/n
 if p.exists(): add(p,'harness/'+n)
add(Path(__file__),'harness/archive_final.py')
manifest={'files':[{'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())]}
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
manifest['archive']={'path':'evidence.tar.gz','bytes':(out/'evidence.tar.gz').stat().st_size,'sha256':hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'archive_bytes':manifest['archive']['bytes'],'summary':summary},indent=2))

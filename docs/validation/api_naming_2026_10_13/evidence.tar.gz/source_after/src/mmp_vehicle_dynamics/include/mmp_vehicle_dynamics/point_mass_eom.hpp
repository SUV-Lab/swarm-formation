// 3DOF flight-path point-mass equations of motion — the ONE forward model
// shared by every consumer (ADR-0002: the neutral benchmark's public EOM).
//
// Extracted from the trajectory-follower simulator (dynamics_sim_node),
// which previously held these formulas as private members of a node class:
// the follower's CONTROLLER (sampling a reference PolyTraj to pick inputs)
// stays where it was — only the vehicle-agnostic physics moved here, so a
// transition GENERATOR can propagate candidate input profiles through the
// exact same equations the follower integrates and the cruise inverse
// dynamics (flight_dynamics.hpp) audits.
//
// State:  position [m, caller's right-handed z-up frame], speed V [m/s],
//         flight-path angle gamma [rad], heading psi [rad]. Heading is
//         measured from +X toward +Y. Current MMP adapters retain planner
//         axes (+X north, +Y west, +Z up) when converting u to metres;
//         unit scaling does not rotate these axes into ENU.
// Inputs: thrust T [N], lift L [N], bank mu [rad], drag D [N]
//
//   Vdot     = (T - D)/m - g sin(gamma)
//   gammadot = L cos(mu)/(m V) - g cos(gamma)/V
//   psidot   = L sin(mu)/(m V cos(gamma))
//   posdot   = V [cos(gamma)cos(psi), cos(gamma)sin(psi), sin(gamma)]
//
// REPRESENTABILITY GUARDS — declared limits, not hidden regularization:
//   * speed is floored at kMinSpeedForRates when dividing (a rate at V=0 is
//     undefined; the caller must treat V near zero as outside the model)
//   * cos(gamma) is floored at kMinCosGamma in psidot: near-vertical flight
//     (|gamma| beyond ~87 deg) is NOT representable in this parameterization
//     (heading becomes singular). This is the same limit the follower's
//     integrator clamps gamma to (+-89 deg). A benchmark that needs
//     near-vertical launch must say so and extend the model, not rely on
//     the guard silently absorbing it.
#ifndef MMP_VEHICLE_DYNAMICS_POINT_MASS_EOM_HPP
#define MMP_VEHICLE_DYNAMICS_POINT_MASS_EOM_HPP

#include <algorithm>
#include <cmath>

#include <Eigen/Core>

#include "mmp_vehicle_dynamics/flight_dynamics.hpp"

namespace mmp_vehicle_dynamics {

constexpr double kMinSpeedForRates = 1.0;   // m/s
constexpr double kMinCosGamma = 0.05;       // |gamma| <~ 87.1 deg

struct PointMassState
{
  Eigen::Vector3d position_m = Eigen::Vector3d::Zero();
  double speed_mps = 0.0;
  double flight_path_angle_rad = 0.0;
  double heading_rad = 0.0;
};

struct PointMassInputs
{
  double thrust_n = 0.0;
  double lift_n = 0.0;
  double drag_n = 0.0;
  double bank_rad = 0.0;
};

struct PointMassDerivative
{
  Eigen::Vector3d position = Eigen::Vector3d::Zero();
  double speed = 0.0;
  double flight_path_angle = 0.0;
  double heading = 0.0;
};

inline Eigen::Vector3d pointMassVelocity(const PointMassState &s)
{
  const double cg = std::cos(s.flight_path_angle_rad);
  return s.speed_mps * Eigen::Vector3d(cg * std::cos(s.heading_rad),
                                       cg * std::sin(s.heading_rad),
                                       std::sin(s.flight_path_angle_rad));
}

inline PointMassDerivative pointMassDerivative(const Parameters &p,
                                               const PointMassState &s,
                                               const PointMassInputs &u)
{
  PointMassDerivative d;
  d.position = pointMassVelocity(s);
  d.speed = (u.thrust_n - u.drag_n) / p.mass_kg -
            p.gravity_mps2 * std::sin(s.flight_path_angle_rad);
  const double safe_speed = std::max(s.speed_mps, kMinSpeedForRates);
  d.flight_path_angle =
      u.lift_n * std::cos(u.bank_rad) / (p.mass_kg * safe_speed) -
      p.gravity_mps2 * std::cos(s.flight_path_angle_rad) / safe_speed;
  const double cos_gamma =
      std::max(kMinCosGamma, std::abs(std::cos(s.flight_path_angle_rad)));
  d.heading = u.lift_n * std::sin(u.bank_rad) /
              (p.mass_kg * safe_speed * cos_gamma);
  return d;
}

// Aero closure — the ONE place commanded (CL, thrust, bank) becomes
// realized forces, shared by the follower's controller and the transition
// generator. Saturation is NEVER silent (review find: a clamp that quietly
// rewrites an infeasible command makes a search over commands lie to
// itself): every limit hit and every state outside the parameterization's
// validity is reported alongside the realized inputs, and the CALLER
// decides whether a saturated command is acceptable (a follower riding a
// limit) or disqualifying (a transition candidate that demanded the
// impossible).
struct PointMassForceResult
{
  PointMassInputs inputs;
  bool cl_saturated{false};
  bool thrust_saturated{false};
  bool bank_saturated{false};
  // False when the STATE itself is outside what this parameterization can
  // meaningfully evaluate: speed below the rate floor or |gamma| in the
  // heading-singular band (see the header guards above).
  bool state_representable{true};
  bool saturated() const
  {
    return cl_saturated || thrust_saturated || bank_saturated;
  }
};

inline PointMassForceResult pointMassForces(const Parameters &p,
                                            const PointMassState &s,
                                            double commanded_cl,
                                            double commanded_thrust_n,
                                            double commanded_bank_rad)
{
  PointMassForceResult r;
  r.state_representable =
      s.speed_mps >= kMinSpeedForRates &&
      std::abs(std::cos(s.flight_path_angle_rad)) >= kMinCosGamma;
  const double rho = airDensity(p, s.position_m.z());
  const double q = 0.5 * rho * s.speed_mps * s.speed_mps;
  const double cl_lo = std::max(0.0, p.lift_coefficient_min);
  const double cl = std::clamp(commanded_cl, cl_lo, p.lift_coefficient_max);
  r.cl_saturated = cl != commanded_cl;
  r.inputs.lift_n = q * p.wing_area_m2 * cl;
  const double cd =
      p.zero_lift_drag_coefficient + p.induced_drag_factor * cl * cl;
  r.inputs.drag_n = q * p.wing_area_m2 * cd;
  r.inputs.thrust_n =
      std::clamp(commanded_thrust_n, p.thrust_min_n, p.thrust_max_n);
  r.thrust_saturated = r.inputs.thrust_n != commanded_thrust_n;
  r.inputs.bank_rad = std::clamp(commanded_bank_rad, -p.bank_angle_max_rad,
                                 p.bank_angle_max_rad);
  r.bank_saturated = r.inputs.bank_rad != commanded_bank_rad;
  return r;
}

}  // namespace mmp_vehicle_dynamics

#endif  // MMP_VEHICLE_DYNAMICS_POINT_MASS_EOM_HPP

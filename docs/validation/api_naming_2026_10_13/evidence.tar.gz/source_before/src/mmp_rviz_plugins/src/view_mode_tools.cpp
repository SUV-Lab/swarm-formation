#include "mmp_rviz_plugins/view_mode_tools.hpp"

#include "rviz_common/display_context.hpp"
#include "rviz_common/view_manager.hpp"
#include "rviz_common/view_controller.hpp"
#include "rviz_common/viewport_mouse_event.hpp"

namespace mmp_rviz_plugins
{

// ---------------------------------------------------------------------------
// FollowCameraTool
// ---------------------------------------------------------------------------

void FollowCameraTool::activate()
{
  auto * vm = context_->getViewManager();
  vm->setCurrentViewControllerType("rviz_default_plugins/ThirdPersonFollower");

  auto * vc = vm->getCurrent();
  if (!vc) return;

  // Target frame: drone_0_chase — the follower's SMOOTHED camera frame
  // (position = vehicle, yaw EMA+slew-limited, roll/pitch never transfer).
  // Following drone_0_base directly whipped the view with every bank/pitch;
  // the chase frame pans instead. Smoothing lives in the follower
  // (chase_yaw_tau_s / chase_yaw_rate_max_dps params), not here.
  auto * tf_prop = vc->subProp("Target Frame");
  if (tf_prop) tf_prop->setValue("drone_0_chase");

  auto * distance_prop = vc->subProp("Distance");
  if (distance_prop) distance_prop->setValue(10.0f);

  // Yaw=0: look in +X direction of drone_0_base (= forward)
  auto * yaw_prop = vc->subProp("Yaw");
  if (yaw_prop) yaw_prop->setValue(-3.14f);

  // Pitch: slightly downward to see the drone
  auto * pitch_prop = vc->subProp("Pitch");
  if (pitch_prop) pitch_prop->setValue(0.0f);

  // Eye Point: 15m behind and 5m above in drone_0_base local frame
  auto * eye_prop = vc->subProp("Focal Point");
  if (eye_prop) {
    auto * x = eye_prop->subProp("X");
    auto * y = eye_prop->subProp("Y");
    auto * z = eye_prop->subProp("Z");
    if (x) x->setValue(0.0f);
    if (y) y->setValue(0.0f);
    if (z) z->setValue(0.0f);
  }
}

int FollowCameraTool::processMouseEvent(rviz_common::ViewportMouseEvent & event)
{
  context_->getViewManager()->getCurrent()->handleMouseEvent(event);
  return Render;
}

// ---------------------------------------------------------------------------
// OrthoViewTool
// ---------------------------------------------------------------------------

void OrthoViewTool::activate()
{
  auto * vm = context_->getViewManager();
  vm->setCurrentViewControllerType("rviz_default_plugins/TopDownOrtho");

  auto * vc = vm->getCurrent();
  if (!vc) return;

  // Use fixed frame (map) as reference
  auto * tf_prop = vc->subProp("Target Frame");
  if (tf_prop) tf_prop->setValue("<Fixed Frame>");
}

int OrthoViewTool::processMouseEvent(rviz_common::ViewportMouseEvent & event)
{
  context_->getViewManager()->getCurrent()->handleMouseEvent(event);
  return Render;
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::FollowCameraTool, rviz_common::Tool)
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::OrthoViewTool, rviz_common::Tool)

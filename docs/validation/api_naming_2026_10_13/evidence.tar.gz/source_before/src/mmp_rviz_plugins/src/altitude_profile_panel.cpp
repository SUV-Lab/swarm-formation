#include "mmp_rviz_plugins/altitude_profile_panel.hpp"

#include <QPainter>

#include "mmp_rviz_plugins/profile_decimate.hpp"
#include <QPen>
#include <QBrush>
#include <QFont>
#include <QFontMetrics>
#include <QPolygonF>
#include <QLinearGradient>
#include <QMetaObject>
#include <QHBoxLayout>
#include <std_msgs/msg/float64.hpp>
#include <mmp_traj_utils/poly_traj.hpp>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <algorithm>

namespace mmp_rviz_plugins
{

// Trajectory xy coordinates are in grid-cell units. One cell = 100 m.
// Keep this in sync with TARGET_CELL_SIZE_M in mmp_terrain/terrain_publisher.py.
static constexpr double GRID_CELL_SIZE_M = 100.0;

// Speed of sound at sea level, ISA (m/s)
static constexpr double MACH_1_MPS = 340.29;

// ============================================================================
// AltitudeProfileWidget Implementation
// ============================================================================

AltitudeProfileWidget::AltitudeProfileWidget(QWidget * parent)
: QWidget(parent),
  max_distance_(0.0),
  min_altitude_(0.0),
  max_altitude_(0.0),
  has_data_(false),
  current_distance_(0.0),
  current_altitude_(0.0),
  has_current_(false)
{
  setMinimumHeight(180);
  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  setStyleSheet("background-color: white;");
}

void AltitudeProfileWidget::setTrajectoryData(
  const std::vector<geometry_msgs::msg::Point> & trajectory_points,
  const std::vector<double> & distances,
  const std::vector<double> & terrain_heights,
  const std::vector<double> & obstacle_top,
  const std::vector<double> & obstacle_bot,
  const std::vector<double> & combined_risk,
  const std::vector<std::vector<double>> & risk_band_lower,
  const std::vector<std::vector<double>> & risk_band_floor,
  const std::vector<std::vector<double>> & risk_band_top)
{
  trajectory_points_ = trajectory_points;
  distances_ = distances;
  terrain_heights_ = terrain_heights;
  obstacle_top_ = obstacle_top;
  obstacle_bot_ = obstacle_bot;
  combined_risk_ = combined_risk;
  risk_band_lower_ = risk_band_lower;
  risk_band_floor_ = risk_band_floor;
  risk_band_top_ = risk_band_top;

  if (trajectory_points_.empty() || distances_.empty()) {
    has_data_ = false;
    cache_dirty_ = true;
    update();
    return;
  }

  has_data_ = true;

  max_distance_ = distances_.back();
  refreshYRange();

  cache_dirty_ = true;
  update();
}

void AltitudeProfileWidget::refreshYRange()
{
  if (!has_data_ || max_distance_ <= 0.0) return;

  double data_min = 0.0;   // sea level always in range
  double data_max = 10.0;

  for (const auto & point : trajectory_points_) {
    data_min = std::min(data_min, point.z);
    data_max = std::max(data_max, point.z);
  }

  // Finite obstacle tops join the y-range (full columns are clamped in draw).
  for (double t : obstacle_top_) {
    if (!std::isnan(t) && t < 1e6) data_max = std::max(data_max, t);
  }

  for (size_t i = 0; i < terrain_heights_.size(); ++i) {
    // NaN terrain = water surface at 0 m; include it in the y-range
    double h = std::isnan(terrain_heights_[i]) ? 0.0 : terrain_heights_[i];
    data_min = std::min(data_min, h);
    data_max = std::max(data_max, h);
  }
  // Risk domes deliberately do NOT drive the axis: dome tops reach km-scale
  // and squashed the trajectory/terrain into an unreadable strip (user
  // feedback). The axis stays trajectory/terrain-scaled; dome fills simply
  // clip at the plot top, and the roof line is what matters near the path.

  // Round axis: pick a 1-2-5 tick step for ~4-5 ticks, snap the top to it,
  // and pin the floor a fraction of a step below 0 so the sea renders as a
  // thin consistent band instead of an arbitrary negative region.
  auto nice_step = [](double raw) {
    const double mag = std::pow(10.0, std::floor(std::log10(std::max(raw, 1e-9))));
    const double m = raw / mag;
    const double s = (m <= 1.0) ? 1.0 : (m <= 2.0) ? 2.0 : (m <= 5.0) ? 5.0 : 10.0;
    return s * mag;
  };
  // ADAPTIVE headroom. Two failure modes bracketed it:
  //  - axis hugging the data (old 1.08x): a 40 m hump over a flat sea filled
  //    the whole plot height — massive vertical exaggeration;
  //  - fixed 3x: a 1000 m mountain mission got a 3000 m axis, squeezing the
  //    entire terrain+trajectory band into the bottom third (empty sky).
  // Rule: show at least 30% headroom, at most 3x, and for low profiles give
  // up to 600 m of sky context (the mission-altitude scale). Flat missions
  // keep the de-exaggerated look; mountain missions use the plot area.
  constexpr double kYHeadroomMin = 1.3;
  constexpr double kYHeadroomMax = 3.0;
  constexpr double kYMinContextM = 600.0;
  const double y_target = std::clamp(kYMinContextM,
                                     data_max * kYHeadroomMin,
                                     data_max * kYHeadroomMax);
  y_tick_step_ = nice_step(std::max(1.0, y_target / 4.0));
  max_altitude_ = std::ceil(y_target / y_tick_step_) * y_tick_step_;
  min_altitude_ = std::min(data_min, 0.0) - 0.35 * y_tick_step_;
  x_tick_step_ = nice_step(std::max(1e-6, (max_distance_ / 1000.0) / 5.0));

  // [Y-SPLIT] Zone-visible bands still never drive the MAIN axis (km-scale
  // tops squashed the mission band into a strip — earlier feedback), but
  // instead of clipping them at the plot top, their real extent now lives in
  // a compressed band above the split (see altToY).
  has_upper_band_ = false;
  y_upper_max_ = max_altitude_;
  double band_max = max_altitude_;
  for (const auto & zone : risk_band_top_)
    for (double t : zone)
      if (!std::isnan(t)) band_max = std::max(band_max, t);
  if (band_max > max_altitude_ + 1e-9) {
    has_upper_band_ = true;
    y_upper_max_ = std::ceil(band_max / y_tick_step_) * y_tick_step_;
  }
}

double AltitudeProfileWidget::altToY(double alt_m, const QRect & plot_area) const
{
  const double lower_range = std::max(1e-9, max_altitude_ - min_altitude_);
  // ADAPTIVE split: a fixed fraction ignores panel height — 1/3 of a tall
  // portrait dock is a comfortable ~200px, but 1/3 of a short landscape dock
  // squashed the mission band to ~60px. Pin the mission band near
  // kLowerMinPx and let the zone region take the rest, bounded so a tall
  // panel still converges to the preferred 1/3 : 2/3 and a tiny one cannot
  // starve the zone band completely.
  double lower_frac = 1.0;
  if (has_upper_band_) {
    constexpr double kLowerMinPx = 200.0;
    const double h = std::max(1.0, static_cast<double>(plot_area.height()));
    lower_frac = std::clamp(kLowerMinPx / h, 1.0 / 3.0, 0.7);
  }
  double ny;
  if (!has_upper_band_ || alt_m <= max_altitude_) {
    ny = (alt_m - min_altitude_) / lower_range * lower_frac;
  } else {
    const double upper_range = std::max(1e-9, y_upper_max_ - max_altitude_);
    const double t = std::min(1.0, (alt_m - max_altitude_) / upper_range);
    ny = lower_frac + t * (1.0 - lower_frac);
  }
  return plot_area.bottom() - ny * plot_area.height();
}

void AltitudeProfileWidget::setCurrentProgress(double distance_travelled, double current_altitude)
{
  current_distance_ = distance_travelled;
  current_altitude_ = current_altitude;
  has_current_ = true;
  update();
}

void AltitudeProfileWidget::setChainSegments(
  const std::vector<double> & junction_s_m, const QVector<QColor> & seg_colors)
{
  chain_junction_s_ = junction_s_m;
  chain_seg_colors_ = seg_colors;
  cache_dirty_ = true;
  update();
}

void AltitudeProfileWidget::clearData()
{
  has_data_ = false;
  has_current_ = false;
  trajectory_points_.clear();
  distances_.clear();
  terrain_heights_.clear();
  chain_junction_s_.clear();
  chain_seg_colors_.clear();
  obstacle_top_.clear();
  obstacle_bot_.clear();
  combined_risk_.clear();
  risk_band_lower_.clear();
  risk_band_floor_.clear();
  risk_band_top_.clear();
  max_distance_ = 0.0;
  current_distance_ = 0.0;
  current_altitude_ = 0.0;
  cache_dirty_ = true;
  update();
}

void AltitudeProfileWidget::paintEvent(QPaintEvent * event)
{
  (void)event;

  QPainter painter(this);
  painter.setRenderHint(QPainter::Antialiasing);

  const int left_margin = 78;
  const int right_margin = 20;
  const int top_margin = 20;
  const int bottom_margin = 50;

  QRect plot_area(
    left_margin,
    top_margin,
    width() - left_margin - right_margin,
    height() - top_margin - bottom_margin
  );

  painter.fillRect(rect(), Qt::white);

  if (!has_data_) {
    painter.setPen(Qt::gray);
    QFont font = painter.font();
    font.setPointSize(12);
    painter.setFont(font);
    painter.drawText(rect(), Qt::AlignCenter, "No trajectory data - Waiting for /viz/opt_trajectory");
    return;
  }

  // A stationary/hover trajectory has valid samples but no ground-track
  // coordinate. Do not divide by a zero x-span or invent a fake distance axis.
  if (max_distance_ <= 1e-9) {
    painter.setPen(QColor(70, 76, 84));
    QFont font = painter.font();
    font.setPointSize(11);
    painter.setFont(font);
    const double altitude = trajectory_points_.empty()
      ? 0.0 : trajectory_points_.front().z;
    painter.drawText(
      rect(), Qt::AlignCenter,
      QString("Stationary trajectory\n0 m ground track | MSL altitude %1 m")
        .arg(altitude, 0, 'f', 1));
    return;
  }

  // Static layers render once into pixmaps (see the header's [PERF] note);
  // the per-repaint cost of a live marker move is three blits + two small
  // dynamic draws instead of the full antialiased profile.
  const qreal dpr = devicePixelRatioF();
  const QSize px_size(static_cast<int>(width() * dpr),
                      static_cast<int>(height() * dpr));
  if (cache_dirty_ || base_cache_.size() != px_size) {
    // Screen points and their column envelope are part of the same cached
    // state: they depend on the trajectory and the plot rect, not on how far
    // the vehicle has travelled. drawElapsedOverlay below runs every repaint.
    traj_px_ = trajScreenPoints(plot_area);
    {
      std::vector<double> xs, ys;
      xs.reserve(traj_px_.size());
      ys.reserve(traj_px_.size());
      for (const auto & p : traj_px_) {xs.push_back(p.x()); ys.push_back(p.y());}
      std::vector<size_t> junctions;
      for (double js : chain_junction_s_) {
        const auto it = std::lower_bound(distances_.begin(), distances_.end(), js);
        if (it != distances_.end()) {
          junctions.push_back(static_cast<size_t>(it - distances_.begin()));
        }
      }
      env_idx_ = column_envelope(xs, ys, 1.0, junctions);
    }
    base_cache_ = QPixmap(px_size);
    base_cache_.setDevicePixelRatio(dpr);
    base_cache_.fill(Qt::white);
    {
      QPainter bp(&base_cache_);
      bp.setRenderHint(QPainter::Antialiasing);
      drawGrid(bp, plot_area);
      drawTerrainProfile(bp, plot_area);
      drawObstacles(bp, plot_area);
      drawTrajectoryProfile(bp, plot_area);
    }
    risk_cache_ = QPixmap(px_size);
    risk_cache_.setDevicePixelRatio(dpr);
    risk_cache_.fill(Qt::transparent);
    {
      QPainter rp(&risk_cache_);
      rp.setRenderHint(QPainter::Antialiasing);
      drawRiskAndEndpoints(rp, plot_area);
    }
    deco_cache_ = QPixmap(px_size);
    deco_cache_.setDevicePixelRatio(dpr);
    deco_cache_.fill(Qt::transparent);
    {
      QPainter dp(&deco_cache_);
      dp.setRenderHint(QPainter::Antialiasing);
      drawAxes(dp, plot_area);
      drawLegend(dp, plot_area);
    }
    cache_dirty_ = false;
  }
  // Blit order preserves the original single-pass z-order exactly:
  // base < elapsed < risk overlay < marker < axes/legend.
  painter.drawPixmap(0, 0, base_cache_);
  drawElapsedOverlay(painter, plot_area);
  painter.drawPixmap(0, 0, risk_cache_);
  drawCurrentPosition(painter, plot_area);
  painter.drawPixmap(0, 0, deco_cache_);
}

void AltitudeProfileWidget::drawLegend(QPainter & painter, const QRect & plot_area)
{
  QFont font = painter.font();
  font.setPointSize(8);
  painter.setFont(font);
  QFontMetrics fm(font);

  struct Entry { QString text; QColor color; bool dashed; bool patch; };
  std::vector<Entry> entries = {
    {"Planned",         QColor(33, 150, 243, 180), true,  false},
    {"Planned elapsed", QColor(33, 150, 243),      false, false},
    {"Terrain",         QColor(210, 180, 140),     false, true},
    {"Obstacle",        QColor(110, 120, 140, 200), false, true},
    {"Water",           QColor(45, 98, 150),        false, true},
  };
  // Risk channels only when they were explicitly supplied. Missing/stale data
  // stays absent rather than being described as zero risk.
  {
    bool any_band = false;
    for (const auto & zone : risk_band_floor_) {
      if (std::any_of(zone.begin(), zone.end(), [](double v) { return std::isfinite(v); })) {
        any_band = true;
        break;
      }
    }
    if (any_band) {
      entries.push_back({"Zone-visible band", QColor(226, 60, 40, 110), false, true});
      entries.push_back({"Terrain-shadow safe", QColor(72, 178, 100, 140), false, true});
    }
    const bool any_value = std::any_of(
      combined_risk_.begin(), combined_risk_.end(),
      [](double v) { return std::isfinite(v); });
    if (any_value) {
      entries.push_back({"Traj risk (green=safe, red=high)", QColor(230, 92, 15), false, false});
    }
  }

  const int sample_w = 18, pad = 8, gap = 14, h = 20;
  int total_w = pad;
  for (const auto & e : entries)
    total_w += sample_w + 4 + fm.horizontalAdvance(e.text) + gap;
  total_w += pad - gap;

  QRect box(plot_area.right() - total_w - 8, plot_area.top() + 6, total_w, h);
  painter.setPen(QPen(QColor(200, 206, 214), 1));
  painter.setBrush(QColor(255, 255, 255, 215));
  painter.drawRoundedRect(box, 4, 4);

  int x = box.left() + pad;
  const int cy = box.center().y();
  for (const auto & e : entries) {
    if (e.patch) {
      painter.setPen(Qt::NoPen);
      painter.setBrush(e.color);
      painter.drawRect(x, cy - 4, sample_w, 8);
    } else {
      painter.setPen(QPen(e.color, 2.5, e.dashed ? Qt::DashLine : Qt::SolidLine));
      painter.drawLine(x, cy, x + sample_w, cy);
    }
    x += sample_w + 4;
    painter.setPen(QColor(70, 76, 84));
    painter.drawText(QRect(x, box.top(), fm.horizontalAdvance(e.text) + 2, h),
                     Qt::AlignLeft | Qt::AlignVCenter, e.text);
    x += fm.horizontalAdvance(e.text) + gap;
  }
}

void AltitudeProfileWidget::drawGrid(QPainter & painter, const QRect & plot_area)
{
  // Subtle sky gradient inside the plot, with a clean frame.
  QLinearGradient sky(plot_area.topLeft(), plot_area.bottomLeft());
  sky.setColorAt(0.0, QColor(245, 250, 255));
  sky.setColorAt(1.0, QColor(255, 255, 255));
  painter.fillRect(plot_area, sky);

  const double y_range = max_altitude_ - min_altitude_;
  if (y_range <= 0.0 || max_distance_ <= 0.0) return;

  // Gridlines on the same round ticks the axis labels use.
  painter.setPen(QPen(QColor(225, 230, 236), 1));
  for (double alt = 0.0; alt <= max_altitude_ + 1e-9; alt += y_tick_step_) {
    int y = static_cast<int>(altToY(alt, plot_area));
    painter.drawLine(plot_area.left(), y, plot_area.right(), y);
  }
  // [Y-SPLIT] compressed upper band: faint tint + dashed axis-break line at
  // the split so the scale change is unmistakable.
  if (has_upper_band_) {
    const int ys = static_cast<int>(altToY(max_altitude_, plot_area));
    painter.fillRect(QRect(plot_area.left() + 1, plot_area.top() + 1,
                           plot_area.width() - 2, ys - plot_area.top() - 1),
                     QColor(247, 240, 240, 130));
    painter.setPen(QPen(QColor(170, 130, 130), 1, Qt::DashLine));
    painter.drawLine(plot_area.left(), ys, plot_area.right(), ys);
  }
  const double max_km = max_distance_ / 1000.0;
  for (double km = 0.0; km <= max_km + 1e-9; km += x_tick_step_) {
    int x = plot_area.left() +
            static_cast<int>(km / max_km * plot_area.width());
    painter.drawLine(x, plot_area.top(), x, plot_area.bottom());
  }

  painter.setPen(QPen(QColor(180, 188, 196), 1));
  painter.setBrush(Qt::NoBrush);
  painter.drawRect(plot_area);
}

void AltitudeProfileWidget::drawTerrainProfile(QPainter & painter, const QRect & plot_area)
{
  if (terrain_heights_.empty() || distances_.empty()) {
    return;
  }

  auto toPixel = [&](double dist, double alt) {
    double norm_x = dist / max_distance_;
    double px = plot_area.left() + norm_x * plot_area.width();
    return QPointF(px, altToY(alt, plot_area));  // [Y-SPLIT] piecewise axis
  };

  // Water baseline at altitude = 0 m
  double water_y = toPixel(0.0, 0.0).y();
  water_y = std::clamp(water_y,
    static_cast<double>(plot_area.top()),
    static_cast<double>(plot_area.bottom()));

  // One continuous sea: a single band across the whole plot plus a single
  // surface line; land is painted opaquely on top. Per-span water rectangles
  // left visible seams at every shoreline.
  painter.setPen(Qt::NoPen);
  painter.setBrush(QColor(38, 92, 145));  // deep-sea blue (black-tinted, not sky blue)
  painter.drawRect(QRectF(plot_area.left() + 1, water_y,
                          plot_area.width() - 2, plot_area.bottom() - water_y - 1));
  painter.setPen(QPen(QColor(70, 130, 175), 1, Qt::DashLine));
  painter.drawLine(QPointF(plot_area.left() + 1, water_y),
                   QPointF(plot_area.right() - 1, water_y));

  // Draw exactly the bilinear terrain samples used by the panel. There is no
  // display-only smoothing, water-gap bridging, or spline interpolation:
  // every finite vertex below is one sampled DEM value at that trajectory XY.
  auto drawLandSegment = [&](size_t lo, size_t hi) {
    QPolygonF pts;
    for (size_t k = lo; k <= hi; ++k) {
      pts << toPixel(distances_[k], terrain_heights_[k]);
    }
    if (pts.empty()) {
      return;
    }

    if (pts.size() >= 2) {
      // Filled polygon down to plot bottom. Opaque fill (tan pre-blended on
      // white) so the sea band underneath cannot bleed through.
      QPolygonF filled;
      filled << QPointF(pts.front().x(), plot_area.bottom());
      for (const auto & p : pts) {
        filled << p;
      }
      filled << QPointF(pts.back().x(), plot_area.bottom());
      painter.setPen(Qt::NoPen);
      painter.setBrush(QColor(227, 208, 183));
      painter.drawPolygon(filled);
    }

    // Straight sampled ridgeline. A one-sample island is retained as a point
    // rather than being invented into a wider synthetic land segment.
    painter.setPen(QPen(QColor(150, 105, 70), 1.5));
    painter.setBrush(Qt::NoBrush);
    if (pts.size() >= 2) painter.drawPolyline(pts);
    else painter.drawPoint(pts.front());
  };

  size_t i = 0;
  while (i < terrain_heights_.size()) {
    if (std::isnan(terrain_heights_[i])) {
      ++i;
      continue;
    }
    size_t lo = i;
    while (i < terrain_heights_.size() && !std::isnan(terrain_heights_[i])) {
      ++i;
    }
    drawLandSegment(lo, i - 1);
  }

  // [RISK-PROFILE] Preserve every zone's independent visible interval. Folding
  // them into one min-floor/max-top envelope falsely painted safe vertical gaps
  // as risky when two zones produced disjoint bands.
  {
    // [SHADOW-SAFE] Per-zone SAFE band first, per-zone VISIBLE band on top.
    // Safe = the zone's own airspace below its detection floor
    // ([max(lower, terrain), floor]); where another zone still sees that
    // altitude its red band overpaints, so the union semantics come out
    // right by draw order alone. This closes the white pockets between
    // overlapping zones (below B's floor but above A's cap) that the old
    // min-floor fill could not represent. v3 payloads have no lower bound
    // (NaN) -> fall back to the terrain surface.
    auto drawBand = [&](const std::vector<double> & top,
                        const std::vector<double> & bot, const QColor & fill) {
      if (top.size() != distances_.size() || bot.size() != distances_.size())
        return;
      painter.save();
      painter.setPen(Qt::NoPen);
      painter.setBrush(fill);
      size_t k = 0;
      while (k < top.size()) {
        if (std::isnan(top[k]) || std::isnan(bot[k])) { ++k; continue; }
        const size_t lo = k;
        while (k < top.size() && !std::isnan(top[k]) && !std::isnan(bot[k]))
          ++k;
        QPolygonF poly;
        for (size_t q = lo; q < k; ++q)
          poly << toPixel(distances_[q], top[q]);
        for (size_t q = k; q-- > lo;)
          poly << toPixel(distances_[q], bot[q]);
        if (poly.size() >= 3) painter.drawPolygon(poly);
      }
      painter.restore();
    };
    painter.save();
    painter.setClipRect(plot_area);  // zone tops may overtop the altitude axis
    const bool have_terr =
        terrain_heights_.size() == distances_.size();
    for (size_t zi = 0;
         zi < risk_band_top_.size() && zi < risk_band_floor_.size(); ++zi) {
      std::vector<double> safe_bot(distances_.size(),
                                   std::numeric_limits<double>::quiet_NaN());
      const bool have_lower = zi < risk_band_lower_.size() &&
          risk_band_lower_[zi].size() == distances_.size();
      for (size_t q = 0; q < distances_.size(); ++q) {
        if (q >= risk_band_floor_[zi].size() ||
            std::isnan(risk_band_floor_[zi][q]))
          continue;  // outside this zone's footprint
        const double terr = (have_terr && !std::isnan(terrain_heights_[q]))
                                ? terrain_heights_[q] : 0.0;
        double bot = terr;
        if (have_lower && !std::isnan(risk_band_lower_[zi][q]))
          bot = std::max(risk_band_lower_[zi][q], terr);
        safe_bot[q] = std::min(bot, risk_band_floor_[zi][q]);
      }
      drawBand(risk_band_floor_[zi], safe_bot, QColor(72, 178, 100, 60));
    }
    for (size_t zi = 0;
         zi < risk_band_top_.size() && zi < risk_band_floor_.size(); ++zi) {
      // Alternating alpha/tint makes overlapping independent bands legible
      // without changing their geometric limits.
      const int red = 218 + static_cast<int>((zi % 3) * 8);
      const int green = 52 + static_cast<int>((zi % 2) * 18);
      drawBand(risk_band_top_[zi], risk_band_floor_[zi],
               QColor(std::min(red, 240), green, 42, 50));
    }
    painter.restore();
  }
}

void AltitudeProfileWidget::drawObstacles(QPainter & painter, const QRect & plot_area)
{
  if (obstacle_top_.empty() || distances_.empty()) return;
  const double y_range = max_altitude_ - min_altitude_;
  if (y_range <= 0.0 || max_distance_ <= 0.0) return;
  auto px = [&](double dist) {
    return plot_area.left() + (dist / max_distance_) * plot_area.width();
  };
  auto py = [&](double alt) {
    return altToY(alt, plot_area);  // [Y-SPLIT] piecewise axis
  };
  // QPainter state is shared across the draw_* calls in paintEvent, and
  // drawPath() FILLS with whatever brush is active — leaving a brush set here
  // caused the next painter (the planned-trajectory path) to render as a
  // filled slate mountain range ("the second terrain"). Scope all state.
  painter.save();
  painter.setPen(Qt::NoPen);
  painter.setBrush(QColor(110, 120, 140, 200));
  const size_t n = std::min(obstacle_top_.size(), distances_.size());
  size_t i = 0;
  while (i < n) {
    if (std::isnan(obstacle_top_[i])) { ++i; continue; }
    size_t j = i;
    double top = obstacle_top_[i];
    double bot = obstacle_bot_[i];
    while (j + 1 < n && !std::isnan(obstacle_top_[j + 1])) {
      ++j;
      top = std::max(top, obstacle_top_[j]);
      bot = std::min(bot, obstacle_bot_[j]);
    }
    const double x0 = std::max(px(distances_[i]) - 1.0, (double)plot_area.left());
    const double x1 = std::min(px(distances_[j]) + 1.0, (double)plot_area.right());
    const double yt = py(std::min(top, max_altitude_));
    const double yb = py(std::max(bot, min_altitude_));
    painter.drawRect(QRectF(QPointF(x0, yt), QPointF(x1, yb)));
    i = j + 1;
  }
  painter.restore();
}

void AltitudeProfileWidget::drawTrajectoryProfile(QPainter & painter, const QRect & plot_area)
{
  if (trajectory_points_.size() < 2 || distances_.empty()) {
    return;
  }

  const std::vector<QPointF> traj_points = trajScreenPoints(plot_area);

  QPolygonF full_path;
  for (const auto & p : traj_points) full_path << p;

  // Draw the exact sampled optimized profile as straight segments. A second
  // Catmull-Rom fit could overshoot both altitude and the original polynomial
  // between samples, so it is inappropriate for a quantitative profile.
  const bool chain_on =
    !chain_seg_colors_.isEmpty() && !chain_junction_s_.empty();
  if (chain_on) {
    // [CHAIN-VIZ] The risk overlay (thick, drawn later) owns the curve's
    // on-line color, so segments are shown as a wide soft halo UNDER the
    // curve — the palette peeks out around the risk line instead of being
    // painted over by it.
    painter.setBrush(Qt::NoBrush);
    size_t k = 0;
    QPolygonF span;
    for (size_t i = 0; i < traj_points.size(); ++i) {
      span << traj_points[i];
      const bool boundary =
        k < chain_junction_s_.size() && distances_[i] >= chain_junction_s_[k];
      if (boundary || i + 1 == traj_points.size()) {
        QColor c = chain_seg_colors_[
          std::min<int>(static_cast<int>(k), chain_seg_colors_.size() - 1)];
        c.setAlpha(110);
        painter.setPen(QPen(c, 10, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        if (span.size() >= 2) painter.drawPolyline(span);
        span.clear();
        span << traj_points[i];
        if (boundary) ++k;
      }
    }
  }

  QPen planned_pen(QColor(33, 150, 243, 140), 2, Qt::DashLine);
  painter.setPen(planned_pen);
  painter.setBrush(Qt::NoBrush);
  painter.drawPolyline(full_path);

  if (chain_on) {
    // [CHAIN-VIZ] Solid segment bar along the plot bottom (unambiguous even
    // where overlays cover the halo) + junction verticals. Labels sit just
    // above the bar — the legend box owns the top of the plot.
    const double bar_top = plot_area.bottom() - 7.0;
    double s_prev = distances_.front();
    for (size_t k = 0; k <= chain_junction_s_.size(); ++k) {
      const double s_end = k < chain_junction_s_.size() ? chain_junction_s_[k]
                                                        : distances_.back();
      const QColor c = chain_seg_colors_[
        std::min<int>(static_cast<int>(k), chain_seg_colors_.size() - 1)];
      const double x0 =
        plot_area.left() + s_prev / max_distance_ * plot_area.width();
      const double x1 =
        plot_area.left() + s_end / max_distance_ * plot_area.width();
      painter.fillRect(QRectF(x0, bar_top, std::max(1.0, x1 - x0), 5.0), c);
      s_prev = s_end;
    }
    painter.setFont(QFont("Arial", 8, QFont::Bold));
    for (size_t j = 0; j < chain_junction_s_.size(); ++j) {
      const double px = plot_area.left() +
        chain_junction_s_[j] / max_distance_ * plot_area.width();
      painter.setPen(QPen(QColor(70, 70, 70, 160), 1, Qt::DashLine));
      painter.drawLine(QPointF(px, plot_area.top()), QPointF(px, bar_top));
      painter.setPen(QColor(40, 40, 40, 230));
      painter.drawText(QPointF(px + 3.0, bar_top - 4.0),
                       QString("J%1").arg(j + 1));
    }
  }

}

std::vector<QPointF> AltitudeProfileWidget::trajScreenPoints(const QRect & plot_area) const
{
  std::vector<QPointF> pts;
  pts.reserve(trajectory_points_.size());
  for (size_t i = 0; i < trajectory_points_.size(); ++i) {
    const double norm_x = distances_[i] / max_distance_;
    pts.emplace_back(plot_area.left() + norm_x * plot_area.width(),
                     altToY(trajectory_points_[i].z, plot_area));
  }
  return pts;
}

// Dynamic: the elapsed portion of the PLANNED path. This is deliberately not
// labelled "flown": only the current odometry point is measured here.
void AltitudeProfileWidget::drawElapsedOverlay(QPainter & painter, const QRect & plot_area)
{
  (void)plot_area;   // geometry now comes from the cached screen points
  if (trajectory_points_.size() < 2 || distances_.empty() ||
    !has_current_ || current_distance_ <= 0.0)
  {
    reportElapsedDrawCost(0, 0);   // 0 km 도 측정 대상이다: 빈 줄이 아니라 0
    return;
  }
  // Cached: traj_px_ and env_idx_ are rebuilt with base_cache_, so this
  // repaint costs the plot WIDTH, not the sample count. Rebuilding all N
  // screen points here and drawing an N-point polyline is what made the
  // panel slow down as the vehicle progressed -- 60 fps at 200 km, 8 at 700.
  if (traj_px_.size() != trajectory_points_.size() || env_idx_.empty()) {
    reportElapsedDrawCost(0, 0);
    return;                       // caches not built yet; next repaint has them
  }
  const std::vector<QPointF> & traj_points = traj_px_;

  // First sample PAST the current distance. distances_ is non-decreasing.
  const size_t cut = static_cast<size_t>(
    std::upper_bound(distances_.begin(), distances_.end(), current_distance_)
    - distances_.begin());

  // env_idx_ describes the WHOLE trajectory, so it cannot simply be truncated:
  // the column the vehicle is currently inside had its min/max chosen over the
  // full column, and those may lie past the cut. envelope_prefix recomputes
  // that one column over [column start, cut) so a peak already passed stays
  // drawn. Completed columns come straight from the cache.
  envelope_prefix(
    [&](size_t i) {return traj_points[i].x();},
    [&](size_t i) {return traj_points[i].y();},
    traj_points.size(), env_idx_, cut, 1.0, prefix_idx_);

  QPolygonF elapsed;
  elapsed.reserve(static_cast<int>(prefix_idx_.size()) + 1);
  for (size_t idx : prefix_idx_) {
    elapsed << traj_points[idx];
  }
  // The exact endpoint at current_distance_ is interpolated, as before: the
  // head of this line is where the vehicle IS, and decimation must not move
  // it back to the nearest kept sample.
  if (cut > 0 && cut < traj_points.size()) {
    const double d0 = distances_[cut - 1];
    const double d1 = distances_[cut];
    double t = (current_distance_ - d0) / std::max(1e-6, d1 - d0);
    t = std::clamp(t, 0.0, 1.0);
    elapsed << traj_points[cut - 1] +
      (traj_points[cut] - traj_points[cut - 1]) * t;
  } else if (cut >= traj_points.size()) {
    elapsed << traj_points.back();
  }

  if (elapsed.size() >= 2) {
    painter.setPen(QPen(QColor(33, 150, 243), 3));
    painter.drawPolyline(elapsed);
  }
  reportElapsedDrawCost(cut, static_cast<size_t>(elapsed.size()));
}

// Read-only instrumentation for the fps investigation: how many points the
// elapsed line actually draws, against how many samples it covers. Silent
// unless MMP_PROFILE_DRAW_STATS is set, and it never affects what is drawn.
void AltitudeProfileWidget::reportElapsedDrawCost(size_t cut, size_t drawn)
{
  static const bool on = ::getenv("MMP_PROFILE_DRAW_STATS") != nullptr;
  if (!on) {
    return;
  }
  using clock = std::chrono::steady_clock;
  static clock::time_point last;
  static size_t frames = 0;
  ++frames;
  const auto now = clock::now();
  if (now - last < std::chrono::seconds(1)) {
    return;
  }
  last = now;
  std::fprintf(
    stderr,
    "[profile] s=%.0fm samples=%zu covered=%zu drawn=%zu frames/s~%zu\n",
    current_distance_, trajectory_points_.size(), cut, drawn, frames);
  frames = 0;
}

// Static (cached): risk overlay + start/end endpoint dots. Split from
// drawTrajectoryProfile because they sit ABOVE the dynamic elapsed line.
void AltitudeProfileWidget::drawRiskAndEndpoints(QPainter & painter, const QRect & plot_area)
{
  if (trajectory_points_.size() < 2 || distances_.empty()) {
    return;
  }
  const std::vector<QPointF> traj_points = trajScreenPoints(plot_area);

  // Quantitative risk overlay from the versioned profile. Known zero risk is green;
  // positive risk follows a fixed green -> yellow -> red ramp. NaN is unknown
  // or stale and leaves the underlying blue plan untouched (never relabelled
  // as zero). sqrt is only a perceptual color mapping; the values themselves
  // remain the planner's actual OR-combined risk in [0, 1].
  if (combined_risk_.size() == traj_points.size()) {
    painter.save();
    painter.setBrush(Qt::NoBrush);
    for (size_t i = 1; i < traj_points.size(); ++i) {
      const double r0 = combined_risk_[i - 1];
      const double r1 = combined_risk_[i];
      if (!std::isfinite(r0) || !std::isfinite(r1)) continue;
      const double risk = std::clamp(0.5 * (r0 + r1), 0.0, 1.0);
      const double s = std::sqrt(risk);
      QColor color;
      if (s < 0.5) {
        color = QColor::fromRgbF(2.0 * s, 0.85, 0.05, 0.95);
      } else {
        color = QColor::fromRgbF(0.95, 1.70 * (1.0 - s), 0.05, 0.95);
      }
      painter.setPen(QPen(color, 3.5, Qt::SolidLine, Qt::RoundCap));
      painter.drawLine(traj_points[i - 1], traj_points[i]);
    }
    painter.restore();
  }

  // Start (green) and end (red) markers
  {
    double norm_x = distances_.front() / max_distance_;
    int pixel_x = plot_area.left() + static_cast<int>(norm_x * plot_area.width());
    int pixel_y = static_cast<int>(altToY(trajectory_points_.front().z, plot_area));
    painter.setBrush(QBrush(QColor(76, 175, 80)));
    painter.setPen(QPen(Qt::white, 2));
    painter.drawEllipse(QPoint(pixel_x, pixel_y), 5, 5);

    norm_x = distances_.back() / max_distance_;
    pixel_x = plot_area.left() + static_cast<int>(norm_x * plot_area.width());
    pixel_y = static_cast<int>(altToY(trajectory_points_.back().z, plot_area));
    painter.setBrush(QBrush(QColor(244, 67, 54)));
    painter.setPen(QPen(Qt::white, 2));
    painter.drawEllipse(QPoint(pixel_x, pixel_y), 5, 5);
  }
}

void AltitudeProfileWidget::drawCurrentPosition(QPainter & painter, const QRect & plot_area)
{
  if (!has_current_ || max_distance_ <= 0.0) {
    return;
  }

  double d = std::clamp(current_distance_, 0.0, max_distance_);
  double norm_x = d / max_distance_;
  int pixel_x = plot_area.left() + static_cast<int>(norm_x * plot_area.width());
  int pixel_y = static_cast<int>(std::clamp(
      altToY(current_altitude_, plot_area),
      static_cast<double>(plot_area.top()),
      static_cast<double>(plot_area.bottom())));

  // Vertical guide line
  painter.setPen(QPen(QColor(255, 140, 0, 150), 1, Qt::DashLine));
  painter.drawLine(pixel_x, plot_area.top(), pixel_x, plot_area.bottom());

  // Drone marker (orange diamond)
  painter.setPen(QPen(Qt::white, 2));
  painter.setBrush(QBrush(QColor(255, 140, 0)));
  QPolygon diamond;
  diamond << QPoint(pixel_x, pixel_y - 7)
          << QPoint(pixel_x + 7, pixel_y)
          << QPoint(pixel_x, pixel_y + 7)
          << QPoint(pixel_x - 7, pixel_y);
  painter.drawPolygon(diamond);
}

void AltitudeProfileWidget::drawAxes(QPainter & painter, const QRect & plot_area)
{
  painter.setPen(QPen(QColor(70, 76, 84), 1));
  QFont font = painter.font();
  font.setPointSize(9);
  painter.setFont(font);

  const double y_range = max_altitude_ - min_altitude_;
  if (y_range <= 0.0 || max_distance_ <= 0.0) return;

  // Labels on the same round ticks the grid uses (clean values: 0, 100, ...).
  for (double alt = 0.0; alt <= max_altitude_ + 1e-9; alt += y_tick_step_) {
    int y = static_cast<int>(altToY(alt, plot_area));
    QString label = QString::number(alt, 'f', y_tick_step_ < 1.0 ? 1 : 0) + " m";
    QRect label_rect(0, y - 10, plot_area.left() - 7, 20);
    painter.drawText(label_rect, Qt::AlignRight | Qt::AlignVCenter, label);
  }
  // [Y-SPLIT] top-of-compressed-band label (grey: different scale up there).
  if (has_upper_band_) {
    painter.save();
    painter.setPen(QColor(150, 120, 120));
    const int ytop = static_cast<int>(altToY(y_upper_max_, plot_area));
    QString label = QString::number(y_upper_max_, 'f', 0) + " m";
    painter.drawText(QRect(0, ytop - 10, plot_area.left() - 7, 20),
                     Qt::AlignRight | Qt::AlignVCenter, label);
    painter.restore();
  }

  const double max_km = max_distance_ / 1000.0;
  for (double km = 0.0; km <= max_km + 1e-9; km += x_tick_step_) {
    int x = plot_area.left() +
            static_cast<int>(km / max_km * plot_area.width());
    QString label = QString::number(km, 'f', x_tick_step_ < 1.0 ? 1 : 0) + " km";
    QRect label_rect(x - 40, plot_area.bottom() + 5, 80, 20);
    painter.drawText(label_rect, Qt::AlignCenter, label);
  }

  font.setPointSize(10);
  font.setBold(true);
  painter.setFont(font);

  painter.save();
  painter.translate(14, plot_area.center().y());
  painter.rotate(-90);
  painter.drawText(-80, -8, 160, 20, Qt::AlignCenter, "MSL altitude (m)");
  painter.restore();

  painter.drawText(plot_area.center().x() - 130, height() - 22, 260, 20,
                   Qt::AlignCenter, "Ground-track distance (km)");
}

// ============================================================================
// AltitudeProfilePanel Implementation
// ============================================================================

AltitudeProfilePanel::AltitudeProfilePanel(QWidget * parent)
: rviz_common::Panel(parent),
  terrain_map_received_(false),
  trajectory_ready_(false),
  has_prev_pos_(false),
  prev_pos_stamp_(0, 0, RCL_ROS_TIME),
  speed_mps_(0.0)
{
  QVBoxLayout * layout = new QVBoxLayout;

  QLabel * title_label = new QLabel("Altitude Profile");
  QFont title_font = title_label->font();
  title_font.setPointSize(12);
  title_font.setBold(true);
  title_label->setFont(title_font);
  layout->addWidget(title_label);

  // Embedded scrubber. Groove aligned with the plot area below (left margin
  // 78 / right 20, 14 px handle -> inset margin-7 per side), so the thumb x
  // equals the plot's current-position marker x by construction.
  scrub_slider_ = new QSlider(Qt::Horizontal);
  scrub_slider_->setRange(0, kSteps);
  scrub_slider_->setValue(0);
  scrub_slider_->setEnabled(false);
  scrub_slider_->setStyleSheet(
    "QSlider::groove:horizontal { height: 6px; background: #cfd6dd;"
    "  border-radius: 3px; }"
    "QSlider::sub-page:horizontal { background: #2196f3; border-radius: 3px; }"
    "QSlider::handle:horizontal { width: 14px; margin: -5px 0;"
    "  background: #e04000; border: 1px solid #ffffff; border-radius: 7px; }");
  auto * scrub_row = new QHBoxLayout;
  scrub_row->setContentsMargins(78 - 7, 0, 20 - 7, 0);
  scrub_row->addWidget(scrub_slider_);
  layout->addLayout(scrub_row);

  auto * ctrl_row = new QHBoxLayout;
  play_button_ = new QPushButton("▶ Play");
  play_button_->setCheckable(true);
  play_button_->setEnabled(false);
  play_button_->setFixedWidth(90);
  time_label_ = new QLabel("--:-- / --:--");
  time_label_->setStyleSheet("QLabel { color : gray; }");
  ctrl_row->addWidget(play_button_);
  ctrl_row->addWidget(time_label_);
  ctrl_row->addStretch();
  layout->addLayout(ctrl_row);

  scrub_timer_ = new QTimer(this);
  connect(scrub_slider_, &QSlider::valueChanged,
          this, &AltitudeProfilePanel::onSliderChanged);
  connect(play_button_, &QPushButton::toggled,
          this, &AltitudeProfilePanel::onPlayToggled);
  connect(scrub_timer_, &QTimer::timeout, this, &AltitudeProfilePanel::onTick);

  profile_widget_ = new AltitudeProfileWidget(this);
  layout->addWidget(profile_widget_, 1);

  status_label_ = new QLabel("Waiting for optimized trajectory...");
  setStatusStyle(QStringLiteral("QLabel { color: gray; padding: 5px; }"));
  layout->addWidget(status_label_);

  setLayout(layout);
}

AltitudeProfilePanel::~AltitudeProfilePanel()
{
}

void AltitudeProfilePanel::onInitialize()
{
  auto rviz_ros_node = getDisplayContext()->getRosNodeAbstraction();
  node_ = rviz_ros_node.lock()->get_raw_node();

  rmw_qos_profile_t qos_profile = rmw_qos_profile_sensor_data;
  auto sensor_qos = rclcpp::QoS(rclcpp::QoSInitialization(qos_profile.history, 5), qos_profile);

  // Subscribe to the optimized trajectory (full path, published as a single
  // Marker). transient_local so a panel/RViz session opened AFTER the plan
  // still receives the latched last trajectory (it is published once per
  // plan, not periodically).
  trajectory_sub_ = node_->create_subscription<visualization_msgs::msg::Marker>(
    "/viz/opt_trajectory",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&AltitudeProfilePanel::trajectoryCallback, this, std::placeholders::_1));

  // Subscribe to drone current state for live progress marker
  current_pos_sub_ = node_->create_subscription<nav_msgs::msg::Odometry>(
    "/dynamics/sim_state",
    sensor_qos,
    std::bind(&AltitudeProfilePanel::currentPositionCallback, this, std::placeholders::_1));

  // Terrain grid map (transient local so we get the latched message)
  auto qos = rclcpp::QoS(rclcpp::KeepLast(1));
  qos.transient_local();
  qos.reliable();
  grid_map_sub_ = node_->create_subscription<grid_map_msgs::msg::GridMap>(
    "/terrain/grid_map",
    qos,
    std::bind(&AltitudeProfilePanel::gridMapCallback, this, std::placeholders::_1));

  // Obstacle geometry for the profile overlay: the invisible CUBE companions
  // of the ship meshes (transient_local, like their publisher).
  dyn_obs_sub_ = node_->create_subscription<visualization_msgs::msg::MarkerArray>(
    "/viz/dynamic_obstacles",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&AltitudeProfilePanel::dynObstacleArrayCallback, this, std::placeholders::_1));

  risk_profile_sub_ = node_->create_subscription<std_msgs::msg::Float64MultiArray>(
    "/viz/risk_profile",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&AltitudeProfilePanel::riskProfileCallback, this, std::placeholders::_1));

  // [CHAIN-VIZ] per-segment chain view — the same latched array the 3D
  // display consumes; clear-only publishes (single-shot plans) empty it.
  chain_seg_sub_ = node_->create_subscription<visualization_msgs::msg::MarkerArray>(
    "/viz/chain_segments",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&AltitudeProfilePanel::chainSegmentsCallback, this, std::placeholders::_1));

  // Embedded scrubber I/O (same topics the standalone progress panel used;
  // remove that panel from the RViz layout to avoid duplicate publishers).
  // PolyTraj contract (mmp_traj_msgs/msg/PolyTraj.msg): RELIABLE +
  // TRANSIENT_LOCAL, published once per plan and latched — match it exactly,
  // a best-effort sub gets nothing from a reliable publisher.
  poly_traj_sub_ = node_->create_subscription<mmp_traj_msgs::msg::PolyTraj>(
    "/planning/trajectory", rclcpp::QoS(5).reliable().transient_local(),
    std::bind(&AltitudeProfilePanel::onTrajectoryMsg, this, std::placeholders::_1));
  rclcpp::QoS cqos(1);
  cqos.reliable();
  cqos.transient_local();
  cursor_pub_ = node_->create_publisher<visualization_msgs::msg::Marker>(
    "/viz/trajectory_cursor", cqos);
  flown_pub_ = node_->create_publisher<visualization_msgs::msg::Marker>(
    "/viz/flown_path", cqos);
  // Follower-slot scrub contract: /dynamics is the follower I/O namespace
  // (/dynamics/sim_state comes back the other way), so the scrub time the user
  // drags here lives there too, NOT under /viz. The mmp_dynamics_sim follower
  // is expected to subscribe to this and drive its state from it.
  scrub_pub_ = node_->create_publisher<std_msgs::msg::Float64>("/dynamics/scrub_time", cqos);

  RCLCPP_INFO(node_->get_logger(),
    "AltitudeProfilePanel initialized (subscribed to /viz/opt_trajectory, /dynamics/sim_state, /terrain/grid_map)");
}

void AltitudeProfilePanel::trajectoryCallback(const visualization_msgs::msg::Marker::SharedPtr msg)
{
  if (msg->action == visualization_msgs::msg::Marker::DELETE ||
      msg->action == visualization_msgs::msg::Marker::DELETEALL ||
      msg->points.size() < 2) {
    trajectory_ready_ = false;
    has_progress_ = false;
    trajectory_points_.clear();
    distances_.clear();
    terrain_heights_.clear();
    obstacle_top_.clear();
    obstacle_bot_.clear();
    rebuildProfile();
    return;
  }

  trajectory_points_ = msg->points;
  has_progress_ = false;
  last_progress_m_ = 0.0;

  // Cumulative distance along the full path, in meters
  distances_.clear();
  distances_.reserve(trajectory_points_.size());
  double cumulative = 0.0;
  distances_.push_back(0.0);
  for (size_t i = 1; i < trajectory_points_.size(); ++i) {
    const auto & a = trajectory_points_[i - 1];
    const auto & b = trajectory_points_[i];
    double dx = (b.x - a.x) * GRID_CELL_SIZE_M;
    double dy = (b.y - a.y) * GRID_CELL_SIZE_M;
    cumulative += std::sqrt(dx * dx + dy * dy);
    distances_.push_back(cumulative);
  }

  // Sample terrain elevation at every trajectory point (once, upfront)
  resampleTerrain();

  trajectory_ready_ = true;
  sampleObstacles();
  rebuildProfile();
}

void AltitudeProfilePanel::resampleTerrain()
{
  const double nan = std::numeric_limits<double>::quiet_NaN();
  terrain_heights_.assign(trajectory_points_.size(), nan);

  if (terrain_map_received_) {
    for (size_t i = 0; i < trajectory_points_.size(); ++i) {
      const auto & p = trajectory_points_[i];
      const float e0 = getElevationAt(p.x, p.y);
      if (!std::isnan(e0)) terrain_heights_[i] = static_cast<double>(e0) * elev_scale_;
    }
  }

  // [RISK-PROFILE] nearest-sample mapping by arc length. Versioned payloads
  // also carry their source trajectory coordinates: validate those
  // against the current trajectory before accepting the latched profile.
  // Arc length alone cannot distinguish two different routes of equal length.
  risk_combined_r_.assign(trajectory_points_.size(), nan);
  risk_band_lower_r_.assign(
    risk_zone_count_, std::vector<double>(trajectory_points_.size(), nan));
  risk_band_floor_r_.assign(
    risk_zone_count_, std::vector<double>(trajectory_points_.size(), nan));
  risk_band_top_r_.assign(
    risk_zone_count_, std::vector<double>(trajectory_points_.size(), nan));
  if (!distances_.empty() && !risk_s_m_.empty()) {
    std::vector<bool> source_valid(risk_s_m_.size(), true);
    bool accept_profile = true;
    if (risk_profile_version_ >= 2) {
      constexpr double kPathMatchToleranceM = 100.0;
      constexpr double kAltitudeMatchToleranceM = 10.0;
      size_t tested = 0;
      size_t matched = 0;
      for (size_t j = 0; j < risk_s_m_.size(); ++j) {
        if (j >= risk_x_u_.size() || j >= risk_y_u_.size() ||
            !std::isfinite(risk_s_m_[j]) ||
            !std::isfinite(risk_x_u_[j]) || !std::isfinite(risk_y_u_[j]) ||
            (risk_profile_version_ >= 3 &&
             (j >= risk_z_u_.size() || !std::isfinite(risk_z_u_[j])))) {
          source_valid[j] = false;
          continue;
        }
        ++tested;
        if (risk_s_m_[j] < -kPathMatchToleranceM ||
            risk_s_m_[j] > distances_.back() + kPathMatchToleranceM) {
          source_valid[j] = false;
          continue;
        }

        const double s = std::clamp(risk_s_m_[j], 0.0, distances_.back());
        auto path_it = std::lower_bound(distances_.begin(), distances_.end(), s);
        size_t hi = static_cast<size_t>(path_it - distances_.begin());
        double px = trajectory_points_.front().x;
        double py = trajectory_points_.front().y;
        double pz = trajectory_points_.front().z;
        if (hi == 0) {
          px = trajectory_points_.front().x;
          py = trajectory_points_.front().y;
          pz = trajectory_points_.front().z;
        } else if (hi >= distances_.size()) {
          px = trajectory_points_.back().x;
          py = trajectory_points_.back().y;
          pz = trajectory_points_.back().z;
        } else {
          const double s0 = distances_[hi - 1];
          const double s1 = distances_[hi];
          const double u = (s1 > s0) ? (s - s0) / (s1 - s0) : 0.0;
          px = trajectory_points_[hi - 1].x +
               u * (trajectory_points_[hi].x - trajectory_points_[hi - 1].x);
          py = trajectory_points_[hi - 1].y +
               u * (trajectory_points_[hi].y - trajectory_points_[hi - 1].y);
          pz = trajectory_points_[hi - 1].z +
               u * (trajectory_points_[hi].z - trajectory_points_[hi - 1].z);
        }
        const double xy_error_m = std::hypot(
          px - risk_x_u_[j], py - risk_y_u_[j]) * GRID_CELL_SIZE_M;
        const double z_error_m = risk_profile_version_ >= 3
          ? std::abs(pz - risk_z_u_[j]) * GRID_CELL_SIZE_M : 0.0;
        source_valid[j] =
          xy_error_m <= kPathMatchToleranceM &&
          z_error_m <= kAltitudeMatchToleranceM;
        if (source_valid[j]) ++matched;
      }
      // Allow a few source samples near sharp corners to exceed the tolerance,
      // but reject the whole profile when it belongs to another latched route.
      accept_profile = tested > 0 &&
        static_cast<double>(matched) / static_cast<double>(tested) >= 0.8;
      if (!accept_profile) {
        RCLCPP_WARN(
          node_->get_logger(),
          "AltitudeProfilePanel: rejected stale risk profile "
          "(%zu/%zu coordinate samples match)",
          matched, tested);
      }
    }

    if (accept_profile) {
      for (size_t i = 0; i < distances_.size(); ++i) {
        const double d = distances_[i];
        auto it = std::lower_bound(risk_s_m_.begin(), risk_s_m_.end(), d);
        size_t j = static_cast<size_t>(it - risk_s_m_.begin());
        if (j >= risk_s_m_.size()) j = risk_s_m_.size() - 1;
        if (j > 0 && d - risk_s_m_[j - 1] < risk_s_m_[j] - d) --j;
        if (std::abs(risk_s_m_[j] - d) > 500.0 || !source_valid[j]) continue;
        // The scalar field is continuous, so linearly interpolate it between
        // valid source samples. This avoids turning a dense risk profile into
        // a nearest-neighbour staircase on the more densely plotted path.
        auto upper = std::lower_bound(risk_s_m_.begin(), risk_s_m_.end(), d);
        const size_t hi = static_cast<size_t>(upper - risk_s_m_.begin());
        if (hi > 0 && hi < risk_s_m_.size() &&
            source_valid[hi - 1] && source_valid[hi] &&
            hi < risk_combined_.size() &&
            std::isfinite(risk_combined_[hi - 1]) &&
            std::isfinite(risk_combined_[hi])) {
          const double s0 = risk_s_m_[hi - 1];
          const double s1 = risk_s_m_[hi];
          const double u = (s1 > s0) ? (d - s0) / (s1 - s0) : 0.0;
          risk_combined_r_[i] =
            risk_combined_[hi - 1] +
            std::clamp(u, 0.0, 1.0) *
            (risk_combined_[hi] - risk_combined_[hi - 1]);
        } else if (j < risk_combined_.size()) {
          risk_combined_r_[i] = risk_combined_[j];
        }
        for (size_t zi = 0; zi < risk_zone_count_; ++zi) {
          if (zi < risk_band_lower_m_.size() &&
              j < risk_band_lower_m_[zi].size()) {
            risk_band_lower_r_[zi][i] = risk_band_lower_m_[zi][j];
          }
          if (zi < risk_band_floor_m_.size() &&
              j < risk_band_floor_m_[zi].size()) {
            risk_band_floor_r_[zi][i] = risk_band_floor_m_[zi][j];
          }
          if (zi < risk_band_top_m_.size() &&
              j < risk_band_top_m_[zi].size()) {
            risk_band_top_r_[zi][i] = risk_band_top_m_[zi][j];
          }
        }
      }
    }
  }
}

void AltitudeProfilePanel::riskProfileCallback(
  const std_msgs::msg::Float64MultiArray::SharedPtr msg)
{
  risk_profile_version_ = 0;
  risk_zone_count_ = 0;
  risk_s_m_.clear();
  risk_x_u_.clear();
  risk_y_u_.clear();
  risk_z_u_.clear();
  risk_combined_.clear();
  risk_band_lower_m_.clear();
  risk_band_floor_m_.clear();
  risk_band_top_m_.clear();

  // Empty means "clear the previous plan's profile".
  if (!msg->data.empty()) {
    const bool versioned_header =
      msg->data.size() >= 2 && std::isfinite(msg->data[0]) &&
      (std::abs(msg->data[0] - 2.0) < 1e-9 ||
       std::abs(msg->data[0] - 3.0) < 1e-9 ||
       std::abs(msg->data[0] - 4.0) < 1e-9);
    if (versioned_header) {
      const int version = static_cast<int>(std::llround(msg->data[0]));
      const double n_raw = msg->data[1];
      const bool n_valid = std::isfinite(n_raw) && n_raw >= 0.0 &&
                           n_raw <= 4096.0 &&
                           std::abs(n_raw - std::round(n_raw)) < 1e-9;
      const size_t n_zone = n_valid ? static_cast<size_t>(std::llround(n_raw)) : 0;
      const size_t geometry_width = version >= 3 ? 5 : 4;
      // v4 carries per-zone TRIPLETS (geometric lower, detection floor, top).
      const size_t zone_width = version >= 4 ? 3 : 2;
      const size_t stride = geometry_width + zone_width * n_zone;
      const bool shape_valid = n_valid && stride >= geometry_width &&
        (msg->data.size() - 2) % stride == 0;
      if (!shape_valid) {
        RCLCPP_WARN(
          node_->get_logger(),
          "AltitudeProfilePanel: malformed risk_profile v%d (size=%zu, N=%g)",
          version, msg->data.size(), n_raw);
      } else {
        risk_profile_version_ = version;
        risk_zone_count_ = n_zone;
        const size_t records = (msg->data.size() - 2) / stride;
        risk_s_m_.reserve(records);
        risk_x_u_.reserve(records);
        risk_y_u_.reserve(records);
        risk_z_u_.reserve(records);
        risk_combined_.reserve(records);
        risk_band_lower_m_.assign(n_zone, {});
        risk_band_floor_m_.assign(n_zone, {});
        risk_band_top_m_.assign(n_zone, {});
        for (size_t zi = 0; zi < n_zone; ++zi) {
          risk_band_lower_m_[zi].reserve(records);
          risk_band_floor_m_[zi].reserve(records);
          risk_band_top_m_[zi].reserve(records);
        }
        for (size_t rec = 0, base = 2; rec < records; ++rec, base += stride) {
          risk_s_m_.push_back(msg->data[base] * GRID_CELL_SIZE_M);
          risk_x_u_.push_back(msg->data[base + 1]);
          risk_y_u_.push_back(msg->data[base + 2]);
          if (version >= 3) {
            risk_z_u_.push_back(msg->data[base + 3]);
            risk_combined_.push_back(msg->data[base + 4]);
          } else {
            risk_z_u_.push_back(
              std::numeric_limits<double>::quiet_NaN());
            risk_combined_.push_back(msg->data[base + 3]);
          }
          const size_t band_offset = version >= 3 ? 5 : 4;
          for (size_t zi = 0; zi < n_zone; ++zi) {
            if (version >= 4) {
              risk_band_lower_m_[zi].push_back(
                msg->data[base + band_offset + 3 * zi] * GRID_CELL_SIZE_M);
              risk_band_floor_m_[zi].push_back(
                msg->data[base + band_offset + 1 + 3 * zi] *
                GRID_CELL_SIZE_M);
              risk_band_top_m_[zi].push_back(
                msg->data[base + band_offset + 2 + 3 * zi] *
                GRID_CELL_SIZE_M);
            } else {
              risk_band_lower_m_[zi].push_back(
                std::numeric_limits<double>::quiet_NaN());
              risk_band_floor_m_[zi].push_back(
                msg->data[base + band_offset + 2 * zi] * GRID_CELL_SIZE_M);
              risk_band_top_m_[zi].push_back(
                msg->data[base + band_offset + 1 + 2 * zi] *
                GRID_CELL_SIZE_M);
            }
          }
        }
      }
    } else {
      // Legacy fallback: quads [s, visibility_roof, dome_top, dome_bottom].
      // It can reproduce the old visible band, but has no x/y binding and no
      // actual combined-risk value. Keep that channel NaN (unknown), never 0.
      if (msg->data.size() % 4 != 0) {
        RCLCPP_WARN(
          node_->get_logger(),
          "AltitudeProfilePanel: malformed legacy risk profile (size=%zu)",
          msg->data.size());
      } else {
        const size_t records = msg->data.size() / 4;
        const double nan = std::numeric_limits<double>::quiet_NaN();
        risk_zone_count_ = records > 0 ? 1 : 0;
        risk_s_m_.reserve(records);
        risk_x_u_.assign(records, nan);
        risk_y_u_.assign(records, nan);
        risk_z_u_.assign(records, nan);
        risk_combined_.assign(records, nan);
        risk_band_floor_m_.assign(risk_zone_count_, {});
        risk_band_top_m_.assign(risk_zone_count_, {});
        for (size_t i = 0; i + 3 < msg->data.size(); i += 4) {
          risk_s_m_.push_back(msg->data[i] * GRID_CELL_SIZE_M);
          risk_band_floor_m_[0].push_back(msg->data[i + 1] * GRID_CELL_SIZE_M);
          risk_band_top_m_[0].push_back(msg->data[i + 2] * GRID_CELL_SIZE_M);
        }
      }
    }
  }

  if (trajectory_ready_ && !trajectory_points_.empty()) {
    resampleTerrain();
    rebuildProfile();
  }
}

void AltitudeProfilePanel::gridMapCallback(const grid_map_msgs::msg::GridMap::SharedPtr msg)
{
  // The terrain publisher uses an empty map for world=none. Treat it as an
  // explicit clear: retaining the previous world's terrain would make a new
  // trajectory appear to intersect terrain which is no longer loaded.
  if (msg->layers.empty() && msg->data.empty()) {
    terrain_map_.reset();
    terrain_map_received_ = false;
    elev_scale_ = GRID_CELL_SIZE_M;
    RCLCPP_INFO_ONCE(node_->get_logger(),
      "AltitudeProfilePanel: cleared terrain profile (no world loaded)");
    if (trajectory_ready_ && !trajectory_points_.empty()) {
      resampleTerrain();
      rebuildProfile();
    }
    return;
  }

  // A malformed non-empty update is not a world-clear command. Retain the
  // previous accepted DEM, matching PathManager::setTerrainData.
  int elevation_layer_idx = -1;
  for (size_t i = 0; i < msg->layers.size(); ++i) {
    if (msg->layers[i] == "elevation") {
      elevation_layer_idx = static_cast<int>(i);
      break;
    }
  }
  bool valid = msg->info.resolution > 0.0 &&
    elevation_layer_idx >= 0 &&
    static_cast<size_t>(elevation_layer_idx) < msg->data.size();
  if (valid) {
    const auto & elevation = msg->data[static_cast<size_t>(elevation_layer_idx)];
    valid = elevation.layout.dim.size() >= 2;
    if (valid) {
      const size_t cols = elevation.layout.dim[0].size;
      const size_t rows = elevation.layout.dim[1].size;
      valid = cols > 0 && rows > 0 &&
        cols <= std::numeric_limits<size_t>::max() / rows &&
        elevation.data.size() >= cols * rows;
    }
  }
  if (!valid) {
    RCLCPP_WARN(
      node_->get_logger(),
      "AltitudeProfilePanel: rejected malformed non-empty terrain GridMap");
    return;
  }

  terrain_map_ = msg;
  terrain_map_received_ = true;
  // Frame is isotropic (1 unit = 100 m on every axis) since the publisher
  // z-scale fix; elevation/z convert to metres with the same constant as xy.
  elev_scale_ = GRID_CELL_SIZE_M;

  RCLCPP_INFO_ONCE(node_->get_logger(),
    "Terrain map received for altitude profile: resolution=%.2f, size=%.2f x %.2f m",
    msg->info.resolution, msg->info.length_x, msg->info.length_y);

  // If the trajectory was cached before terrain arrived, re-sample now
  if (trajectory_ready_ && !trajectory_points_.empty()) {
    resampleTerrain();
    rebuildProfile();
  }
}

void AltitudeProfilePanel::currentPositionCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
{
  // Odometry producers publish linear velocity in m/s (body-frame components;
  // its Euclidean norm is frame-invariant). Prefer it over position finite
  // differences: dragging the scrubber teleports the displayed pose and made
  // the old estimator report a false speed spike.
  const auto &pos = msg->pose.pose.position;
  const auto &twist = msg->twist.twist.linear;
  rclcpp::Time stamp(msg->header.stamp, RCL_ROS_TIME);
  const bool twist_valid =
    std::isfinite(twist.x) && std::isfinite(twist.y) && std::isfinite(twist.z);
  if (twist_valid) {
    speed_mps_ = std::sqrt(
      twist.x * twist.x + twist.y * twist.y + twist.z * twist.z);
  } else if (has_prev_pos_) {
    // Compatibility fallback for malformed/legacy odometry without a usable
    // twist. Reject implausible jumps rather than turning a scrub seek into a
    // speed measurement.
    double dt = (stamp - prev_pos_stamp_).seconds();
    if (dt > 1e-4 && dt < 1.0) {
      double dx = (pos.x - prev_pos_.x) * GRID_CELL_SIZE_M;
      double dy = (pos.y - prev_pos_.y) * GRID_CELL_SIZE_M;
      double dz = (pos.z - prev_pos_.z) * elev_scale_;
      double inst = std::sqrt(dx * dx + dy * dy + dz * dz) / dt;
      if (std::isfinite(inst) && inst <= 500.0) {
        constexpr double kEmaAlpha = 0.15;
        speed_mps_ = kEmaAlpha * inst + (1.0 - kEmaAlpha) * speed_mps_;
      }
    }
  }
  prev_pos_ = pos;
  prev_pos_stamp_ = stamp;
  has_prev_pos_ = true;

  if (!trajectory_ready_ || trajectory_points_.empty()) {
    return;
  }

  // [PERF] Coalesce the 50 Hz sim feed to 10 Hz before ANY further work.
  // Every message used to run the full-trajectory projection and then queue
  // a GUI lambda that repainted the whole antialiased profile widget,
  // relaid-out the status label, and re-polished its stylesheet. Measured by
  // panel-removal A/B (2026-08-20): this path alone was the difference
  // between 27 fps and 62 fps for the ENTIRE rviz frame loop in flight.
  const int64_t now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
    std::chrono::steady_clock::now().time_since_epoch()).count();
  if (now_ms - last_live_push_ms_ < 100) {
    return;
  }
  last_live_push_ms_ = now_ms;

  // Project onto trajectory SEGMENTS, not just sampled vertices. At a
  // self-intersection several segments can be equally close; among near-ties,
  // prefer the candidate closest to the previous progress. Progress itself is
  // not clamped, so dragging the scrubber backwards still works.
  double best_d2 = std::numeric_limits<double>::max();
  struct Projection {
    double d2;
    double progress_m;
  };
  std::vector<Projection> projections;
  projections.reserve(trajectory_points_.size() - 1);
  for (size_t i = 0; i + 1 < trajectory_points_.size(); ++i) {
    const auto & a = trajectory_points_[i];
    const auto & b = trajectory_points_[i + 1];
    const double vx = b.x - a.x;
    const double vy = b.y - a.y;
    const double len2 = vx * vx + vy * vy;
    double u = 0.0;
    if (len2 > 1e-12) {
      u = std::clamp(
        ((pos.x - a.x) * vx + (pos.y - a.y) * vy) / len2, 0.0, 1.0);
    }
    const double qx = a.x + u * vx;
    const double qy = a.y + u * vy;
    const double d2 = (pos.x - qx) * (pos.x - qx) +
                      (pos.y - qy) * (pos.y - qy);
    const double progress =
      distances_[i] + u * (distances_[i + 1] - distances_[i]);
    projections.push_back({d2, progress});
    best_d2 = std::min(best_d2, d2);
  }

  constexpr double kTieToleranceU = 0.05;  // 5 m in the 100 m/unit frame
  double progress = projections.front().progress_m;
  double best_continuity = std::numeric_limits<double>::max();
  for (const auto & candidate : projections) {
    if (candidate.d2 > best_d2 + kTieToleranceU * kTieToleranceU) continue;
    const double continuity = has_progress_
      ? std::abs(candidate.progress_m - last_progress_m_)
      : candidate.d2;
    if (continuity < best_continuity) {
      best_continuity = continuity;
      progress = candidate.progress_m;
    }
  }
  last_progress_m_ = progress;
  has_progress_ = true;
  // ROS callbacks run on RViz's spin thread, not the Qt GUI thread; widget
  // data and labels must only be touched on the GUI thread (paintEvent
  // iterates the same vectors) -> marshal via a queued call.
  const double alt_real = pos.z * elev_scale_;
  const double total_km = distances_.back() / 1000.0;
  const double mach = speed_mps_ / MACH_1_MPS;
  const double speed = speed_mps_;
  QMetaObject::invokeMethod(profile_widget_, [this, progress, alt_real,
                                              total_km, mach, speed]() {
    profile_widget_->setCurrentProgress(progress, alt_real);
    status_label_->setText(
      QString("Progress: %1 / %2 km  |  MSL alt %3 m  |  speed: Mach %4  (%5 m/s)")
        .arg(progress / 1000.0, 0, 'f', 2)
        .arg(total_km, 0, 'f', 2)
        .arg(alt_real, 0, 'f', 2)
        .arg(mach, 0, 'f', 2)
        .arg(speed, 0, 'f', 0));
    setStatusStyle(QStringLiteral("QLabel { color: green; padding: 5px; }"));
  }, Qt::QueuedConnection);
}

// setStyleSheet is NOT a cheap setter: every call invalidates and re-polishes
// the widget's style even when the sheet text is identical. On the live
// telemetry path that ran at feed rate — skip repeats.
void AltitudeProfilePanel::setStatusStyle(const QString & sheet)
{
  if (status_style_ == sheet) {
    return;
  }
  status_style_ = sheet;
  status_label_->setStyleSheet(sheet);
}

void AltitudeProfilePanel::dynObstacleArrayCallback(
  const visualization_msgs::msg::MarkerArray::SharedPtr msg)
{
  // The publisher sends DELETEALL + the full set each time: rebuild the
  // dynamic slice of the cache wholesale.
  for (auto it = obstacles_.begin(); it != obstacles_.end();) {
    if ((it->first >> 32) == 1) it = obstacles_.erase(it);
    else ++it;
  }
  for (const auto & m : msg->markers) {
    if (m.ns != "dynamic_obstacles_geom" ||
        m.action != visualization_msgs::msg::Marker::ADD) {
      continue;
    }
    ProfileObstacle g;
    g.is_box = true;
    g.cx = m.pose.position.x; g.cy = m.pose.position.y; g.cz = m.pose.position.z;
    g.sx = m.scale.x; g.sy = m.scale.y; g.sz = m.scale.z;
    g.yaw = 2.0 * std::atan2(m.pose.orientation.z, m.pose.orientation.w);
    obstacles_[(int64_t(1) << 32) | int64_t(m.id)] = g;
  }
  if (trajectory_ready_) { sampleObstacles(); rebuildProfile(); }
}

void AltitudeProfilePanel::sampleObstacles()
{
  const double nan = std::numeric_limits<double>::quiet_NaN();
  obstacle_top_.assign(trajectory_points_.size(), nan);
  obstacle_bot_.assign(trajectory_points_.size(), nan);
  if (obstacles_.empty()) return;
  for (size_t i = 0; i < trajectory_points_.size(); ++i) {
    const double x = trajectory_points_[i].x;
    const double y = trajectory_points_[i].y;
    double top = 0.0, bot = 0.0;
    bool have = false;
    for (const auto & kv : obstacles_) {
      const auto & g = kv.second;
      const double dx = x - g.cx, dy = y - g.cy;
      const double c = std::cos(g.yaw), sn = std::sin(g.yaw);
      const double bx =  c * dx + sn * dy;
      const double by = -sn * dx + c * dy;
      bool inside;
      if (g.is_box) {
        inside = std::abs(bx) <= 0.5 * g.sx && std::abs(by) <= 0.5 * g.sy;
      } else {
        const double rx = 0.5 * g.sx, ry = 0.5 * g.sy;
        inside = (rx > 0 && ry > 0) &&
                 (bx * bx) / (rx * rx) + (by * by) / (ry * ry) <= 1.0;
      }
      if (!inside) continue;
      // sz <= 0 (unspecified) = full-height column (yaml "infinite" columns).
      const double t = (g.sz > 1e-9) ? g.cz + 0.5 * g.sz : 1e9;
      const double b = (g.sz > 1e-9) ? g.cz - 0.5 * g.sz : 0.0;
      if (!have) { top = t; bot = b; have = true; }
      else { top = std::max(top, t); bot = std::min(bot, b); }
    }
    if (have) { obstacle_top_[i] = top; obstacle_bot_[i] = bot; }
  }
  // DIAGNOSTIC: the overlay drew implausible km-wide slabs once; log exactly
  // what the cache holds and how many samples tested inside so the next
  // occurrence explains itself.
  size_t covered = 0;
  for (double t : obstacle_top_) if (!std::isnan(t)) ++covered;
  RCLCPP_INFO(node_->get_logger(),
              "[ALT-OVERLAY] obstacles=%zu, samples inside=%zu/%zu",
              obstacles_.size(), covered, obstacle_top_.size());
}

void AltitudeProfilePanel::rebuildProfile()
{
  if (!trajectory_ready_ || trajectory_points_.empty()) {
    QMetaObject::invokeMethod(profile_widget_, [this]() {
      profile_widget_->clearData();
    }, Qt::QueuedConnection);
    return;
  }

  // Flight z is on the same compressed scale as the gridmap; show it in real metres.
  std::vector<geometry_msgs::msg::Point> traj_real = trajectory_points_;
  for (auto & p : traj_real) {
    p.z *= elev_scale_;
  }
  // Called from ROS callbacks (RViz spin thread): the widget vectors are
  // iterated by paintEvent on the GUI thread, so hand over copies there.
  const QString text = QString("Trajectory: %1 points, %2 km")
                         .arg(trajectory_points_.size())
                         .arg(distances_.back() / 1000.0, 0, 'f', 2);
  // Obstacle extents to real metres (full columns stay huge; clamped in draw).
  std::vector<double> obs_top = obstacle_top_;
  std::vector<double> obs_bot = obstacle_bot_;
  for (auto & v : obs_top) if (!std::isnan(v)) v *= elev_scale_;
  for (auto & v : obs_bot) if (!std::isnan(v)) v *= elev_scale_;

  QMetaObject::invokeMethod(profile_widget_,
      [this, traj_real = std::move(traj_real), distances = distances_,
       terrain = terrain_heights_,
       obs_top = std::move(obs_top), obs_bot = std::move(obs_bot),
       risk = risk_combined_r_, risk_lower = risk_band_lower_r_,
       risk_floor = risk_band_floor_r_,
       risk_top = risk_band_top_r_,
       text]() {
        profile_widget_->setTrajectoryData(traj_real, distances, terrain,
                                           obs_top, obs_bot,
                                           risk, risk_lower, risk_floor,
                                           risk_top);
        status_label_->setText(text);
        setStatusStyle(QStringLiteral("QLabel { color: green; padding: 5px; }"));
      }, Qt::QueuedConnection);
  // A trajectory may arrive after the latched chain array — remap onto the
  // fresh profile either way.
  pushChainToWidget();
}

void AltitudeProfilePanel::chainSegmentsCallback(
  const visualization_msgs::msg::MarkerArray::SharedPtr msg)
{
  chain_seg_colors_.clear();
  chain_junctions_.clear();
  for (const auto & m : msg->markers) {
    if (m.action != visualization_msgs::msg::Marker::ADD) continue;
    if (m.ns == "chain_seg" || m.ns == "chain_terminal") {
      chain_seg_colors_.push_back(
        QColor::fromRgbF(m.color.r, m.color.g, m.color.b));
    } else if (m.ns == "chain_junction") {
      chain_junctions_.push_back(m.pose.position);
    }
  }
  pushChainToWidget();
}

void AltitudeProfilePanel::pushChainToWidget()
{
  // Junction positions are frame-unit 3D points; the profile x-axis is arc
  // length. Snap each junction to the nearest trajectory sample (xy) and use
  // that sample's distance — exact enough at profile resolution, and immune
  // to unit/scale drift between the two channels.
  std::vector<double> js;
  if (!chain_junctions_.empty() && trajectory_ready_ &&
      !trajectory_points_.empty() && !distances_.empty()) {
    js.reserve(chain_junctions_.size());
    for (const auto & q : chain_junctions_) {
      size_t best = 0;
      double bd = std::numeric_limits<double>::max();
      for (size_t i = 0; i < trajectory_points_.size(); ++i) {
        const double dx = trajectory_points_[i].x - q.x;
        const double dy = trajectory_points_[i].y - q.y;
        const double d = dx * dx + dy * dy;
        if (d < bd) { bd = d; best = i; }
      }
      js.push_back(distances_[best]);
    }
    std::sort(js.begin(), js.end());
  }
  const QVector<QColor> colors = js.empty() ? QVector<QColor>() : chain_seg_colors_;
  QMetaObject::invokeMethod(profile_widget_,
      [this, js = std::move(js), colors]() {
        profile_widget_->setChainSegments(js, colors);
      }, Qt::QueuedConnection);
}

float AltitudeProfilePanel::getElevationAt(double x, double y)
{
  if (!terrain_map_received_ || !terrain_map_) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  int elevation_layer_idx = -1;
  for (size_t i = 0; i < terrain_map_->layers.size(); ++i) {
    if (terrain_map_->layers[i] == "elevation") {
      elevation_layer_idx = i;
      break;
    }
  }

  if (elevation_layer_idx < 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  double length_x = terrain_map_->info.length_x;
  double length_y = terrain_map_->info.length_y;
  double terrain_origin_x = terrain_map_->info.pose.position.x - length_x / 2.0;
  double terrain_origin_y = terrain_map_->info.pose.position.y - length_y / 2.0;

  const auto& elevation_data = terrain_map_->data[elevation_layer_idx];
  if (elevation_data.layout.dim.size() < 2) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  int terrain_cols = elevation_data.layout.dim[0].size;
  int terrain_rows = elevation_data.layout.dim[1].size;

  // grid_map cells are square and length_x spans the matrix ROWS (X axis), so
  // deriving a cell size as length_x / cols breaks on non-square maps.
  double terrain_cell_size = terrain_map_->info.resolution;
  if (!(terrain_cell_size > 0.0) || terrain_cols <= 0 || terrain_rows <= 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  // [TERRAIN-FRAME] world -> grid, grid_map core convention (row <-> X,
  // col <-> Y, both mirrored) — keep in sync with TerrainData::getElevation
  // and TrajectoryMetricsPanel::getElevationAt.
  // CELL-CENTER convention (the -0.5), matching the grid_map_rviz_plugin mesh
  // (vertices at cell centres). Without it the sampled surface sat half a
  // cell (~114 m) off the rendered terrain. floor() (not int-cast) so coords
  // just outside the origin round down consistently with the planner instead
  // of truncating toward zero.
  double fx = (terrain_origin_y + length_y - y) / terrain_cell_size - 0.5;  // column
  double fy = (terrain_origin_x + length_x - x) / terrain_cell_size - 0.5;  // row
  if (fx < -0.5 || fx > static_cast<double>(terrain_cols) - 0.5 ||
      fy < -0.5 || fy > static_cast<double>(terrain_rows) - 0.5) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  int col0 = static_cast<int>(std::floor(fx));
  int row0 = static_cast<int>(std::floor(fy));

  double tx = fx - col0;
  double ty = fy - row0;

  const float nan = std::numeric_limits<float>::quiet_NaN();
  auto at = [&](int col, int row) -> float {
    const int clamped_col = std::clamp(col, 0, terrain_cols - 1);
    const int clamped_row = std::clamp(row, 0, terrain_rows - 1);
    const int index = clamped_col * terrain_rows + clamped_row;
    if (index < 0 || index >= static_cast<int>(elevation_data.data.size())) {
      return nan;
    }
    return elevation_data.data[index];
  };

  const float e00 = at(col0, row0);
  const float e10 = at(col0 + 1, row0);
  const float e01 = at(col0, row0 + 1);
  const float e11 = at(col0 + 1, row0 + 1);

  // Match TerrainData::getElevation exactly: NaN water corners blend as sea
  // level 0, while a stencil touching the geometric map boundary replicates
  // the nearest DEM cell. This prevents cropped land edges from appearing as
  // a false downhill toward sea level.
  const bool n00 = std::isnan(e00), n10 = std::isnan(e10);
  const bool n01 = std::isnan(e01), n11 = std::isnan(e11);
  if (n00 && n10 && n01 && n11) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  const double f00 = n00 ? 0.0 : e00;
  const double f10 = n10 ? 0.0 : e10;
  const double f01 = n01 ? 0.0 : e01;
  const double f11 = n11 ? 0.0 : e11;

  float elevation = static_cast<float>(
    (1.0 - tx) * (1.0 - ty) * f00 +
    tx          * (1.0 - ty) * f10 +
    (1.0 - tx) * ty          * f01 +
    tx          * ty          * f11
  );

  return elevation;
}


namespace {
// seconds -> "M:SS"
QString fmtTimeScrub(double s)
{
  if (s < 0) s = 0;
  int sec = static_cast<int>(s + 0.5);
  return QString("%1:%2").arg(sec / 60).arg(sec % 60, 2, 10, QChar('0'));
}
}  // namespace

bool AltitudeProfilePanel::evalAt(double t_abs, double & x, double & y, double & z) const
{
  if (!has_traj_ || traj_.duration.empty() || !std::isfinite(t_abs)) return false;
  // traj_ passed mmp_traj_utils::validate on receipt, so sizes are trusted.
  double pos[3];
  mmp_traj_utils::evalAt(traj_, t_abs, pos);
  x = pos[0]; y = pos[1]; z = pos[2];
  return true;
}

double AltitudeProfilePanel::tToS(double t) const
{
  if (arc_s_.size() < 2 || total_duration_ <= 1e-9) return 0.0;
  const double u = std::clamp(t / total_duration_, 0.0, 1.0) *
                   static_cast<double>(arc_s_.size() - 1);
  const int i = std::min(static_cast<int>(u), static_cast<int>(arc_s_.size()) - 2);
  const double fr = u - i;
  return arc_s_[i] * (1.0 - fr) + arc_s_[i + 1] * fr;
}

double AltitudeProfilePanel::sToT(double s) const
{
  if (arc_s_.size() < 2 || total_len_ <= 1e-9) return 0.0;
  s = std::clamp(s, 0.0, total_len_);
  const auto it = std::lower_bound(arc_s_.begin(), arc_s_.end(), s);
  const size_t i = std::min<size_t>(it - arc_s_.begin(), arc_s_.size() - 1);
  if (i == 0) return 0.0;
  const double s0 = arc_s_[i - 1], s1 = arc_s_[i];
  const double fr = (s1 > s0) ? (s - s0) / (s1 - s0) : 0.0;
  const double dt = total_duration_ / static_cast<double>(arc_s_.size() - 1);
  return (static_cast<double>(i - 1) + fr) * dt;
}

void AltitudeProfilePanel::clearScrubber(const QString & reason)
{
  scrub_timer_->stop();
  play_button_->blockSignals(true);
  play_button_->setChecked(false);
  play_button_->setText("▶ Play");
  play_button_->setEnabled(false);
  play_button_->blockSignals(false);
  scrub_slider_->blockSignals(true);
  scrub_slider_->setValue(0);
  scrub_slider_->setEnabled(false);
  scrub_slider_->blockSignals(false);

  traj_ = mmp_traj_msgs::msg::PolyTraj{};
  has_traj_ = false;
  total_duration_ = 0.0;
  cur_t_ = 0.0;
  arc_s_.clear();
  total_len_ = 0.0;
  time_label_->setText(reason);
  time_label_->setStyleSheet("QLabel { color : gray; }");

  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = node_->now();
  marker.action = visualization_msgs::msg::Marker::DELETE;
  marker.id = 0;
  marker.ns = "trajectory_cursor";
  cursor_pub_->publish(marker);
  marker.ns = "flown_path";
  flown_pub_->publish(marker);
}

void AltitudeProfilePanel::onTrajectoryMsg(const mmp_traj_msgs::msg::PolyTraj::SharedPtr msg)
{
  // This callback runs on RViz's ROS spin thread. traj_ and the t/duration
  // state are read by the GUI-side tick/refresh/evalAt, and QWidget methods
  // (slider, button) may only be touched on the GUI thread — marshal the
  // whole update there.
  QMetaObject::invokeMethod(this, [this, msg]() {
    bool valid = mmp_traj_utils::validate(*msg);
    double total_duration = 0.0;
    if (valid) {
      total_duration = mmp_traj_utils::totalDuration(*msg);
      // Scrubber-specific: a degenerate (near-zero) total is unusable even
      // when the wire contract holds.
      valid = std::isfinite(total_duration) && total_duration > 1e-6;
    }
    if (!valid) {
      RCLCPP_WARN(
        node_->get_logger(),
        "AltitudeProfilePanel: clearing scrubber after invalid trajectory message");
      clearScrubber("No valid trajectory");
      return;
    }

    traj_ = *msg;
    total_duration_ = total_duration;
    has_traj_ = true;

    // xy arc-length table at uniform t. The altitude panel's distance axis
    // is xy-only, so distance fractions computed from this table place the
    // slider thumb exactly under that panel's current-position marker.
    arc_s_.assign(kArcN, 0.0);
    {
      double px = 0.0, py = 0.0, pz = 0.0;
      evalAt(0.0, px, py, pz);
      for (int n = 1; n < kArcN; ++n) {
        double cx, cy, cz;
        const double tn = total_duration_ * n / (kArcN - 1);
        if (evalAt(tn, cx, cy, cz)) {
          arc_s_[n] = arc_s_[n - 1] + std::hypot(cx - px, cy - py);
          px = cx; py = cy;
        } else {
          arc_s_[n] = arc_s_[n - 1];
        }
      }
    }
    total_len_ = arc_s_.back();

    scrub_slider_->setEnabled(true);
    play_button_->setEnabled(true);
    cur_t_ = 0.0;
    scrub_slider_->blockSignals(true);
    scrub_slider_->setValue(0);
    scrub_slider_->blockSignals(false);
    refreshScrub();
  }, Qt::QueuedConnection);
}

void AltitudeProfilePanel::refreshScrub()
{
  if (!has_traj_) return;
  const double t = std::clamp(cur_t_, 0.0, total_duration_);
  double x, y, z;
  if (!evalAt(t, x, y, z)) return;

  // Current-position sphere: solid and a touch darker, passing through the
  // translucent reference tunnel.
  visualization_msgs::msg::Marker m;
  m.header.frame_id = "map";
  m.header.stamp = node_->now();
  m.ns = "trajectory_cursor";
  m.id = 0;
  // Drone mesh (obj+mtl, Blender export): long axis = +y (nose), so the
  // pre-rotation is just -90 deg about z folded into the yaw. Native length
  // 14.9 units -> scale 2.0 gives a ~30-unit marker.
  m.type = visualization_msgs::msg::Marker::MESH_RESOURCE;
  m.mesh_resource = "package://mmp_viz_assets/meshes/drone.obj";
  m.mesh_use_embedded_materials = true;
  m.action = visualization_msgs::msg::Marker::ADD;
  m.pose.position.x = x;
  m.pose.position.y = y;
  m.pose.position.z = z;
  {
    // Orient the drone mesh along the FULL 3D path direction (heading + climb),
    // not just horizontal heading, so it pitches nose-up/down on vertical motion.
    double dx = 1.0, dy = 0.0, dz = 0.0;  // fallback: face +x, level
    double x2, y2, z2;
    const double t2 = std::min(t + 0.5, total_duration_);
    if (t2 > t && evalAt(t2, x2, y2, z2) &&
        (std::hypot(x2 - x, y2 - y) > 1e-9 || std::abs(z2 - z) > 1e-9)) {
      dx = x2 - x; dy = y2 - y; dz = z2 - z;
    } else if (t > 0.0 && evalAt(std::max(0.0, t - 0.5), x2, y2, z2) &&
               (std::hypot(x - x2, y - y2) > 1e-9 || std::abs(z - z2) > 1e-9)) {
      dx = x - x2; dy = y - y2; dz = z - z2;  // at the trajectory end: look back
    }
    const double yaw  = std::atan2(dy, dx);
    const double elev = std::atan2(dz, std::hypot(dx, dy));  // + climb, - descent
    // Mesh: nose = local +y, up = local +z. Target rotation
    //   R = Rz(yaw) * Ry(-elev) * Rz(-90deg)
    // makes the nose track the 3D direction while the drone stays upright (no roll).
    // Below is the closed-form quaternion of that product (reduces to the old
    // yaw-only form when elev == 0).
    const double k = 0.70710678118654752440;  // sqrt(2)/2
    const double sp = std::sin(0.5 * elev), cp = std::cos(0.5 * elev);
    const double sy = std::sin(0.5 * yaw),  cy = std::cos(0.5 * yaw);
    m.pose.orientation.x = k * sp * (cy + sy);
    m.pose.orientation.y = k * sp * (sy - cy);
    m.pose.orientation.z = k * cp * (sy - cy);
    m.pose.orientation.w = k * cp * (cy + sy);
  }
  m.scale.x = m.scale.y = m.scale.z = 0.8;   // was 2.0 — read as a jumbo jet at map scale
  // White tint + embedded materials = mesh's own colors. (All-zero color is
  // the documented "use embedded" convention but renders invisible on some
  // RViz builds, so use the identity tint instead.)
  m.color.r = m.color.g = m.color.b = 1.0f; m.color.a = 1.0f;
  cursor_pub_->publish(m);

  // Flown path [0, t]: a LINE_STRIP, not spheres — the old SPHERE_LIST at 300
  // fixed samples put ~1 km between 550 m balls on long missions, which read
  // as a string of separate circles. RViz billboards line strips toward the
  // camera, so a line never vanishes edge-on and has no sampling gaps.
  visualization_msgs::msg::Marker fp;
  fp.header = m.header;
  fp.ns = "flown_path";
  fp.id = 0;
  fp.type = visualization_msgs::msg::Marker::LINE_STRIP;
  fp.action = visualization_msgs::msg::Marker::ADD;
  fp.pose.orientation.w = 1.0;
  fp.scale.x = 1.7;   // line width (u); slightly > the 1.5 u reference tube
  // Opaque: two overlapping translucent tubes z-fight and flicker; an opaque
  // fill over the translucent reference is stable.
  fp.color.r = 1.0f; fp.color.g = 0.55f; fp.color.b = 0.1f; fp.color.a = 1.0f;  // opaque orange
  const int M = 300;
  for (int k = 0; k <= M; ++k) {
    double fx, fy, fz;
    if (evalAt(t * static_cast<double>(k) / M, fx, fy, fz)) {
      geometry_msgs::msg::Point p;
      p.x = fx; p.y = fy; p.z = fz;
      fp.points.push_back(p);
    }
  }
  flown_pub_->publish(fp);

  std_msgs::msg::Float64 st;
  st.data = t;
  scrub_pub_->publish(st);  // follower moves the drone to this t

  const double pct = total_duration_ > 0 ? 100.0 * t / total_duration_ : 0.0;
  time_label_->setText(
    QString("%1 / %2   (%3%)\nMSL alt  %4 m")
      .arg(fmtTimeScrub(t)).arg(fmtTimeScrub(total_duration_)).arg(pct, 0, 'f', 0)
      .arg(z * GRID_CELL_SIZE_M, 0, 'f', 1));
  time_label_->setStyleSheet("QLabel { color : black; }");
}

void AltitudeProfilePanel::onSliderChanged(int value)
{
  // The slider maps DISTANCE fraction (matching the altitude panel x-axis);
  // convert to scrub time through the arc table.
  const double fr = static_cast<double>(value) / kSteps;
  cur_t_ = (total_len_ > 1e-9) ? sToT(fr * total_len_) : fr * total_duration_;
  refreshScrub();
}

void AltitudeProfilePanel::onPlayToggled(bool checked)
{
  if (checked && has_traj_) {
    play_button_->setText("⏸ Pause");
    scrub_timer_->start(50);  // 20 Hz
  } else {
    play_button_->setText("▶ Play");
    scrub_timer_->stop();
    if (play_button_->isChecked()) {
      play_button_->blockSignals(true);
      play_button_->setChecked(false);
      play_button_->blockSignals(false);
    }
  }
}

void AltitudeProfilePanel::onTick()
{
  cur_t_ += 0.05 * kPlaySpeed;  // 50 ms tick -> real-time at kPlaySpeed = 1
  if (cur_t_ >= total_duration_) {
    cur_t_ = total_duration_;
    onPlayToggled(false);  // reached the end -> stop
  }
  // reflect on the slider (display only) without re-triggering onSliderChanged
  scrub_slider_->blockSignals(true);
  scrub_slider_->setValue(
    total_len_ > 1e-9
      ? static_cast<int>(tToS(cur_t_) / total_len_ * kSteps)
      : (total_duration_ > 1e-9
           ? static_cast<int>(cur_t_ / total_duration_ * kSteps) : 0));
  scrub_slider_->blockSignals(false);
  refreshScrub();
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::AltitudeProfilePanel, rviz_common::Panel)

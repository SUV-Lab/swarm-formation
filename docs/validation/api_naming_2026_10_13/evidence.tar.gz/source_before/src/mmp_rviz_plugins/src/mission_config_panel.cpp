#include "mmp_rviz_plugins/mission_config_panel.hpp"

#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QStringList>

#include <algorithm>
#include <cmath>



namespace {
// Browse opens this subdirectory by default (mission start/goal).
QString missionDir()
{
  // Source tree, not the install share: data is no longer installed (see
  // mmp_terrain/setup.py) — the source dir is the single authority. Workspace
  // root from MMP_WS, container default /ws.
  const QString ws = qEnvironmentVariable("MMP_WS", QStringLiteral("/ws"));
  const QString src = ws + QStringLiteral("/src/mmp_terrain/data/scenarios/missions");
  if (QDir(src).exists()) return src;
  return QString();
}
}  // namespace

namespace mmp_rviz_plugins
{

MissionConfigPanel::MissionConfigPanel(QWidget * parent)
: rviz_common::Panel(parent)
{
  auto * root = new QVBoxLayout(this);

  auto * file_row = new QHBoxLayout();
  file_path_edit_ = new QLineEdit(this);
  file_path_edit_->setPlaceholderText("mission.yaml (start + goal)");
  browse_button_ = new QPushButton("Browse...", this);
  file_row->addWidget(file_path_edit_);
  file_row->addWidget(browse_button_);
  root->addLayout(file_row);

  // Auto corridor: before the mission is published, terrain_publisher crops
  // the fine 30-40 m DEM around this mission's start/goal (full-map frame) —
  // replaces loading the whole 250 m full map by hand. Unchecked = Run is
  // refused: the old publish-on-whatever-is-loaded path bypassed the
  // resolver and the ingestion receipt (removed, see onRunClicked).
  corridor_check_ = new QCheckBox(
      "Auto-load corridor map (30 m terrain around the mission, full-map frame)", this);
  corridor_check_->setChecked(true);
  root->addWidget(corridor_check_);

  run_button_ = new QPushButton("▶ Run mission (start → goal)", this);
  run_button_->setStyleSheet(
      "QPushButton { font-weight: bold; padding: 6px; "
      "background-color: #2d8f4a; color: white; }"
      "QPushButton:hover:enabled { background-color: #36a655; }"
      "QPushButton:disabled { background-color: #555555; color: #aaaaaa; }");
  root->addWidget(run_button_);

  status_label_ = new QLabel("", this);
  status_label_->setWordWrap(true);
  root->addWidget(status_label_);

  // Run stays disabled until both a yaml is picked and a path_manager node
  // is in the graph. Without those, publishing /mission/trajectory_command
  // is a no-op and just confuses the user.
  run_button_->setEnabled(false);

  connect(browse_button_, &QPushButton::clicked,
          this, &MissionConfigPanel::onBrowseClicked);
  connect(run_button_, &QPushButton::clicked,
          this, &MissionConfigPanel::onRunClicked);
  connect(file_path_edit_, &QLineEdit::textChanged,
          this, [this](const QString &){
            // Editing the selection invalidates in-flight work (see the
            // selection_generation_ member comment).
            ++selection_generation_;
            refreshRunButtonEnabled();
          });

  readiness_timer_ = new QTimer(this);
  readiness_timer_->setInterval(1000);  // 1 Hz graph poll — cheap
  connect(readiness_timer_, &QTimer::timeout,
          this, &MissionConfigPanel::pollReadiness);

  corridor_timer_ = new QTimer(this);
  corridor_timer_->setInterval(100);
  connect(corridor_timer_, &QTimer::timeout,
          this, &MissionConfigPanel::pollCorridor);
}

void MissionConfigPanel::onInitialize()
{
  node_ = getDisplayContext()
            ->getRosNodeAbstraction()
            .lock()
            ->get_raw_node();

  trajectory_cmd_pub_ =
      node_->create_publisher<mmp_mission_msgs::msg::TrajectoryCommand>(
          "/mission/trajectory_command", rclcpp::QoS(10).reliable());

  rclcpp::QoS map_qos(1);
  map_qos.transient_local().reliable();

  // [TERRAIN-READY] planner ingestion receipt (see the member comment).
  terrain_ready_sub_ = node_->create_subscription<std_msgs::msg::Float64MultiArray>(
      "/planning/terrain_ready", map_qos,
      [this](std_msgs::msg::Float64MultiArray::SharedPtr msg) {
        if (msg->data.size() < 3) return;
        ready_ox_u_ = msg->data[1];
        ready_oy_u_ = msg->data[2];
        ready_lx_u_ = msg->data.size() >= 5 ? msg->data[3] : -1.0;
        ready_ly_u_ = msg->data.size() >= 5 ? msg->data[4] : -1.0;
        // res last: pollCorridor treats ready_res_u_ > 0 as "receipt
        // present", so the other fields must be in place first.
        ready_res_u_ = msg->data[0];
      });

  load_map_client_ =
      node_->create_client<mmp_mission_msgs::srv::LoadMap>("/terrain/load_map");

  // Start polling now that we have a node to query the graph from.
  readiness_timer_->start();
  // Initial check so the button isn't briefly enabled with stale state.
  pollReadiness();
}

void MissionConfigPanel::onBrowseClicked()
{
  QString start_dir = file_path_edit_->text();
  if (start_dir.isEmpty() || !QFileInfo(start_dir).exists()) {
    start_dir = missionDir();
  }
  const QString path = QFileDialog::getOpenFileName(
      this, "Select mission YAML", start_dir,
      "YAML files (*.yaml *.yml)");
  if (!path.isEmpty()) {
    file_path_edit_->setText(path);
  }
}

void MissionConfigPanel::onRunClicked()
{
  // Belt to the button's suspenders: textChanged re-enables Run, so a click
  // can still land while a corridor load or ingestion wait is in flight —
  // re-entering here mid-wait bricked the flow (review find).
  if (corridor_pending_ || ready_pending_) {
    setStatus("corridor still loading/ingesting — wait for it to finish",
              /*error=*/true);
    return;
  }
  const std::string path = file_path_edit_->text().toStdString();
  if (path.empty()) {
    setStatus("No file selected", /*error=*/true);
    return;
  }

  // This panel does not parse mission yaml. /terrain/load_map resolves it
  // (mmp_terrain.mission is the one coordinate implementation) and the
  // response's ResolvedMission is the only source of what gets published.
  // Corridor OFF is refused for the same reason: no publish path may bypass
  // the resolver and the ingestion receipt.
  if (!(corridor_check_ && corridor_check_->isChecked())) {
    setStatus("Run with corridor OFF is disabled — mission coordinates come "
              "from /terrain/load_map and publish waits for the corridor "
              "ingestion receipt. Check the box and Run again.",
              /*error=*/true);
    return;
  }
  // Availability guard on the service we are about to call (a short blocking
  // wait, not a poll: the graph may have only just come up). No service =
  // no publish; there is no local-parse fallback.
  if (!load_map_client_->wait_for_service(std::chrono::milliseconds(250))) {
    setStatus("terrain_publisher not available — nothing published (mission "
              "coordinates only exist as resolver output)", /*error=*/true);
    return;
  }

  // Fingerprint of the file at request time (a hash, not a parse). Compared
  // against the response's mission_sha256: the server must have resolved
  // exactly the bytes the user picked.
  QFile mission_file(QString::fromStdString(path));
  if (!mission_file.open(QIODevice::ReadOnly)) {
    setStatus(QString("cannot read %1").arg(QString::fromStdString(path)),
              /*error=*/true);
    return;
  }
  const std::string sha = QCryptographicHash::hash(
      mission_file.readAll(), QCryptographicHash::Sha256).toHex().toStdString();

  QFileInfo info(QString::fromStdString(path));
  auto req = std::make_shared<mmp_mission_msgs::srv::LoadMap::Request>();
  req->world = "full_map";
  req->mission_path = path;      // non-empty + full_map = corridor mode
  req->corridor_halfwidth_u = 0.0;  // 0 = the node's default berth
  req->resolution_m = 0.0;          // 0 = auto ladder
  req->resolve_only = false;
  // Fresh token per Run: the response gate accepts only the newest request's
  // answer (stale responses are discarded).
  req->request_token =
      (info.baseName() + "#" + QString::number(++request_counter_))
          .toStdString();
  pending_token_ = req->request_token;
  pending_sha_ = sha;
  pending_generation_ = selection_generation_;
  pending_name_ = info.baseName();
  corridor_pending_ = true;
  corridor_ticks_ = 0;
  run_button_->setEnabled(false);
  setStatus(QString("loading corridor map... (30 m terrain crop around %1)")
                .arg(pending_name_), /*error=*/false);
  corridor_future_ = load_map_client_->async_send_request(req).future.share();
  corridor_timer_->start();
}

void MissionConfigPanel::pollCorridor()
{
  // [TERRAIN-READY] second phase: corridor published, waiting for the
  // planner's ingestion receipt before releasing the mission command.
  if (ready_pending_) {
    ++ready_ticks_;
    const double tol = std::max(expect_res_u_, 0.01);
    // Extent joins the match when the receipt carries it (5-element form):
    // origin+resolution alone alias two corridors sharing a corner.
    const bool extent_ok =
      ready_lx_u_ <= 0.0 || expect_lx_u_ <= 0.0 ||
      (std::abs(ready_lx_u_ - expect_lx_u_) <= 2.0 * tol &&
       std::abs(ready_ly_u_ - expect_ly_u_) <= 2.0 * tol);
    const bool match =
      ready_res_u_ > 0.0 &&
      std::abs(ready_res_u_ - expect_res_u_) <= 1e-9 + expect_res_u_ * 0.001 &&
      std::abs(ready_ox_u_ - expect_ox_u_) <= tol &&
      std::abs(ready_oy_u_ - expect_oy_u_) <= tol && extent_ok;
    if (!match && ready_ticks_ <= 300) return;  // keep waiting (<= 30 s)
    ready_pending_ = false;
    corridor_timer_->stop();
    refreshRunButtonEnabled();
    if (!match) {
      // The 30 s publish-anyway fail-open is gone: without a receipt the
      // planner may hold the coarse global DEM or another corridor.
      setStatus(QString("%1 loaded — no ingestion receipt in 30 s; mission "
                        "'%2' NOT published (a planner without "
                        "/planning/terrain_ready cannot prove it holds this "
                        "corridor — check the planner build/log)")
                    .arg(pending_geom_).arg(pending_name_), true);
      return;
    }
    // Re-run the SAME gate before release: the user can edit the selection
    // during the (up to 30 s) receipt wait too, and one shared decision
    // function keeps this check and the response-phase check from drifting.
    if (!accepted_resp_ ||
        gateResolvedResponse(*accepted_resp_, pending_token_, pending_sha_,
                             pending_generation_, selection_generation_) !=
        ResponseGate::kAccept)
    {
      accepted_resp_.reset();
      setStatus(QString("mission selection changed while waiting for "
                        "ingestion — '%1' NOT published; Run again with the "
                        "current file").arg(pending_name_), true);
      return;
    }
    accepted_resp_.reset();
    publish(pending_mission_);
    QString done = QString("%1 ingested -> mission '%2' published")
                       .arg(pending_geom_).arg(pending_name_);
    if (!pending_warnings_.isEmpty()) {
      done += QString(" — %1").arg(pending_warnings_);
    }
    setStatus(done, !pending_warnings_.isEmpty());
    return;
  }
  if (!rclcpp::ok()) {  // context down (Ctrl-C mid-load): stop, don't throw
    corridor_pending_ = false;
    corridor_timer_->stop();
    return;
  }
  if (!corridor_pending_ || !corridor_future_.valid()) {
    corridor_timer_->stop();  // nothing in flight; wait_for on an invalid future is UB
    return;
  }
  ++corridor_ticks_;
  // Corridor crops take seconds, but a cold full_map load is much slower —
  // keep the 60 s watchdog.
  if (corridor_ticks_ > 600) {
    corridor_pending_ = false;
    corridor_timer_->stop();
    refreshRunButtonEnabled();
    setStatus("corridor load timed out — check the terrain_publisher log", true);
    return;
  }

  if (corridor_future_.wait_for(std::chrono::milliseconds(0)) !=
      std::future_status::ready) {
    return;
  }
  corridor_pending_ = false;

  mmp_mission_msgs::srv::LoadMap::Response::SharedPtr resp;
  try {
    resp = corridor_future_.get();
  } catch (const std::exception &) {
  }
  if (!resp || !resp->success) {
    corridor_timer_->stop();
    refreshRunButtonEnabled();
    setStatus(QString("corridor map load failed: %1")
                  .arg(resp ? QString::fromStdString(resp->message)
                            : QString("service exception")), true);
    return;
  }

  // Response gate (pure check in mission_command.cpp, pinned by gtests):
  // stale token, unresolved response (old server), file sha mismatch, or
  // missing geometry — all refuse with zero publishes. This refusal replaces
  // the old publish-immediately path for legacy servers.
  const ResponseGate verdict =
      gateResolvedResponse(*resp, pending_token_, pending_sha_,
                           pending_generation_, selection_generation_);
  if (verdict != ResponseGate::kAccept) {
    corridor_timer_->stop();
    refreshRunButtonEnabled();
    QString why;
    switch (verdict) {
      case ResponseGate::kSelectionChanged:
        why = "mission selection changed while the corridor loaded — Run "
              "again with the current file";
        break;
      case ResponseGate::kStaleToken:
        why = "stale response (token mismatch) — not the newest Run's answer";
        break;
      case ResponseGate::kNotResolved:
        why = "server returned no resolved mission (terrain_publisher older "
              "than ResolvedMission?) — cannot publish without coordinates";
        break;
      case ResponseGate::kShaMismatch:
        why = "mission file changed between the request and the server's "
              "read (sha mismatch) — Run again to re-resolve";
        break;
      default:
        why = "no corridor geometry in the reply — the ingestion receipt "
              "cannot be matched";
        break;
    }
    setStatus(QString("mission NOT published: %1").arg(why), true);
    return;
  }
  // The response's resolution is the only source of the mission to publish.
  accepted_resp_ = resp;   // for the receipt-release re-gate above
  pending_mission_ = fromResolved(resp->mission, pending_name_.toStdString());
  QStringList warn_list;
  for (const auto & w : resp->mission.warnings) {
    warn_list << QString::fromStdString(w);
  }
  pending_warnings_ = warn_list.join("; ");

  // Report what actually loaded, not what was asked for: the auto ladder may
  // have coarsened the resolution and the crop is clamped to the DEM data
  // bounds. Bounds are frame units (1 u = 100 m, isotropic), and the server
  // snaps the bbox to a whole number of cells, so the cell counts are exact.
  const double span_x_u = resp->max_bound_u[0] - resp->min_bound_u[0];
  const double span_y_u = resp->max_bound_u[1] - resp->min_bound_u[1];
  const double res = resp->actual_resolution_m;
  QString geom;
  if (res > 0.0 && span_x_u > 0.0 && span_y_u > 0.0) {
    geom = QString("corridor %1x%2 @ %3 m")
               .arg(std::llround(span_x_u * 100.0 / res))
               .arg(std::llround(span_y_u * 100.0 / res))
               .arg(res, 0, 'f', 0);
  } else {
    geom = QString("corridor u=(%1,%2)..(%3,%4)")
               .arg(resp->min_bound_u[0], 0, 'f', 0)
               .arg(resp->min_bound_u[1], 0, 'f', 0)
               .arg(resp->max_bound_u[0], 0, 'f', 0)
               .arg(resp->max_bound_u[1], 0, 'f', 0);
  }
  // [TERRAIN-READY] The service published+latched the corridor BEFORE
  // replying, but the planner may still be DIGESTING it (SDF rebuild + risk
  // masks take seconds on big crops) — launching now races that ingestion
  // and can plan on the coarse global DEM. Hold the mission until the
  // planner's ingestion receipt matches this corridor. (A reply without
  // geometry was already refused by the gate — there is no skip-the-receipt
  // branch.)
  expect_res_u_ = resp->actual_resolution_m / 100.0;
  expect_ox_u_ = resp->min_bound_u[0];
  expect_oy_u_ = resp->min_bound_u[1];
  expect_lx_u_ = resp->max_bound_u[0] - resp->min_bound_u[0];
  expect_ly_u_ = resp->max_bound_u[1] - resp->min_bound_u[1];
  pending_geom_ = geom;
  ready_pending_ = true;
  ready_ticks_ = 0;
  // NOT cleared here. The receipt this gate waits for has usually ALREADY
  // arrived by the time this code runs: the server publishes the corridor
  // BEFORE it replies (see above), and rviz2's main thread then spends
  // seconds deserializing that same 38.5 MB GridMap for its displays, so
  // the planner ingests and publishes its receipt while the Qt timer that
  // brings us here is starved. Clearing it meant waiting for a second
  // receipt that is never published — ReplanFSM emits exactly one per
  // terrain message — so every Run fell through the 30 s fail-open. That
  // is not a hypothesis: across 12 recorded panel sessions the gap from
  // the planner's corridor ingestion to the mission command is 33.0 s in
  // seven of them (32.99-34.30) and 1.92 s in the pre-gate ones.
  //
  // The clear was added so a previous corridor sharing this one's corner
  // and resolution could not release the gate early. The match below now
  // also compares EXTENT, and corner + resolution + extent identify the
  // corridor: a receipt that matches all three certifies that the planner
  // holds exactly this map, whether it said so a moment ago or just now.
  setStatus(QString("%1 loaded — waiting for planner ingestion...")
                .arg(geom), false);
}

void MissionConfigPanel::publish(const ParsedMission & m)
{
  // 명령 구성은 mission_command.cpp 에 있다 — Qt 없이 시험할 수 있는 자리다.
  // 증가는 여기 남는다: 빌더가 순수해야 같은 미션을 두 번 넣어 id 가 달라지는지
  // 검사할 수 있다.
  trajectory_cmd_pub_->publish(buildTrajectoryCommand(m, ++sequence_counter_));
}

void MissionConfigPanel::setStatus(const QString & text, bool error)
{
  status_label_->setText(text);
  status_label_->setStyleSheet(error ? "color: red;" : "color: black;");
}

// ---- readiness gating ---------------------------------------------------

bool MissionConfigPanel::pathManagerUp() const
{
  // rclcpp::ok() gate + catch: the readiness QTimer keeps firing after the
  // SIGINT handler has invalidated the rcl context (Qt's event loop outlives
  // rclcpp shutdown), and get_node_names() on a dead context THROWS
  // std::runtime_error — uncaught in a Qt slot -> std::terminate. This was a
  // deterministic abort on every Ctrl-C/close (reproduced under valgrind:
  // "failed to get node names: rcl node's context is invalid").
  if (!node_ || !rclcpp::ok()) return false;
  try {
    // ReplanFSM nodes are named replan_fsm_drone_<i> by path_manager.launch.py.
    // Any one of them being in the graph means a planner is listening on
    // /mission/trajectory_command. Names come back as "/replan_fsm_drone_0" etc.
    for (const auto & full : node_->get_node_graph_interface()->get_node_names()) {
      auto pos = full.find_last_of('/');
      const std::string bare = (pos == std::string::npos) ? full : full.substr(pos + 1);
      if (bare.rfind("replan_fsm_drone_", 0) == 0) return true;
    }
  } catch (const std::exception &) {
    return false;  // context tearing down between the ok() check and the call
  }
  return false;
}

void MissionConfigPanel::pollReadiness()
{
  const bool up = pathManagerUp();
  if (up != path_manager_up_) {
    path_manager_up_ = up;
    refreshRunButtonEnabled();
  }
}

void MissionConfigPanel::refreshRunButtonEnabled()
{
  const bool have_yaml = !file_path_edit_->text().trimmed().isEmpty();
  // In-flight corridor/ingestion phases keep Run down: a second click mid-
  // wait either bricked the flow (corridor re-entry) or let a direct Run be
  // overridden later by the held mission (review finds).
  run_button_->setEnabled(have_yaml && path_manager_up_ &&
                          !corridor_pending_ && !ready_pending_);
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(
    mmp_rviz_plugins::MissionConfigPanel, rviz_common::Panel)

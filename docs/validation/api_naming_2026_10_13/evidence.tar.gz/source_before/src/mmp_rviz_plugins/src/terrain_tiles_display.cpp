#include "mmp_rviz_plugins/terrain_tiles_display.hpp"

#include "mmp_rviz_plugins/border_stitch.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <set>
#include <vector>

#include <QElapsedTimer>
#include <turbojpeg.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QUrl>

#include <OgreAxisAlignedBox.h>
#include <OgreCamera.h>
#include <OgreHardwarePixelBuffer.h>
#include <OgreMaterialManager.h>
#include <OgreRenderTarget.h>
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
#include <OgreTechnique.h>
#include <OgreTextureManager.h>
#include <OgreViewport.h>

#include "rviz_common/display_context.hpp"
#include "rviz_common/properties/bool_property.hpp"
#include "rviz_common/properties/float_property.hpp"
#include "rviz_common/properties/int_property.hpp"
#include "rviz_common/properties/string_property.hpp"
#include "rviz_common/view_controller.hpp"
#include "rviz_common/view_manager.hpp"

namespace mmp_rviz_plugins
{

namespace
{
// Concurrent tile fetches. Each tile is TWO HTTP requests (hgt + img), so the
// socket pool below must cover 2x this number or Qt queues the excess FIFO —
// which destroys the nearest-first ordering tick() sorts so carefully.
constexpr int kMaxInflight = 24;
// Terrain z-extent (world units, 1 u = 100 m) used for frustum culling. The map
// tops out at ~27 u; the slack keeps the box valid under z exaggeration.
constexpr double kZLo = -1.0;
// Terrain box top FALLBACK (frame units), used until /ftile/meta supplies the
// map's real elevation ceiling (elev_max_m). A constant authored for one map
// silently breaks on the next: 30 u (3000 m) was written for the Korea map
// and the east-asia map reaches ~37.7 u near Fuji — summit tiles culled while
// visibly on screen. Keep the box TIGHT to the real terrain: oversizing it
// collapses near-tile distances and wastes the leaf budget (see cover()).
constexpr double kZTopFallback = 40.0;
// Ticks a tile stays resident after leaving the view (50 ms each = 8 s): a
// camera wobble must not evict-then-refetch the tiles it just showed.
constexpr uint64_t kGraceTicks = 160;
// Levels never evicted. A zoom-OUT needs the coarse ancestors, but while you
// were zoomed IN they were invisible, so the LRU threw them away — and the
// screen went empty for the half second it took to fetch them back. The whole
// pyramid down to this level is ~120 tiles: pin it as a permanent base layer so
// there is ALWAYS something to draw, at any camera position.
constexpr int kPinLevel = 4;
// Prefetch margin: children are requested once a node is within this factor of
// its split threshold, so they are already resident when the camera actually
// crosses it (an instant swap instead of a visible wait).
constexpr double kPrefetch = 0.55;
// Ceiling for the escalated refinement threshold. A camera INSIDE the terrain
// clamps dist to 0.5 and pushes hundreds of tiles to sse in the thousands —
// no finite threshold fits the budget, and without a ceiling the carried
// threshold multiplies every tick and diverges to +inf (permanent max-coarse
// after the camera comes back out). At the cap the draw is best-effort
// over-budget; recovery after leaving the terrain is the plain 0.9 decay.
constexpr double kThrCap = 256.0;
const Ogre::String kResourceGroup = Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME;
uint64_t g_instance_counter = 0;
}  // namespace

TerrainTilesDisplay::TerrainTilesDisplay()
{
  instance_id_ = ++g_instance_counter;
  url_property_ = new rviz_common::properties::StringProperty(
    "Server URL", "http://localhost:8085",
    "Globe tile server base URL (serves /ftile/*).", this);
  // 4 px/cell: a tile has 64 cells and a 256 px texture, so at 4 px per cell the
  // tile covers ~256 screen px and the imagery renders 1:1. Larger values
  // stretch the texture (blurry); smaller ones only add tiles.
  detail_property_ = new rviz_common::properties::FloatProperty(
    "Detail", 4.0,
    "Max screen-space error in pixels before a tile is split. 4 = texture-matched "
    "(1 texel per pixel). Lower = sharper geometry and more tiles.", this);
  detail_property_->setMin(2.0f);
  detail_property_->setMax(64.0f);
  budget_property_ = new rviz_common::properties::IntProperty(
    "Tile budget", 1500, "Resident tiles (LRU). Higher = fewer reloads, more VRAM.",
    this);
  budget_property_->setMin(64);
  budget_property_->setMax(3000);
  level_property_ = new rviz_common::properties::IntProperty(
    "Level override", -1, "-1 = pick per tile from screen-space error.", this);
  level_property_->setMin(-1);
  level_property_->setMax(12);
  exaggeration_property_ = new rviz_common::properties::FloatProperty(
    "Z exaggeration", 1.0, "Visual-only vertical scale on the tile meshes.", this);
  exaggeration_property_->setMin(0.1f);
  exaggeration_property_->setMax(10.0f);
  adaptive_skirt_property_ = new rviz_common::properties::BoolProperty(
    "Adaptive skirt", true,
    "Size each tile's crack-hiding skirt from its border relief instead of a "
    "constant 3% of tile span (measured LOD cracks never exceed ~half that). "
    "Off = legacy constant depth. Toggling rebuilds tiles progressively.", this);
  backface_property_ = new rviz_common::properties::BoolProperty(
    "Backface culling", false,
    "Cull skirt back sides and the terrain underside. "
    "Off matches the legacy double-sided rendering.", this);
}

TerrainTilesDisplay::~TerrainTilesDisplay()
{
  // Stop the Qt timers and release the rclcpp param client BEFORE rviz tears
  // down its shared node. world_client_ (AsyncParametersClient) registers a
  // parameter-events subscription + service clients in the node's default
  // CallbackGroup; if it outlives the panel, rclcpp::CallbackGroup::
  // ~CallbackGroup walks the dangling entity at shutdown and SIGSEGVs
  // (VisualizerApp -> Node dtor). Isolated to THIS display: a panels-removed
  // config still crashed 6/6, stock rviz 0/6; this reset makes it clean.
  if (timer_) {timer_->stop();}
  if (drain_timer_) {drain_timer_->stop();}
  world_client_.reset();
  destroyAll();
}

// Least-loaded manager, by outstanding requests. Round-robin ignored
// occupancy: a manager whose tiles stalled kept receiving refills, and the
// new requests FIFO-queued behind the stalled ones — the nearest missing
// tiles filling LAST, the exact inversion the priority sort exists to avoid.
int TerrainTilesDisplay::pickNam()
{
  int best = 0;
  for (int i = 1; i < static_cast<int>(nams_.size()); ++i) {
    if (nam_load_[i] < nam_load_[best]) {
      best = i;
    }
  }
  return best;
}

void TerrainTilesDisplay::onInitialize()
{
  // Qt caps HTTP/1.1 at 6 sockets per host PER MANAGER; kMaxInflight tiles are
  // 2x requests each, so 8 x 6 = 48 sockets >= 24 x 2 keeps every request on a
  // live socket instead of a FIFO queue that ignores the priority sort.
  for (int i = 0; i < 8; ++i) {
    nams_.push_back(new QNetworkAccessManager(this));
  }
  nam_load_.assign(nams_.size(), 0);
  timer_ = new QTimer(this);
  timer_->setInterval(50);           // camera-follow cadence (visibility batches)
  connect(timer_, &QTimer::timeout, this, &TerrainTilesDisplay::tick);
  drain_timer_ = new QTimer(this);
  drain_timer_->setInterval(16);     // once per frame-ish
  connect(drain_timer_, &QTimer::timeout, this, &TerrainTilesDisplay::drain);
  // world_client_ is created in onEnable() and released in onDisable() so it
  // never outlives rviz's shared node at shutdown (see onEnable).
}

void TerrainTilesDisplay::onEnable()
{
  // Create the rclcpp param client HERE (not onInitialize) and release it in
  // onDisable. rviz disables every display before it destroys its shared node
  // at shutdown, so an onDisable release happens while the node is still alive
  // — whereas the display's own destructor runs AFTER the node is gone
  // (VisualizerApp -> Node dtor), too late, which is why a destructor reset
  // did NOT stop the CallbackGroup SIGSEGV. Verified on the NVIDIA GPU.
  if (!world_client_) {
    auto rviz_node = context_->getRosNodeAbstraction().lock();
    if (rviz_node) {
      world_client_ = std::make_shared<rclcpp::AsyncParametersClient>(
        rviz_node->get_raw_node(), "/terrain_publisher");
    }
  }
  timer_->start();
  drain_timer_->start();
}

void TerrainTilesDisplay::onDisable()
{
  timer_->stop();
  drain_timer_->stop();
  world_client_.reset();       // free CallbackGroup entities while node lives
  world_poll_stamp_ = 0;       // re-poll world on next enable
  destroyAll();
}

void TerrainTilesDisplay::reset()
{
  Display::reset();
  destroyAll();
}

void TerrainTilesDisplay::fetchMeta()
{
  if (meta_inflight_ || stamp_ < meta_retry_after_) {
    return;
  }
  meta_inflight_ = true;
  QNetworkRequest req(QUrl(url_property_->getString() + "/ftile/meta"));
  // Same half-open-socket hazard as the tile requests: without a timeout, a
  // meta fetch caught mid-server-restart hangs forever, meta_inflight_ never
  // clears, and the display stays blank for the whole session.
  req.setTransferTimeout(15000);
  const int ni = pickNam();
  ++nam_load_[ni];
  QNetworkReply * reply = nams_[ni]->get(req);
  connect(reply, &QNetworkReply::finished, this, [this, ni, reply]() {
      --nam_load_[ni];
      reply->deleteLater();
      meta_inflight_ = false;
      if (reply->error() != QNetworkReply::NoError) {
        meta_retry_after_ = stamp_ + 20;   // ~1 s: don't hammer a down server at tick rate
        setStatus(rviz_common::properties::StatusProperty::Error, "Server",
                  "meta fetch failed: " + reply->errorString());
        return;
      }
      const auto doc = QJsonDocument::fromJson(reply->readAll());
      const auto o = doc.object();
      root_ = o["root"].toDouble(16384.0);
      grid_ = o["grid"].toInt(65);
      maxz_ = o["maxz"].toInt(9);
      lx_ = o["Lx"].toDouble(0.0);
      ly_ = o["Ly"].toDouble(0.0);
      // Real terrain ceiling from the server (metres -> units, +200 m slack);
      // absent on older servers -> conservative fallback.
      z_top_u_ = o.contains("elev_max_m") ?
        o["elev_max_m"].toDouble(3800.0) * 0.01 + 2.0 : kZTopFallback;
      meta_ok_ = true;
      setStatus(rviz_common::properties::StatusProperty::Ok, "Server", "connected");
    });
}

// Quadtree traversal that decides, for every node, whether to DRAW it or to
// descend into its four children — and it draws a node only when its whole
// subtree cannot be drawn. That exclusivity is what makes the picture stable:
// the earlier version drew a loaded child AND its parent (as a stand-in for the
// child's not-yet-loaded siblings), so two surfaces occupied the same space and
// z-fought, which is the flicker you see on every small camera move.
//
// Returns true when this node's area is fully covered by what it queued for
// drawing (either itself, or all four children recursively).
bool TerrainTilesDisplay::cover(
  const TileKey & key, const Ogre::Camera * cam, double px_per_unit_at_1,
  std::vector<TileKey> * visible, double thr)
{
  ++visited_;
  const double S = root_ / static_cast<double>(1 << key.z);
  const double x0 = key.x * S, y0 = key.y * S;
  if (x0 >= lx_ || y0 >= ly_) {
    return true;                               // off the map: nothing to cover
  }
  const double x1 = std::min(x0 + S, lx_), y1 = std::min(y0 + S, ly_);

  const Ogre::AxisAlignedBox box(
    Ogre::Vector3(static_cast<Ogre::Real>(x0), static_cast<Ogre::Real>(y0),
                  static_cast<Ogre::Real>(kZLo)),
    Ogre::Vector3(static_cast<Ogre::Real>(x1), static_cast<Ogre::Real>(y1),
                  static_cast<Ogre::Real>(z_top_u_ * last_exag_)));
  if (!cam->isVisible(box)) {
    // Drop hysteresis state on the way out — the WHOLE stale subtree, not
    // just this node: a node that kept its split_ entry while off-screen
    // re-entered under the 0.6x MERGE threshold, so revisited areas
    // materialized one level finer than a fresh visit — overshooting the
    // leaf budget and kicking the whole screen into the coarsen/resharpen
    // cycle precisely when the camera returned somewhere it had been.
    purgeSplit(key);
    ++culled_;
    return true;                               // culled: nothing to cover
  }

  const Ogre::Vector3 p = cam->getDerivedPosition();
  const Ogre::Vector3 c = box.getCenter(), h = box.getHalfSize();
  const Ogre::Vector3 d(std::abs(p.x - c.x), std::abs(p.y - c.y), std::abs(p.z - c.z));
  const Ogre::Vector3 q(std::max(0.0f, d.x - h.x), std::max(0.0f, d.y - h.y),
                        std::max(0.0f, d.z - h.z));
  const double dist = std::max(0.5, static_cast<double>(q.length()));

  bool split;
  const int forced = level_property_->getInt();
  if (forced >= 0) {
    split = key.z < std::min(forced, maxz_);
  } else {
    const double geo_err = S / static_cast<double>(grid_ - 1);   // cell size (units)
    const double sse = geo_err * px_per_unit_at_1 / dist;        // pixels
    // HYSTERESIS: a single threshold flips split/merge on sub-pixel camera
    // motion, and each flip swaps a whole tile layer. Once split, a node stays
    // split until the error falls well below the threshold.
    const bool was = split_.count(key) > 0;
    split = key.z < maxz_ && (was ? sse > thr * 0.6 : sse > thr);
    // Warm the children BEFORE the camera needs them.
    if (!split && key.z < maxz_ && sse > thr * kPrefetch) {
      for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
          const TileKey c{key.z + 1, key.x * 2 + i, key.y * 2 + j};
          const double cs = c.x * (S * 0.5), cy = c.y * (S * 0.5);
          if (cs < lx_ && cy < ly_ && !tiles_.count(c)) {
            want_.emplace_back(dist + 1e5, c);      // low priority
          }
        }
      }
    }
  }
  // NOTE: no count-based cutoff HERE. The traversal is depth-first in x/y
  // order, so cutting off "when the count is exceeded" starved whatever region
  // happened to be visited LAST — a sharp diagonal boundary of permanent blur
  // on screen. Fairness is handled in tick(): if the leaf count exceeds the
  // budget, the WHOLE screen retries at a coarser threshold.

  const bool loaded = tiles_.count(key) > 0;

  if (split) {
    // All-or-nothing: children append directly; if any child fails, roll the
    // vector back to the mark so this node is drawn INSTEAD (never both).
    const size_t mark = visible->size();
    bool all = true;
    for (int i = 0; i < 2; ++i) {
      for (int j = 0; j < 2; ++j) {
        all &= cover(TileKey{key.z + 1, key.x * 2 + i, key.y * 2 + j}, cam,
                     px_per_unit_at_1, visible, thr);
      }
    }
    if (all) {                                 // children cover it -> use them
      split_.insert(key);
      return true;
    }
    visible->resize(mark);

    // children not ready: draw THIS node instead (never both), keep loading them
    ++leaf_count_;
    if (loaded) {
      visible->push_back(key);
      return true;
    }
    want_.emplace_back(dist, key);             // and we still need ourselves
    return false;
  }

  purgeSplit(key);   // merged: descendants' hysteresis is stale too
  ++leaf_count_;
  if (loaded) {
    visible->push_back(key);
    return true;
  }
  want_.emplace_back(dist, key);
  return false;
}

// Erase a node's split hysteresis together with its split descendants. The
// recursion follows only nodes that were actually in split_, so the cost is
// bounded by the entries removed — and a subtree whose interior was already
// purged stops the walk early (the rare doubly-stranded corner survives one
// extra visit, which is harmless: it just merges one level at a time).
void TerrainTilesDisplay::purgeSplit(const TileKey & key)
{
  if (!split_.erase(key)) {
    return;
  }
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < 2; ++j) {
      purgeSplit(TileKey{key.z + 1, key.x * 2 + i, key.y * 2 + j});
    }
  }
}

void TerrainTilesDisplay::tick()
{
  // The tick counter advances FIRST, before any early return. Every cooldown in
  // this class is expressed as "stamp_ + n", so a stamp that only advances on
  // the path where everything already works makes those cooldowns permanent:
  // the meta fetch set meta_retry_after_ = stamp_ + 20, returned before the
  // increment, and never retried. A tile server that came up late was then
  // never noticed, and only restarting rviz -- which resets stamp_ to 0 --
  // brought the terrain back.
  ++stamp_;

  // Full-map-frame guard: every ~10 s ask terrain_publisher which world is
  // loaded. /ftile/* serves the full-map frame only, so any other
  // world would render the wrong relief under a foreign-frame mission.
  if (world_client_ && stamp_ >= world_poll_stamp_ && rclcpp::ok() &&
      world_client_->service_is_ready())
  {
    world_poll_stamp_ = stamp_ + 200;
    world_client_->get_parameters(
      {"world"},
      [this](std::shared_future<std::vector<rclcpp::Parameter>> fut) {
        // Completion fires on the ROS spin thread; active_world_/world_ok_
        // are read by the GUI-thread tick() — marshal the write there.
        const auto params = fut.get();
        if (params.empty()) {return;}
        const std::string world = params[0].as_string();
        QMetaObject::invokeMethod(this, [this, world]() {
          active_world_ = world;
          world_ok_ = (active_world_ == "full_map" || active_world_ == "none" ||
                       active_world_.empty());
        });
      });
  }
  if (!world_ok_) {
    setStatus(rviz_common::properties::StatusProperty::Error, "Server",
              QString("world '%1' is not full_map — TerrainTiles serves "
                      "the full-map frame only; tiles hidden")
                .arg(QString::fromStdString(active_world_)));
    destroyAll();
    return;
  }
  if (!meta_ok_) {
    fetchMeta();
    return;
  }
  auto * vm = context_->getViewManager();
  auto * view = vm ? vm->getCurrent() : nullptr;
  Ogre::Camera * cam = view ? view->getCamera() : nullptr;
  if (!cam) {
    return;
  }
  // Z exaggeration is baked into the meshes, so a change must rebuild them.
  const float exag = exaggeration_property_->getFloat();
  if (std::abs(exag - last_exag_) > 1e-4f) {
    last_exag_ = exag;
    destroyAll();
    return;
  }
  // Skirt style and culling mode reconcile PER TILE every tick, not on a
  // change-detect: a property flip-flop between two ticks would strand tiles
  // built in the window with the wrong state, and a shadow flag never
  // notices. Cull mode is an in-place material setter; a stale skirt needs a
  // mesh rebuild, trickled at the eviction cap so a toggle doesn't destroy
  // 1500 tiles in one tick.
  {
    const bool adaptive = adaptive_skirt_property_->getBool();
    const Ogre::CullingMode want_cm = backface_property_->getBool() ?
      Ogre::CULL_ANTICLOCKWISE : Ogre::CULL_NONE;
    std::vector<TileKey> stale_skirt;
    for (auto & kv : tiles_) {
      if (kv.second.material &&
        kv.second.material->getTechnique(0)->getPass(0)->getCullingMode() != want_cm)
      {
        kv.second.material->setCullingMode(want_cm);
      }
      if (kv.second.adaptive != adaptive && stale_skirt.size() < 12) {
        stale_skirt.push_back(kv.first);
      }
    }
    for (const auto & k : stale_skirt) {
      destroyTile(k);
    }
  }

  Ogre::Viewport * vp = cam->getViewport();
  const double screen_h = vp ? vp->getActualHeight() : 800.0;
  const double fovy = cam->getFOVy().valueRadians();
  const double px_per_unit_at_1 = screen_h / (2.0 * std::tan(0.5 * fovy));

  QElapsedTimer perf_t;
  perf_t.start();

  want_.clear();

  // Adaptive threshold: refine at the requested Detail; if that wants more
  // leaves than the budget allows, retry the WHOLE screen one notch coarser —
  // everywhere degrades equally instead of starving one region.
  //
  // Three rules keep this from limit-cycling (which it did):
  // 1. The threshold CARRIES ACROSS TICKS instead of resetting to Detail
  //    every tick. Resetting re-ran the whole escalation from scratch each
  //    tick, so near the budget the screen pumped sharp<->coarse at tick rate.
  // 2. It DECAYS toward Detail only with HEADROOM — the previous tick
  //    escalated nothing and demand sat below 90% of budget. Unconditional
  //    decay walked thr straight back below the value that had just failed,
  //    re-split the marginal band, and overflowed again: a ~3 Hz sawtooth.
  //    With the dead-band, thr parks at the lowest value that fits and moves
  //    only when demand actually falls.
  // 3. The escalation factor must beat the split hysteresis: merge happens at
  //    thr*0.6, so a notch of 1.6 gave 1.6*0.6 = 0.96 < 1 — one notch could
  //    NEVER merge an already-split node, and since a loading screen's leaf
  //    demand rises on its own (a split parent standing in for unready
  //    children counts 1 leaf, its loaded children count 4), sharpening
  //    itself pushed demand over budget and forced a very visible 2-notch
  //    (2.56x) coarsen. 1.8*0.6 = 1.08 > 1: one notch sheds leaves.
  // View-motion gate for the failure floor below: "this threshold failed" is
  // only meaningful while the view stands still. Compare against the pose
  // WHERE THE FLOOR WAS SET, not the previous tick — a per-tick baseline let
  // arbitrarily large motion pass unnoticed as long as each 50 ms step
  // stayed under the epsilon (a slow orbit is exactly that), leaving a stale
  // floor to blur a genuinely new view. Micro-jitter stays inside the
  // epsilon ball around the anchor and keeps the floor.
  const Ogre::Vector3 cam_pos = cam->getDerivedPosition();
  const Ogre::Quaternion cam_ori = cam->getDerivedOrientation();
  if (fail_floor_ > 0.0 &&
    ((cam_pos - floor_pos_).length() > 0.1f ||
    std::abs(cam_ori.Dot(floor_ori_)) < 0.99999f))
  {
    fail_floor_ = 0.0;
  }

  const qint64 cover_t0 = perf_t.nsecsElapsed();
  const size_t leaf_budget = static_cast<size_t>(budget_property_->getInt()) / 2;
  std::vector<TileKey> visible;
  const double base_thr = detail_property_->getFloat();
  double thr = base_thr;
  int attempts = 0;
  if (level_property_->getInt() >= 0) {
    // Forced level: cover() ignores thr entirely, so escalating — and
    // STORING the escalated value — would only poison the carried threshold
    // (leaf demand at a forced deep level exceeds any budget, all 6 notches
    // fire every tick, and the carry diverges within seconds). One pass, and
    // the carry resets so auto mode restarts fresh at Detail.
    leaf_count_ = 0;
    visited_ = 0;
    culled_ = 0;
    want_.clear();
    cover(TileKey{0, 0, 0}, cam, px_per_unit_at_1, &visible, thr);
    thr_carry_ = 0.0;
    fail_floor_ = 0.0;
  } else {
    // Decay toward Detail only with HEADROOM (previous tick escalated
    // nothing and demand sat below 90% of budget) AND only while staying
    // clear of the FAILURE FLOOR — the highest threshold that overflowed
    // under this view. Without the floor, decay re-entered the failure zone
    // and re-split the very band that had just overflowed (worst under a
    // straight-down view, where many tiles share nearly the same sse): a
    // slow sawtooth instead of the old fast one. The floor lifts when the
    // camera moves (above) or if demand collapses outright.
    const double proposed = std::max(base_thr, thr_carry_ * 0.9);
    const bool headroom = escalations_ == 0 &&
      leaf_count_ <= leaf_budget - leaf_budget / 10;
    if (leaf_count_ < leaf_budget / 2) {
      fail_floor_ = 0.0;   // demand collapsed: the recorded failure is moot
    }
    const bool clear = proposed >= fail_floor_ * 1.05;
    thr = (headroom && clear) ? proposed : std::max(base_thr, thr_carry_);
    for (;; ++attempts) {
      leaf_count_ = 0;
      visited_ = 0;
      culled_ = 0;
      want_.clear();
      visible.clear();
      cover(TileKey{0, 0, 0}, cam, px_per_unit_at_1, &visible, thr);
      if (leaf_count_ <= leaf_budget) {
        break;
      }
      fail_floor_ = thr;          // this thr was EVALUATED and overflowed...
      floor_pos_ = cam_pos;       // ...at THIS pose (motion-gate anchor)
      floor_ori_ = cam_ori;
      if (attempts >= 5 || thr >= kThrCap) {
        // Best effort: keep the over-budget result at the EVALUATED thr —
        // multiplying once more would store a value cover() never saw, and
        // repeating past the cap would diverge (see kThrCap).
        break;
      }
      thr = std::min(thr * 1.8, kThrCap);
    }
    thr_carry_ = thr;
  }
  escalations_ = attempts;
  std::sort(visible.begin(), visible.end());
  last_visible_ = visible;
  const double cover_ms = (perf_t.nsecsElapsed() - cover_t0) / 1e6;

  // Bootstrap the pinned base pyramid ONCE, regardless of where the camera
  // looks. cover() only ever visits what is in the frustum, so without this a
  // fast turn to an unseen part of the map has no coarse tile to fall back on
  // and the view blinks empty. ~120 tiles, fetched once, kept forever.
  if (!base_ready_) {
    bool all = true;
    for (int z = 0; z <= kPinLevel; ++z) {
      const double S = root_ / static_cast<double>(1 << z);
      const int nx = static_cast<int>(std::ceil(lx_ / S));
      const int ny = static_cast<int>(std::ceil(ly_ / S));
      for (int x = 0; x < std::max(1, nx); ++x) {
        for (int y = 0; y < std::max(1, ny); ++y) {
          const TileKey k{z, x, y};
          if (!tiles_.count(k)) {
            all = false;
            want_.emplace_back(-1e9 + z, k);     // highest priority, shallow first
          }
        }
      }
    }
    base_ready_ = all;
  }

  // Zombie sweep (belt and braces on top of the transfer timeout): anything
  // pending for ~25 s is written off so its slot frees up. The replies are
  // abort()ed — erasing the map entry alone left both sockets occupied AND,
  // worse, the stale reply's finish() later erased the RE-requested tile's
  // fresh pending record, spawning a third fetch (finish() now identity-checks
  // before erasing, and abort-after-erase makes that check see a vacated slot,
  // so a sweep write-off costs no retry cooldown).
  for (auto it = pending_.begin(); it != pending_.end();) {
    if (it->second->stamp + 500 < stamp_) {
      const auto pend = it->second;
      it = pending_.erase(it);
      if (pend->rh) {pend->rh->abort();}
      if (pend->ri) {pend->ri->abort();}
    } else {
      ++it;
    }
  }

  // TELEPORT. A jump leaves every request, arrival and split decision for a
  // position the camera is no longer at. None of that is cancelled today --
  // requests only die in the ~25 s zombie sweep, ready_ is a plain FIFO so
  // those arrivals become meshes FIRST, and the grace period holds the old
  // tiles 8 s -- so the new position loads while competing with work nobody
  // will see. Cancel the stale WORK, and only that: resident tiles are left
  // to the ordinary LRU (its per-tick cap exists because a teardown burst is
  // what corrupts the Mesa swrast heap), and the pinned coarse pyramid is
  // never touched, because it is the only guarantee that something is drawn.
  if (cam) {
    const Ogre::Vector3 p = cam->getDerivedPosition();
    if (teleport_.step(p.x, p.y, p.z)) {
      teleport_stamp_ = stamp_;
      std::set<TileKey> keep(visible.begin(), visible.end());
      for (const auto & w : want_) {keep.insert(w.second);}

      // 1. in-flight requests the new view does not want
      int aborted = 0;
      for (auto it = pending_.begin(); it != pending_.end();) {
        if (it->first.z <= kPinLevel || keep.count(it->first)) {
          ++it;
          continue;
        }
        const auto pend = it->second;
        it = pending_.erase(it);
        if (pend->rh) {pend->rh->abort();}
        if (pend->ri) {pend->ri->abort();}
        ++aborted;
      }

      // 2. arrivals for the old position, and border re-stitches for tiles
      //    that are about to be evicted anyway
      const size_t ready_before = ready_.size();
      std::deque<Ready> keep_ready;
      for (auto & r : ready_) {
        if (r.key.z <= kPinLevel || keep.count(r.key)) {
          keep_ready.push_back(std::move(r));
        } else {
          ready_keys_.erase(r.key);
        }
      }
      ready_ = std::move(keep_ready);
      std::deque<TileKey> keep_stitch;
      for (const auto & k : restitch_) {
        if (k.z <= kPinLevel || keep.count(k)) {
          keep_stitch.push_back(k);
        } else {
          restitch_keys_.erase(k);
        }
      }
      restitch_ = std::move(keep_stitch);

      // 3. carried LOD state describes the view we just left
      thr_carry_ = 0.0;
      fail_floor_ = 0.0;
      for (auto it = split_.begin(); it != split_.end();) {
        it = (it->z <= kPinLevel || keep.count(*it)) ? std::next(it)
                                                         : split_.erase(it);
      }
      retry_after_.clear();   // a cooldown earned somewhere else is not news here

      setStatus(rviz_common::properties::StatusProperty::Ok, "Teleport",
                QString("jump: aborted %1 requests, dropped %2 arrivals, "
                        "kept %3 pinned levels")
                  .arg(aborted).arg(ready_before - ready_.size())
                  .arg(kPinLevel + 1));
    }
  }

  // request, nearest first
  std::sort(want_.begin(), want_.end(),
            [](const auto & a, const auto & b) {return a.first < b.first;});
  // After a jump the queue is empty of everything except the new view, so
  // fetch the COARSE levels first: something sharp appears immediately and
  // refines, instead of the deepest tiles trickling in over a blank base.
  if (teleport_stamp_ == stamp_) {
    order_coarse_then_near(want_);
  }
  int inflight = static_cast<int>(pending_.size());
  for (const auto & w : want_) {
    if (inflight >= kMaxInflight) {
      break;
    }
    if (tiles_.count(w.second) || pending_.count(w.second) ||
        ready_keys_.count(w.second)) {
      continue;
    }
    if (auto it = retry_after_.find(w.second); it != retry_after_.end()) {
      if (stamp_ < it->second) {
        continue;  // failed recently — in cooldown
      }
      retry_after_.erase(it);
    }
    requestTile(w.second);
    ++inflight;
  }

  // visibility
  const qint64 vis_t0 = perf_t.nsecsElapsed();
  for (auto & kv : tiles_) {
    const bool vis = std::binary_search(visible.begin(), visible.end(), kv.first);
    if (vis != kv.second.visible) {
      kv.second.visible = vis;
      if (kv.second.obj) {
        kv.second.obj->setVisible(vis);
      }
    }
    if (vis) {
      kv.second.last_used = stamp_;
      // LOD ring moved across one of this tile's edges? Queue a border
      // re-stitch (budgeted in drain()) so the mesh conforms to what is
      // actually drawn next to it now.
      const uint32_t sig = edgeSig(kv.first);
      if (sig != kv.second.edge_sig &&
        restitch_keys_.insert(kv.first).second)
      {
        restitch_.push_back(kv.first);
      }
    }
  }

  // LRU eviction. A GRACE PERIOD keeps recently-seen tiles resident: dropping a
  // tile the moment it leaves the view means a small camera wobble re-fetches
  // it, which is exactly the churn that makes the picture feel unstable.
  const size_t budget = static_cast<size_t>(budget_property_->getInt());
  if (tiles_.size() > budget) {
    std::vector<std::pair<uint64_t, TileKey>> lru;
    lru.reserve(tiles_.size());
    for (const auto & kv : tiles_) {
      if (kv.first.z <= kPinLevel) {
        continue;                                   // pinned base layer
      }
      if (!kv.second.visible && kv.second.last_used + kGraceTicks < stamp_) {
        lru.emplace_back(kv.second.last_used, kv.first);
      }
    }
    std::sort(lru.begin(), lru.end(),
              [](const auto & a, const auto & b) {return a.first < b.first;});
    // Cap evictions PER TICK. A full-range zoom-out abandons a whole deep
    // subtree at once, so the unbounded drop destroyed hundreds of tiles in
    // one tick — each freeing an Ogre GL vertex buffer + texture. That
    // synchronous teardown burst is what the software GL stack (Mesa swrast)
    // corrupts its heap on, and it left the picture to hitch even elsewhere.
    // Tile creation is already frame-budgeted in drain(); mirror it here so
    // teardown trickles out too. Staying a little over budget for a few
    // frames is harmless (VRAM headroom); the backlog clears within ~1 s.
    constexpr size_t kMaxEvictPerTick = 12;   // 20 Hz tick: same 240/s as before
    size_t to_drop = std::min(tiles_.size() - budget, kMaxEvictPerTick);
    for (const auto & e : lru) {
      if (to_drop-- == 0) {
        break;
      }
      destroyTile(e.second);
    }
  }

  const double vis_ms = (perf_t.nsecsElapsed() - vis_t0) / 1e6;
  const double tick_ms = perf_t.nsecsElapsed() / 1e6;
  tick_ms_sum_ += tick_ms;
  tick_ms_max_ = std::max(tick_ms_max_, tick_ms);
  cover_ms_sum_ += cover_ms;
  cover_ms_max_ = std::max(cover_ms_max_, cover_ms);
  vis_ms_sum_ += vis_ms;
  vis_ms_max_ = std::max(vis_ms_max_, vis_ms);

  // Status flush at ~2 Hz, not tick rate: four strings changing 20x/s are
  // themselves measurable Qt property-tree work, and the numbers are for a
  // human anyway. Perf accumulators cover the whole window; the LOD line
  // samples the flushing tick.
  if (++perf_ticks_ < 10) {
    return;
  }
  setStatus(rviz_common::properties::StatusProperty::Ok, "Tiles",
            QString("drawn %1 | resident %2 | loading %3 | build queue %4")
              .arg(visible.size()).arg(tiles_.size()).arg(pending_.size())
              .arg(ready_.size()));
  // LOD telemetry: effective threshold vs base, budget pressure, traversal and
  // cull counts, and the drawn-tile zoom histogram — enough to tell a texture
  // problem from a refinement-policy problem from a fetch problem at a glance.
  QString zh;
  {
    int zc[16] = {};
    for (const auto & k : visible) {
      if (k.z >= 0 && k.z < 16) {
        ++zc[k.z];
      }
    }
    for (int z = 0; z < 16; ++z) {
      if (zc[z]) {
        zh += QString(" z%1:%2").arg(z).arg(zc[z]);
      }
    }
  }
  setStatus(rviz_common::properties::StatusProperty::Ok, "LOD",
            QString("thr %1%2 (base %3, escalations %4) | leaves %5/%6 | "
                    "visited %7, frustum-culled %8 |%9")
              .arg(thr, 0, 'f', 2)
              .arg(thr >= kThrCap ? QStringLiteral(" px CAP") :
                   QStringLiteral(" px"))
              .arg(base_thr, 0, 'f', 1).arg(attempts)
              .arg(leaf_count_).arg(leaf_budget).arg(visited_).arg(culled_)
              .arg(zh));
  // Actual render measurements from Ogre, windowed to this flush interval:
  // realized fps (the RViz "Frame Rate" cap shows up here), worst frame time
  // in the window, and the draw-call (batch) / triangle load of the whole
  // scene — the direct evidence for or against a per-tile-object bottleneck.
  if (vp && vp->getTarget()) {
    const Ogre::RenderTarget::FrameStats & fs = vp->getTarget()->getStatistics();
    setStatus(rviz_common::properties::StatusProperty::Ok, "Render",
              QString("fps %1 (avg %2) | worst frame %3 ms | "
                      "draw batches %4 | tris %5")
                .arg(fs.lastFPS, 0, 'f', 0).arg(fs.avgFPS, 0, 'f', 0)
                .arg(static_cast<qulonglong>(fs.worstFrameTime))
                .arg(static_cast<qulonglong>(fs.batchCount))
                .arg(static_cast<qulonglong>(fs.triangleCount)));
    // Machine-readable telemetry for automated runs (MMP_TILES_PERF=1):
    // the same numbers, greppable from the process stderr / launch log.
    static const bool perf_log = qEnvironmentVariableIsSet("MMP_TILES_PERF");
    if (perf_log) {
      fprintf(
        stderr,
        "[tiles-perf] fps %.0f avg %.0f worst_ms %lu batches %zu tris %zu | "
        "thr %.2f esc %d leaves %zu drawn %zu queue %zu loading %zu | "
        "tick %.2f/%.2f cover %.2f/%.2f vis %.2f/%.2f build %.2f/%.2f n %llu\n",
        static_cast<double>(fs.lastFPS), static_cast<double>(fs.avgFPS),
        fs.worstFrameTime, fs.batchCount, fs.triangleCount,
        thr, attempts, leaf_count_, visible.size(), ready_.size(),
        pending_.size(),
        tick_ms_sum_ / perf_ticks_, tick_ms_max_,
        cover_ms_sum_ / perf_ticks_, cover_ms_max_,
        vis_ms_sum_ / perf_ticks_, vis_ms_max_,
        build_count_ ? build_ms_sum_ / build_count_ : 0.0, build_ms_max_,
        static_cast<unsigned long long>(build_count_));
    }
    // Reset only every 10th flush (5 s window): Ogre recomputes lastFPS/avgFPS
    // once per second, so the previous every-flush (0.5 s) reset starved that
    // boundary and the fps fields read 0 forever. worstFrameTime is therefore
    // the worst over the last <=5 s.
    if (++stat_resets_ >= 10) {
      stat_resets_ = 0;
      vp->getTarget()->resetStatistics();
    }
  }
  const double n = static_cast<double>(perf_ticks_);
  setStatus(rviz_common::properties::StatusProperty::Ok, "Timing",
            QString("tick avg %1 / max %2 ms (cover %3/%4, vis+evict %5/%6) "
                    "| build avg %7 / max %8 ms over %9 tiles")
              .arg(tick_ms_sum_ / n, 0, 'f', 2).arg(tick_ms_max_, 0, 'f', 2)
              .arg(cover_ms_sum_ / n, 0, 'f', 2).arg(cover_ms_max_, 0, 'f', 2)
              .arg(vis_ms_sum_ / n, 0, 'f', 2).arg(vis_ms_max_, 0, 'f', 2)
              .arg(build_count_ ? build_ms_sum_ / build_count_ : 0.0, 0, 'f', 2)
              .arg(build_ms_max_, 0, 'f', 2)
              .arg(build_count_));
  perf_ticks_ = 0;
  tick_ms_sum_ = tick_ms_max_ = 0.0;
  cover_ms_sum_ = cover_ms_max_ = 0.0;
  vis_ms_sum_ = vis_ms_max_ = 0.0;
  build_ms_sum_ = build_ms_max_ = 0.0;
  build_count_ = 0;
}

// Budgeted asset preparation: decode + mesh at most a couple of tiles per
// frame, and stop early once ~8 ms are spent. The GPU renders whatever is
// already resident without interruption; new tiles trickle in smoothly instead
// of freezing the UI thread when a burst of replies lands.
void TerrainTilesDisplay::drain()
{
  // BOTH queues must gate this early-out: the ready_-only guard predated the
  // restitch queue, and a tick that enqueued ONLY re-stitches (the common
  // case — children finish loading, then NEXT tick their neighbours' sigs
  // change) hit it and starved the queue until some unrelated fetch landed,
  // leaving wrong seams standing indefinitely under a static camera.
  if (ready_.empty() && restitch_.empty()) {
    return;
  }
  QElapsedTimer t;
  t.start();
  int built = 0;
  // The ELAPSED budget is what protects frame pacing; the count cap is only a
  // sanity bound. (It was 2, which throttled fill to ~2 tiles per GUI turn —
  // minutes to sharpen a 4K view.) The guard runs BEFORE each build and a
  // build is ~1-3 ms on a GPU box, so the worst turn is budget + one build;
  // at the old 8 ms that overran into ~11 of the 16.7 ms a 60 fps frame has —
  // this drain shares the GUI thread with Ogre's renderer, so that overrun IS
  // the streaming stutter. 5 ms keeps the worst turn under half a frame.
  // Border re-stitches run FIRST: they are the visible seam being wrong RIGHT
  // NOW on an already-shown tile (a fresh build is merely missing detail).
  // Mesh-only (stored heights, existing texture — no decode), ~1 ms each.
  while (!restitch_.empty() && t.elapsed() < 3) {
    const TileKey key = restitch_.front();
    restitch_.pop_front();
    restitch_keys_.erase(key);
    auto it = tiles_.find(key);
    if (it == tiles_.end()) {
      continue;
    }
    const uint32_t sig = edgeSig(key);
    if (sig == it->second.edge_sig) {
      continue;
    }
    try {
      buildMesh(key, it->second, sig);
    } catch (const std::exception & e) {
      setStatus(rviz_common::properties::StatusProperty::Warn, "Build",
                QString("tile %1 restitch failed: %2")
                  .arg(QString::fromStdString(key.str())).arg(e.what()));
    }
  }

  while (!ready_.empty() && built < 12 && t.elapsed() < 5) {
    Ready r = std::move(ready_.front());
    ready_.pop_front();
    ready_keys_.erase(r.key);
    // drain() is a raw QTimer slot: an Ogre exception escaping here unwinds
    // through the Qt event loop and aborts rviz. Today's build path is proven
    // exception-free, but that rests on invariants (mip count == Ogre's own
    // clamp) no compiler enforces — shield the loop, skip the tile instead.
    const qint64 build_t0 = t.nsecsElapsed();
    try {
      buildTile(r.key, r.hgt, r.img);
    } catch (const std::exception & e) {
      // Sweep up whatever the failed build already registered — the ids are
      // deterministic, so leftovers would make every retry throw
      // ItemIdentityException forever — and back the tile off like a fetch
      // failure (its fetch SUCCEEDED, so the fetch cooldown never engages).
      const std::string id =
        "mmp_ftile_" + std::to_string(instance_id_) + "_" + r.key.str();
      if (scene_manager_->hasManualObject(id + "_obj")) {
        auto * obj = scene_manager_->getManualObject(id + "_obj");
        obj->detachFromParent();
        scene_manager_->destroyManualObject(obj);
      }
      if (auto mat = Ogre::MaterialManager::getSingleton().getByName(
          id + "_mat", kResourceGroup))
      {
        Ogre::MaterialManager::getSingleton().remove(mat);
      }
      if (auto tex = Ogre::TextureManager::getSingleton().getByName(
          id + "_tex", kResourceGroup))
      {
        Ogre::TextureManager::getSingleton().remove(tex);
      }
      retry_after_[r.key] = stamp_ + 100;
      setStatus(rviz_common::properties::StatusProperty::Warn, "Build",
                QString("tile %1 build failed: %2")
                  .arg(QString::fromStdString(r.key.str())).arg(e.what()));
    }
    const double build_ms = (t.nsecsElapsed() - build_t0) / 1e6;
    build_ms_sum_ += build_ms;
    build_ms_max_ = std::max(build_ms_max_, build_ms);
    ++build_count_;
    ++built;
  }

}

void TerrainTilesDisplay::requestTile(const TileKey & key)
{
  auto pend = std::make_shared<Pending>();
  pend->stamp = stamp_;
  pending_[key] = pend;
  const QString base = url_property_->getString();
  const QString zxy =
    QString("/%1/%2/%3").arg(key.z).arg(key.x).arg(key.y);

  auto finish = [this, key, pend]() {
      if (!pend->hgt_done || !pend->img_done) {
        return;
      }
      // Identity check: only the CURRENT pending record for this key may
      // retire it. A zombie-swept request's reply used to erase the fresh
      // re-request's record here, so the next tick fired a THIRD pair.
      auto it = pending_.find(key);
      const bool current = it != pending_.end() && it->second.get() == pend.get();
      if (current) {
        pending_.erase(it);
      }
      if (!pend->failed) {
        retry_after_.erase(key);
        // Guard against a duplicate already queued or already built (two
        // in-flight requests for the same key can both land here).
        if (!tiles_.count(key) && ready_keys_.insert(key).second) {
          ready_.push_back(Ready{key, pend->hgt, pend->img});
        }
      } else if (current) {
        // ~5 s cooldown (100 ticks) before this tile may be re-requested —
        // failure is otherwise forgotten instantly and the 50 ms tick
        // re-fires every wanted tile against a down server forever.
        retry_after_[key] = stamp_ + 100;
      }
    };

  // BOTH halves of the pair go through the SAME manager: splitting them
  // across managers let one half queue behind strangers, and the tile
  // completes only when the slower half lands.
  const int ni = pickNam();
  nam_load_[ni] += 2;
  QNetworkAccessManager * m = nams_[ni];
  QNetworkRequest req_h(QUrl(base + "/ftile/hgt" + zxy));
  // No default timeout in Qt: a request caught mid-server-restart waits
  // FOREVER on its half-open socket. Enough of those exhaust kMaxInflight and
  // the display silently stops fetching — half the screen stays blurred no
  // matter how long you wait. 15 s covers a cold-cache server cut.
  req_h.setTransferTimeout(15000);
  QNetworkReply * rh = m->get(req_h);
  pend->rh = rh;
  connect(rh, &QNetworkReply::finished, this, [this, ni, rh, pend, finish]() {
      --nam_load_[ni];
      pend->rh = nullptr;         // sweep must not abort a dead pointer
      rh->deleteLater();
      pend->hgt_done = true;
      if (rh->error() != QNetworkReply::NoError) {
        pend->failed = true;
      } else {
        pend->hgt = rh->readAll();
      }
      finish();
    });
  QNetworkRequest req_i(QUrl(base + "/ftile/img" + zxy + ".png"));
  req_i.setTransferTimeout(15000);
  QNetworkReply * ri = m->get(req_i);
  pend->ri = ri;
  connect(ri, &QNetworkReply::finished, this, [this, ni, ri, pend, finish]() {
      --nam_load_[ni];
      pend->ri = nullptr;
      ri->deleteLater();
      pend->img_done = true;
      if (ri->error() != QNetworkReply::NoError) {
        pend->failed = true;
      } else {
        pend->img = ri->readAll();
      }
      finish();
    });
}

void TerrainTilesDisplay::buildTile(
  const TileKey & key, const QByteArray & hgt, const QByteArray & img)
{
  const int G = grid_;
  if (hgt.size() != static_cast<int>(sizeof(float)) * G * G) {
    return;
  }
  // [SMASH-RESOLVED 2026-07-20] The long-hunted intermittent RViz stack-smash
  // was isolated to Qt 5.15.3's QImage decode path itself: a minimal console
  // loop (fromData + convertToFormat over cached tiles, NO RViz/Ogre) crashes
  // 13-43% of runs with JPEG and 16/30 with the SAME tiles re-encoded as PNG
  // (format-independent -> not the jpeg/png handler), while direct
  // libjpeg-turbo (tjDecompress2) over the identical files is 0/30 clean.
  // glibc chunk metadata gets corrupted and a later free() aborts ("stack
  // smashing detected" via free's fortified helper). MALLOC_PERTURB_
  // amplifies (up to 100%), MALLOC_CHECK_=3 suppresses; ASan/valgrind/gdb all
  // mask it (allocator/layout sensitivity). Fix: bypass QImage entirely —
  // decode with turbojpeg straight into the RGBA buffer Ogre blits from.
  // (QImage was only ever a decode vehicle here; PixelBox wants raw bytes.)
  int tw = 0, th = 0, tsub = 0, tcs = 0;
  std::vector<unsigned char> rgba;
  {
    tjhandle tj = tjInitDecompress();
    if (!tj) {
      return;
    }
    // 1024 cap, not 8192: the server contract is 256^2 and the decode + mip
    // chain + uploads below run unbudgeted on the GUI thread — an 8192^2
    // payload would freeze rviz for hundreds of ms per tile. Anything over
    // 1024 is a broken or hostile server, not a tile.
    bool ok =
      tjDecompressHeader3(
        tj, reinterpret_cast<const unsigned char *>(img.constData()),
        static_cast<unsigned long>(img.size()), &tw, &th, &tsub, &tcs) == 0 &&
      tw > 0 && th > 0 && tw <= 1024 && th <= 1024;
    if (ok) {
      rgba.resize(static_cast<size_t>(tw) * th * 4);
      ok = tjDecompress2(
        tj, reinterpret_cast<const unsigned char *>(img.constData()),
        static_cast<unsigned long>(img.size()), rgba.data(), tw, 0, th,
        TJPF_RGBA, 0) == 0;
    }
    tjDestroy(tj);
    if (!ok) {
      // Server emits JPEG only; a payload turbojpeg cannot parse is a bad
      // fetch — skip the tile rather than fall back into the buggy Qt path.
      return;
    }
  }
  if (tiles_.count(key)) {
    return;
  }

  const std::string id =
    "mmp_ftile_" + std::to_string(instance_id_) + "_" + key.str();

  Tile tile;
  // A full mip chain, built HERE on the CPU and uploaded level by level.
  // Without mips, ground at grazing angles minifies the full-res texture per
  // fragment and the whole terrain shimmers. TU_AUTOMIPMAP was tried first,
  // but Ogre's GL path implements it with the deprecated GL_GENERATE_MIPMAP
  // texparam, which a driver may silently ignore — leaving the allocated mip
  // levels unfilled and the shimmer intact. A 2x2 box chain for a 256^2 RGBA
  // tile is ~87k pixels of arithmetic: cheaper than one JPEG decode, and it
  // works identically on every GL stack.
  int mips = 0;
  for (int m = std::max(tw, th); m > 1; m >>= 1) {
    ++mips;
  }
  tile.texture = Ogre::TextureManager::getSingleton().createManual(
    id + "_tex", kResourceGroup, Ogre::TEX_TYPE_2D,
    tw, th, mips, Ogre::PF_A8B8G8R8,
    Ogre::TU_STATIC_WRITE_ONLY);
  {
    // Upload via blitFromMemory (Ogre owns pitch/format conversion). The
    // source is the turbojpeg-decoded RGBA buffer — byte order R,G,B,A,
    // matching PF_A8B8G8R8 on little-endian exactly like the old
    // QImage::Format_RGBA8888 bits did.
    const Ogre::PixelBox src(tw, th, 1, Ogre::PF_A8B8G8R8, rgba.data());
    tile.texture->getBuffer(0, 0)->blitFromMemory(src);
    // Level 1 reads straight from rgba (no full-size copy); deeper levels
    // ping-pong between two small buffers.
    std::vector<unsigned char> bufa, bufb;
    const unsigned char * curp = rgba.data();
    int cw = tw, ch = th;
    for (int level = 1; level <= mips; ++level) {
      const int nw = std::max(1, cw >> 1), nh = std::max(1, ch >> 1);
      std::vector<unsigned char> & nxt = (level % 2) ? bufa : bufb;
      nxt.resize(static_cast<size_t>(nw) * nh * 4);
      for (int y = 0; y < nh; ++y) {
        const int y0 = std::min(2 * y, ch - 1), y1 = std::min(2 * y + 1, ch - 1);
        for (int x = 0; x < nw; ++x) {
          const int x0 = std::min(2 * x, cw - 1), x1 = std::min(2 * x + 1, cw - 1);
          const unsigned char * a = &curp[(static_cast<size_t>(y0) * cw + x0) * 4];
          const unsigned char * b = &curp[(static_cast<size_t>(y0) * cw + x1) * 4];
          const unsigned char * c = &curp[(static_cast<size_t>(y1) * cw + x0) * 4];
          const unsigned char * d = &curp[(static_cast<size_t>(y1) * cw + x1) * 4];
          unsigned char * o = &nxt[(static_cast<size_t>(y) * nw + x) * 4];
          for (int k = 0; k < 4; ++k) {
            o[k] = static_cast<unsigned char>((a[k] + b[k] + c[k] + d[k] + 2) >> 2);
          }
        }
      }
      const Ogre::PixelBox mip(nw, nh, 1, Ogre::PF_A8B8G8R8, nxt.data());
      tile.texture->getBuffer(0, level)->blitFromMemory(mip);
      curp = nxt.data();
      cw = nw;
      ch = nh;
    }
  }

  tile.material = Ogre::MaterialManager::getSingleton().create(id + "_mat", kResourceGroup);
  Ogre::Pass * pass = tile.material->getTechnique(0)->getPass(0);
  pass->setLightingEnabled(false);
  Ogre::TextureUnitState * tu = pass->createTextureUnitState(id + "_tex");
  tu->setTextureAddressingMode(Ogre::TextureUnitState::TAM_CLAMP);
  // trilinear across the mip chain + anisotropy for the oblique ground
  // plane; without this the mip chain above would still pop and smear
  tu->setTextureFiltering(Ogre::TFO_ANISOTROPIC);
  tu->setTextureAnisotropy(8);
  // This mesh is wound opposite to Ogre's default convention (its top reads
  // CLOCKWISE from above), so the usable culling mode is ANTICLOCKWISE — the
  // default CULL_CLOCKWISE would erase the whole terrain. The skirt emission
  // below flips two of its four edges so all outward faces agree with it.
  tile.material->setCullingMode(
    backface_property_->getBool() ? Ogre::CULL_ANTICLOCKWISE : Ogre::CULL_NONE);

  tile.hgt = hgt;
  buildMesh(key, tile, edgeSig(key));
  tile.last_used = stamp_;
  tiles_[key] = tile;
}

// 4 bits per edge (-x, +x, -y, +y): depth of the coarser neighbour DRAWN
// across that edge in the last cover() pass. Levels are independently
// resampled from the source DEM (a parent is NOT a decimation of its
// children — measured mismatches up to ~270 m), so at every LOD ring the two
// surfaces genuinely disagree along the shared border: the gap flickers as
// skirt-textured teeth exactly at the block edges. The fix is to pull this
// tile's border vertices onto the drawn neighbour's actual surface.
uint32_t TerrainTilesDisplay::edgeSig(const TileKey & key) const
{
  uint32_t sig = 0;
  for (int e = 0; e < 4; ++e) {
    const int nx = key.x + (e == 1 ? 1 : 0) - (e == 0 ? 1 : 0);
    const int ny = key.y + (e == 3 ? 1 : 0) - (e == 2 ? 1 : 0);
    if (nx < 0 || ny < 0) {
      continue;
    }
    const TileKey nk{key.z, nx, ny};
    if (std::binary_search(last_visible_.begin(), last_visible_.end(), nk)) {
      // Same level drawn: shared lattice, seamless by construction — mark it
      // (0xF) so the skirt on this edge can be a sliver instead of a wall.
      sig |= 0xFu << (e * 4);
      continue;
    }
    for (int d = 1; d <= 4 && d <= key.z; ++d) {
      const TileKey ak{key.z - d, nx >> d, ny >> d};
      if (std::binary_search(last_visible_.begin(), last_visible_.end(), ak)) {
        sig |= static_cast<uint32_t>(d) << (e * 4);
        break;
      }
    }
    // Neighbour drawn finer (its children conform to us from their side) or
    // not drawn at all (frustum-culled: no visible seam) -> 0.
  }
  // Corner bits: a drawn same-level DIAGONAL participates in the 4-way
  // corner rule (border_stitch.hpp), so its appearance must change the sig
  // and re-trigger a stitch exactly like an edge neighbour's.
  for (int c = 0; c < 4; ++c) {
    const int dx = (c & 1) ? 1 : -1;
    const int dy = (c & 2) ? 1 : -1;
    if (key.x + dx < 0 || key.y + dy < 0) {
      continue;
    }
    const TileKey dk{key.z, key.x + dx, key.y + dy};
    if (std::binary_search(last_visible_.begin(), last_visible_.end(), dk)) {
      sig |= 1u << (16 + c);
    }
  }
  return sig;
}

void TerrainTilesDisplay::buildMesh(const TileKey & key, Tile & tile, uint32_t sig)
{
  const int G = grid_;
  if (tile.hgt.size() != static_cast<int>(sizeof(float)) * G * G) {
    return;
  }
  const std::string id =
    "mmp_ftile_" + std::to_string(instance_id_) + "_" + key.str();
  if (tile.obj) {          // re-stitch: replace the mesh, keep texture/material
    tile.obj->detachFromParent();
    scene_manager_->destroyManualObject(tile.obj);
    tile.obj = nullptr;
  }

  // Conformed height copy: for each edge with a drawn coarser neighbour,
  // sample THAT tile's actual border heights (its hgt is resident — drawn
  // implies resident) at our vertex positions and overwrite ours. The two
  // surfaces then meet exactly; the skirt only has rounding left to hide.
  // Quadtree exclusivity guarantees the shared border is also an edge line
  // of the ancestor tile, so only its border row/col is ever sampled.
  const auto * h0 = reinterpret_cast<const float *>(tile.hgt.constData());
  std::vector<float> hc(h0, h0 + G * G);
  // Same-level borders first — canonical edge averaging and the 4-way corner
  // rule, RAW inputs only (see border_stitch.hpp for why: independently
  // warped tiles disagree along shared borders by up to ~134 m, and a
  // hc-based, order-dependent average left 42-43% of four-tile corners
  // mismatched — pinholes exactly at tile corners). The ancestor conform
  // below runs AFTER and overwrites its own edges: a coarser neighbour's
  // surface owns the border wherever one is drawn.
  float same_diff_m[4];
  {
    const auto nb = [&](int dx, int dy) -> border_stitch::Neighbor {
        border_stitch::Neighbor n;
        const int nx = key.x + dx, ny = key.y + dy;
        if (nx < 0 || ny < 0) {
          return n;
        }
        const TileKey nk{key.z, nx, ny};
        n.drawn = std::binary_search(
          last_visible_.begin(), last_visible_.end(), nk);
        auto it = tiles_.find(nk);
        if (it != tiles_.end() &&
          it->second.hgt.size() == static_cast<int>(sizeof(float)) * G * G)
        {
          n.raw = reinterpret_cast<const float *>(it->second.hgt.constData());
        }
        return n;
      };
    border_stitch::apply_same_level(hc, h0, G, sig, nb, same_diff_m);
  }
  // Coarser-neighbour edges: conform onto the ancestor's actual surface
  // (border_stitch::apply_coarser; pure, gtest-pinned). Runs AFTER the
  // same-level pass so a coarser neighbour owns any border it touches.
  {
    const auto anc = [&](int nx, int ny, int d) -> const float * {
        const TileKey ak{key.z - d, nx >> d, ny >> d};
        auto ait = tiles_.find(ak);
        if (ait == tiles_.end() ||
          ait->second.hgt.size() != static_cast<int>(sizeof(float)) * G * G)
        {
          return static_cast<const float *>(nullptr);
        }
        return reinterpret_cast<const float *>(ait->second.hgt.constData());
      };
    border_stitch::apply_coarser(hc, G, key.x, key.y, sig, anc);
  }
  const float * h = hc.data();

  const double span = root_ / static_cast<double>(1 << key.z);
  const double x0 = key.x * span, y0 = key.y * span;
  const double step = span / static_cast<double>(G - 1);
  const float exag = exaggeration_property_->getFloat();
  const float zs = 0.01f * exag;                    // metres -> frame units
  // Skirt depth. The legacy constant (3% of span) is 788 m at z8 — measured
  // LOD cracks against the real parent tiles (16k-tile sample of this very
  // cache) never exceeded 481 m, with medians ~12x smaller, so the constant
  // painted huge streaked curtains at every LOD seam, worst on flat coastal
  // tiles where the crack is ~0. The adaptive form covers 99.94% of measured
  // cracks from the tile's own border ring: 2x the steepest border step +
  // 10% of the border relief + 10 m, capped at the legacy value (never
  // deeper than before). Heights are metres here; *0.01 converts to units.
  const float legacy_skirt = static_cast<float>(span) * 0.03f * exag + 0.2f;
  float skirt = legacy_skirt;
  tile.adaptive = adaptive_skirt_property_->getBool();
  if (tile.adaptive) {
    float bmin = h[0], bmax = h[0], maxstep = 0.0f;
    const auto scan = [&](auto at) {
        float prev = at(0);
        for (int k = 0; k < G; ++k) {
          const float v = at(k);
          bmin = std::min(bmin, v);
          bmax = std::max(bmax, v);
          maxstep = std::max(maxstep, std::abs(v - prev));
          prev = v;
        }
      };
    scan([&](int k) {return h[k];});                        // i = 0
    scan([&](int k) {return h[(G - 1) * G + k];});          // i = G-1
    scan([&](int k) {return h[k * G];});                    // j = 0
    scan([&](int k) {return h[k * G + (G - 1)];});          // j = G-1
    skirt = std::min(
      (2.0f * maxstep + 0.1f * (bmax - bmin)) * 0.01f * exag + 0.1f, skirt);
    if (!std::isfinite(skirt)) {
      skirt = legacy_skirt;   // NaN heights must not poison the mesh
    }
  }
  // Per-edge depth. A coarser-conformed border meets the ancestor's surface
  // EXACTLY -> 15 m sliver. A same-level border was just AVERAGED with the
  // neighbour's raw data, but until the neighbour's own re-stitch lands the
  // visible crack is half the measured raw difference -> skirt sized from
  // that measurement (floor 15 m), typically ~15-40 m instead of a wall.
  // Only an edge facing UNDRAWN area (off-frustum/off-map, where no seam can
  // be seen anyway) keeps the deep data-driven depth for the moment its
  // neighbour first appears.
  float skirt_e[4];
  for (int e = 0; e < 4; ++e) {
    const int dd = (sig >> (e * 4)) & 0xF;
    if (dd == 0) {
      skirt_e[e] = skirt;
    } else if (dd == 0xF) {
      skirt_e[e] = std::max(0.15f, 0.6f * same_diff_m[e] * 0.01f) * exag;
    } else {
      skirt_e[e] = 0.15f * exag;
    }
  }

  tile.obj = scene_manager_->createManualObject(id + "_obj");
  tile.obj->estimateVertexCount(G * G + 4 * G);
  tile.obj->estimateIndexCount(((G - 1) * (G - 1) + 4 * (G - 1)) * 6);
  tile.obj->begin(id + "_mat", Ogre::RenderOperation::OT_TRIANGLE_LIST, kResourceGroup);
  // grid vertices: index(i,j) = i*G + j; array row i = wx ascending,
  // column j = wy ascending — exactly how the server writes both payloads.
  for (int i = 0; i < G; ++i) {
    for (int j = 0; j < G; ++j) {
      tile.obj->position(
        static_cast<Ogre::Real>(x0 + i * step),
        static_cast<Ogre::Real>(y0 + j * step),
        h[i * G + j] * zs);
      tile.obj->textureCoord(
        static_cast<Ogre::Real>(j) / (G - 1),
        static_cast<Ogre::Real>(i) / (G - 1));
    }
  }
  for (int i = 0; i + 1 < G; ++i) {
    for (int j = 0; j + 1 < G; ++j) {
      const int a = i * G + j;
      tile.obj->quad(a, a + 1, a + G + 1, a + G);
    }
  }
  // Skirts: duplicate each border vertex pulled down by `skirt`, then stitch a
  // quad strip. Hides the cracks where neighbouring tiles have another level.
  // `flip` reverses the quad cycle on the two edges whose natural winding
  // faces INTO the tile (proved from the emission order: the skirt normal is
  // -s*delta*(d_hat x z_hat), height terms cancel) so that, together with the
  // clockwise-from-above top, every outward face survives CULL_ANTICLOCKWISE.
  // Under CULL_NONE the flip renders identically — lighting is disabled.
  int next = G * G;
  const auto edge = [&](auto index_of, bool flip, float sk) {
      const int first = next;
      for (int k = 0; k < G; ++k) {
        const int src = index_of(k);
        const int i = src / G, j = src % G;
        tile.obj->position(
          static_cast<Ogre::Real>(x0 + i * step),
          static_cast<Ogre::Real>(y0 + j * step),
          h[src] * zs - sk);
        tile.obj->textureCoord(
          static_cast<Ogre::Real>(j) / (G - 1),
          static_cast<Ogre::Real>(i) / (G - 1));
        ++next;
      }
      for (int k = 0; k + 1 < G; ++k) {
        if (flip) {
          tile.obj->quad(first + k, first + k + 1, index_of(k + 1), index_of(k));
        } else {
          tile.obj->quad(index_of(k), index_of(k + 1), first + k + 1, first + k);
        }
      }
    };
  edge([G](int k) {return k;}, true, skirt_e[0]);                    // i = 0
  edge([G](int k) {return (G - 1) * G + k;}, false, skirt_e[1]);     // i = G-1
  edge([G](int k) {return k * G;}, false, skirt_e[2]);               // j = 0
  edge([G](int k) {return k * G + (G - 1);}, true, skirt_e[3]);      // j = G-1
  tile.obj->end();

  // Fresh builds start hidden (tick() decides; avoids a 1-frame flash); a
  // re-stitch of an already-shown tile must stay shown — a hidden frame at
  // an LOD seam is exactly the flicker this rebuild exists to remove.
  tile.obj->setVisible(tile.visible);
  scene_node_->attachObject(tile.obj);
  tile.edge_sig = sig;
}

void TerrainTilesDisplay::destroyTile(const TileKey & key)
{
  auto it = tiles_.find(key);
  if (it == tiles_.end()) {
    return;
  }
  Tile & t = it->second;
  if (t.obj) {
    t.obj->detachFromParent();
    scene_manager_->destroyManualObject(t.obj);
  }
  if (t.material) {
    Ogre::MaterialManager::getSingleton().remove(t.material);
  }
  if (t.texture) {
    Ogre::TextureManager::getSingleton().remove(t.texture);
  }
  tiles_.erase(it);
}

void TerrainTilesDisplay::destroyAll()
{
  while (!tiles_.empty()) {
    destroyTile(tiles_.begin()->first);
  }
  // Vacate the map BEFORE aborting: abort() fires the finished lambdas, whose
  // finish() then sees no current record — no cooldown, no ready_ insert (the
  // abort marks the pend failed). Skipping the abort left up to 48 orphaned
  // requests holding every socket while the rebuild tried to refetch.
  {
    auto pending = std::move(pending_);
    pending_.clear();
    for (auto & kv : pending) {
      if (kv.second->rh) {kv.second->rh->abort();}
      if (kv.second->ri) {kv.second->ri->abort();}
    }
  }
  retry_after_.clear();
  ready_.clear();
  ready_keys_.clear();
  want_.clear();
  split_.clear();
  last_visible_.clear();
  restitch_.clear();
  restitch_keys_.clear();
  base_ready_ = false;
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::TerrainTilesDisplay, rviz_common::Display)

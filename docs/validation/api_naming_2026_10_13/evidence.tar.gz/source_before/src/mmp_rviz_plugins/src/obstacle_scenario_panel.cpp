#include "mmp_rviz_plugins/obstacle_scenario_panel.hpp"

#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QHBoxLayout>


#include "yaml-cpp/yaml.h"

namespace {
// Browse opens this subdirectory by default (obstacles + risk zones).
QString scenarioDir()
{
  // Source tree, not the install share: data is no longer installed (see
  // mmp_terrain/setup.py) — the source dir is the single authority. Workspace
  // root from MMP_WS, container default /ws.
  const QString ws = qEnvironmentVariable("MMP_WS", QStringLiteral("/ws"));
  const QString src = ws + QStringLiteral("/src/mmp_terrain/data/scenarios/obstacles");
  if (QDir(src).exists()) return src;
  return QString();
}
}  // namespace

namespace mmp_rviz_plugins
{

ObstacleScenarioPanel::ObstacleScenarioPanel(QWidget * parent)
: rviz_common::Panel(parent)
{
  auto * root = new QVBoxLayout(this);

  auto * file_row = new QHBoxLayout();
  file_path_edit_ = new QLineEdit(this);
  file_path_edit_->setPlaceholderText("scenario.yaml (obstacles + risk_zones)");
  browse_button_ = new QPushButton("Browse...", this);
  file_row->addWidget(file_path_edit_);
  file_row->addWidget(browse_button_);
  root->addLayout(file_row);

  // The radio drives BOTH arrays' `replace` flag (obstacles and risk zones).
  auto * mode_box = new QGroupBox("Append/Replace (obstacles + risk zones)", this);
  auto * mode_row = new QHBoxLayout(mode_box);
  append_radio_  = new QRadioButton("Append",  mode_box);
  replace_radio_ = new QRadioButton("Replace", mode_box);
  replace_radio_->setChecked(true);
  mode_row->addWidget(append_radio_);
  mode_row->addWidget(replace_radio_);
  root->addWidget(mode_box);

  auto * action_row = new QHBoxLayout();
  load_button_  = new QPushButton("Load (obstacles + risk zones)", this);
  clear_button_ = new QPushButton("Clear dynamic obstacles", this);
  action_row->addWidget(load_button_);
  action_row->addWidget(clear_button_);
  root->addLayout(action_row);

  status_label_ = new QLabel("", this);
  status_label_->setWordWrap(true);
  root->addWidget(status_label_);

  connect(browse_button_, &QPushButton::clicked,
          this, &ObstacleScenarioPanel::onBrowseClicked);
  connect(load_button_, &QPushButton::clicked,
          this, &ObstacleScenarioPanel::onLoadClicked);
  connect(clear_button_, &QPushButton::clicked,
          this, &ObstacleScenarioPanel::onClearClicked);
}

void ObstacleScenarioPanel::onInitialize()
{
  node_ = getDisplayContext()
            ->getRosNodeAbstraction()
            .lock()
            ->get_raw_node();

  // transient_local on BOTH load publishers: a late-joining subscriber (RViz
  // metrics panel, a planner restarted after the scenario was loaded, and
  // terrain_publisher's corridor-coverage mirror) still receives the last
  // published set. The obstacle publisher shipped VOLATILE for months, which
  // made it QoS-INCOMPATIBLE with terrain_publisher's transient-local
  // subscription — the corridor crop never enclosed a single obstacle, with
  // no warning (a TL subscriber simply never matches a volatile writer).
  load_pub_ = node_->create_publisher<mmp_mission_msgs::msg::DynamicObstacleArray>(
      "/mission/obstacles", rclcpp::QoS(1).reliable().transient_local());
  risk_zones_pub_ = node_->create_publisher<mmp_mission_msgs::msg::RiskZoneArray>(
      "/mission/risk_zones", rclcpp::QoS(1).reliable().transient_local());
}

void ObstacleScenarioPanel::onBrowseClicked()
{
  QString start_dir = file_path_edit_->text();
  if (start_dir.isEmpty() || !QFileInfo(start_dir).exists()) {
    start_dir = scenarioDir();
  }
  const QString path = QFileDialog::getOpenFileName(
      this, "Select scenario YAML", start_dir,
      "YAML files (*.yaml *.yml)");
  if (!path.isEmpty()) {
    file_path_edit_->setText(path);
  }
}

void ObstacleScenarioPanel::onLoadClicked()
{
  const std::string path = file_path_edit_->text().toStdString();
  if (path.empty()) {
    setStatus("No file selected", /*error=*/true);
    return;
  }

  ParsedScenario sc;
  std::string err;
  if (!parseYaml(path, sc, err)) {
    setStatus(QString::fromStdString("Parse error: " + err), /*error=*/true);
    return;
  }

  // One radio, one meaning: RiskZoneArray gained `replace` so Append no
  // longer silently drops the zones a previous Load installed.
  sc.obstacles.replace = replace_radio_->isChecked();
  sc.risk_zones.replace = sc.obstacles.replace;

  // Race-safe publish order: risk_zones first (planner installs the
  // soft cost field), then dynamic obstacles. Both subscribers share
  // the same MutuallyExclusive callback group, so FIFO is preserved.
  risk_zones_pub_->publish(sc.risk_zones);
  load_pub_->publish(sc.obstacles);

  QFileInfo info(QString::fromStdString(path));
  setStatus(
      QString("Loaded '%1': %2 risk zones + %3 dynamic obstacles (%4)")
          .arg(info.baseName())
          .arg(sc.risk_zones.zones.size())
          .arg(sc.obstacles.obstacles.size())
          .arg(sc.obstacles.replace ? "Replace" : "Append"),
      /*error=*/false);
}

void ObstacleScenarioPanel::onClearClicked()
{
  // Uniform clear verb: an EMPTY array with replace=true on the same latched
  // topic the Load button uses. The separate /dynamic_obstacles/clear
  // std_msgs/Empty topic was retired with the move to mmp_mission_msgs —
  // one topic per layer, so the latched state a late joiner sees is the
  // cleared state instead of the last loaded set.
  mmp_mission_msgs::msg::DynamicObstacleArray empty_obstacles;
  empty_obstacles.replace = true;

  // Also clear risk zones so the visualization and planner stay in sync.
  mmp_mission_msgs::msg::RiskZoneArray empty_zones;
  empty_zones.replace = true;

  // Same order as Load: zones first, then obstacles.
  risk_zones_pub_->publish(empty_zones);
  load_pub_->publish(empty_obstacles);

  setStatus("Cleared dynamic obstacles and risk zones", /*error=*/false);
}

bool ObstacleScenarioPanel::parseYaml(
    const std::string & file_path,
    ParsedScenario & out,
    std::string & err) const
{
  try {
    YAML::Node root = YAML::LoadFile(file_path);

    // === Dynamic obstacles (V3) — sphere (round) or box (axis-aligned) ===
    auto parseObsSeq = [&out, &err](const YAML::Node &seq) -> bool {
      for (const auto &node : seq) {
        const std::string type = node["type"]
          ? node["type"].as<std::string>() : "";
        if (type != "sphere" && type != "box") continue;
        const auto center = node["center"];
        if (!center || !center.IsSequence() || center.size() != 3) {
          err = type + " entry missing center [x,y,z]";
          return false;
        }
        // Scenario-yaml unit convention (same as MissionConfigPanel's
        // z_to_units): xy positions are FRAME UNITS, z and physical
        // dimensions are METRES — the frame is isotropic at 1 unit = 100 m,
        // so the conversion is a fixed /100. This conversion was MISSING
        // here: the planner consumed "size: [50, 160, 70]" (a 50x160x70 m
        // ship) as frame units and dodged a 5x16x7 KM block — 100x oversized
        // keep-outs, exposed the moment the altitude panel grew an obstacle
        // overlay and drew the slabs the planner actually believes in.
        constexpr double kMetresToUnits = 0.01;
        mmp_mission_msgs::msg::DynamicObstacleSpec spec;
        spec.center.x = center[0].as<double>();
        spec.center.y = center[1].as<double>();
        spec.center.z = center[2].as<double>() * kMetresToUnits;
        if (type == "box") {
          // box: collision (SDF kCube) == visual bbox. size = full extents [sx,sy,sz].
          const auto size = node["size"];
          if (!size || !size.IsSequence() || size.size() != 3) {
            err = "box entry missing size [sx,sy,sz]";
            return false;
          }
          const double sx = size[0].as<double>();
          const double sy = size[1].as<double>();
          const double sz = size[2].as<double>();
          if (sx <= 0.0 || sy <= 0.0 || sz <= 0.0) {
            err = "box entry has non-positive size";
            return false;
          }
          spec.kind = mmp_mission_msgs::msg::DynamicObstacleSpec::KIND_CUBE;
          spec.size.x = sx * kMetresToUnits;
          spec.size.y = sy * kMetresToUnits;
          spec.size.z = sz * kMetresToUnits;
        } else {  // sphere
          const double r = node["radius"]
            ? node["radius"].as<double>() : 0.0;
          if (r <= 0.0) {
            err = "sphere entry has non-positive radius";
            return false;
          }
          spec.kind = mmp_mission_msgs::msg::DynamicObstacleSpec::KIND_SPHERE;
          spec.radius = r * kMetresToUnits;
        }
        // Optional visual model name (catalog key, e.g. "building", "car").
        spec.model = node["model"] ? node["model"].as<std::string>() : "";
        out.obstacles.obstacles.push_back(spec);
      }
      return true;
    };

    if (root["dynamic_obstacles"] && root["dynamic_obstacles"].IsSequence()) {
      if (!parseObsSeq(root["dynamic_obstacles"])) return false;
    }

    // === Risk zones (V3 soft cost field) ===
    // Two accepted forms:
    //   1) flat array: risk_zones: [cx,cy,cz,reach,peak, ...]
    //   2) sequence of maps: risk_zones: [{center:[...], reach:..., peak:...}]
    if (root["risk_zones"] && root["risk_zones"].IsSequence()) {
      const auto &seq = root["risk_zones"];
      if (seq.size() > 0 && seq[0].IsScalar()) {
        if (seq.size() % 5 != 0) {
          err = "risk_zones flat array length must be a multiple of 5";
          return false;
        }
        for (size_t i = 0; i < seq.size(); i += 5) {
          mmp_mission_msgs::msg::RiskZoneSpec z;
          z.center.x = seq[i + 0].as<double>();
          z.center.y = seq[i + 1].as<double>();
          z.center.z = seq[i + 2].as<double>();
          z.reach    = seq[i + 3].as<double>();
          // Raw max_risk_level (scenario yamls use 90-150): the shared moat
          // cap (1-1e-3) at field level is the single saturation authority.
          // Clamping here silently rewrote the file semantics to peak=1.
          z.peak     = seq[i + 4].as<double>();
          if (z.reach > 0.0 && z.peak > 0.0) {
            out.risk_zones.zones.push_back(z);
          }
        }
      } else {
        for (const auto &node : seq) {
          const auto c = node["center"];
          if (!c || !c.IsSequence() || c.size() != 3) {
            err = "risk_zones entry needs center [x,y,z]";
            return false;
          }
          mmp_mission_msgs::msg::RiskZoneSpec z;
          z.center.x = c[0].as<double>();
          z.center.y = c[1].as<double>();
          z.center.z = c[2].as<double>();
          z.reach = node["reach"] ? node["reach"].as<double>() : 0.0;
          z.peak  = node["peak"]  ? node["peak"].as<double>() : 0.0;  // raw, see above
          if (z.reach > 0.0 && z.peak > 0.0) {
            out.risk_zones.zones.push_back(z);
          }
        }
      }
    }

    return true;
  } catch (const YAML::Exception & e) {
    err = e.what();
    return false;
  } catch (const std::exception & e) {
    err = e.what();
    return false;
  }
}

void ObstacleScenarioPanel::setStatus(const QString & text, bool error)
{
  status_label_->setText(text);
  status_label_->setStyleSheet(error ? "color: red;" : "color: black;");
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(
    mmp_rviz_plugins::ObstacleScenarioPanel, rviz_common::Panel)

#include "mmp_rviz_plugins/map_selector_panel.hpp"

#include <QCoreApplication>
#include "rviz_rendering/mesh_loader.hpp"
#include <QPointer>
#include <QEventLoop>
#include <QHBoxLayout>
#include <QVBoxLayout>

#include <signal.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <future>

namespace mmp_rviz_plugins
{

namespace
{
constexpr const char * kBaseLaunchCmd =
    "ros2 launch path_manager rviz_path_manager.launch.py";
constexpr int kForceKillDelayMs = 3000;
constexpr int kPollIntervalMs = 500;
constexpr int kWorldFetchTimeoutMs = 500;
}  // namespace

MapSelectorPanel::MapSelectorPanel(QWidget * parent)
: rviz_common::Panel(parent)
{
  QVBoxLayout * main_layout = new QVBoxLayout;

  QLabel * title_label = new QLabel("MMP Control Panel");
  QFont title_font = title_label->font();
  title_font.setPointSize(12);
  title_font.setBold(true);
  title_label->setFont(title_font);
  main_layout->addWidget(title_label);

  // ===== Section 2: Path planner launch =====
  main_layout->addWidget(new QLabel("Path Planner Launch:"));
  auto * button_row = new QHBoxLayout;
  start_button_ = new QPushButton("▶ Start");
  stop_button_  = new QPushButton("■ Stop");
  stop_button_->setEnabled(false);
  button_row->addWidget(start_button_);
  button_row->addWidget(stop_button_);
  main_layout->addLayout(button_row);
  launch_status_label_ = new QLabel("");
  launch_status_label_->setWordWrap(true);
  main_layout->addWidget(launch_status_label_);

  main_layout->addStretch();
  setLayout(main_layout);

  // Timers (launch section)
  poll_timer_ = new QTimer(this);
  poll_timer_->setInterval(500);
  connect(poll_timer_, &QTimer::timeout, this, &MapSelectorPanel::onPollProcess);
  force_kill_timer_ = new QTimer(this);
  force_kill_timer_->setSingleShot(true);
  force_kill_timer_->setInterval(3000);
  connect(force_kill_timer_, &QTimer::timeout,
          this, &MapSelectorPanel::onForceKillIfStillRunning);

  connect(start_button_, &QPushButton::clicked,
          this, &MapSelectorPanel::onStartClicked);
  connect(stop_button_, &QPushButton::clicked,
          this, &MapSelectorPanel::onStopClicked);

  setLaunchState(LaunchState::NotRunning);
}

MapSelectorPanel::~MapSelectorPanel()
{
  // Don't leave orphaned launch trees behind when RViz closes.
  if (child_pgid_ > 0) {
    sendSignal(SIGINT);
    for (int i = 0; i < 30; ++i) {
      int status;
      if (waitpid(child_pgid_, &status, WNOHANG) != 0) break;
      usleep(100 * 1000);
    }
    sendSignal(SIGKILL);
    waitpid(child_pgid_, nullptr, 0);
  }
}

void MapSelectorPanel::onInitialize()
{
  // Get the ROS node from the parent
  auto rviz_ros_node = getDisplayContext()->getRosNodeAbstraction();
  node_ = rviz_ros_node.lock()->get_raw_node();

  // Pre-warm the obstacle mesh cache. Mesh markers arriving mid-session ran
  // assimp + GL buffer/texture creation INTERLEAVED with terrain-tile bursts
  // — the exact window where a roaming heap corruption kept striking (stack
  // canary in an innocent GL lockImpl; deep-dive 2026-07-16). Loading them
  // once now, in a quiet heap/GL state, removes that window entirely
  // (loadMeshFromResource caches forever; later marker loads are no-ops).
  for (const char * mesh : {"package://mmp_viz_assets/meshes/building.dae",
                            "package://mmp_viz_assets/meshes/car.dae",
                            "package://mmp_viz_assets/meshes/simple_ship.dae",
                            "package://mmp_viz_assets/meshes/drone.obj"}) {
    if (!rviz_rendering::loadMeshFromResource(mesh)) {
      RCLCPP_WARN(node_->get_logger(), "mesh prewarm failed: %s", mesh);
    }
  }
}

// =========================================================================
// Path planner launch control (formerly LaunchControlPanel).
// Forks `ros2 launch path_manager rviz_path_manager.launch.py` with its own
// session/pgid so signals don't leak in either direction; PR_SET_PDEATHSIG
// guarantees the launch tree dies if RViz dies before we can call Stop.
// =========================================================================

void MapSelectorPanel::onStartClicked()
{
  if (launch_state_ == LaunchState::Running || launch_state_ == LaunchState::Stopping) return;

  const std::string world = fetchCurrentWorld();
  std::string launch_cmd = kBaseLaunchCmd;
  if (!world.empty()) {
    launch_cmd += " world:=" + world;
  }

  if (!spawnLaunch(launch_cmd)) {
    setLaunchState(LaunchState::Crashed, "fork/exec failed; see RViz terminal for errno");
    return;
  }
  setLaunchState(LaunchState::Running,
                 QString("running (pgid %1)%2")
                   .arg(child_pgid_)
                   .arg(world.empty() ? "" : QString(" — world=%1").arg(QString::fromStdString(world))));
  poll_timer_->start();
}

void MapSelectorPanel::onStopClicked()
{
  if (launch_state_ != LaunchState::Running) return;
  sendSignal(SIGINT);
  setLaunchState(LaunchState::Stopping, "SIGINT sent, waiting for graceful exit...");
  force_kill_timer_->start();
}

bool MapSelectorPanel::spawnLaunch(const std::string & launch_cmd)
{
  pid_t pid = fork();
  if (pid < 0) return false;

  if (pid == 0) {
    // prctl before setsid so the trigger is tied to the original parent
    // (RViz), not the new session leader (ourselves). Race guard: if RViz
    // already died between fork() and now, prctl can't help — bail.
    prctl(PR_SET_PDEATHSIG, SIGTERM);
    if (getppid() == 1) _exit(0);
    setsid();

    // Wrap the launch in a bash trap so that *if RViz dies without going
    // through our Stop button*, we don't just kill ourselves and leave the
    // grandchildren (ros2 launch's node processes) orphaned to init. The
    // trap nukes the whole process group, including all those grandchildren.
    // Graceful shutdown via the Stop button (SIGINT) still flows through
    // ros2 launch normally — this only fires on SIGTERM from PR_SET_PDEATHSIG.
    //
    // Run the launch in the background and `wait`, NOT `exec`: bash must stay
    // resident (exec would replace it and drop the trap) and must be sitting in
    // an interruptible wait so the queued TERM trap can actually fire.
    const std::string wrapped =
        "trap 'kill -KILL -$$' TERM; " + launch_cmd + " & wait";
    execlp("bash", "bash", "-c", wrapped.c_str(), static_cast<char *>(nullptr));
    _exit(127);
  }

  child_pgid_ = pid;
  return true;
}

void MapSelectorPanel::sendSignal(int sig)
{
  if (child_pgid_ <= 0) return;
  if (::kill(-child_pgid_, sig) != 0 && errno != ESRCH) {
    launch_status_label_->setText(
      QString("kill(%1) failed: %2").arg(sig).arg(std::strerror(errno)));
  }
}

void MapSelectorPanel::onPollProcess()
{
  if (child_pgid_ <= 0) return;
  int status = 0;
  pid_t r = waitpid(child_pgid_, &status, WNOHANG);
  if (r == 0) return;
  if (r < 0 && errno != ECHILD) return;

  poll_timer_->stop();
  force_kill_timer_->stop();
  const pid_t pgid_was = child_pgid_;
  child_pgid_ = -1;

  if (launch_state_ == LaunchState::Stopping) {
    setLaunchState(LaunchState::NotRunning, QString("stopped (pgid %1)").arg(pgid_was));
    return;
  }
  if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
    setLaunchState(LaunchState::NotRunning, "exited cleanly");
  } else if (WIFSIGNALED(status)) {
    setLaunchState(LaunchState::Crashed,
                   QString("killed by signal %1").arg(WTERMSIG(status)));
  } else {
    setLaunchState(LaunchState::Crashed,
                   QString("exit code %1").arg(WEXITSTATUS(status)));
  }
}

void MapSelectorPanel::onForceKillIfStillRunning()
{
  if (child_pgid_ <= 0) return;
  launch_status_label_->setText("SIGINT didn't shut it down; sending SIGKILL");
  sendSignal(SIGKILL);
}

std::string MapSelectorPanel::fetchCurrentWorld()
{
  if (!node_) return {};
  auto pc = std::make_shared<rclcpp::AsyncParametersClient>(node_, "/terrain_publisher");
  if (!pc->service_is_ready()) {
    RCLCPP_WARN(node_->get_logger(),
                "/terrain_publisher parameter service not ready; "
                "launching without world override");
    return {};
  }
  auto future = pc->get_parameters({"world"});
  using clock = std::chrono::steady_clock;
  const auto deadline = clock::now() + std::chrono::milliseconds(kWorldFetchTimeoutMs);
  // Pumping the event loop here keeps the ROS executor turning (the reply
  // arrives on a GUI-thread event), but AllEvents also delivers USER INPUT —
  // and rviz_common deletes custom panels with a plain `delete` from two
  // user-reachable actions (File->Open Config: loadPanels(); Panels->Delete
  // Panel: onDeletePanel()). Either one lands mid-pump, frees `this`, and the
  // rest of onStartClicked() writes through the dangling pointer. Excluding
  // user input makes both paths unreachable; the QPointer is a second fence
  // in case some future rviz deletes panels from a non-input event.
  QPointer<MapSelectorPanel> self(this);
  while (clock::now() < deadline) {
    if (future.wait_for(std::chrono::milliseconds(0)) == std::future_status::ready) break;
    QCoreApplication::processEvents(QEventLoop::ExcludeUserInputEvents, 20);
    if (!self) return {};
  }
  if (future.wait_for(std::chrono::milliseconds(0)) != std::future_status::ready) {
    RCLCPP_WARN(node_->get_logger(),
                "Timed out fetching /terrain_publisher.world; "
                "launching without world override");
    return {};
  }
  auto params = future.get();
  if (params.empty() || params[0].get_type() != rclcpp::ParameterType::PARAMETER_STRING) {
    return {};
  }
  return params[0].as_string();
}

void MapSelectorPanel::setLaunchState(LaunchState s, const QString & detail)
{
  launch_state_ = s;
  QString text;
  QString color;
  switch (s) {
    case LaunchState::NotRunning:
      text  = detail.isEmpty() ? "not running" : "not running — " + detail;
      color = "gray";
      start_button_->setEnabled(true);
      stop_button_->setEnabled(false);
      break;
    case LaunchState::Running:
      text  = detail.isEmpty() ? "running" : detail;
      color = "green";
      start_button_->setEnabled(false);
      stop_button_->setEnabled(true);
      break;
    case LaunchState::Stopping:
      text  = detail.isEmpty() ? "stopping..." : detail;
      color = "orange";
      start_button_->setEnabled(false);
      stop_button_->setEnabled(false);
      break;
    case LaunchState::Crashed:
      text  = detail.isEmpty() ? "crashed" : "crashed — " + detail;
      color = "red";
      start_button_->setEnabled(true);
      stop_button_->setEnabled(false);
      break;
  }
  launch_status_label_->setText(text);
  launch_status_label_->setStyleSheet(QString("QLabel { color : %1; }").arg(color));
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::MapSelectorPanel, rviz_common::Panel)

#include "mmp_rviz_plugins/mission_command.hpp"

namespace mmp_rviz_plugins
{

std::string missionIdFor(const ParsedMission & m, int sequence)
{
  // stem 이 비어도(파일 없이 구성한 미션) sequence 가 Run 마다 다르므로 id 도
  // 다르다. 사람이 읽을 절반이 없을 뿐이다.
  return m.yaml_stem + "#" + std::to_string(sequence);
}

mmp_mission_msgs::msg::TrajectoryCommand buildTrajectoryCommand(
  const ParsedMission & m, int sequence)
{
  // No header: TrajectoryCommand dropped it (and target_velocity /
  // min_flight_altitude) in the mmp_mission_msgs move — all three were
  // write-only on the wire. `sequence` is the ordering authority.
  mmp_mission_msgs::msg::TrajectoryCommand cmd;
  cmd.drone_id = 0;
  cmd.sequence = sequence;
  cmd.mission_id = missionIdFor(m, sequence);

  // The yaml z is real metres; the planner/terrain frame is ISOTROPIC with
  // 1 unit = 100 m on every axis (publisher z-scale bug fixed), so the
  // conversion is a fixed /100 — no terrain-resolution compensation.
  const double z_to_units = 0.01;
  cmd.start_position  = m.start;
  cmd.target_position = m.goal;
  cmd.start_position.z  *= z_to_units;
  cmd.target_position.z *= z_to_units;

  cmd.waypoints.clear();
  for (auto wp : m.waypoints) {
    wp.z *= z_to_units;
    cmd.waypoints.push_back(wp);
  }
  cmd.waypoints.push_back(cmd.target_position);

  cmd.formation_type = m.formation_type;
  cmd.formation_scale = m.formation_scale;
  cmd.formation_offset.x = 0.0;
  cmd.formation_offset.y = 0.0;
  cmd.formation_offset.z = 0.0;

  geometry_msgs::msg::Point pattern_point;
  pattern_point.x = 0.0;
  pattern_point.y = 0.0;
  pattern_point.z = 0.0;
  cmd.formation_pattern.push_back(pattern_point);

  // 0 = "use the planner's yaml value" (replan_fsm only overrides when > 0).
  // A hardcoded 1.0 here silently shrank MINCO pieces 6x: the corner-adaptive
  // densifier then emitted 1200+ inner points and the optimizer could only
  // trace the shortcut polyline (zigzag and all) instead of smoothing it.
  // (min_flight_altitude is no longer on the wire — the planner yaml owns it.)
  cmd.length_per_piece   = 0.0;
  cmd.obstacle_clearance = 0.0;
  cmd.initial_speed = m.initial_speed_mps;
  cmd.use_initial_speed = m.use_initial_speed;
  cmd.use_initial_velocity = m.use_initial_velocity;
  cmd.initial_velocity = m.initial_velocity_mps;
  cmd.use_initial_acceleration = m.use_initial_acceleration;
  cmd.initial_acceleration = m.initial_acceleration_mps2;
  cmd.use_final_velocity = m.use_final_velocity;
  cmd.final_velocity = m.final_velocity_mps;
  cmd.use_final_acceleration = m.use_final_acceleration;
  cmd.final_acceleration = m.final_acceleration_mps2;

  return cmd;
}

ParsedMission fromResolved(
  const mmp_mission_msgs::msg::ResolvedMission & r,
  const std::string & yaml_stem)
{
  ParsedMission m;
  m.start = r.start;
  m.goal = r.goal;
  m.waypoints.assign(r.waypoints.begin(), r.waypoints.end());
  m.formation_type = r.formation_type;
  m.formation_scale = r.formation_scale;
  m.initial_speed_mps = r.initial_speed_mps;
  m.use_initial_speed = r.use_initial_speed;
  m.use_initial_velocity = r.use_initial_velocity;
  m.initial_velocity_mps = r.initial_velocity_mps;
  m.use_initial_acceleration = r.use_initial_acceleration;
  m.initial_acceleration_mps2 = r.initial_acceleration_mps2;
  m.use_final_velocity = r.use_final_velocity;
  m.final_velocity_mps = r.final_velocity_mps;
  m.use_final_acceleration = r.use_final_acceleration;
  m.final_acceleration_mps2 = r.final_acceleration_mps2;
  // Ignored-vector notices travel as response warning strings now; the flag
  // is not reconstructed by re-parsing them (fragile reverse coupling).
  m.ignored_velocity_vector = false;
  m.yaml_stem = yaml_stem;
  return m;
}

ResponseGate gateResolvedResponse(
  const mmp_mission_msgs::srv::LoadMap::Response & resp,
  const std::string & expected_token,
  const std::string & expected_sha256_hex,
  int request_generation,
  int current_generation)
{
  if (request_generation != current_generation) {
    return ResponseGate::kSelectionChanged;
  }
  if (resp.request_token != expected_token) {
    return ResponseGate::kStaleToken;
  }
  if (!resp.mission_resolved) {
    return ResponseGate::kNotResolved;
  }
  if (resp.mission.mission_sha256 != expected_sha256_hex) {
    return ResponseGate::kShaMismatch;
  }
  if (!(resp.actual_resolution_m > 0.0)) {
    return ResponseGate::kNoGeometry;
  }
  return ResponseGate::kAccept;
}

}  // namespace mmp_rviz_plugins

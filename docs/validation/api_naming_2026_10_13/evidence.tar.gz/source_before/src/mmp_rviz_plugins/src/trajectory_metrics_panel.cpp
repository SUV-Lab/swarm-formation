#include "mmp_rviz_plugins/trajectory_metrics_panel.hpp"

#include "mmp_rviz_plugins/dyn_param_map.hpp"

#include <QVBoxLayout>
#include <QHeaderView>
#include <QFont>
#include <QBrush>
#include <QTimer>
#include <mmp_traj_utils/poly_traj.hpp>
#include <cmath>
#include <algorithm>
#include <limits>

namespace mmp_rviz_plugins
{

// Grid cell size in meters. Trajectory/obstacle xy are in grid units.
// Keep in sync with TARGET_CELL_SIZE_M in mmp_terrain/terrain_publisher.py.
static constexpr double GRID_CELL_SIZE_M = 100.0;

// The dynamics row uses the shared fixed-wing inverse model. Parameters are
// live-synced from the planner so optimization, audit logs, and RViz evaluate
// the same raw (unmargined) flight envelope.

namespace
{

constexpr int kDynamicObstacleSource = 1;
constexpr double kRiskProfileMatchToleranceM = 10.0;

int64_t obstacleKey(int source, int id)
{
  return (static_cast<int64_t>(source) << 32) |
         static_cast<uint32_t>(id);
}

QString formatDuration(double seconds)
{
  if (!std::isfinite(seconds) || seconds < 0.0) {
    return QStringLiteral("—");
  }
  if (seconds < 60.0) {
    return QString::number(seconds, 'f', seconds < 10.0 ? 2 : 1) + " s";
  }
  const int hours = static_cast<int>(seconds / 3600.0);
  seconds -= 3600.0 * hours;
  const int minutes = static_cast<int>(seconds / 60.0);
  seconds -= 60.0 * minutes;
  if (hours > 0) {
    return QString("%1 h %2 min %3 s")
      .arg(hours)
      .arg(minutes)
      .arg(seconds, 0, 'f', 1);
  }
  return QString("%1 min %2 s")
    .arg(minutes)
    .arg(seconds, 0, 'f', 1);
}

QString formatDistance(double meters)
{
  if (!std::isfinite(meters)) {
    return QStringLiteral("—");
  }
  if (std::abs(meters) >= 1000.0) {
    return QString::number(meters / 1000.0, 'f', 2) + " km";
  }
  return QString::number(meters, 'f', 1) + " m";
}

QString formatShare(double part, double total)
{
  const double pct = total > 1e-9 ? 100.0 * part / total : 0.0;
  return QString::number(pct, 'f', 2) + "%";
}

bool segmentIntersectsObstacle(
  const Eigen::Vector3d & world_a,
  const Eigen::Vector3d & world_b,
  const ObstacleGeom & obstacle)
{
  const double c = std::cos(obstacle.yaw);
  const double s = std::sin(obstacle.yaw);
  auto to_local = [&](const Eigen::Vector3d & p) {
    const double dx = p.x() - obstacle.cx;
    const double dy = p.y() - obstacle.cy;
    return Eigen::Vector3d(
      c * dx + s * dy,
      -s * dx + c * dy,
      p.z() - obstacle.cz);
  };
  const Eigen::Vector3d a = to_local(world_a);
  const Eigen::Vector3d b = to_local(world_b);
  const Eigen::Vector3d d = b - a;

  double t_lo = 0.0;
  double t_hi = 1.0;
  auto intersect_slab = [&](double p0, double dp, double half) {
    if (!std::isfinite(half)) {
      return true;
    }
    if (half <= 0.0) {
      return false;
    }
    if (std::abs(dp) < 1e-12) {
      return std::abs(p0) <= half;
    }
    double enter = (-half - p0) / dp;
    double leave = (half - p0) / dp;
    if (enter > leave) {
      std::swap(enter, leave);
    }
    t_lo = std::max(t_lo, enter);
    t_hi = std::min(t_hi, leave);
    return t_lo <= t_hi;
  };

  const double hz = obstacle.sz > 1e-9
    ? 0.5 * obstacle.sz
    : std::numeric_limits<double>::infinity();
  if (!intersect_slab(a.z(), d.z(), hz)) {
    return false;
  }

  if (obstacle.shape == ObstacleGeom::RECT) {
    return intersect_slab(a.x(), d.x(), 0.5 * obstacle.sx) &&
           intersect_slab(a.y(), d.y(), 0.5 * obstacle.sy);
  }

  const double rx = 0.5 * obstacle.sx;
  const double ry = 0.5 * obstacle.sy;
  if (rx <= 0.0 || ry <= 0.0) {
    return false;
  }
  const double ax = a.x() / rx;
  const double ay = a.y() / ry;
  const double dx = d.x() / rx;
  const double dy = d.y() / ry;
  const double qa = dx * dx + dy * dy;
  const double qb = 2.0 * (ax * dx + ay * dy);
  const double qc = ax * ax + ay * ay - 1.0;
  if (qa < 1e-12) {
    return qc <= 0.0 && t_lo <= t_hi;
  }
  const double disc = qb * qb - 4.0 * qa * qc;
  if (disc < 0.0) {
    return qc <= 0.0 && t_lo <= t_hi;
  }
  const double root = std::sqrt(std::max(0.0, disc));
  double enter = (-qb - root) / (2.0 * qa);
  double leave = (-qb + root) / (2.0 * qa);
  if (enter > leave) {
    std::swap(enter, leave);
  }
  t_lo = std::max(t_lo, enter);
  t_hi = std::min(t_hi, leave);
  return t_lo <= t_hi;
}

}  // namespace

TrajectoryMetricsPanel::TrajectoryMetricsPanel(QWidget * parent)
: rviz_common::Panel(parent)
{
  auto * layout = new QVBoxLayout;

  title_label_ = new QLabel("Trajectory Metrics");
  QFont f = title_label_->font();
  f.setPointSize(12);
  f.setBold(true);
  title_label_->setFont(f);
  layout->addWidget(title_label_);

  table_ = new QTableWidget(this);
  table_->setColumnCount(3);
  QStringList headers; headers << "Metric" << "Value" << "Note";
  table_->setHorizontalHeaderLabels(headers);
  table_->verticalHeader()->setVisible(false);
  table_->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
  table_->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
  table_->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
  table_->setEditTriggers(QAbstractItemView::NoEditTriggers);
  table_->setSelectionMode(QAbstractItemView::NoSelection);
  table_->setFocusPolicy(Qt::NoFocus);
  table_->setAlternatingRowColors(true);

  // Rows:
  //   0 trajectory distance
  //   1 flight time
  //   2 intersected obstacles        (unique 3-D collision volumes)
  //   3 time in nominal risk regions (union of planner ellipsoids)
  //   4 distance in risk regions     (3-D arc length in that union)
  //   5 maximum penetration depth    (horizontal-radius-equivalent depth)
  //   6 risk-weighted path length    (authoritative effective ∫ r ds)
  //   7 peak flight-limit usage      (maximum raw-limit ratio)
  //   8 flight-limit violation time  (cruise-domain duration and fraction)
  //   9 minimum terrain clearance    (trajectory altitude minus DEM)
  table_->setRowCount(10);
  setRow(0, "Trajectory Length", "—", "waiting for /planning/trajectory");
  setRow(1, "Flight Duration", "—", "");
  setRow(2, "Intersected Obstacles", "—", "");
  setRow(3, "Time Inside Risk Zones", "—", "");
  setRow(4, "Distance Inside Risk Zones", "—", "");
  setRow(5, "Maximum Risk-Zone Penetration", "—", "");
  setRow(6, "Risk-Weighted Path Length", "—", "");
  setRow(7, "Peak Flight-Limit Usage", "—", "");
  setRow(8, "Flight-Limit Violation Time", "—", "");
  setRow(9, "Minimum Terrain Clearance", "—", "waiting for /terrain/grid_map");

  layout->addWidget(table_, 1);
  setLayout(layout);
}

TrajectoryMetricsPanel::~TrajectoryMetricsPanel()
{
  // Tear down the rclcpp entities we registered on rviz's SHARED node BEFORE
  // that node is destroyed. dyn_param_timer_ is a wall timer registered in the
  // node's default CallbackGroup; if it (and the subs/param-client) outlive the
  // panel without being cancelled, rclcpp::CallbackGroup::~CallbackGroup walks
  // a dangling entity at shutdown and SIGSEGVs (VisualizerApp -> Node dtor).
  // Verified: stock rviz quits clean 6/6, this config crashed until this reset.
  if (dyn_param_timer_) {
    dyn_param_timer_->cancel();
    dyn_param_timer_.reset();
  }
  dyn_param_client_.reset();
  trajectory_sub_.reset();
  dynamic_obstacle_sub_.reset();
  risk_sub_.reset();
  risk_profile_sub_.reset();
  grid_map_sub_.reset();
}

void TrajectoryMetricsPanel::setRow(int row, const QString & name, const QString & value,
                                    const QString & note, const QColor & value_color)
{
  auto * name_item  = new QTableWidgetItem(name);
  auto * value_item = new QTableWidgetItem(value);
  auto * note_item  = new QTableWidgetItem(note);

  value_item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
  if (value_color.isValid()) {
    value_item->setForeground(QBrush(value_color));
  }
  QFont mono = value_item->font();
  mono.setFamily("Monospace");
  value_item->setFont(mono);

  table_->setItem(row, 0, name_item);
  table_->setItem(row, 1, value_item);
  table_->setItem(row, 2, note_item);
}

void TrajectoryMetricsPanel::onInitialize()
{
  auto rviz_ros_node = getDisplayContext()->getRosNodeAbstraction();
  node_ = rviz_ros_node.lock()->get_raw_node();

  // PolyTraj contract (mmp_traj_msgs/msg/PolyTraj.msg): RELIABLE +
  // TRANSIENT_LOCAL, published once per plan and latched — match it exactly,
  // a best-effort sub gets nothing from a reliable publisher.
  trajectory_sub_ = node_->create_subscription<mmp_traj_msgs::msg::PolyTraj>(
    "/planning/trajectory",
    rclcpp::QoS(5).reliable().transient_local(),
    std::bind(&TrajectoryMetricsPanel::trajectoryCallback, this, std::placeholders::_1));

  // Runtime scenario objects arrive as a full MarkerArray whose invisible
  // *_geom markers carry the exact collision boxes (the visible mesh scales
  // cannot be decoded).
  dynamic_obstacle_sub_ =
    node_->create_subscription<visualization_msgs::msg::MarkerArray>(
      "/viz/dynamic_obstacles",
      rclcpp::QoS(1).reliable().transient_local(),
      std::bind(
        &TrajectoryMetricsPanel::dynamicObstacleArrayCallback, this,
        std::placeholders::_1));

  // Authoritative risk geometry (incl. peak/reach) — the /risk_field
  // markers only carry a sphere radius, not the moat peak, so subscribe
  // to the same RiskZoneArray that planning consumes.
  risk_sub_ = node_->create_subscription<mmp_mission_msgs::msg::RiskZoneArray>(
    "/mission/risk_zones",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&TrajectoryMetricsPanel::riskZoneArrayCallback, this, std::placeholders::_1));
  risk_profile_sub_ =
    node_->create_subscription<std_msgs::msg::Float64MultiArray>(
      "/viz/risk_profile",
      rclcpp::QoS(1).reliable().transient_local(),
      std::bind(
        &TrajectoryMetricsPanel::riskProfileCallback, this,
        std::placeholders::_1));

  // Terrain DEM for the clearance metric — same latched grid_map the altitude
  // panel consumes (transient_local so we get it even if published before us).
  grid_map_sub_ = node_->create_subscription<grid_map_msgs::msg::GridMap>(
    "/terrain/grid_map",
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&TrajectoryMetricsPanel::gridMapCallback, this, std::placeholders::_1));

  // Live-sync the fixed-wing parameters from the planner node so the
  // envelope grading (row 7) follows optimizer_params.yaml instead of a
  // hand-mirrored constant. Retries every 10 s: covers the planner starting
  // after RViz AND picks up parameter changes between missions.
  dyn_param_client_ = std::make_shared<rclcpp::AsyncParametersClient>(
      node_, "/replan_fsm_drone_0");
  dyn_param_timer_ = node_->create_wall_timer(
      std::chrono::seconds(10), [this]() { fetchDynParams(); });
  fetchDynParams();

  RCLCPP_INFO(node_->get_logger(),
    "TrajectoryMetricsPanel initialized (trajectory, runtime obstacles, "
    "risk geometry/profile, terrain)");
}

void TrajectoryMetricsPanel::fetchDynParams()
{
  // rclcpp::ok(): the retry QTimer outlives rclcpp shutdown on Ctrl-C; ROS
  // calls on a dead context throw out of a Qt slot -> std::terminate.
  if (!rclcpp::ok() || !dyn_param_client_ || !dyn_param_client_->service_is_ready()) {
    return;  // planner not up yet; the 10 s timer retries
  }
  // The planner declares optimization/* only when its optimizer
  // initializes (first mission). A get_parameters for undeclared names
  // makes the PLANNER's parameter service log 'Failed to get parameters'
  // on every poll — so probe the name list first (list_parameters never
  // throws server-side) and fetch only once the block exists.
  // NOTE the probe name is the FULL parameter name, not the "optimization"
  // prefix: rclcpp's list_parameters hardcodes '.' as its prefix separator,
  // so the planner's '/'-separated names ("optimization/dynamics_unit_xy_m")
  // never match a bare {"optimization"} prefix — that probe returned empty
  // forever and the panel silently graded with compiled-in defaults (found
  // divergent in live config: speed_min 120 vs the planner's 122).
  // Exact-name matching (name == prefix) is separator-independent;
  // dyn_param_probe_test pins both behaviours.
  dyn_param_client_->list_parameters(
      {"optimization/dynamics_unit_xy_m"}, 1,
      [this](std::shared_future<rcl_interfaces::msg::ListParametersResult>
                 fut) {
        const auto res = fut.get();
        if (std::find(res.names.begin(), res.names.end(),
                      std::string("optimization/dynamics_unit_xy_m")) ==
            res.names.end()) {
          return;  // optimizer not initialized yet — retry silently
        }
        fetchDynParamsNow();
      });
}

void TrajectoryMetricsPanel::fetchDynParamsNow()
{
  if (!rclcpp::ok() || !dyn_param_client_) return;
  // 이름 목록과 벡터->스냅숏 매핑은 dyn_param_map.hpp(Qt-free)로 추출 —
  // dyn_param_probe_test가 실값 유입(122.0)까지 같은 코드로 고정한다.
  dyn_param_client_->get_parameters(
      dynParamNames(),
      [this](std::shared_future<std::vector<rclcpp::Parameter>> fut) {
        // Completion fires on the ROS spin thread — marshal to the GUI thread
        // (dynamics_params_ etc. are read by the GUI-side recompute). The
        // future is already resolved here, so fut.get() below cannot block.
        QMetaObject::invokeMethod(this, [this, fut]() {
        try {
          DynParamSnapshot snap;
          if (!applyDynParams(fut.get(), dynamics_params_, snap)) return;
          const bool changed = !dyn_params_live_ ||
              snap.params.load_factor_max != dynamics_params_.load_factor_max ||
              snap.params.speed_max_mps != dynamics_params_.speed_max_mps ||
              snap.terrain_clearance_target_m != terrain_clearance_target_m_ ||
              snap.risk_vertical_ratio != risk_vertical_ratio_ ||
              snap.risk_zone_agl != risk_zone_agl_;
          dyn_unit_xy_m_ = snap.unit_xy_m;
          dyn_unit_z_m_ = snap.unit_z_m;
          terrain_clearance_target_m_ = snap.terrain_clearance_target_m;
          risk_vertical_ratio_ = snap.risk_vertical_ratio;
          risk_zone_agl_ = snap.risk_zone_agl;
          dynamics_params_ = snap.params;
          dyn_params_live_ = true;
          if (changed) {
            RCLCPP_INFO(node_->get_logger(),
                        "TrajectoryMetricsPanel: dynamics params live-synced "
                        "(V=[%.0f,%.0f] m/s, n<=%.2f, T<=%.0f N, "
                        "terrain target=%.0f m, risk Rv/Rh=%.2f)",
                        dynamics_params_.speed_min_mps,
                        dynamics_params_.speed_max_mps,
                        dynamics_params_.load_factor_max,
                        dynamics_params_.thrust_max_n,
                        terrain_clearance_target_m_,
                        risk_vertical_ratio_);
            scheduleRecompute();
          }
        } catch (const std::exception &e) {
          RCLCPP_WARN_ONCE(node_->get_logger(),
                           "TrajectoryMetricsPanel: dynamics param fetch failed (%s) "
                           "— using yaml-mirror defaults", e.what());
        }
        });
      });
}

void TrajectoryMetricsPanel::dynamicObstacleArrayCallback(
  const visualization_msgs::msg::MarkerArray::SharedPtr msg)
{
  QMetaObject::invokeMethod(this, [this, msg]() {
    // PathManager publishes DELETEALL followed by the complete current set.
    for (auto it = obstacles_.begin(); it != obstacles_.end();) {
      const int source = static_cast<int>(
        static_cast<uint64_t>(it->first) >> 32);
      if (source == kDynamicObstacleSource) {
        it = obstacles_.erase(it);
      } else {
        ++it;
      }
    }
    for (const auto & marker : msg->markers) {
      if (marker.ns != "dynamic_obstacles_geom" ||
          marker.action != visualization_msgs::msg::Marker::ADD ||
          marker.type != visualization_msgs::msg::Marker::CUBE) {
        continue;
      }
      ObstacleGeom g;
      g.shape = ObstacleGeom::RECT;
      g.cx = marker.pose.position.x;
      g.cy = marker.pose.position.y;
      g.cz = marker.pose.position.z;
      g.sx = marker.scale.x;
      g.sy = marker.scale.y;
      g.sz = marker.scale.z;
      g.yaw =
        2.0 * std::atan2(
        marker.pose.orientation.z, marker.pose.orientation.w);
      obstacles_[obstacleKey(kDynamicObstacleSource, marker.id)] = g;
    }
    scheduleRecompute();
  });
}

void TrajectoryMetricsPanel::riskZoneArrayCallback(
  const mmp_mission_msgs::msg::RiskZoneArray::SharedPtr msg)
{
  // ROS spin thread — marshal to the GUI thread (risks_ + table_).
  QMetaObject::invokeMethod(this, [this, msg]() {
    // Honor `replace` exactly as the planner does: true clears the active set
    // first, false appends. Assuming full-replace here would drop the earlier
    // zones the planner still costs against on an Append load (and would show
    // an empty set as "no zones" instead of the clear it is).
    if (msg->replace) {
      risks_.clear();
    }
    int id = static_cast<int>(risks_.size());
    for (const auto & z : msg->zones) {
      RiskGeom t;
      t.cx = z.center.x;
      t.cy = z.center.y;
      t.cz = z.center.z;
      t.reach = z.reach;
      t.peak = z.peak;
      risks_[id++] = t;
    }
    scheduleRecompute();
  });
}

void TrajectoryMetricsPanel::riskProfileCallback(
  const std_msgs::msg::Float64MultiArray::SharedPtr msg)
{
  QMetaObject::invokeMethod(this, [this, msg]() {
    risk_profile_version_ = 0;
    risk_profile_zone_count_ = 0;
    risk_profile_.clear();
    if (msg->data.empty()) {
      scheduleRecompute();
      return;
    }
    if (msg->data.size() < 2 || !std::isfinite(msg->data[0]) ||
        !std::isfinite(msg->data[1])) {
      scheduleRecompute();
      return;
    }
    const int version = static_cast<int>(std::llround(msg->data[0]));
    const double zone_count_raw = msg->data[1];
    const bool zone_count_valid =
      zone_count_raw >= 0.0 && zone_count_raw <= 4096.0 &&
      std::abs(zone_count_raw - std::round(zone_count_raw)) < 1e-9;
    if ((version != 3 && version != 4) || !zone_count_valid) {
      scheduleRecompute();
      return;
    }
    const size_t zone_count =
      static_cast<size_t>(std::llround(zone_count_raw));
    const size_t zone_width = version >= 4 ? 3 : 2;
    const size_t stride = 5 + zone_width * zone_count;
    if (stride < 5 || (msg->data.size() - 2) % stride != 0) {
      RCLCPP_WARN(
        node_->get_logger(),
        "TrajectoryMetricsPanel: malformed risk profile v%d (size=%zu, zones=%zu)",
        version, msg->data.size(), zone_count);
      scheduleRecompute();
      return;
    }
    const size_t records = (msg->data.size() - 2) / stride;
    if (records < 2) {
      scheduleRecompute();
      return;
    }
    std::vector<RiskProfileSample> parsed;
    parsed.reserve(records);
    bool valid = true;
    for (size_t rec = 0, base = 2; rec < records; ++rec, base += stride) {
      RiskProfileSample sample{
        msg->data[base + 1],
        msg->data[base + 2],
        msg->data[base + 3],
        msg->data[base + 4]};
      if (!std::isfinite(sample.x) || !std::isfinite(sample.y) ||
          !std::isfinite(sample.z) || !std::isfinite(sample.risk)) {
        valid = false;
        break;
      }
      sample.risk = std::clamp(sample.risk, 0.0, 1.0);
      parsed.push_back(sample);
    }
    if (valid) {
      risk_profile_version_ = version;
      risk_profile_zone_count_ = zone_count;
      risk_profile_ = std::move(parsed);
    }
    scheduleRecompute();
  });
}

void TrajectoryMetricsPanel::gridMapCallback(const grid_map_msgs::msg::GridMap::SharedPtr msg)
{
  // Ignore the empty latched map published before a world is loaded (see
  // AltitudeProfilePanel::gridMapCallback).
  if (msg->info.resolution <= 0.0 || msg->data.empty()) {
    return;
  }
  // ROS spin thread — marshal to the GUI thread (terrain cache + table_).
  QMetaObject::invokeMethod(this, [this, msg]() {
    terrain_map_ = msg;
    terrain_received_ = true;
    scheduleRecompute();
  });
}

// Terrain elevation at (x,y) in FRAME units. Ported verbatim from
// AltitudeProfilePanel::getElevationAt so the clearance metric samples the DEM
// exactly as the altitude plot draws it (same world->grid transform, same
// bilinear blend, same water-as-NaN rule). Returns NaN over open water.
float TrajectoryMetricsPanel::getElevationAt(double x, double y)
{
  if (!terrain_received_ || !terrain_map_) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  int elevation_layer_idx = -1;
  for (size_t i = 0; i < terrain_map_->layers.size(); ++i) {
    if (terrain_map_->layers[i] == "elevation") {
      elevation_layer_idx = static_cast<int>(i);
      break;
    }
  }
  if (elevation_layer_idx < 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  double length_x = terrain_map_->info.length_x;
  double length_y = terrain_map_->info.length_y;
  double terrain_origin_x = terrain_map_->info.pose.position.x - length_x / 2.0;
  double terrain_origin_y = terrain_map_->info.pose.position.y - length_y / 2.0;

  const auto & elevation_data = terrain_map_->data[elevation_layer_idx];
  if (elevation_data.layout.dim.size() < 2) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  int terrain_cols = elevation_data.layout.dim[0].size;
  int terrain_rows = elevation_data.layout.dim[1].size;

  // grid_map cells are square and length_x spans the matrix ROWS (X axis), so
  // deriving a cell size as length_x / cols breaks on non-square maps.
  double terrain_cell_size = terrain_map_->info.resolution;

  // [TERRAIN-FRAME] world -> grid, grid_map core convention (row <-> X,
  // col <-> Y, both mirrored) — keep in sync with TerrainData::getElevation
  // and AltitudeProfilePanel::getElevationAt. CELL-CENTER convention (the
  // -0.5); corner-convention sampling sat half a cell off the rendered mesh.
  double fx = (terrain_origin_y + length_y - y) / terrain_cell_size - 0.5;  // column
  double fy = (terrain_origin_x + length_x - x) / terrain_cell_size - 0.5;  // row

  int col0 = static_cast<int>(std::floor(fx));
  int row0 = static_cast<int>(std::floor(fy));
  int col1 = col0 + 1;
  int row1 = row0 + 1;

  if (col0 < 0 || col1 >= terrain_cols || row0 < 0 || row1 >= terrain_rows) {
    int col = std::max(0, std::min(col0, terrain_cols - 1));
    int row = std::max(0, std::min(row0, terrain_rows - 1));
    int index = col * terrain_rows + row;
    if (index >= static_cast<int>(elevation_data.data.size())) {
      return std::numeric_limits<float>::quiet_NaN();
    }
    float elevation = elevation_data.data[index];
    if (std::isnan(elevation)) {
      return std::numeric_limits<float>::quiet_NaN();
    }
    return elevation;
  }

  double tx = fx - col0;
  double ty = fy - row0;

  float e00 = elevation_data.data[col0 * terrain_rows + row0];
  float e10 = elevation_data.data[col1 * terrain_rows + row0];
  float e01 = elevation_data.data[col0 * terrain_rows + row1];
  float e11 = elevation_data.data[col1 * terrain_rows + row1];

  // Water is stored as NaN but MEANS sea level (publisher blanks elev <= 0);
  // blend NaN corners as 0 so the coastal band is smooth. Pure-water samples
  // (all four NaN) stay NaN so the caller can treat them as sea level 0.
  const bool n00 = std::isnan(e00), n10 = std::isnan(e10);
  const bool n01 = std::isnan(e01), n11 = std::isnan(e11);
  if (n00 && n10 && n01 && n11) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  const double f00 = n00 ? 0.0 : e00;
  const double f10 = n10 ? 0.0 : e10;
  const double f01 = n01 ? 0.0 : e01;
  const double f11 = n11 ? 0.0 : e11;

  return static_cast<float>(
    (1.0 - tx) * (1.0 - ty) * f00 +
    tx         * (1.0 - ty) * f10 +
    (1.0 - tx) * ty         * f01 +
    tx         * ty         * f11);
}

void TrajectoryMetricsPanel::trajectoryCallback(const mmp_traj_msgs::msg::PolyTraj::SharedPtr msg)
{
  if (!mmp_traj_utils::validate(*msg)) {
    return;
  }
  // ROS spin thread — marshal to the GUI thread (latest_traj_ + table_).
  QMetaObject::invokeMethod(this, [this, msg]() {
    latest_traj_ = msg;
    scheduleRecompute();
  });
}

void TrajectoryMetricsPanel::scheduleRecompute()
{
  if (recompute_pending_) {
    return;
  }
  recompute_pending_ = true;
  QTimer::singleShot(0, this, [this]() {
    recompute_pending_ = false;
    recomputeMetrics();
  });
}

void TrajectoryMetricsPanel::recomputeMetrics()
{
  if (!latest_traj_) {
    return;
  }
  const auto & traj = *latest_traj_;
  const int piece_num = static_cast<int>(traj.duration.size());

  // Evaluate the polynomial at absolute time t_abs (0 at trajectory start).
  // Also returns velocity and acceleration (frame units/s, /s^2) — analytic
  // derivatives of the same piece, for the inverse-dynamics check below.
  // Piece lookup + coefficient convention live in mmp_traj_utils.
  auto eval_at = [&](double t_abs, double & x, double & y, double & z,
                     double vel[3], double acc[3]) {
    double pos[3];
    mmp_traj_utils::evalAt(traj, t_abs, pos, vel, acc);
    x = pos[0]; y = pos[1]; z = pos[2];
  };

  // Total flight time.
  double total_duration = 0.0;
  for (double d : traj.duration) {
    if (!(d > 0.0) || !std::isfinite(d)) {
      setRow(0, "Trajectory Length", "—", "invalid trajectory duration");
      setRow(1, "Flight Duration", "—", "invalid trajectory duration");
      return;
    }
    total_duration += d;
  }
  if (!(total_duration > 0.0) || !std::isfinite(total_duration)) {
    setRow(0, "Trajectory Length", "—", "invalid trajectory duration");
    setRow(1, "Flight Duration", "—", "invalid trajectory duration");
    return;
  }

  // Dense sampling for dwell time, arc length, collision, terrain and dynamics.
  constexpr double kDt = 0.01;
  const int n_steps = static_cast<int>(std::ceil(total_duration / kDt)) + 1;

  double total_distance_m = 0.0;
  double zone_dwell_s = 0.0;
  double zone_path_m = 0.0;
  double max_in_zone_depth_m = 0.0;
  double dyn_violation_s = 0.0;
  double dyn_eval_s = 0.0;
  double dyn_ramp_s = 0.0;
  double dyn_ramp_peak = 0.0;
  double dyn_peak_util = 0.0;
  mmp_vehicle_dynamics::EnvelopeLimit dyn_peak_limit =
      mmp_vehicle_dynamics::EnvelopeLimit::None;
  mmp_vehicle_dynamics::Evaluation dyn_peak_eval;
  double terr_min_clearance_m = std::numeric_limits<double>::infinity();
  double terr_below_s = 0.0;
  double terr_below_target_s = 0.0;

  // Snapshot the GUI-thread cache. Counting by vector index lets the panel
  // report unique intersected volumes rather than the number of hit samples.
  std::vector<ObstacleGeom> obstacle_geoms;
  obstacle_geoms.reserve(obstacles_.size());
  for (const auto & kv : obstacles_) {
    obstacle_geoms.push_back(kv.second);
  }
  std::vector<bool> obstacle_hit(obstacle_geoms.size(), false);

  // Convert raw AGL source heights to the same effective zone centers used by
  // PathManager. The nominal-zone metrics deliberately ignore terrain
  // visibility; terrain-masked risk is reported separately from risk_profile.
  std::vector<RiskGeom> effective_risks;
  effective_risks.reserve(risks_.size());
  for (const auto & kv : risks_) {
    RiskGeom zone = kv.second;
    if (risk_zone_agl_ && terrain_received_) {
      const float elevation = getElevationAt(zone.cx, zone.cy);
      const double ground =
        std::isfinite(elevation) && elevation > 0.0f
        ? static_cast<double>(elevation)
        : 0.0;
      zone.cz = ground + zone.cz;
    }
    effective_risks.push_back(zone);
  }

  Eigen::Vector3d prev_position_u = Eigen::Vector3d::Zero();
  bool have_previous = false;
  bool prev_inside_zone = false;
  bool prev_below_terrain = false;
  bool prev_below_target = false;
  double prev_t = 0.0;

  for (int i = 0; i < n_steps; ++i) {
    const double t = std::min(i * kDt, total_duration);
    const double sample_dt = have_previous ? t - prev_t : 0.0;
    double x, y, z;
    double vel[3], acc[3];
    eval_at(t, x, y, z, vel, acc);
    const Eigen::Vector3d position_u(x, y, z);

    // Evaluate the same inverse-dynamics model used by the trajectory
    // optimizer. Time is accumulated only over the interval since the
    // previous sample, preventing a one-sample overcount at both ends.
    {
      const Eigen::Vector3d position_m(
          x * dyn_unit_xy_m_, y * dyn_unit_xy_m_, z * dyn_unit_z_m_);
      const Eigen::Vector3d velocity_mps(
          vel[0] * dyn_unit_xy_m_, vel[1] * dyn_unit_xy_m_,
          vel[2] * dyn_unit_z_m_);
      const Eigen::Vector3d acceleration_mps2(
          acc[0] * dyn_unit_xy_m_, acc[1] * dyn_unit_xy_m_,
          acc[2] * dyn_unit_z_m_);
      const auto evaluation = mmp_vehicle_dynamics::evaluateInverseDynamics(
          dynamics_params_, position_m, velocity_mps, acceleration_mps2);
      if (evaluation.valid &&
          evaluation.speed_mps < dynamics_params_.model_activation_speed_mps) {
        dyn_ramp_s += sample_dt;
      } else if (evaluation.valid) {
        mmp_vehicle_dynamics::EnvelopeLimit limit;
        const double utilization =
            mmp_vehicle_dynamics::envelopeUtilization(
                dynamics_params_, evaluation, &limit);
        if (evaluation.speed_mps < dynamics_params_.speed_min_mps) {
          dyn_ramp_s += sample_dt;
          if (std::isfinite(utilization) && utilization > dyn_ramp_peak) {
            dyn_ramp_peak = utilization;
          }
        } else {
          dyn_eval_s += sample_dt;
          if (!mmp_vehicle_dynamics::isWithinEnvelope(
                  dynamics_params_, evaluation)) {
            dyn_violation_s += sample_dt;
          }
          if (std::isfinite(utilization) && utilization > dyn_peak_util) {
            dyn_peak_util = utilization;
            dyn_peak_limit = limit;
            dyn_peak_eval = evaluation;
          }
        }
      }
    }

    // Terrain clearance: trajectory altitude minus interpolated DEM. NaN is
    // open water and therefore uses sea level zero.
    bool below_terrain = false;
    bool below_target = false;
    if (terrain_received_) {
      const float e = getElevationAt(x, y);
      const double terr_frame = std::isnan(e) ? 0.0 : static_cast<double>(e);
      const double clearance_m = (z - terr_frame) * dyn_unit_z_m_;
      terr_min_clearance_m = std::min(terr_min_clearance_m, clearance_m);
      below_terrain = clearance_m < 0.0;
      below_target = clearance_m < terrain_clearance_target_m_;
      if (have_previous) {
        terr_below_s +=
          0.5 * (static_cast<double>(prev_below_terrain) +
                 static_cast<double>(below_terrain)) * sample_dt;
        terr_below_target_s +=
          0.5 * (static_cast<double>(prev_below_target) +
                 static_cast<double>(below_target)) * sample_dt;
      }
    }

    double seg_len_m = 0.0;
    if (have_previous) {
      const double dx = (x - prev_position_u.x()) * dyn_unit_xy_m_;
      const double dy = (y - prev_position_u.y()) * dyn_unit_xy_m_;
      const double dz = (z - prev_position_u.z()) * dyn_unit_z_m_;
      seg_len_m = std::sqrt(dx * dx + dy * dy + dz * dz);
      total_distance_m += seg_len_m;
    }

    // Nominal risk-zone occupancy uses the planner's 3-D ellipsoid geometry.
    // Overlapping zones form a union, so time and length are counted once.
    bool inside_any = false;
    for (const auto & zone : effective_risks) {
      if (!(zone.reach > 0.0) || !(risk_vertical_ratio_ > 0.0)) {
        continue;
      }
      const double rv = zone.reach * risk_vertical_ratio_;
      const double dx = x - zone.cx;
      const double dy = y - zone.cy;
      const double dz = z - zone.cz;
      const double q = std::sqrt(
        (dx * dx + dy * dy) / (zone.reach * zone.reach) +
        (dz * dz) / (rv * rv));
      if (q < 1.0) {
        inside_any = true;
        const double horizontal_distance = std::hypot(dx, dy);
        max_in_zone_depth_m = std::max(
          max_in_zone_depth_m,
          (zone.reach - horizontal_distance) * dyn_unit_xy_m_);
      }
    }
    if (have_previous) {
      const double inside_fraction =
        0.5 * (static_cast<double>(prev_inside_zone) +
               static_cast<double>(inside_any));
      zone_dwell_s += inside_fraction * sample_dt;
      zone_path_m += inside_fraction * seg_len_m;
    }

    // Segment-vs-volume testing catches thin obstacles between samples and
    // respects obstacle height instead of treating every object as an
    // infinitely tall 2-D footprint.
    const Eigen::Vector3d segment_start =
      have_previous ? prev_position_u : position_u;
    for (size_t k = 0; k < obstacle_geoms.size(); ++k) {
      if (!obstacle_hit[k] &&
          segmentIntersectsObstacle(
            segment_start, position_u, obstacle_geoms[k])) {
        obstacle_hit[k] = true;
      }
    }

    prev_position_u = position_u;
    prev_inside_zone = inside_any;
    prev_below_terrain = below_terrain;
    prev_below_target = below_target;
    prev_t = t;
    have_previous = true;
  }

  int hit_count = 0;
  for (bool hit : obstacle_hit) {
    if (hit) {
      ++hit_count;
    }
  }
  const int total_obs = static_cast<int>(obstacle_geoms.size());

  const QColor kSafe(30, 140, 60);
  const QColor kWarn(200, 120, 0);
  const QColor kDanger(200, 40, 40);

  // The profile is the authoritative effective risk field already evaluated
  // by PathManager, including overlapping zones and terrain visibility.
  // Check its coordinates before consuming a transient-local sample from a
  // previous plan.
  bool risk_profile_matches =
    risk_profile_version_ >= 3 &&
    risk_profile_.size() >= 2 &&
    risk_profile_zone_count_ == risks_.size();
  if (risk_profile_matches) {
    const size_t check_count = std::min<size_t>(64, risk_profile_.size());
    for (size_t check = 0; check < check_count; ++check) {
      const size_t index =
        check_count > 1
        ? check * (risk_profile_.size() - 1) / (check_count - 1)
        : 0;
      const double t =
        total_duration * static_cast<double>(index) /
        static_cast<double>(risk_profile_.size() - 1);
      double x, y, z;
      double vel[3], acc[3];
      eval_at(t, x, y, z, vel, acc);
      const auto & sample = risk_profile_[index];
      const double dx = (x - sample.x) * dyn_unit_xy_m_;
      const double dy = (y - sample.y) * dyn_unit_xy_m_;
      const double dz = (z - sample.z) * dyn_unit_z_m_;
      if (std::sqrt(dx * dx + dy * dy + dz * dz) >
          kRiskProfileMatchToleranceM) {
        risk_profile_matches = false;
        break;
      }
    }
  }

  double risk_weighted_distance_m = 0.0;
  double risk_profile_distance_m = 0.0;
  double risk_peak = 0.0;
  if (risk_profile_matches) {
    risk_peak = risk_profile_.front().risk;
    for (size_t i = 1; i < risk_profile_.size(); ++i) {
      const auto & a = risk_profile_[i - 1];
      const auto & b = risk_profile_[i];
      const double dx = (b.x - a.x) * dyn_unit_xy_m_;
      const double dy = (b.y - a.y) * dyn_unit_xy_m_;
      const double dz = (b.z - a.z) * dyn_unit_z_m_;
      const double segment_m = std::sqrt(dx * dx + dy * dy + dz * dz);
      risk_profile_distance_m += segment_m;
      risk_weighted_distance_m += 0.5 * (a.risk + b.risk) * segment_m;
      risk_peak = std::max(risk_peak, b.risk);
    }
  }

  // Write the general path metrics using display-friendly units. Internal
  // calculations remain SI for reproducible logs and experiments.
  setRow(
    0, "Trajectory Length", formatDistance(total_distance_m),
    QString("%1 polynomial segments").arg(piece_num));

  const double mean_speed_mps = total_distance_m / total_duration;
  setRow(
    1, "Flight Duration", formatDuration(total_duration),
    QString("%1 s; mean speed %2 m/s")
      .arg(total_duration, 0, 'f', 2)
      .arg(mean_speed_mps, 0, 'f', 1));

  const bool any_hit = hit_count > 0;
  setRow(
    2, "Intersected Obstacles",
    QString("%1 / %2").arg(hit_count).arg(total_obs),
    total_obs == 0 ? "no obstacle collision volumes loaded"
    : (any_hit ? "3-D trajectory-volume intersection detected"
               : "clear in 3-D"),
    any_hit ? kDanger : kSafe);

  if (risks_.empty()) {
    setRow(3, "Time Inside Risk Zones", "—", "no risk zones loaded");
    setRow(4, "Distance Inside Risk Zones", "—", "no risk zones loaded");
    setRow(5, "Maximum Risk-Zone Penetration", "—", "no risk zones loaded");
    setRow(6, "Risk-Weighted Path Length", "—", "no risk zones loaded");
  } else {
    const bool avoided = zone_dwell_s <= 1e-6;
    const QString geometry_note =
      QString("%1 nominal 3-D zones; terrain masking not applied")
      .arg(risks_.size());

    setRow(
      3, "Time Inside Risk Zones",
      formatDuration(zone_dwell_s) +
        " (" + formatShare(zone_dwell_s, total_duration) + ")",
      avoided ? "fully outside nominal zone geometry" : geometry_note,
      avoided ? kSafe : kWarn);

    setRow(
      4, "Distance Inside Risk Zones",
      formatDistance(zone_path_m) +
        " (" + formatShare(zone_path_m, total_distance_m) + ")",
      avoided ? "fully outside nominal zone geometry" : geometry_note,
      avoided ? kSafe : kWarn);

    setRow(
      5, "Maximum Risk-Zone Penetration",
      formatDistance(max_in_zone_depth_m),
      avoided ? "stayed outside nominal zone geometry"
      : "maximum horizontal distance past a nominal zone boundary",
      avoided ? kSafe : kWarn);

    if (!risk_profile_matches) {
      setRow(
        6, "Risk-Weighted Path Length", "—",
        "waiting for the matching planner risk profile");
    } else {
      const double mean_risk =
        risk_profile_distance_m > 1e-9
        ? risk_weighted_distance_m / risk_profile_distance_m
        : 0.0;
      const bool negligible = risk_weighted_distance_m <= 1.0;
      setRow(
        6, "Risk-Weighted Path Length",
        formatDistance(risk_weighted_distance_m),
        QString("terrain-masked planner risk: mean %1%, peak %2%")
          .arg(100.0 * mean_risk, 0, 'f', 2)
          .arg(100.0 * risk_peak, 0, 'f', 2),
        negligible ? kSafe : kWarn);
    }
  }

  // Separate "how close to a limit" from "how long a limit was violated".
  if (dyn_eval_s <= 1e-9) {
    setRow(7, "Peak Flight-Limit Usage", "—", "no valid cruise segment");
    setRow(8, "Flight-Limit Violation Time", "—", "no valid cruise segment");
  } else {
    const double util_pct = 100.0 * dyn_peak_util;
    QColor utilization_color = kSafe;
    if (util_pct > 100.0) {
      utilization_color = kDanger;
    } else if (util_pct >= 90.0) {
      utilization_color = kWarn;
    }
    QString utilization_note =
      QString("limiting item: %1; n=%2, CL=%3, T=%4 kN; 100% = limit")
        .arg(mmp_vehicle_dynamics::envelopeLimitName(dyn_peak_limit))
        .arg(dyn_peak_eval.load_factor, 0, 'f', 2)
        .arg(dyn_peak_eval.signed_lift_coefficient, 0, 'f', 2)
        .arg(dyn_peak_eval.thrust_required_n / 1000.0, 0, 'f', 1);
    if (!dyn_params_live_) {
      utilization_note += "; fallback limits";
    }
    setRow(
      7, "Peak Flight-Limit Usage",
      QString::number(util_pct, 'f', 0) + "%",
      utilization_note, utilization_color);

    QString violation_note =
      QString("evaluated for V >= %1 m/s")
        .arg(dynamics_params_.speed_min_mps, 0, 'f', 0);
    if (dyn_ramp_s > 1e-9) {
      violation_note +=
        "; " + formatDuration(dyn_ramp_s) + " below-minimum-speed flight excluded";
      if (dyn_ramp_peak > 0.0) {
        violation_note +=
          QString(" (peak %1%)").arg(100.0 * dyn_ramp_peak, 0, 'f', 0);
      }
    }
    const bool dynamics_clear = dyn_violation_s <= 1e-9;
    setRow(
      8, "Flight-Limit Violation Time",
      formatDuration(dyn_violation_s) +
        " (" + formatShare(dyn_violation_s, dyn_eval_s) + ")",
      violation_note,
      dynamics_clear ? kSafe : kDanger);
  }

  // Terrain is separate from the explicit obstacle-volume count above.
  if (!terrain_received_) {
    setRow(
      9, "Minimum Terrain Clearance", "—",
      "waiting for /terrain/grid_map");
  } else {
    const double below_pct = 100.0 * terr_below_s / total_duration;
    const double target_pct =
      100.0 * terr_below_target_s / total_duration;
    const bool below = terr_below_s > 0.0;
    const bool sustained = below_pct >= 0.05;
    QColor col;
    QString note;
    if (sustained) {
      col = kDanger;
      note =
        "below terrain for " + QString::number(below_pct, 'f', 2) +
        "% of flight time";
    } else if (below) {
      col = kWarn;
      note =
        "momentary terrain dip; below configured clearance for " +
        QString::number(target_pct, 'f', 2) + "% of flight time";
    } else if (terr_below_target_s > 0.0) {
      col = kWarn;
      note =
        QString("%1% of flight below the configured %2 m clearance")
          .arg(target_pct, 0, 'f', 2)
          .arg(terrain_clearance_target_m_, 0, 'f', 0);
    } else {
      col = kSafe;
      note =
        QString("meets the configured %1 m clearance")
          .arg(terrain_clearance_target_m_, 0, 'f', 0);
    }
    setRow(
      9, "Minimum Terrain Clearance",
      QString::number(terr_min_clearance_m, 'f', 1) + " m",
      note, col);
  }
}

}  // namespace mmp_rviz_plugins

#include <pluginlib/class_list_macros.hpp>
PLUGINLIB_EXPORT_CLASS(mmp_rviz_plugins::TrajectoryMetricsPanel, rviz_common::Panel)

// teleport.hpp의 정책을 고정하는 행동 시험.
//
// 700 km 점프 직후의 버벅임은 맵 크기도 컬링 실패도 아니다. 새 위치의
// 고해상도 타일이 클라이언트에 없으니 다시 읽고 디코드·메시·업로드해야
// 하는데, 현재 구현이 그 작업을 이미 떠난 위치의 작업과 경쟁시킨다.
//
// 이 시험이 지키는 불변식:
//   1. 일반 pan에서는 게이트가 발동하지 않는다.
//   2. 큰 점프는 정확히 한 번만 발동한다 (착지 흔들림에 재발동 금지).
//   3. 새 view가 원하지 않는 키만 stale로 뽑힌다.
//   4. z0-4 고정 기본층은 절대 stale이 아니다 — 항상 무언가는 그려져야 한다.
//   5. 정리 후 순서는 coarse -> fine, 같은 레벨에서는 가까운 것 먼저.
//   6. 왕복 순간이동에도 게이트가 매번 정확히 한 번씩 선다.
#include <gtest/gtest.h>

#include <set>
#include <vector>

#include "mmp_rviz_plugins/teleport.hpp"

namespace
{
struct K
{
  int z, x, y;
  bool operator<(const K & o) const
  {
    if (z != o.z) {return z < o.z;}
    if (x != o.x) {return x < o.x;}
    return y < o.y;
  }
  bool operator==(const K & o) const {return z == o.z && x == o.x && y == o.y;}
};
constexpr int kPinnedMaxZ = 4;
}  // namespace

using mmp_rviz_plugins::TeleportGate;

// 1. 일반 pan에서는 발동하지 않는다.
TEST(Teleport, an_ordinary_pan_never_trips_the_gate)
{
  TeleportGate g;
  g.step(0, 0, 0);
  // 20 Hz로 100틱, 틱당 50 u(5 km) = 100 km/s. 사람이 끌 수 있는 것보다 빠르지만
  // 연속적이다. 게이트는 속도가 아니라 불연속을 본다.
  for (int i = 1; i <= 100; ++i) {
    EXPECT_FALSE(g.step(i * 50.0, 0, 0)) << "tick " << i;
  }
}

// 2. 큰 점프는 정확히 한 번.
TEST(Teleport, one_jump_fires_exactly_once)
{
  TeleportGate g;
  g.step(0, 0, 0);
  EXPECT_TRUE(g.step(7000, 0, 0)) << "700 km 점프가 발동해야 한다";
  // 착지 후 몇 틱 흔들려도 다시 발동하면 안 된다.
  int again = 0;
  for (int i = 1; i <= 20; ++i) {
    if (g.step(7000 + i * 10.0, 0, 0)) {++again;}
  }
  EXPECT_EQ(again, 0) << "착지 흔들림에 재발동";
}

// 하나의 사용자 동작이 여러 틱에 걸쳐 큰 델타로 나뉘어도 한 번이어야 한다.
// 뷰 컨트롤러는 초점을 즉시 옮기지 않고 몇 틱에 나눠 옮기므로, 래치가 없으면
// 한 번의 점프가 매 틱 취소를 부른다.
TEST(Teleport, a_jump_spread_over_several_ticks_is_still_one_event)
{
  TeleportGate g;
  g.step(0, 0, 0);
  int fired = 0;
  for (int i = 1; i <= 3; ++i) {           // 2500 u 씩 3틱 = 750 km
    if (g.step(i * 2500.0, 0, 0)) {++fired;}
  }
  EXPECT_EQ(fired, 1) << "한 동작인데 " << fired << "번 발동";
  for (int i = 0; i < 5; ++i) {g.step(7500, 0, 0);}   // 정지 -> 재무장
  EXPECT_TRUE(g.armed());
}

// 3. 왕복 점프는 각각 한 번씩.
TEST(Teleport, a_round_trip_fires_once_each_way)
{
  TeleportGate g;
  g.step(0, 0, 0);
  EXPECT_TRUE(g.step(7000, 0, 0));
  for (int i = 0; i < 5; ++i) {g.step(7000, 0, 0);}   // settle: 재무장
  EXPECT_TRUE(g.step(0, 0, 0)) << "돌아오는 점프도 발동해야 한다";
  for (int i = 0; i < 5; ++i) {g.step(0, 0, 0);}
  EXPECT_TRUE(g.armed()) << "정지하면 다시 무장";
}

// 게이트는 첫 pose에서는 발동하지 않는다 (비교 대상이 없다).
TEST(Teleport, the_first_pose_is_not_a_jump)
{
  TeleportGate g;
  EXPECT_FALSE(g.step(1e6, 1e6, 1e6));
}

// 4. 새 view가 원하지 않는 키만 stale.
TEST(Teleport, only_keys_the_new_view_does_not_want_are_stale)
{
  const std::vector<K> have{{11, 100, 100}, {11, 900, 900}, {10, 50, 50}};
  const std::set<K> keep{{11, 900, 900}};
  const auto stale = mmp_rviz_plugins::stale_keys(have, keep, kPinnedMaxZ);
  ASSERT_EQ(stale.size(), 2u);
  EXPECT_EQ(stale[0], (K{11, 100, 100}));
  EXPECT_EQ(stale[1], (K{10, 50, 50}));
}

// 5. 고정 기본층은 절대 stale이 아니다.
TEST(Teleport, the_pinned_base_is_never_stale)
{
  std::vector<K> have;
  for (int z = 0; z <= 6; ++z) {have.push_back({z, 0, 0});}
  const auto stale = mmp_rviz_plugins::stale_keys(have, std::set<K>{},
                                                  kPinnedMaxZ);
  for (const auto & k : stale) {
    EXPECT_GT(k.z, kPinnedMaxZ) << "z" << k.z << " 는 고정층인데 stale";
  }
  EXPECT_EQ(stale.size(), 2u) << "z5, z6 만 stale";
}

// 6. coarse -> fine, 같은 레벨에서는 가까운 것 먼저.
TEST(Teleport, rebuild_order_is_coarse_then_near)
{
  std::vector<std::pair<double, K>> items{
    {5.0, {11, 1, 1}}, {90.0, {8, 2, 2}}, {1.0, {11, 3, 3}}, {50.0, {8, 4, 4}}};
  mmp_rviz_plugins::order_coarse_then_near(items);
  EXPECT_EQ(items[0].second.z, 8);
  EXPECT_EQ(items[1].second.z, 8);
  EXPECT_DOUBLE_EQ(items[0].first, 50.0) << "같은 레벨은 가까운 것 먼저";
  EXPECT_DOUBLE_EQ(items[1].first, 90.0);
  EXPECT_EQ(items[2].second.z, 11);
  EXPECT_DOUBLE_EQ(items[2].first, 1.0);
}

// 정렬은 안정적이어야 한다 — 같은 (z, 거리)의 상대 순서가 뒤집히면
// 같은 카메라에서 두 번 부른 결과가 달라진다.
TEST(Teleport, the_order_is_stable_for_ties)
{
  // 작은 배열은 introsort 도 삽입정렬로 떨어져 우연히 안정적이다.
  // 분할이 실제로 일어날 만큼 크게 만들고, 전부 동률로 둔다.
  std::vector<std::pair<double, K>> a;
  for (int i = 0; i < 64; ++i) {a.push_back({1.0, {9, i, i}});}
  const auto before = a;
  mmp_rviz_plugins::order_coarse_then_near(a);
  EXPECT_EQ(a, before) << "동률 원소의 입력 순서가 보존되어야 한다";
}

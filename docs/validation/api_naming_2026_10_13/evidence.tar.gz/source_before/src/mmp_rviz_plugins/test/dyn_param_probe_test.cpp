// TrajectoryMetrics 패널의 dynamics 파라미터 프로브 계약.
//
// 플래너는 'optimization/dynamics_*'처럼 '/' 구분 이름을 선언하는데,
// rclcpp의 list_parameters prefix 매칭은 '.' 구분만 인식한다: 프리픽스
// {"optimization"} 프로브는 영원히 빈손이라(수리 전 패널) dynamics
// 파라미터가 컴파일 기본값에서 영구 미동기됐다 — 실제 설정과 이미 어긋나
// 있었다(speed_min 120 vs 122). 정확한 전체 이름 프로브(이름==프리픽스)는
// 구분자와 무관하게 매칭된다. 이 시험은 두 동작을 모두 고정하고, 실값
// 122.0이 클라이언트로 온전히 유입됨을 확인한다.
#include <gtest/gtest.h>

#include <algorithm>
#include <chrono>
#include <memory>
#include <string>

#include <rclcpp/rclcpp.hpp>

#include "mmp_rviz_plugins/dyn_param_map.hpp"

using namespace std::chrono_literals;

class DynParamProbe : public ::testing::Test
{
protected:
  static void SetUpTestSuite() {rclcpp::init(0, nullptr);}
  static void TearDownTestSuite() {rclcpp::shutdown();}
};

TEST_F(DynParamProbe, SlashNamesNeedExactNameProbes)
{
  auto server = std::make_shared<rclcpp::Node>("fake_planner");
  // 실플래너와 같은 '/' 이름으로 25개 전부 선언(유효 범위의 실전형 값 —
  // applyDynParams의 validity 게이트를 통과해야 122가 도달한다).
  const std::vector<std::pair<std::string, double>> doubles = {
    {"optimization/dynamics_unit_xy_m", 100.0},
    {"optimization/dynamics_unit_z_m", 100.0},
    {"optimization/dynamics_mass_kg", 1000.0},
    {"optimization/dynamics_wing_area_m2", 20.0},
    {"optimization/dynamics_g", 9.81},
    {"optimization/dynamics_rho0_kgpm3", 1.225},
    {"optimization/dynamics_density_scale_height_m", 8500.0},
    {"optimization/dynamics_altitude_reference_m", 0.0},
    {"optimization/dynamics_cd0", 0.02},
    {"optimization/dynamics_induced_drag_factor", 0.05},
    {"optimization/dynamics_cl_min", -0.5},
    {"optimization/dynamics_cl_max", 1.2},
    {"optimization/dynamics_load_factor_max", 2.5},
    {"optimization/dynamics_thrust_min_n", 0.0},
    {"optimization/dynamics_thrust_max_n", 3200.0},
    {"optimization/dynamics_speed_min_mps", 122.0},
    {"optimization/dynamics_speed_max_mps", 230.0},
    {"optimization/dynamics_activation_speed_mps", 60.0},
    {"optimization/dynamics_dynamic_pressure_max_pa", 100000.0},
    {"optimization/dynamics_bank_max_deg", 60.0},
    {"optimization/dynamics_flight_path_max_deg", 30.0},
    {"optimization/dynamics_margin", 0.05},
    {"optimization/obstacle_clearance", 0.5},
    {"manager/risk_vertical_ratio", 0.35},
  };
  for (const auto & kv : doubles) {
    server->declare_parameter(kv.first, kv.second);
  }
  server->declare_parameter("manager/risk_zone_agl", true);

  auto client_node = std::make_shared<rclcpp::Node>("probe_client");
  auto client = std::make_shared<rclcpp::AsyncParametersClient>(
    client_node, "fake_planner");

  rclcpp::executors::SingleThreadedExecutor ex;
  ex.add_node(server);
  ex.add_node(client_node);
  ASSERT_TRUE(client->wait_for_service(5s));

  // 공용 목록의 머리를 그대로 사용 — 패널이 프로브하는 바로 그 이름이며,
  // 목록이 바뀌거나 구 프리픽스 프로브로 회귀하는 변이를 함께 잡는다.
  const std::string want = mmp_rviz_plugins::dynParamNames().front();

  // 수리 전 프로브: prefix "optimization" — '/' 이름은 절대 안 나온다.
  auto f1 = client->list_parameters({"optimization"}, 2);
  ASSERT_EQ(ex.spin_until_future_complete(f1, 5s),
            rclcpp::FutureReturnCode::SUCCESS);
  const auto r1 = f1.get();
  EXPECT_EQ(std::find(r1.names.begin(), r1.names.end(), want),
            r1.names.end())
    << "rclcpp가 '/' 이름을 prefix 매칭하기 시작했다면 패널 프로브 재검토";

  // 수리 후 프로브: 정확한 전체 이름 — 매칭된다.
  auto f2 = client->list_parameters({want}, 1);
  ASSERT_EQ(ex.spin_until_future_complete(f2, 5s),
            rclcpp::FutureReturnCode::SUCCESS);
  const auto r2 = f2.get();
  EXPECT_NE(std::find(r2.names.begin(), r2.names.end(), want),
            r2.names.end());

  // 실값 유입 — 패널이 쓰는 것과 SAME 이름 목록 + SAME 매핑을 경유해
  // 122.0이 스냅숏의 speed_min에 도달한다(주장과 시험이 같은 코드).
  auto f3 = client->get_parameters(mmp_rviz_plugins::dynParamNames());
  ASSERT_EQ(ex.spin_until_future_complete(f3, 5s),
            rclcpp::FutureReturnCode::SUCCESS);
  mmp_vehicle_dynamics::Parameters base;
  mmp_rviz_plugins::DynParamSnapshot snap;
  ASSERT_TRUE(mmp_rviz_plugins::applyDynParams(f3.get(), base, snap));
  EXPECT_DOUBLE_EQ(snap.params.speed_min_mps, 122.0);
  EXPECT_DOUBLE_EQ(snap.params.thrust_max_n, 3200.0);
  EXPECT_DOUBLE_EQ(snap.terrain_clearance_target_m, 50.0);   // 0.5 u * 100 m
  EXPECT_TRUE(snap.risk_zone_agl);
}

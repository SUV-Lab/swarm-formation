// 틱 카운터와 쿨다운의 계약.
//
// 실제로 났던 일: 타일 서버가 늦게 뜨면 RViz 가 그걸 영영 못 알아챘다.
// meta fetch 가 실패하면 "stamp_ + 20 전에는 재시도 안 함" 을 걸어두는데,
// 실패 경로가 ++stamp_ 앞에서 return 해버려 카운터가 멈췄다. 쿨다운이 영원히
// 만료되지 않았고, 체크박스를 껐다 켜도 stamp_ 와 쿨다운이 멤버라 그대로였다.
// RViz 재시작만이 유일한 복구였다.
#include <gtest/gtest.h>

#include "mmp_rviz_plugins/tick_cooldown.hpp"

using mmp_rviz_plugins::TickClock;

TEST(TickCooldown, a_backoff_expires_if_the_counter_keeps_advancing)
{
  TickClock c;
  const uint64_t wait = c.backoff(20);
  EXPECT_FALSE(c.ready(wait));
  for (int i = 0; i < 20; ++i) {c.advance();}
  EXPECT_TRUE(c.ready(wait)) << "20틱을 지나고도 쿨다운이 안 풀렸다";
}

TEST(TickCooldown, a_backoff_never_expires_if_the_counter_stalls)
{
  // 고장났던 모양 그대로: 실패 경로가 advance() 를 안 부른다.
  TickClock c;
  const uint64_t wait = c.backoff(20);
  for (int i = 0; i < 10000; ++i) { /* 실패 경로가 조기 반환 */ }
  EXPECT_FALSE(c.ready(wait))
    << "이 시험이 아무것도 잡지 못하고 있다";
}

TEST(TickCooldown, the_counter_advances_on_every_tick_including_failing_ones)
{
  // 고친 모양: advance() 가 맨 위에 있으니 실패해도 카운터가 흐른다.
  TickClock c;
  uint64_t wait = 0;
  bool ok = false;
  int retries = 0;
  for (int tick = 0; tick < 200; ++tick) {
    c.advance();                        // ← 조기 반환보다 먼저
    if (ok) {continue;}
    if (!c.ready(wait)) {continue;}     // 쿨다운 중
    ++retries;
    if (tick >= 100) {ok = true;}       // 100틱째에 서버가 뜬다
    else {wait = c.backoff(20);}        // 아직이면 다시 대기
  }
  EXPECT_TRUE(ok) << "서버가 뜬 뒤에도 끝내 못 붙었다";
  EXPECT_GE(retries, 5) << "재시도가 사실상 없었다";
}

TEST(TickCooldown, disable_and_enable_does_not_rescue_a_stalled_counter)
{
  // 체크박스를 껐다 켜도 stamp_·쿨다운은 멤버라 남는다 — 재시작만이 답이었다.
  TickClock c;
  const uint64_t wait = c.backoff(20);
  // (껐다 켜기: 카운터를 건드리지 않는다)
  EXPECT_FALSE(c.ready(wait));
  TickClock fresh;                      // RViz 재시작 = 새 객체
  EXPECT_TRUE(fresh.ready(0));
}

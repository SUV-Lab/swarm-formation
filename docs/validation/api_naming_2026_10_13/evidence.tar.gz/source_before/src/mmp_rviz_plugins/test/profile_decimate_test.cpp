// profile_decimate.hpp 의 계약을 고정하는 행동 시험.
//
// 고도 프로파일 패널은 위험 오버레이를 궤적 구간마다 개별 drawLine 으로,
// 계획선을 N 점 폴리라인으로 그린다. 800 km 계획은 수만 표본을 폭 수백 px
// 플롯에 밀어넣으므로, 프레임 전체를 같은 픽셀 열에 겹쳐 그리는 데 쓴다.
// (실측: 패널을 열면 700 km 지점에서 rviz2 주 스레드 82%, 8 fps, GPU 5%.
//  패널만 닫으면 즉시 회복.)
//
// 이 시험이 지키는 불변식:
//   1. 점이 적으면 그대로 둔다 (손해 볼 게 없다).
//   2. 열마다 최대 4개 — 진입·최소·최대·이탈 — 만 남긴다.
//   3. 첫 점과 끝 점은 언제나 남는다.
//   4. 봉우리와 골(그려지는 외곽선)은 절대 사라지지 않는다.
//   5. 인덱스는 증가 순서로, 중복 없이 나온다 (병렬 배열 조회에 쓰인다).
//   6. must_keep(체인 분기점 등)은 반드시 포함된다.
//   7. 위험 집계는 최댓값이다 — 화면에서 위험이 낮게 보이면 안 된다.
//   8. NaN(모름)은 0(안전)으로 바뀌지 않는다.
//   9. 진행선(elapsed)은 전체 외곽선을 잘라 쓸 수 없다. 진행점이 열 중간에
//      있으면 그 열의 최소·최대가 진행점 뒤에 있을 수 있고, 그러면 이미
//      지나온 봉우리가 화면에서 사라졌다가 열을 넘는 순간 되살아난다.
//      envelope_prefix 는 그 한 열만 [열 시작, cut) 으로 다시 계산한다.
#include <gtest/gtest.h>

#include <cmath>
#include <vector>

#include "mmp_rviz_plugins/profile_decimate.hpp"

using mmp_rviz_plugins::column_envelope;
using mmp_rviz_plugins::envelope_prefix;
using mmp_rviz_plugins::worst_between;

TEST(ProfileDecimate, a_short_series_is_left_exact)
{
  const std::vector<double> xs{0, 1, 2, 3}, ys{5, 6, 7, 8};
  const auto k = column_envelope(xs, ys);
  ASSERT_EQ(k.size(), 4u);
  for (size_t i = 0; i < 4; ++i) {EXPECT_EQ(k[i], i);}
}

TEST(ProfileDecimate, one_column_keeps_at_most_four_samples)
{
  std::vector<double> xs(1000, 10.5), ys;      // 전부 같은 픽셀 열
  for (size_t i = 0; i < 1000; ++i) {ys.push_back(static_cast<double>(i % 97));}
  const auto k = column_envelope(xs, ys);
  EXPECT_LE(k.size(), 4u) << "한 열에 " << k.size() << "개";
  EXPECT_EQ(k.front(), 0u);
  EXPECT_EQ(k.back(), 999u);
}

TEST(ProfileDecimate, the_envelope_survives)
{
  // 한 열 안에 뾰족한 봉우리와 골. 둘 다 남아야 그림이 같다.
  std::vector<double> xs(200, 3.2), ys(200, 50.0);
  ys[70] = 999.0;                                    // 봉우리
  ys[130] = -999.0;                                  // 골
  const auto k = column_envelope(xs, ys);
  bool peak = false, trough = false;
  for (size_t i : k) {
    if (ys[i] == 999.0) {peak = true;}
    if (ys[i] == -999.0) {trough = true;}
  }
  EXPECT_TRUE(peak) << "봉우리가 사라졌다";
  EXPECT_TRUE(trough) << "골이 사라졌다";
}

TEST(ProfileDecimate, a_long_ramp_collapses_to_about_the_column_count)
{
  std::vector<double> xs, ys;
  for (int i = 0; i < 40000; ++i) {                  // 400 px 폭에 4만 표본
    xs.push_back(i * 0.01);
    ys.push_back(std::sin(i * 0.001) * 100.0);
  }
  const auto k = column_envelope(xs, ys);
  EXPECT_LT(k.size(), 2000u) << "줄지 않았다: " << k.size();
  EXPECT_GT(k.size(), 100u) << "너무 줄어 모양이 남지 않는다";
  EXPECT_EQ(k.front(), 0u);
  EXPECT_EQ(k.back(), 39999u);
}

TEST(ProfileDecimate, indices_are_sorted_and_unique)
{
  std::vector<double> xs, ys;
  for (int i = 0; i < 5000; ++i) {xs.push_back(i * 0.05); ys.push_back(i % 13);}
  const auto k = column_envelope(xs, ys);
  ASSERT_FALSE(k.empty());
  for (size_t i = 1; i < k.size(); ++i) {
    EXPECT_LT(k[i - 1], k[i]) << "정렬/중복 위반 at " << i;
  }
}

TEST(ProfileDecimate, must_keep_indices_are_always_present)
{
  std::vector<double> xs(3000, 1.0), ys(3000, 0.0);
  const std::vector<size_t> junctions{7, 1234, 2999};
  const auto k = column_envelope(xs, ys, 1.0, junctions);
  for (size_t j : junctions) {
    EXPECT_NE(std::find(k.begin(), k.end(), j), k.end())
      << "분기점 " << j << " 이 빠졌다";
  }
}

TEST(ProfileDecimate, risk_is_aggregated_by_the_worst_not_the_average)
{
  // 한 열 안에 위험이 튀면 화면에는 그 위험이 보여야 한다.
  const std::vector<double> r{0.0, 0.0, 0.9, 0.0, 0.0};
  EXPECT_DOUBLE_EQ(worst_between(r, 0, 4), 0.9);
}

TEST(ProfileDecimate, unknown_risk_never_becomes_safe_risk)
{
  const double nan = std::numeric_limits<double>::quiet_NaN();
  const std::vector<double> all_unknown{nan, nan, nan};
  EXPECT_TRUE(std::isnan(worst_between(all_unknown, 0, 2)))
    << "모름이 0(안전)으로 바뀌었다";
  const std::vector<double> mixed{nan, 0.4, nan};
  EXPECT_DOUBLE_EQ(worst_between(mixed, 0, 2), 0.4) << "아는 값은 살아야 한다";
}


// ---------------------------------------------------------------------------
// 진행 중인 마지막 한 열 (envelope_prefix)
// ---------------------------------------------------------------------------

namespace
{
// 열 0: 0..9, 열 1: 10..19, 열 2: 20..29. 열마다 표본 10개.
struct Series
{
  std::vector<double> xs, ys;
};
Series three_columns()
{
  Series s;
  for (size_t i = 0; i < 30; ++i) {
    const size_t col = i / 10;
    s.xs.push_back(static_cast<double>(col) + static_cast<double>(i % 10) * 0.09);
    s.ys.push_back(0.0);
  }
  s.ys[3] = 7.0;      // 열 0 안의 굴곡
  s.ys[12] = 50.0;    // 열 1: cut 앞의 국소 봉우리
  s.ys[17] = 100.0;   // 열 1: 열 전체의 최대 — cut 뒤
  s.ys[18] = -100.0;  // 열 1: 열 전체의 최소 — cut 뒤
  s.ys[25] = 9.0;
  return s;
}
bool has(const std::vector<size_t> & v, size_t k)
{
  return std::find(v.begin(), v.end(), k) != v.end();
}
}  // namespace

// 코덱스가 지적한 구멍 그대로: 열 전체의 최대·최소가 cut 뒤에 있어도
// cut 앞의 국소 봉우리는 남아야 한다.
TEST(ProfilePrefix, a_peak_already_passed_survives_when_the_columns_extremes_are_not)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0);
  const size_t cut = 13;             // 12 까지 그린다; 13 도 같은 열이다

  // 전체 외곽선을 그냥 자르면 봉우리가 사라진다 — 고치기 전의 동작.
  std::vector<size_t> naive;
  for (size_t e : env) {
    if (e >= cut) {break;}
    naive.push_back(e);
  }
  EXPECT_FALSE(has(naive, 12)) << "이 시험이 아무것도 잡지 못하고 있다";

  const std::vector<size_t> prefix = envelope_prefix(s.xs, s.ys, env, cut, 1.0);
  EXPECT_TRUE(has(prefix, 12)) << "지나온 봉우리가 진행선에서 빠졌다";
}

// 그리는 모든 열에 대해, 그 열에서 cut 이전 구간의 y 최소·최대가 실제로
// 선택된 점 안에 있어야 한다. 모든 cut 에 대해 검사한다.
TEST(ProfilePrefix, every_drawn_column_keeps_its_true_extremes_at_every_cut)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0);

  for (size_t cut = 1; cut <= s.xs.size(); ++cut) {
    const std::vector<size_t> prefix = envelope_prefix(s.xs, s.ys, env, cut, 1.0);
    ASSERT_FALSE(prefix.empty()) << "cut=" << cut;
    for (size_t col = 0; col < 3; ++col) {
      double lo = 1e300, hi = -1e300;
      bool any = false;
      for (size_t i = col * 10; i < (col + 1) * 10 && i < cut; ++i) {
        lo = std::min(lo, s.ys[i]);
        hi = std::max(hi, s.ys[i]);
        any = true;
      }
      if (!any) {continue;}
      double got_lo = 1e300, got_hi = -1e300;
      for (size_t idx : prefix) {
        if (idx / 10 != col) {continue;}
        got_lo = std::min(got_lo, s.ys[idx]);
        got_hi = std::max(got_hi, s.ys[idx]);
      }
      EXPECT_DOUBLE_EQ(lo, got_lo) << "cut=" << cut << " 열=" << col;
      EXPECT_DOUBLE_EQ(hi, got_hi) << "cut=" << cut << " 열=" << col;
    }
  }
}

// 진행선의 머리는 cut-1 에 붙는다. 그 뒤에 패널이 정확한 보간점을 잇는다.
TEST(ProfilePrefix, the_prefix_always_ends_on_the_last_covered_sample)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0);
  for (size_t cut = 1; cut <= s.xs.size(); ++cut) {
    const std::vector<size_t> prefix = envelope_prefix(s.xs, s.ys, env, cut, 1.0);
    ASSERT_FALSE(prefix.empty()) << "cut=" << cut;
    EXPECT_EQ(prefix.back(), cut - 1) << "cut=" << cut;
    EXPECT_LT(prefix.back(), cut);
    for (size_t k = 1; k < prefix.size(); ++k) {
      EXPECT_LT(prefix[k - 1], prefix[k]) << "cut=" << cut;
    }
  }
}

// 이미 지나간 열은 캐시 그대로다 — 다시 계산하지 않는다.
TEST(ProfilePrefix, completed_columns_come_straight_from_the_cache)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0);
  const std::vector<size_t> prefix = envelope_prefix(s.xs, s.ys, env, 13, 1.0);
  std::vector<size_t> before_col1, cached_before_col1;
  for (size_t e : prefix) {if (e < 10) {before_col1.push_back(e);}}
  for (size_t e : env) {if (e < 10) {cached_before_col1.push_back(e);}}
  EXPECT_EQ(before_col1, cached_before_col1);
}

// 부분 열 안의 must_keep(체인 분기점)은 다시 계산해도 살아남는다.
TEST(ProfilePrefix, must_keep_inside_the_partial_column_is_not_recomputed_away)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0, {11});
  const std::vector<size_t> prefix = envelope_prefix(s.xs, s.ys, env, 13, 1.0);
  EXPECT_TRUE(has(prefix, 11)) << "분기점이 부분 열 재계산에 지워졌다";
}

// 전체를 다 그릴 때는 캐시와 완전히 같아야 한다.
TEST(ProfilePrefix, drawing_everything_is_exactly_the_cached_envelope)
{
  const Series s = three_columns();
  const std::vector<size_t> env = column_envelope(s.xs, s.ys, 1.0);
  EXPECT_EQ(envelope_prefix(s.xs, s.ys, env, s.xs.size(), 1.0), env);
  EXPECT_TRUE(envelope_prefix(s.xs, s.ys, env, 0, 1.0).empty());
}

// 그리는 점 수는 표본 수가 아니라 열 수에 비례한다 — 성능 주장의 본체.
TEST(ProfilePrefix, the_drawn_point_count_follows_the_plot_width_not_the_samples)
{
  std::vector<double> xs, ys;
  for (size_t i = 0; i < 40000; ++i) {       // 800 km 급 계획, 폭 800 px
    xs.push_back(static_cast<double>(i) * 800.0 / 40000.0);
    ys.push_back(std::sin(static_cast<double>(i) * 0.05) * 100.0);
  }
  const std::vector<size_t> env = column_envelope(xs, ys, 1.0);
  const std::vector<size_t> prefix = envelope_prefix(xs, ys, env, 35000, 1.0);
  EXPECT_LT(prefix.size(), 4u * 800u + 8u);
  EXPECT_LT(prefix.size(), 35000u / 8u) << "솎기가 사실상 아무것도 못 줄였다";
}

// border_stitch.hpp의 수렴 계약을 고정하는 행동 시험.
//
// 시험이 지키는 불변식 (코덱스 리뷰 요구 항목):
//   1. 두 같은 레벨 타일의 전체 공유 변이 bit-identical하게 수렴한다.
//   2. 2x2 네 타일의 중앙 꼭짓점 네 값이 정확히 같다 (4-way canonical).
//   3. 과도기 최대 간극(내 평균 변 vs 이웃 RAW 변)은 same_diff의 절반
//      이하 — 스커트 공식 max(15 m, 0.6*same_diff)가 덮는 범위.
//   4. 그려졌지만 미상주(퇴거)인 참여자는 sig 비트를 해제해 재시도를
//      예약하고, 절대 조용히 생략되지 않는다.
//   5. 참여자 집합이 같으면 계산 순서·타일 정체와 무관하게 같은 값 —
//      부분 쿼드(대각 미표시)에서도 적격 타일들끼리 일치한다.
#include <gtest/gtest.h>

#include <array>
#include <cmath>
#include <map>
#include <vector>

#include "mmp_rviz_plugins/border_stitch.hpp"

namespace bs = mmp_rviz_plugins::border_stitch;

namespace
{
constexpr int G = 5;

// 결정적 의사난수 지형: 타일 (tx,ty)의 (i,j) 표본. 인접 타일이 같은 격자점
// 에서 서로 다른 값을 갖도록 타일 정체를 섞는다(독립 warp 불일치 모사).
float H(int tx, int ty, int i, int j)
{
  const uint32_t s = 2654435761u * (tx * 73856093u ^ ty * 19349663u ^
                                    i * 83492791u ^ j * 297121507u);
  return 100.0f + (s % 10007) * 0.01f;
}

std::vector<float> raw_tile(int tx, int ty)
{
  std::vector<float> h(G * G);
  for (int i = 0; i < G; ++i) {
    for (int j = 0; j < G; ++j) {
      h[i * G + j] = H(tx, ty, i, j);
    }
  }
  return h;
}

struct World
{
  std::map<std::pair<int, int>, std::vector<float>> raw;      // resident
  std::map<std::pair<int, int>, bool> drawn;

  bs::NeighborFn nb_for(int tx, int ty)
  {
    return [this, tx, ty](int dx, int dy) {
             bs::Neighbor n;
             const auto k = std::make_pair(tx + dx, ty + dy);
             auto d = drawn.find(k);
             n.drawn = d != drawn.end() && d->second;
             auto r = raw.find(k);
             if (r != raw.end()) {
               n.raw = r->second.data();
             }
             return n;
           };
  }

  uint32_t sig_for(int tx, int ty)
  {
    // TerrainTilesDisplay::edgeSig의 같은 레벨 부분과 동일한 규칙.
    uint32_t sig = 0;
    for (int e = 0; e < 4; ++e) {
      int dx, dy;
      bs::edge_delta(e, &dx, &dy);
      auto d = drawn.find({tx + dx, ty + dy});
      if (d != drawn.end() && d->second) {
        sig |= 0xFu << (e * 4);
      }
    }
    for (int c = 0; c < 4; ++c) {
      const int dx = (c & 1) ? 1 : -1;
      const int dy = (c & 2) ? 1 : -1;
      auto d = drawn.find({tx + dx, ty + dy});
      if (d != drawn.end() && d->second) {
        sig |= 1u << (16 + c);
      }
    }
    return sig;
  }

  // 타일 하나를 스티칭해 (hc, 최종 sig, same_diff) 반환.
  struct Out
  {
    std::vector<float> hc;
    uint32_t sig;
    float diff[4];
  };
  Out stitch(int tx, int ty)
  {
    Out o;
    o.hc = raw.at({tx, ty});
    o.sig = sig_for(tx, ty);
    bs::apply_same_level(o.hc, raw.at({tx, ty}).data(), G, o.sig,
                         nb_for(tx, ty), o.diff);
    return o;
  }
};

World full_quad()
{
  World w;
  for (int tx = 0; tx <= 1; ++tx) {
    for (int ty = 0; ty <= 1; ++ty) {
      w.raw[{tx, ty}] = raw_tile(tx, ty);
      w.drawn[{tx, ty}] = true;
    }
  }
  return w;
}
}  // namespace

TEST(BorderStitch, SharedEdgeConvergesBitIdentical)
{
  World w = full_quad();
  const auto a = w.stitch(0, 0);          // +x edge (e=1)
  const auto b = w.stitch(1, 0);          // -x edge (e=0)
  for (int k = 0; k < G; ++k) {
    EXPECT_EQ(a.hc[bs::edge_midx(1, k, G)], b.hc[bs::edge_midx(0, k, G)])
      << "k=" << k;
  }
  const auto c = w.stitch(0, 1);          // 공유 y-변도 동일해야 한다
  for (int k = 0; k < G; ++k) {
    EXPECT_EQ(a.hc[bs::edge_midx(3, k, G)], c.hc[bs::edge_midx(2, k, G)]);
  }
}

TEST(BorderStitch, QuadCenterCornerIdenticalAcrossFourTiles)
{
  World w = full_quad();
  // 중앙 격자점: (0,0)의 (+x,+y) 코너 = (1,0)의 (-x,+y) = (0,1)의 (+x,-y)
  // = (1,1)의 (-x,-y).
  const float v00 = w.stitch(0, 0).hc[(G - 1) * G + (G - 1)];
  const float v10 = w.stitch(1, 0).hc[0 * G + (G - 1)];
  const float v01 = w.stitch(0, 1).hc[(G - 1) * G + 0];
  const float v11 = w.stitch(1, 1).hc[0];
  EXPECT_EQ(v00, v10);
  EXPECT_EQ(v00, v01);
  EXPECT_EQ(v00, v11);
  // 그리고 그 값은 네 RAW 코너의 평균이다.
  const double want = (H(0, 0, G - 1, G - 1) + H(1, 0, 0, G - 1) +
                       H(0, 1, G - 1, 0) + H(1, 1, 0, 0)) / 4.0;
  EXPECT_NEAR(v00, want, 1e-4);
}

TEST(BorderStitch, TransientGapBoundedByHalfMeasuredDiff)
{
  World w = full_quad();
  const auto a = w.stitch(0, 0);
  const auto & braw = w.raw.at({1, 0});   // 이웃이 아직 재스티칭 전 = RAW 표시
  float worst = 0.0f;
  for (int k = 0; k < G; ++k) {
    worst = std::max(worst, std::abs(a.hc[bs::edge_midx(1, k, G)] -
                                     braw[bs::edge_nidx(1, k, G)]));
  }
  EXPECT_LE(worst, 0.5f * a.diff[1] + 1e-4f);
  EXPECT_GT(a.diff[1], 0.0f);             // 지형이 실제로 불일치했음을 확인
}

TEST(BorderStitch, DrawnButEvictedParticipantsClearBitsForRetry)
{
  World w = full_quad();
  w.raw.erase({1, 0});                    // 그려졌지만 상주 아님(퇴거)
  const auto a = w.stitch(0, 0);
  EXPECT_EQ((a.sig >> 4) & 0xF, 0u) << "+x edge bit must clear";
  // 대각만 퇴거: 변은 스티칭되고 코너 비트만 해제된다.
  World w2 = full_quad();
  w2.raw.erase({1, 1});
  const auto a2 = w2.stitch(0, 0);
  EXPECT_EQ((a2.sig >> 4) & 0xF, 0xFu);
  EXPECT_EQ((a2.sig >> 16) & 0x8, 0u) << "(+x,+y) corner bit must clear";
}

TEST(BorderStitch, LShapeCornerIdenticalAcrossAllThreeTiles)
{
  // 대각 (1,1)이 그려지지 않은 3-타일 L자 — 프러스텀 경계의 흔한 배치.
  // 초판 규칙("양쪽 변이 같은 레벨일 때만 코너 canonical")은 A만
  // canonical화하고 B/C는 변 평균만 받아 A=(A+B+C)/3, B=(A+B)/2,
  // C=(A+C)/2로 갈라졌다(코덱스 적대 검증). 세 타일 모두 같은 참여자
  // 집합 {A,B,C}를 보고 같은 값에 수렴해야 한다.
  World w = full_quad();
  w.drawn[{1, 1}] = false;
  w.raw.erase({1, 1});
  const float a = w.stitch(0, 0).hc[(G - 1) * G + (G - 1)];
  const float b = w.stitch(1, 0).hc[0 * G + (G - 1)];
  const float c = w.stitch(0, 1).hc[(G - 1) * G + 0];
  EXPECT_EQ(a, b);
  EXPECT_EQ(a, c);
  const double want = (H(0, 0, G - 1, G - 1) + H(1, 0, 0, G - 1) +
                       H(0, 1, G - 1, 0)) / 3.0;
  EXPECT_NEAR(a, want, 1e-4);
}

TEST(BorderStitch, TwoTileFrustumEdgeCornersAgree)
{
  // 좌우 두 타일만 그려진 경우(프러스텀 절단): 공유 변의 양 끝 코너도
  // 두 타일이 같은 값(쌍 평균)이어야 한다.
  World w;
  for (int tx = 0; tx <= 1; ++tx) {
    w.raw[{tx, 0}] = raw_tile(tx, 0);
    w.drawn[{tx, 0}] = true;
  }
  const auto a = w.stitch(0, 0);
  const auto b = w.stitch(1, 0);
  EXPECT_EQ(a.hc[(G - 1) * G + 0], b.hc[0]);                     // (+x,-y)
  EXPECT_EQ(a.hc[(G - 1) * G + (G - 1)], b.hc[G - 1]);           // (+x,+y)
  const double want = (H(0, 0, G - 1, 0) + H(1, 0, 0, 0)) / 2.0;
  EXPECT_NEAR(a.hc[(G - 1) * G + 0], want, 1e-4);
}

TEST(BorderStitch, MixedLevelCornerConvergesThroughAncestor)
{
  // 같은 레벨 A(0,0)·B(1,0)의 +y 쪽에 코어스 조상(d=1)이 그려진 경우:
  // 두 타일의 공유 꼭짓점은 코너 canonical이 아니라 조상 conform이
  // 소유하며, 둘 다 같은 격자점을 같은 값으로 보간해 수렴해야 한다.
  std::vector<float> anc_raw = raw_tile(7, 7);
  World w;
  for (int tx = 0; tx <= 1; ++tx) {
    w.raw[{tx, 0}] = raw_tile(tx, 0);
    w.drawn[{tx, 0}] = true;
  }
  auto run = [&](int tx) {
      World::Out o;
      o.hc = w.raw.at({tx, 0});
      o.sig = w.sig_for(tx, 0);
      o.sig |= 1u << (3 * 4);            // +y edge: coarser at depth 1
      float diff[4];
      bs::apply_same_level(o.hc, w.raw.at({tx, 0}).data(), G, o.sig,
                           w.nb_for(tx, 0), diff);
      const auto anc = [&](int, int, int d) -> const float * {
          return d == 1 ? anc_raw.data() : nullptr;
        };
      bs::apply_coarser(o.hc, G, tx, 0, o.sig, anc);
      return o;
    };
  const auto a = run(0);
  const auto b = run(1);
  EXPECT_EQ(a.hc[(G - 1) * G + (G - 1)], b.hc[0 * G + (G - 1)]);
  // 변 내부도 하나의 조상 표면 위에 있다: A의 +y 변 끝 = B의 +y 변 시작.
  EXPECT_EQ(a.hc[bs::edge_midx(3, G - 1, G)], b.hc[bs::edge_midx(3, 0, G)]);
}

TEST(BorderStitch, DiagonalReappearanceReconvergesAllFour)
{
  // L자(3-mean)로 수렴한 뒤 대각이 나타나면 sig가 바뀌어 재스티칭되고,
  // 네 타일 전부 4-mean으로 다시 같아져야 한다.
  World w = full_quad();
  w.drawn[{1, 1}] = false;
  w.raw.erase({1, 1});
  const float before = w.stitch(0, 0).hc[(G - 1) * G + (G - 1)];
  const uint32_t sig_l = w.stitch(0, 0).sig;

  w.raw[{1, 1}] = raw_tile(1, 1);
  w.drawn[{1, 1}] = true;
  const uint32_t sig_full = w.sig_for(0, 0);
  EXPECT_NE(sig_l & (0x8u << 16), sig_full & (0x8u << 16))
    << "diagonal appearance must change the sig (re-stitch trigger)";
  const float v00 = w.stitch(0, 0).hc[(G - 1) * G + (G - 1)];
  const float v10 = w.stitch(1, 0).hc[0 * G + (G - 1)];
  const float v01 = w.stitch(0, 1).hc[(G - 1) * G + 0];
  const float v11 = w.stitch(1, 1).hc[0];
  EXPECT_EQ(v00, v10);
  EXPECT_EQ(v00, v01);
  EXPECT_EQ(v00, v11);
  EXPECT_NE(before, v00);               // 실제로 값이 갱신됐음(3-mean != 4-mean)
}

// [V-2] 발행자 절반의 계약: Run 마다 다른 mission_id.
//
// ReplanFSM 은 mission_id 를 부등호로만 쓴다(replan_fsm.cpp:1102-1104). 같은
// 값이 다시 오면 "같은 미션의 재계획" 으로 읽고 명령된 시작점을 채택하지
// 않는다. 패널이 상수를 보내는 동안 두 번째 미션부터 이전 미션의 궤적점에서
// 계획됐고, 재현 측정은 9.24 km 어긋남이었다
// (path_manager/test/mission_sequence_test.cpp).
//
// 그 재현 시험이 단일변수 대조로 보인 것은 "mission_id 만 바꾸면 채택된다"
// 이다. 그러니 이 파일이 그 나머지 절반을 못박는다 — 발행자가 정말로 Run
// 마다 다른 값을 내는가.
//
// 상수로 되돌리면 첫 번째 검사가 죽는다. 그것이 이 파일의 존재 이유다.

#include <gtest/gtest.h>

#include <string>

#include "mmp_rviz_plugins/mission_command.hpp"

namespace
{

mmp_rviz_plugins::ParsedMission sampleMission()
{
  mmp_rviz_plugins::ParsedMission m;
  m.yaml_stem = "r1_coastal_terrain_following";
  m.start.x = 30.0;   m.start.y = 150.0;  m.start.z = 300.0;   // yaml 은 미터
  m.goal.x  = 330.0;  m.goal.y  = 150.0;  m.goal.z  = 150.0;
  m.initial_speed_mps = 200.0;
  m.use_initial_speed = true;
  return m;
}

}  // namespace

// ── 이것이 V-2 의 회귀망이다 ────────────────────────────────────────────
TEST(MissionCommand, ConsecutiveRunsOfTheSameMissionGetDifferentIds)
{
  const auto m = sampleMission();
  const auto a = mmp_rviz_plugins::buildTrajectoryCommand(m, 1);
  const auto b = mmp_rviz_plugins::buildTrajectoryCommand(m, 2);

  // 미션 내용이 완전히 같아도 Run 이 다르면 다른 미션이다. 같은 값을 보내면
  // ReplanFSM 이 명령된 시작점을 통째로 무시한다.
  EXPECT_NE(a.mission_id, b.mission_id)
      << "같은 미션을 두 번 Run 했는데 mission_id 가 같다 — 두 번째 Run 은 "
         "이전 미션의 궤적점에서 계획된다";
  EXPECT_FALSE(a.mission_id.empty());
}

TEST(MissionCommand, IdCarriesTheStemAndTheSequence)
{
  const auto m = sampleMission();
  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(m, 7);
  EXPECT_EQ(c.mission_id, "r1_coastal_terrain_following#7");
  EXPECT_EQ(c.sequence, 7);
}

TEST(MissionCommand, IdStaysUniqueWithoutAStem)
{
  // 파일 없이 구성한 미션이라 stem 이 비어도 Run 마다 달라야 한다 —
  // 식별을 파일명에 의존하지 않는다.
  mmp_rviz_plugins::ParsedMission m = sampleMission();
  m.yaml_stem.clear();
  EXPECT_NE(mmp_rviz_plugins::buildTrajectoryCommand(m, 1).mission_id,
            mmp_rviz_plugins::buildTrajectoryCommand(m, 2).mission_id);
}

// ── 옮기면서 조용히 바뀌기 쉬운 것들 ───────────────────────────────────
TEST(MissionCommand, ZIsConvertedToPlannerUnitsAndXyIsNot)
{
  auto m = sampleMission();
  m.waypoints.resize(1);
  m.waypoints[0].x = 200.0; m.waypoints[0].y = 100.0; m.waypoints[0].z = 250.0;

  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(m, 1);
  // 1 unit = 100 m, z 만 나눈다. xy 는 이미 단위계다.
  EXPECT_DOUBLE_EQ(c.start_position.x, 30.0);
  EXPECT_DOUBLE_EQ(c.start_position.y, 150.0);
  EXPECT_DOUBLE_EQ(c.start_position.z, 3.0);
  EXPECT_DOUBLE_EQ(c.target_position.z, 1.5);
  ASSERT_EQ(c.waypoints.size(), 2u);
  EXPECT_DOUBLE_EQ(c.waypoints[0].z, 2.5);
}

TEST(MissionCommand, TargetIsAppendedAsTheLastWaypoint)
{
  auto m = sampleMission();
  m.waypoints.resize(2);
  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(m, 1);
  ASSERT_EQ(c.waypoints.size(), 3u);
  EXPECT_DOUBLE_EQ(c.waypoints.back().x, c.target_position.x);
  EXPECT_DOUBLE_EQ(c.waypoints.back().z, c.target_position.z);
}

TEST(MissionCommand, PlannerOwnedDefaultsStayZero)
{
  // 0 = "플래너의 yaml 값을 써라". 1.0 을 박았을 때 MINCO 조각이 6배 작아져
  // 최적화기가 지름길 폴리라인을 따라가기만 했다.
  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(sampleMission(), 1);
  EXPECT_DOUBLE_EQ(c.length_per_piece, 0.0);
  EXPECT_DOUBLE_EQ(c.obstacle_clearance, 0.0);
}

TEST(MissionCommand, TheStatedInitialSpeedSurvives)
{
  // 진술이 없으면 triggerGlobalPlan 이 INITIAL_STATE_UNSPECIFIED 로 거절한다.
  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(sampleMission(), 1);
  EXPECT_TRUE(c.use_initial_speed);
  EXPECT_DOUBLE_EQ(c.initial_speed, 200.0);
  EXPECT_FALSE(c.use_initial_velocity);
}

// ── resolver response -> command: values travel verbatim ────────────────
namespace
{

mmp_mission_msgs::msg::ResolvedMission sampleResolved()
{
  mmp_mission_msgs::msg::ResolvedMission r;
  r.start.x = 10.0;  r.start.y = 20.0;  r.start.z = 100.0;   // z: metres AGL
  r.goal.x = 40.0;   r.goal.y = 50.0;   r.goal.z = 150.0;
  r.waypoints.resize(3);
  r.waypoints[0].x = 15.0; r.waypoints[0].y = 25.0; r.waypoints[0].z = 110.0;
  r.waypoints[1].x = 20.0; r.waypoints[1].y = 30.0; r.waypoints[1].z = 120.0;
  r.waypoints[2].x = 30.0; r.waypoints[2].y = 40.0; r.waypoints[2].z = 130.0;
  r.formation_type = "line";
  r.formation_scale = 50.0;
  r.initial_speed_mps = 180.0;
  r.use_initial_speed = true;
  r.use_final_velocity = true;
  r.final_velocity_mps.x = 120.0;
  r.final_velocity_mps.y = -3.0;
  r.final_velocity_mps.z = 0.5;
  r.mission_sha256 = "deadbeef";
  r.frame_digest = "cafebabe";
  return r;
}

}  // namespace

TEST(FromResolved, WaypointOrderCountAndZSurviveToTheWire)
{
  // Waypoint order/count/z survive to the wire; the /100 z conversion
  // happens exactly once, in buildTrajectoryCommand.
  const auto m = mmp_rviz_plugins::fromResolved(sampleResolved(), "r9_test");
  ASSERT_EQ(m.waypoints.size(), 3u);
  EXPECT_DOUBLE_EQ(m.waypoints[1].z, 120.0);        // 여기서는 아직 미터

  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(m, 3);
  ASSERT_EQ(c.waypoints.size(), 4u);                // 3 + appended goal
  EXPECT_DOUBLE_EQ(c.waypoints[0].x, 15.0);
  EXPECT_DOUBLE_EQ(c.waypoints[1].x, 20.0);
  EXPECT_DOUBLE_EQ(c.waypoints[2].x, 30.0);         // order preserved
  EXPECT_DOUBLE_EQ(c.waypoints[1].z, 1.2);          // metres -> u, once
  EXPECT_DOUBLE_EQ(c.start_position.z, 1.0);
  EXPECT_DOUBLE_EQ(c.target_position.z, 1.5);
  EXPECT_DOUBLE_EQ(c.waypoints.back().z, c.target_position.z);
  EXPECT_EQ(c.mission_id, "r9_test#3");
}

TEST(FromResolved, InitialAndFinalStateTravelVerbatim)
{
  // No re-validation, re-projection or clamping — touching values here
  // revives the duplicate implementation the panel shed.
  const auto m = mmp_rviz_plugins::fromResolved(sampleResolved(), "s");
  const auto c = mmp_rviz_plugins::buildTrajectoryCommand(m, 1);
  EXPECT_TRUE(c.use_initial_speed);
  EXPECT_DOUBLE_EQ(c.initial_speed, 180.0);
  EXPECT_FALSE(c.use_initial_velocity);
  EXPECT_TRUE(c.use_final_velocity);
  EXPECT_DOUBLE_EQ(c.final_velocity.x, 120.0);
  EXPECT_DOUBLE_EQ(c.final_velocity.y, -3.0);
  EXPECT_DOUBLE_EQ(c.final_velocity.z, 0.5);
  EXPECT_FALSE(c.use_final_acceleration);
  EXPECT_EQ(c.formation_type, "line");
  EXPECT_DOUBLE_EQ(c.formation_scale, 50.0);
}

// ── response gate: a mutation turning any refusal into kAccept dies here ─
namespace
{

mmp_mission_msgs::srv::LoadMap::Response goodResponse()
{
  mmp_mission_msgs::srv::LoadMap::Response r;
  r.success = true;
  r.request_token = "r9#4";
  r.mission_resolved = true;
  r.mission = sampleResolved();          // mission_sha256 = "deadbeef"
  r.actual_resolution_m = 30.0;
  return r;
}

}  // namespace

TEST(ResponseGate, AcceptsOnlyTheFullyProvenResponse)
{
  using mmp_rviz_plugins::ResponseGate;
  const auto ok = goodResponse();
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(ok, "r9#4", "deadbeef", 4, 4),
            ResponseGate::kAccept);
}

TEST(ResponseGate, StaleTokenIsRefused)
{
  // A late old response must not pose as the newest Run's mission.
  using mmp_rviz_plugins::ResponseGate;
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(
              goodResponse(), "r9#5", "deadbeef", 4, 4),
            ResponseGate::kStaleToken);
}

TEST(ResponseGate, UnresolvedResponseIsRefused)
{
  // Consuming a pre-ResolvedMission server's zero-struct flies to (0,0)
  // — the spot of the old publish-immediately fail-open.
  using mmp_rviz_plugins::ResponseGate;
  auto r = goodResponse();
  r.mission_resolved = false;
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(r, "r9#4", "deadbeef", 4, 4),
            ResponseGate::kNotResolved);
}

TEST(ResponseGate, ShaMismatchIsRefused)
{
  // The server parsed different bytes than the user's file (rewritten
  // after the request).
  using mmp_rviz_plugins::ResponseGate;
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(
              goodResponse(), "r9#4", "0123abcd", 4, 4),
            ResponseGate::kShaMismatch);
}

TEST(ResponseGate, MissingGeometryIsRefused)
{
  // Without corridor geometry the receipt gate cannot match anything —
  // the old code published immediately here (fail-open, removed).
  using mmp_rviz_plugins::ResponseGate;
  auto r = goodResponse();
  r.actual_resolution_m = 0.0;
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(r, "r9#4", "deadbeef", 4, 4),
            ResponseGate::kNoGeometry);
}

TEST(ResponseGate, SelectionChangeDuringFlightIsRefused)
{
  // Request A in flight, the user switches the file field to B: A's answer
  // still matches its OWN token and sha, so only the selection generation
  // can refuse it — otherwise the screen shows B while A gets published.
  using mmp_rviz_plugins::ResponseGate;
  EXPECT_EQ(mmp_rviz_plugins::gateResolvedResponse(
              goodResponse(), "r9#4", "deadbeef", 4, 5),
            ResponseGate::kSelectionChanged);
}

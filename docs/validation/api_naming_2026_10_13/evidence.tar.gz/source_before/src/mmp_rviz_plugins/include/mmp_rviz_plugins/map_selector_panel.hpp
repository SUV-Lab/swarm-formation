#ifndef MMP_RVIZ_PLUGINS__MAP_SELECTOR_PANEL_HPP_
#define MMP_RVIZ_PLUGINS__MAP_SELECTOR_PANEL_HPP_

#include <QLabel>
#include <QPushButton>
#include <QTimer>
#include <QVBoxLayout>

#include <sys/types.h>

#include <string>

#include "rclcpp/rclcpp.hpp"
#include "rviz_common/panel.hpp"
#include "rviz_common/display_context.hpp"
#include "rviz_common/ros_integration/ros_node_abstraction.hpp"

namespace mmp_rviz_plugins
{

// MMP Control: path_manager launch tree start/stop. (Map selection was
// removed 2026-07-25: the corridor auto-load owns the world now — missions
// pick their own terrain, so there is nothing left to select by hand.)
class MapSelectorPanel : public rviz_common::Panel
{
  Q_OBJECT

public:
  explicit MapSelectorPanel(QWidget * parent = nullptr);
  virtual ~MapSelectorPanel();

  virtual void onInitialize() override;

private Q_SLOTS:
  // launch control
  void onStartClicked();
  void onStopClicked();
  void onPollProcess();
  void onForceKillIfStillRunning();

private:
  // ---- launch control helpers ----
  enum class LaunchState { NotRunning, Running, Stopping, Crashed };
  void setLaunchState(LaunchState s, const QString & detail = QString());
  bool spawnLaunch(const std::string & launch_cmd);
  void sendSignal(int sig);
  // Returns the currently-selected map name (terrain_publisher's `world`
  // parameter) so we can pass it through to the launch tree as `world:=...`.
  // Empty string on failure — caller falls back to the launch defaults.
  std::string fetchCurrentWorld();

  rclcpp::Node::SharedPtr node_;

  // ---- launch control widgets / state ----
  QPushButton * start_button_;
  QPushButton * stop_button_;
  QLabel * launch_status_label_;
  QTimer * poll_timer_;
  QTimer * force_kill_timer_;

  pid_t child_pgid_ = -1;
  LaunchState launch_state_ = LaunchState::NotRunning;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__MAP_SELECTOR_PANEL_HPP_

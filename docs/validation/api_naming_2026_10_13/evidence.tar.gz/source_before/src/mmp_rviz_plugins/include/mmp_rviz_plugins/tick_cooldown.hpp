#ifndef MMP_RVIZ_PLUGINS__TICK_COOLDOWN_HPP_
#define MMP_RVIZ_PLUGINS__TICK_COOLDOWN_HPP_

// The display expresses every backoff as "not before stamp_ + n", where stamp_
// counts ticks. That only works if the counter advances on EVERY tick.
//
// It did not. tick() returned early when the meta fetch had not succeeded, and
// the increment sat below that return, so a failed fetch set a cooldown the
// counter could never reach. A tile server that came up a minute late was
// never retried; the display said "Connection refused" for the whole session
// and only restarting rviz -- which builds a fresh object with stamp_ = 0 --
// recovered it. Toggling the checkbox did not, because the stamp and the
// cooldown are members that survive disable/enable.
//
// This models just that: a counter and a gate, so a test can hold the failing
// path open for as long as it likes and still demand a retry.

#include <cstdint>

namespace mmp_rviz_plugins
{

/// One tick counter with cooldown gates hung off it.
class TickClock
{
public:
  /// Call once at the top of every tick, before any early return.
  void advance() {++stamp_;}

  uint64_t stamp() const {return stamp_;}

  /// May an action guarded by `not_before` run now?
  bool ready(uint64_t not_before) const {return stamp_ >= not_before;}

  /// The stamp an action should wait for after failing, `ticks` from now.
  uint64_t backoff(uint64_t ticks) const {return stamp_ + ticks;}

private:
  uint64_t stamp_ = 0;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__TICK_COOLDOWN_HPP_

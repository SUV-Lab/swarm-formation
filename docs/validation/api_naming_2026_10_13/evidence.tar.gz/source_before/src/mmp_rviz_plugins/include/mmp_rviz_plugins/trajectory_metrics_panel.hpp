#ifndef MMP_RVIZ_PLUGINS__TRAJECTORY_METRICS_PANEL_HPP_
#define MMP_RVIZ_PLUGINS__TRAJECTORY_METRICS_PANEL_HPP_

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/panel.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>

#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <mmp_traj_msgs/msg/poly_traj.hpp>
#include <mmp_mission_msgs/msg/risk_zone_array.hpp>
#include <grid_map_msgs/msg/grid_map.hpp>
#include <mmp_vehicle_dynamics/flight_dynamics.hpp>
#include <std_msgs/msg/float64_multi_array.hpp>

#include <QWidget>
#include <QTableWidget>
#include <QLabel>
#include <cstdint>
#include <vector>
#include <unordered_map>

namespace mmp_rviz_plugins
{

struct ObstacleGeom
{
  enum Shape { ELLIPSE, RECT };
  Shape shape;
  double cx, cy, cz;
  double sx, sy, sz;  // full collision extents; sz <= 0 means an infinite column
  double yaw;     // heading about +Z from the marker orientation (RECT);
                  // collision primitives are oriented, so the test must be too
};

// Nominal risk-zone geometry from /mission/risk_zones. The planner derives the
// effective AGL-grounded center and vertical semi-axis from live parameters.
struct RiskGeom
{
  double cx, cy, cz;
  double reach;
  double peak;
};

// Authoritative terrain-masked risk sampled by PathManager on the optimized
// trajectory and published in /viz/risk_profile v3/v4.
struct RiskProfileSample
{
  double x, y, z;
  double risk;
};

class TrajectoryMetricsPanel : public rviz_common::Panel
{
  Q_OBJECT

public:
  explicit TrajectoryMetricsPanel(QWidget * parent = nullptr);
  ~TrajectoryMetricsPanel() override;

  void onInitialize() override;

private:
  void trajectoryCallback(const mmp_traj_msgs::msg::PolyTraj::SharedPtr msg);
  void dynamicObstacleArrayCallback(
    const visualization_msgs::msg::MarkerArray::SharedPtr msg);
  void riskZoneArrayCallback(const mmp_mission_msgs::msg::RiskZoneArray::SharedPtr msg);
  void riskProfileCallback(const std_msgs::msg::Float64MultiArray::SharedPtr msg);
  void gridMapCallback(const grid_map_msgs::msg::GridMap::SharedPtr msg);
  // Terrain elevation at (x,y) in FRAME units (1 = 100 m), bilinear. Returns
  // NaN over open water (no elevation) — callers treat that as sea level 0.
  // Ported from AltitudeProfilePanel so the two panels sample terrain identically.
  float getElevationAt(double x, double y);

  void recomputeMetrics();
  // Coalesces a burst of data updates (obstacles, risk geometry and the risk
  // profile land back to back) into a single recomputeMetrics per event-loop
  // pass. GUI thread only.
  void scheduleRecompute();
  void setRow(int row, const QString & name, const QString & value,
              const QString & note = QString(), const QColor & value_color = QColor());

  rclcpp::Node::SharedPtr node_;

  // Shared fixed-wing flight-envelope parameters, live-synced from the
  // planner. Defaults match the shared model until the parameter service is
  // available.
  double dyn_unit_xy_m_     = 100.0;
  double dyn_unit_z_m_      = 100.0;
  double terrain_clearance_target_m_ = 50.0;
  double risk_vertical_ratio_ = 0.35;
  bool risk_zone_agl_ = false;
  mmp_vehicle_dynamics::Parameters dynamics_params_;
  bool   dyn_params_live_   = false;
  std::shared_ptr<rclcpp::AsyncParametersClient> dyn_param_client_;
  rclcpp::TimerBase::SharedPtr dyn_param_timer_;
  void fetchDynParams();
  void fetchDynParamsNow();

  rclcpp::Subscription<mmp_traj_msgs::msg::PolyTraj>::SharedPtr trajectory_sub_;
  rclcpp::Subscription<visualization_msgs::msg::MarkerArray>::SharedPtr
    dynamic_obstacle_sub_;
  rclcpp::Subscription<mmp_mission_msgs::msg::RiskZoneArray>::SharedPtr risk_sub_;
  rclcpp::Subscription<std_msgs::msg::Float64MultiArray>::SharedPtr risk_profile_sub_;
  rclcpp::Subscription<grid_map_msgs::msg::GridMap>::SharedPtr grid_map_sub_;

  mmp_traj_msgs::msg::PolyTraj::SharedPtr latest_traj_;

  // Latched terrain DEM (grid_map) for the terrain-clearance metric.
  grid_map_msgs::msg::GridMap::SharedPtr terrain_map_;
  bool terrain_received_ = false;

  // Source-tagged key (source << 32 | marker id) keeps runtime marker ids
  // distinct should another obstacle feed ever be added back.
  std::unordered_map<int64_t, ObstacleGeom> obstacles_;
  std::unordered_map<int, RiskGeom> risks_;
  int risk_profile_version_ = 0;
  size_t risk_profile_zone_count_ = 0;
  std::vector<RiskProfileSample> risk_profile_;

  QTableWidget * table_;
  QLabel * title_label_;
  bool recompute_pending_ = false;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__TRAJECTORY_METRICS_PANEL_HPP_

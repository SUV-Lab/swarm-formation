#ifndef MMP_RVIZ_PLUGINS__DYN_PARAM_MAP_HPP_
#define MMP_RVIZ_PLUGINS__DYN_PARAM_MAP_HPP_

// TrajectoryMetrics 패널의 dynamics 파라미터 수신 계약 — Qt 없이 시험
// 가능하도록 추출된 순수 매핑. 패널이 이 이름 목록으로 get_parameters를
// 부르고, 도착한 벡터를 applyDynParams가 스냅숏으로 해석한다.
// dyn_param_probe_test가 프로브('/' 이름은 정확한 전체 이름으로만 매칭)와
// 함께 "플래너의 122.0이 실제로 이 매핑을 통과해 speed_min에 도달한다"를
// 행동으로 고정한다 — 시험과 주장이 같은 코드를 지나가게 하기 위함.

#include <cmath>
#include <string>
#include <vector>

#include <rclcpp/parameter.hpp>
#include <mmp_vehicle_dynamics/flight_dynamics.hpp>

namespace mmp_rviz_plugins
{

struct DynParamSnapshot
{
  mmp_vehicle_dynamics::Parameters params;
  double unit_xy_m = 0.0;
  double unit_z_m = 0.0;
  double terrain_clearance_target_m = 0.0;
  double risk_vertical_ratio = 0.0;
  bool risk_zone_agl = false;
};

inline const std::vector<std::string> & dynParamNames()
{
  static const std::vector<std::string> names = {
    "optimization/dynamics_unit_xy_m",
    "optimization/dynamics_unit_z_m",
    "optimization/dynamics_mass_kg",
    "optimization/dynamics_wing_area_m2",
    "optimization/dynamics_g",
    "optimization/dynamics_rho0_kgpm3",
    "optimization/dynamics_density_scale_height_m",
    "optimization/dynamics_altitude_reference_m",
    "optimization/dynamics_cd0",
    "optimization/dynamics_induced_drag_factor",
    "optimization/dynamics_cl_min",
    "optimization/dynamics_cl_max",
    "optimization/dynamics_load_factor_max",
    "optimization/dynamics_thrust_min_n",
    "optimization/dynamics_thrust_max_n",
    "optimization/dynamics_speed_min_mps",
    "optimization/dynamics_speed_max_mps",
    "optimization/dynamics_activation_speed_mps",
    "optimization/dynamics_dynamic_pressure_max_pa",
    "optimization/dynamics_bank_max_deg",
    "optimization/dynamics_flight_path_max_deg",
    "optimization/dynamics_margin",
    "optimization/obstacle_clearance",
    "manager/risk_vertical_ratio",
    "manager/risk_zone_agl",
  };
  return names;
}

// dynParamNames() 순서의 파라미터 벡터를 스냅숏으로 해석. 크기 불일치·
// 비정상 값(단위/여유 <= 0, 동역학 파라미터 무효)은 false — 호출자는
// 기존 상태를 유지한다.
inline bool applyDynParams(const std::vector<rclcpp::Parameter> & ps,
                           const mmp_vehicle_dynamics::Parameters & base,
                           DynParamSnapshot & out)
{
  if (ps.size() != dynParamNames().size()) {
    return false;
  }
  size_t i = 0;
  const double unit_xy = ps[i++].as_double();
  const double unit_z = ps[i++].as_double();
  mmp_vehicle_dynamics::Parameters candidate = base;
  candidate.mass_kg = ps[i++].as_double();
  candidate.wing_area_m2 = ps[i++].as_double();
  candidate.gravity_mps2 = ps[i++].as_double();
  candidate.sea_level_density_kgpm3 = ps[i++].as_double();
  candidate.density_scale_height_m = ps[i++].as_double();
  candidate.altitude_reference_m = ps[i++].as_double();
  candidate.zero_lift_drag_coefficient = ps[i++].as_double();
  candidate.induced_drag_factor = ps[i++].as_double();
  candidate.lift_coefficient_min = ps[i++].as_double();
  candidate.lift_coefficient_max = ps[i++].as_double();
  candidate.load_factor_max = ps[i++].as_double();
  candidate.thrust_min_n = ps[i++].as_double();
  candidate.thrust_max_n = ps[i++].as_double();
  candidate.speed_min_mps = ps[i++].as_double();
  candidate.speed_max_mps = ps[i++].as_double();
  candidate.model_activation_speed_mps = ps[i++].as_double();
  candidate.dynamic_pressure_max_pa = ps[i++].as_double();
  candidate.bank_angle_max_rad = ps[i++].as_double() * M_PI / 180.0;
  candidate.flight_path_angle_max_rad = ps[i++].as_double() * M_PI / 180.0;
  candidate.constraint_margin = ps[i++].as_double();
  const double clearance_u = ps[i++].as_double();
  const double risk_vertical_ratio = ps[i++].as_double();
  const bool risk_zone_agl = ps[i++].as_bool();
  if (unit_xy <= 0.0 || unit_z <= 0.0 ||
    clearance_u <= 0.0 || risk_vertical_ratio <= 0.0 ||
    !mmp_vehicle_dynamics::parametersAreValid(candidate))
  {
    return false;
  }
  out.params = candidate;
  out.unit_xy_m = unit_xy;
  out.unit_z_m = unit_z;
  out.terrain_clearance_target_m = clearance_u * unit_z;
  out.risk_vertical_ratio = risk_vertical_ratio;
  out.risk_zone_agl = risk_zone_agl;
  return true;
}

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__DYN_PARAM_MAP_HPP_

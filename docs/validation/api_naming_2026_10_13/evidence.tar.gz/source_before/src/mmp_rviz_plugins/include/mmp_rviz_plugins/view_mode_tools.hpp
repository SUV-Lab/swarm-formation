#ifndef MMP_RVIZ_PLUGINS__VIEW_MODE_TOOLS_HPP_
#define MMP_RVIZ_PLUGINS__VIEW_MODE_TOOLS_HPP_

#include "rviz_common/tool.hpp"
#include <QString>

namespace mmp_rviz_plugins
{

// Tool: FPS follow-camera that tracks drone_0_base from behind
class FollowCameraTool : public rviz_common::Tool
{
  Q_OBJECT
public:
  FollowCameraTool() = default;
  ~FollowCameraTool() override = default;

  void onInitialize() override {}
  void activate() override;
  void deactivate() override {}
  int processMouseEvent(rviz_common::ViewportMouseEvent & event) override;
};

// Tool: Switches to top-down orthogonal view
class OrthoViewTool : public rviz_common::Tool
{
  Q_OBJECT
public:
  OrthoViewTool() = default;
  ~OrthoViewTool() override = default;

  void onInitialize() override {}
  void activate() override;
  void deactivate() override {}
  int processMouseEvent(rviz_common::ViewportMouseEvent & event) override;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__VIEW_MODE_TOOLS_HPP_

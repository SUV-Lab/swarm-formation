#ifndef MMP_RVIZ_PLUGINS__TERRAIN_TILES_DISPLAY_HPP_
#define MMP_RVIZ_PLUGINS__TERRAIN_TILES_DISPLAY_HPP_

// Streaming quadtree terrain for RViz: screen-space-error LOD + frustum
// culling, tiles fetched from the globe tile server's frame-native endpoints
// (/ftile/*, a quadtree directly in planner world units, so there is no
// map-projection code here at all). Rendering only — the planner keeps
// consuming grid_map topics.
//
// Why not grid_map: a grid_map is ONE flat message at ONE resolution, so a
// nationwide map is capped at 250 m. Here only the tiles the camera can see
// are resident, each at the resolution that view needs, so the on-screen
// triangle count is independent of map size.

#include <deque>
#include <map>
#include <set>
#include <memory>
#include <string>
#include <tuple>
#include <vector>

#include <QByteArray>
#include <QNetworkAccessManager>
#include <QTimer>

#include <OgreManualObject.h>
#include <OgreMaterial.h>
#include <OgreQuaternion.h>
#include <OgreTexture.h>
#include <OgreVector3.h>

#include "rviz_common/display.hpp"
#include "mmp_rviz_plugins/teleport.hpp"
#include "rclcpp/rclcpp.hpp"

namespace rviz_common
{
namespace properties
{
class StringProperty;
class IntProperty;
class FloatProperty;
class BoolProperty;
}  // namespace properties
}  // namespace rviz_common

namespace Ogre
{
class Camera;
}

class QNetworkReply;

namespace mmp_rviz_plugins
{

class TerrainTilesDisplay : public rviz_common::Display
{
  Q_OBJECT

public:
  TerrainTilesDisplay();
  ~TerrainTilesDisplay() override;

protected:
  void onInitialize() override;
  void onEnable() override;
  void onDisable() override;
  void reset() override;

private Q_SLOTS:
  void tick();
  void drain();      // budgeted mesh building (a few ms per frame)

private:
  struct TileKey
  {
    int z, x, y;
    bool operator<(const TileKey & o) const
    {
      return std::tie(z, x, y) < std::tie(o.z, o.x, o.y);
    }
    bool operator==(const TileKey & o) const
    {
      return z == o.z && x == o.x && y == o.y;
    }
    TileKey parent() const {return TileKey{z - 1, x / 2, y / 2};}
    std::string str() const
    {
      return std::to_string(z) + "_" + std::to_string(x) + "_" + std::to_string(y);
    }
  };

  struct Tile
  {
    Ogre::ManualObject * obj = nullptr;
    Ogre::MaterialPtr material;
    Ogre::TexturePtr texture;
    // Height payload kept resident (16.9 KB) so LOD-boundary edges can be
    // re-stitched against this tile when a finer neighbour needs its actual
    // surface heights, and so this tile's own mesh can be rebuilt without a
    // refetch when its edge situation changes.
    QByteArray hgt;
    // Which coarser-neighbour depths (4 bits per edge) the current mesh's
    // borders were conformed to. Levels are resampled independently, so a
    // fine tile's border only meets a coarser neighbour's surface if it is
    // pulled onto it explicitly — this records what the mesh assumes.
    uint32_t edge_sig = 0;
    uint64_t last_used = 0;      // LRU stamp
    bool visible = false;
    bool adaptive = true;        // skirt style this mesh was built with
  };

  // Tiles whose bytes have arrived but whose mesh is not yet built. Building
  // happens on a budget (a few ms per frame) instead of inside the network
  // callbacks — a burst of 40 replies used to decode+mesh 40 tiles in ONE
  // event-loop turn (~200 ms), which is the stutter on every zoom.
  struct Ready
  {
    TileKey key;
    QByteArray hgt;
    QByteArray img;
  };

  struct Pending
  {
    QByteArray hgt;
    QByteArray img;
    bool hgt_done = false;
    bool img_done = false;
    bool failed = false;
    uint64_t stamp = 0;      // tick when requested (zombie sweep)
    // Live replies, nulled by their finished-lambdas; the zombie sweep
    // abort()s whatever is still set so a written-off request actually
    // releases its socket instead of haunting the pool.
    QNetworkReply * rh = nullptr;
    QNetworkReply * ri = nullptr;
  };

  void fetchMeta();
  void requestTile(const TileKey & key);
  void buildTile(const TileKey & key, const QByteArray & hgt, const QByteArray & img);
  // Emit (or re-emit) the tile's ManualObject from its stored heights, with
  // LOD-boundary borders conformed per `sig`. Texture/material are reused.
  void buildMesh(const TileKey & key, Tile & tile, uint32_t sig);
  // bits [4e..4e+3] per edge (-x,+x,-y,+y): 0xF = same-level neighbour drawn
  // (canonical average stitch), 1..4 = coarser ancestor depth, 0 = nothing
  // drawn (finer/culled). bits 16+c flag drawn same-level DIAGONALS for the
  // 4-way corner rule (see border_stitch.hpp).
  uint32_t edgeSig(const TileKey & key) const;
  void destroyTile(const TileKey & key);
  void destroyAll();

  // Quadtree traversal: draws a node OR its four children, never both (see .cpp).
  // Returns true when the node's area is fully covered by what it queued.
  // `visible` is append-only with size-mark rollback (no per-node containers).
  bool cover(const TileKey & key, const Ogre::Camera * cam, double px_per_unit_at_1,
             std::vector<TileKey> * visible, double thr);

  // Qt caps HTTP/1.1 at SIX concurrent connections PER HOST per manager, so a
  // single QNetworkAccessManager throttles us to 6 tiles in flight — with a
  // cold cache (server cutting each tile from remote imagery, seconds each)
  // that alone makes the ring crawl in. A small pool of managers multiplies
  // the limit; requests go to the least-loaded manager (nam_load_ counts
  // outstanding requests per manager).
  std::vector<QNetworkAccessManager *> nams_;
  std::vector<int> nam_load_;
  int pickNam();
  QTimer * timer_ = nullptr;
  QTimer * drain_timer_ = nullptr;
  std::deque<Ready> ready_;

  rviz_common::properties::StringProperty * url_property_;
  rviz_common::properties::FloatProperty * detail_property_;      // max screen-space error (px)
  rviz_common::properties::IntProperty * budget_property_;        // resident tile cap
  rviz_common::properties::IntProperty * level_property_;         // -1 = auto
  rviz_common::properties::FloatProperty * exaggeration_property_;
  rviz_common::properties::BoolProperty * adaptive_skirt_property_;  // border-relief skirt depth
  rviz_common::properties::BoolProperty * backface_property_;        // CULL_ANTICLOCKWISE toggle

  // /ftile/meta
  bool meta_ok_ = false;
  bool meta_inflight_ = false;
  uint64_t meta_retry_after_ = 0;   // failure cooldown (tick stamp)
  double root_ = 16384.0;
  int grid_ = 65;
  int maxz_ = 9;
  double lx_ = 0.0, ly_ = 0.0;
  double z_top_u_ = 40.0;   // terrain ceiling for cull boxes (from /ftile/meta)

  std::map<TileKey, Tile> tiles_;
  std::map<TileKey, std::shared_ptr<Pending>> pending_;
  // Keys whose bytes have arrived and are queued in ready_ but not yet built.
  // tick() must skip re-requesting these: it previously gated only on tiles_
  // and pending_, so a key sitting in ready_ (fetched, awaiting drain) was
  // re-fetched, re-decoded, and pushed to ready_ AGAIN — the duplicate then
  // hit buildTile's tiles_.count(key) early-return, decoding+destroying a
  // redundant QImage every frame. That redundant decode churn is the
  // intermittent "stack smashing" abort site (buildTile+0x138).
  std::set<TileKey> ready_keys_;
  // The /ftile/* endpoints serve the full-map frame only. If the planner runs
  // another world, the tiles would silently render the full map under
  // that mission — poll terrain_publisher's 'world'
  // param and blank the display with an error status on mismatch.
  rclcpp::AsyncParametersClient::SharedPtr world_client_;
  uint64_t world_poll_stamp_ = 0;
  bool world_ok_ = true;
  std::string active_world_ = "full_map";

  // Failure cooldown (tick stamp until which a tile may not be re-requested).
  // Without it a down/restarting server got every wanted tile re-fired each
  // 100 ms tick — kMaxInflight x 2 HTTP requests in a permanent retry storm,
  // thundering-herding the server exactly as it came back up.
  std::map<TileKey, uint64_t> retry_after_;
  std::vector<std::pair<double, TileKey>> want_;   // (distance, key) to request
  // Drawn set of the last tick (sorted) — the authority edgeSig() consults
  // for what is actually rendered next to a tile.
  std::vector<TileKey> last_visible_;
  // Tiles whose borders must be re-stitched to a changed neighbour LOD.
  // Processed in drain() under the frame budget; keys deduped.
  std::deque<TileKey> restitch_;
  std::set<TileKey> restitch_keys_;
  std::set<TileKey> split_;                        // hysteresis: nodes currently split
  size_t leaf_count_ = 0;    // leaves produced by the last cover() pass
  size_t visited_ = 0;       // nodes traversed by the last cover() pass
  size_t culled_ = 0;        // nodes frustum-culled by the last cover() pass
  // Effective refinement threshold carried across ticks (decays toward the
  // Detail property only when the previous tick had headroom). Resetting it
  // every tick made the whole screen pump sharp<->coarse whenever leaf
  // demand hovered near the budget.
  double thr_carry_ = 0.0;
  int escalations_ = 0;      // threshold notches the last tick needed
  // Highest threshold that overflowed under the CURRENT view: decay may not
  // re-enter it (prevents a slow re-split sawtooth under a static camera).
  // Cleared when the camera moves CUMULATIVELY away from the pose where the
  // floor was set (floor_pos_/floor_ori_ anchor), or on a demand collapse.
  double fail_floor_ = 0.0;
  Ogre::Vector3 floor_pos_ = Ogre::Vector3::ZERO;
  Ogre::Quaternion floor_ori_ = Ogre::Quaternion::IDENTITY;
  // Erase a node's split-hysteresis entry together with its split descendants
  // (stale entries make revisited areas materialize too fine).
  void purgeSplit(const TileKey & key);
  bool base_ready_ = false;   // pinned coarse pyramid fully resident
  uint64_t stamp_ = 0;
  // Discontinuous camera moves. A 700 km jump leaves the whole previous
  // position's work in flight: requests are only cancelled by the ~25 s
  // zombie sweep, ready_ is a plain FIFO so those arrivals mesh first, and
  // the grace period holds the old tiles 8 s. The gate lets tick() cancel
  // that work once per jump -- it never mass-destroys resident tiles, and
  // never touches the pinned coarse pyramid.
  TeleportGate teleport_;
  uint64_t teleport_stamp_ = 0;   // tick the last jump was seen
  uint64_t instance_id_ = 0;
  float last_exag_ = 1.0f;
  // Perf accumulators, flushed to the status panel at ~2 Hz (four status
  // strings changing at tick rate are themselves measurable Qt work).
  int perf_ticks_ = 0;
  int stat_resets_ = 0;      // Ogre FrameStats reset cadence (every 10th flush)
  double tick_ms_sum_ = 0.0, tick_ms_max_ = 0.0;
  double cover_ms_sum_ = 0.0, cover_ms_max_ = 0.0;
  double vis_ms_sum_ = 0.0, vis_ms_max_ = 0.0;
  double build_ms_sum_ = 0.0, build_ms_max_ = 0.0;   // drain() buildTile time
  uint64_t build_count_ = 0;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__TERRAIN_TILES_DISPLAY_HPP_

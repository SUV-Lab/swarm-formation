#ifndef MMP_RVIZ_PLUGINS__OBSTACLE_SCENARIO_PANEL_HPP_
#define MMP_RVIZ_PLUGINS__OBSTACLE_SCENARIO_PANEL_HPP_

#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QRadioButton>
#include <QVBoxLayout>

#include <string>

#include "rclcpp/rclcpp.hpp"
#include "rviz_common/panel.hpp"
#include "rviz_common/display_context.hpp"
#include "rviz_common/ros_integration/ros_node_abstraction.hpp"

#include "mmp_mission_msgs/msg/dynamic_obstacle_array.hpp"
#include "mmp_mission_msgs/msg/risk_zone_array.hpp"

namespace mmp_rviz_plugins
{

// Loads obstacles + risk_zones from a YAML file and pushes them to the
// running planner via /mission/obstacles and /mission/risk_zones.
// Mission (start/goal) is owned by MissionConfigPanel — not this one.
//
// YAML schema:
//   dynamic_obstacles:               # optional, V3 dynamic sphere layer
//     - { type: sphere, center: [..], radius: ... }
//     ...
//   risk_zones: [cx, cy, cz, reach, peak, ...]   # flat, multiples of 5
//                                                 # or sequence of maps
class ObstacleScenarioPanel : public rviz_common::Panel
{
  Q_OBJECT

public:
  explicit ObstacleScenarioPanel(QWidget * parent = nullptr);
  ~ObstacleScenarioPanel() override = default;

  void onInitialize() override;

protected Q_SLOTS:
  void onBrowseClicked();
  void onLoadClicked();
  void onClearClicked();

private:
  struct ParsedScenario
  {
    mmp_mission_msgs::msg::DynamicObstacleArray obstacles;
    mmp_mission_msgs::msg::RiskZoneArray risk_zones;
  };

  bool parseYaml(const std::string & file_path,
                 ParsedScenario & out,
                 std::string & err) const;

  void setStatus(const QString & text, bool error);

  // UI
  QLineEdit *      file_path_edit_   = nullptr;
  QPushButton *    browse_button_    = nullptr;
  QRadioButton *   append_radio_     = nullptr;
  QRadioButton *   replace_radio_    = nullptr;
  QPushButton *    load_button_      = nullptr;
  QPushButton *    clear_button_     = nullptr;
  QLabel *         status_label_     = nullptr;

  // ROS
  rclcpp::Node::SharedPtr node_;
  rclcpp::Publisher<mmp_mission_msgs::msg::DynamicObstacleArray>::SharedPtr load_pub_;
  rclcpp::Publisher<mmp_mission_msgs::msg::RiskZoneArray>::SharedPtr risk_zones_pub_;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__OBSTACLE_SCENARIO_PANEL_HPP_

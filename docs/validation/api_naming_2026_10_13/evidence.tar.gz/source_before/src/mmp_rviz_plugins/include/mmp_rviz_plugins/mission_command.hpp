// 미션 yaml 에서 읽은 것을 TrajectoryCommand 로 바꾸는 규칙. **Qt 를 물지
// 않는다** — 패널 안에 있으면 QApplication 과 DisplayContext 없이는 한 줄도
// 검사할 수 없고, 실제로 검사된 적이 없었다.
//
// mission_id 정책이 여기 있다는 것이 핵심이다. 그 정책이 패널 안에 상수로
// 박혀 있던 동안 ReplanFSM 의 mission_changed 는 첫 성공 이후 영원히 거짓이
// 었고, 두 번째 미션부터 이전 미션의 궤적점에서 계획됐다(감사 V-2,
// 9.24 km). 정책을 시험 가능한 자리로 옮겨서 상수로 되돌리면 시험이 죽게
// 만든다.

#ifndef MMP_RVIZ_PLUGINS__MISSION_COMMAND_HPP_
#define MMP_RVIZ_PLUGINS__MISSION_COMMAND_HPP_

#include <string>
#include <vector>

#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/vector3.hpp"
#include "mmp_mission_msgs/msg/resolved_mission.hpp"
#include "mmp_mission_msgs/msg/trajectory_command.hpp"
#include "mmp_mission_msgs/srv/load_map.hpp"

namespace mmp_rviz_plugins
{

struct ParsedMission
{
  geometry_msgs::msg::Point start;
  geometry_msgs::msg::Point goal;
  // Intermediate waypoints (yaml metres, same convention as start/goal).
  // The corridor crop already sizes itself around these — dropping them
  // here made the flown mission silently diverge from the loaded corridor.
  std::vector<geometry_msgs::msg::Point> waypoints;
  std::string formation_type = "none";
  double formation_scale = 0.0;
  // No default. The wire's use_initial_speed is the claim, and a default
  // would send a speed nobody wrote — which is the fabrication the
  // initial-state contract exists to stop. Presence of the yaml key is the
  // opt-in; a mission stating neither form is a parse error.
  double initial_speed_mps = 0.0;
  bool use_initial_speed = false;
  bool use_initial_velocity = false;
  geometry_msgs::msg::Vector3 initial_velocity_mps;
  bool use_initial_acceleration = false;
  geometry_msgs::msg::Vector3 initial_acceleration_mps2;
  // [PHASE] mission FINAL state (mirror of the initial fields; SI, the
  // FSM converts and validates — sub-stall final speeds fail the plan
  // unless planning/allow_final_boundary_relaxation is set).
  bool use_final_velocity = false;
  geometry_msgs::msg::Vector3 final_velocity_mps;
  bool use_final_acceleration = false;
  geometry_msgs::msg::Vector3 final_acceleration_mps2;
  // Vector present in the yaml but use_initial_velocity not true —
  // surfaced in the status label so the ignore is never silent.
  bool ignored_velocity_vector = false;
  // 미션 파일 이름(확장자 없이). mission_id 의 사람이 읽는 절반이다. 비어
  // 있어도 id 는 sequence 때문에 여전히 Run 마다 다르다 — 식별을 파일명에
  // 의존하지 않는다.
  std::string yaml_stem;
};

// 이 Run 의 mission_id. "<stem>#<sequence>" 이고, sequence 가 Run 마다
// 엄격히 증가하므로 id 도 Run 마다 다르다.
//
// ReplanFSM 은 이 값을 부등호로만 쓴다(replan_fsm.cpp:1102-1104). 같은 값이
// 다시 오면 "같은 미션의 재계획" 으로 읽고 명령된 시작점을 채택하지 않는다.
// 그러니 발행자가 Run 마다 다른 값을 내는 것이 계약이다.
std::string missionIdFor(const ParsedMission & m, int sequence);

// 미션 하나를 그대로 실어 나르는 명령. sequence 는 호출자가 증가시켜 넘긴다
// — 증가를 여기 넣으면 이 함수가 순수하지 않게 되고 시험할 수 없다.
mmp_mission_msgs::msg::TrajectoryCommand buildTrajectoryCommand(
  const ParsedMission & m, int sequence);

// Resolver-authority response -> ParsedMission, all values VERBATIM: z stays
// metres AGL (the single x0.01 lives in buildTrajectoryCommand), vectors stay
// authored frame-axis components. Re-validating or converting here would
// revive the duplicate implementation the panel just shed. yaml_stem comes
// from the caller (the response carries no path).
ParsedMission fromResolved(
  const mmp_mission_msgs::msg::ResolvedMission & r,
  const std::string & yaml_stem);

// LoadMap response gate — may this response's mission become the publish
// candidate? Pure (extracted from the panel's Qt path) so gtests pin it:
// a mutation reviving a fail-open (any refusal -> kAccept) dies in tests.
enum class ResponseGate
{
  kAccept,            // publish candidate (the ingestion receipt comes next)
  kSelectionChanged,  // the user edited the mission selection while this
                      // call flew — its own token/sha still match, so only
                      // the generation can refuse it
  kStaleToken,        // not the newest request's token — a late old response
  kNotResolved,       // server resolved nothing (incl. pre-ResolvedMission
                      // servers); consuming the zero-struct flies to (0,0)
  kShaMismatch,       // server parsed different bytes than the caller's file
  kNoGeometry         // no corridor geometry to match the receipt against
};

// Ask only on success=true responses (failures are already refusals).
// kAccept requires all five: request_generation == current_generation
// (caller bumps current on every selection edit), token match,
// mission_resolved, mission_sha256 == expected_sha256_hex,
// actual_resolution_m > 0.
ResponseGate gateResolvedResponse(
  const mmp_mission_msgs::srv::LoadMap::Response & resp,
  const std::string & expected_token,
  const std::string & expected_sha256_hex,
  int request_generation,
  int current_generation);

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__MISSION_COMMAND_HPP_

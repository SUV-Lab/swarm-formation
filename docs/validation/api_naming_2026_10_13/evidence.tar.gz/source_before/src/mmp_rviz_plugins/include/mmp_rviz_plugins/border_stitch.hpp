#ifndef MMP_RVIZ_PLUGINS__BORDER_STITCH_HPP_
#define MMP_RVIZ_PLUGINS__BORDER_STITCH_HPP_

// Canonical same-level border stitching, extracted PURE so a gtest can pin
// the convergence contract without Ogre/Qt.
//
// Why it exists: the tile server warps every tile independently and GDAL's
// approximate transformer is extent-dependent, so two same-level tiles
// DISAGREE along their shared border (measured on the live cache: 99-100% of
// land border pairs differ, 40-56% by >15 m, up to ~134 m) — and FOUR tiles
// disagree at a shared corner. The viewer closes the seams with rules every
// participant can compute identically from RAW data alone:
//
//   EDGE   (two tiles):  border sample -> mean(raw_mine, raw_neighbour)
//   CORNER (four tiles): corner sample -> mean of the RAW corners of every
//          participant that is drawn at this level AND resident (me, the two
//          edge neighbours, the diagonal). Applied only where BOTH adjacent
//          edges are same-level: a coarser-conformed edge owns its corners.
//
// A first version averaged hc[..] (already modified by earlier edges) in
// -x,+x,-y,+y order, so the four tiles combined different values in
// different orders at corners: 42-43% of live four-tile corners stayed
// mismatched, up to 65 m — pinholes exactly at tile corners. Hence RAW-only
// inputs and an explicit 4-way corner pass, locked by border_stitch_test.
//
// sig layout (matches TerrainTilesDisplay::edgeSig): bits [4e..4e+3] hold the
// edge code for e in {-x,+x,-y,+y} (0xF = same-level drawn, 1..4 = coarser
// ancestor depth, 0 = nothing drawn); bits 16+c flag a drawn same-level
// DIAGONAL for corner c in {(-x,-y),(+x,-y),(-x,+y),(+x,+y)}. A drawn-but-
// not-resident participant clears its bit so the caller's re-stitch loop
// retries once it lands.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <vector>

namespace mmp_rviz_plugins
{
namespace border_stitch
{

struct Neighbor
{
  const float * raw = nullptr;   // null = not resident
  bool drawn = false;            // drawn same-level in the last cover() pass
};
using NeighborFn = std::function<Neighbor(int dx, int dy)>;

inline int edge_midx(int e, int k, int G)
{
  switch (e) {
    case 0: return k;                    // -x edge: row i = 0
    case 1: return (G - 1) * G + k;      // +x edge: row i = G-1
    case 2: return k * G;                // -y edge: col j = 0
    default: return k * G + (G - 1);     // +y edge: col j = G-1
  }
}

inline int edge_nidx(int e, int k, int G)   // neighbour's facing edge
{
  switch (e) {
    case 0: return (G - 1) * G + k;
    case 1: return k;
    case 2: return k * G + (G - 1);
    default: return k * G;
  }
}

inline void edge_delta(int e, int * dx, int * dy)
{
  *dx = (e == 1 ? 1 : 0) - (e == 0 ? 1 : 0);
  *dy = (e == 3 ? 1 : 0) - (e == 2 ? 1 : 0);
}

// corner c: (cx, cy) in {-1,+1}^2, my corner lattice index, adjacent edges.
inline void corner_info(int c, int G, int * cx, int * cy, int * idx,
                        int * ex, int * ey)
{
  *cx = (c & 1) ? 1 : -1;
  *cy = (c & 2) ? 1 : -1;
  const int i = (*cx > 0) ? G - 1 : 0;
  const int j = (*cy > 0) ? G - 1 : 0;
  *idx = i * G + j;
  *ex = (*cx > 0) ? 1 : 0;
  *ey = (*cy > 0) ? 3 : 2;
}

// A participant's OWN corner index for the shared lattice point, given its
// offset (dx, dy) from me: each unit of offset mirrors that coordinate.
inline int mirrored_corner(int idx, int dx, int dy, int G)
{
  int i = idx / G, j = idx % G;
  if (dx != 0) {i = G - 1 - i;}
  if (dy != 0) {j = G - 1 - j;}
  return i * G + j;
}

// Apply the canonical rules to hc (a copy of raw). Edges/corners are taken
// from `sig`; unsatisfiable bits (drawn neighbour not resident) are CLEARED
// in-place so the caller re-stitches when it arrives. same_diff_m[e] returns
// the max |raw difference| seen on each same-level edge (skirt sizing: until
// the neighbour's own re-stitch lands, the visible crack is half of this).
inline void apply_same_level(std::vector<float> & hc, const float * raw,
                             int G, uint32_t & sig, const NeighborFn & nb,
                             float same_diff_m[4])
{
  for (int e = 0; e < 4; ++e) {
    same_diff_m[e] = 0.0f;
    if (((sig >> (e * 4)) & 0xF) != 0xF) {
      continue;
    }
    int dx, dy;
    edge_delta(e, &dx, &dy);
    const Neighbor n = nb(dx, dy);
    if (n.raw == nullptr) {
      sig &= ~(0xFu << (e * 4));       // evicted: retry when it lands
      continue;
    }
    for (int k = 0; k < G; ++k) {
      const float mine = raw[edge_midx(e, k, G)];
      const float theirs = n.raw[edge_nidx(e, k, G)];
      if (std::isfinite(mine) && std::isfinite(theirs)) {
        same_diff_m[e] = std::max(same_diff_m[e], std::abs(mine - theirs));
        hc[edge_midx(e, k, G)] = 0.5f * (mine + theirs);
      }
    }
  }
  // Corners, RAW inputs only. The rule must hold for EVERY tile that touches
  // the lattice point, not only for tiles with two same-level edges: a first
  // version gated on "both adjacent edges same-level", so in a 3-tile L
  // (diagonal culled — routine at the frustum boundary) only the inner tile
  // canonicalised while the arms kept their pairwise edge averages:
  // A=(A+B+C)/3 vs B=(A+B)/2 vs C=(A+C)/2 — corner pinholes survived.
  // Now: a corner participates when ANY adjacent edge is same-level, and its
  // value is the mean over the SAME participant set every toucher derives
  // from the shared drawn snapshot: me + whichever of {x-, y-, diagonal
  // neighbour} is drawn at this level. A coarser-conformed adjacent edge
  // still owns its corners (apply_coarser overwrites them afterwards, and
  // both same-level tiles under one ancestor interpolate the same point, so
  // they converge through the ancestor instead).
  for (int c = 0; c < 4; ++c) {
    int cx, cy, idx, ex, ey;
    corner_info(c, G, &cx, &cy, &idx, &ex, &ey);
    const int exc = (sig >> (ex * 4)) & 0xF;
    const int eyc = (sig >> (ey * 4)) & 0xF;
    if (exc != 0xF && eyc != 0xF) {
      continue;      // no same-level edge touches this corner
    }
    if ((exc >= 1 && exc <= 4) || (eyc >= 1 && eyc <= 4)) {
      continue;      // a coarser neighbour owns it via its conformed edge
    }
    double sum = 0.0;
    int cnt = 0;
    bool pending = false;
    if (std::isfinite(raw[idx])) {
      sum += raw[idx];
      ++cnt;
    }
    const auto join = [&](int dx, int dy) {
        const Neighbor n = nb(dx, dy);
        if (!n.drawn) {
          return;                      // not participating — consistent for all
        }
        if (n.raw == nullptr) {
          pending = true;              // drawn but evicted: retry later
          return;
        }
        const float v = n.raw[mirrored_corner(idx, dx, dy, G)];
        if (std::isfinite(v)) {
          sum += v;
          ++cnt;
        }
      };
    join(cx, 0);
    join(0, cy);
    join(cx, cy);
    if (pending) {
      // Keep the sig unsatisfied so the stitch retries when the participant
      // lands (an evicted EDGE neighbour already cleared its edge bits in
      // the pass above; an evicted diagonal clears its corner bit here).
      sig &= ~(1u << (16 + c));
      continue;
    }
    if (cnt > 0) {
      hc[idx] = static_cast<float>(sum / cnt);
    }
  }
}

// Conform edges facing a DRAWN COARSER neighbour onto that ancestor's actual
// surface: sample its border heights at our vertex positions (linear along
// the shared border). Pure for the same reason as above — two same-level
// tiles under one ancestor interpolate the same lattice point to the same
// value, which border_stitch_test pins. anc(nx, ny, d) returns the resident
// raw grid of the ancestor of (nx, ny) at depth d, or null (then the edge's
// sig bits clear so the caller retries when it lands).
using AncestorFn = std::function<const float *(int nx, int ny, int d)>;

inline void apply_coarser(std::vector<float> & hc, int G, int key_x, int key_y,
                          uint32_t & sig, const AncestorFn & anc)
{
  for (int e = 0; e < 4; ++e) {
    const int d = (sig >> (e * 4)) & 0xF;
    if (d == 0 || d == 0xF) {
      continue;
    }
    int dx, dy;
    edge_delta(e, &dx, &dy);
    const int nx = key_x + dx, ny = key_y + dy;
    const float * ah = anc(nx, ny, d);
    if (ah == nullptr) {
      sig &= ~(0xFu << (e * 4));       // ancestor evicted: retry next tick
      continue;
    }
    const int scale = 1 << d;
    // Offset of this tile along the shared border, in level-z tiles from the
    // ancestor's origin (x-edges run along y and vice versa).
    const int off = (e < 2) ? key_y - ((ny >> d) << d)
                            : key_x - ((nx >> d) << d);
    for (int k = 0; k < G; ++k) {
      const double u = (static_cast<double>(off) * (G - 1) + k) / scale;
      const int u0 = static_cast<int>(u);
      const int u1 = std::min(u0 + 1, G - 1);
      const double f = u - u0;
      hc[edge_midx(e, k, G)] = static_cast<float>(
        (1.0 - f) * ah[edge_nidx(e, u0, G)] + f * ah[edge_nidx(e, u1, G)]);
    }
  }
}

}  // namespace border_stitch
}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__BORDER_STITCH_HPP_

#ifndef MMP_RVIZ_PLUGINS__TELEPORT_HPP_
#define MMP_RVIZ_PLUGINS__TELEPORT_HPP_

// Teleport policy, extracted PURE so a gtest can pin it without Ogre/Qt.
//
// Why it exists: after a 700 km jump the new position's tiles are not in
// client memory or on the GPU, so they must be read, JPEG-decoded, meshed and
// uploaded again. That is unavoidable. What is avoidable is making that
// compete with work for the position the camera has already left:
//
//   * a request is only cancelled by the ~25 s zombie sweep, so tiles that
//     went off-screen keep occupying sockets and the inflight budget;
//   * ready_ is a plain FIFO -- want_ is distance-sorted when requests go
//     OUT, but arrivals are built in arrival order, so the old position's
//     tiles become meshes first;
//   * kGraceTicks holds the old tiles 8 s;
//   * evictions are capped at 12 per tick.
//
// The cap is NOT a performance knob: destroying hundreds of Ogre buffers in
// one tick is what corrupts the Mesa swrast heap. So this policy cancels
// stale WORK; it never mass-destroys resident tiles and never touches the
// pinned coarse pyramid, which is the only thing guaranteeing something is
// on screen at all times.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <deque>
#include <set>
#include <vector>

namespace mmp_rviz_plugins
{

/// Distinguishes a pan from a discontinuous jump, from camera position alone.
///
/// A pan is continuous: per-tick motion is bounded by how fast a human drags.
/// A teleport lands the camera somewhere else in ONE tick. The gate therefore
/// fires on a single-tick delta, and latches: it will not fire again until
/// the camera has settled below `settle_u`, so one jump is one event even
/// when the controller takes a few ticks to come to rest.
class TeleportGate
{
public:
  /// jump_u: single-tick distance that means "not a pan" (frame units, 1 u =
  /// 100 m). 2000 u = 200 km in one 50 ms tick is 4,000 km/s.
  explicit TeleportGate(double jump_u = 2000.0, double settle_u = 200.0)
  : jump_u_(jump_u), settle_u_(settle_u) {}

  /// Feed this tick's camera position. True exactly once per jump.
  bool step(double x, double y, double z)
  {
    const bool first = !have_;
    const double dx = x - px_, dy = y - py_, dz = z - pz_;
    px_ = x; py_ = y; pz_ = z; have_ = true;
    if (first) {
      return false;                       // no previous pose: nothing to compare
    }
    const double d = std::sqrt(dx * dx + dy * dy + dz * dz);
    if (armed_ && d >= jump_u_) {
      armed_ = false;                     // latch until the camera settles
      return true;
    }
    if (!armed_ && d <= settle_u_) {
      armed_ = true;
    }
    return false;
  }

  bool armed() const {return armed_;}
  void reset() {have_ = false; armed_ = true;}

private:
  double jump_u_, settle_u_;
  double px_ = 0.0, py_ = 0.0, pz_ = 0.0;
  bool have_ = false;
  bool armed_ = true;
};


/// Keys in `have` that the new view no longer wants. `keep` is the union of
/// what is visible and what was just queued to fetch; `pinned` is the coarse
/// base, which is never stale.
template<class Key, class Container>
std::vector<Key> stale_keys(
  const Container & have, const std::set<Key> & keep, int pinned_max_z)
{
  std::vector<Key> out;
  for (const Key & key : have) {
    if (key.z <= pinned_max_z || keep.count(key)) {
      continue;
    }
    out.push_back(key);
  }
  return out;
}

/// Build order after a teleport: coarse levels first so SOMETHING sharp
/// appears immediately, then nearest first inside a level. Plain arrival
/// order lets the position the camera has left finish first.
template<class Key>
void order_coarse_then_near(
  std::vector<std::pair<double, Key>> & items)
{
  std::stable_sort(
    items.begin(), items.end(),
    [](const std::pair<double, Key> & a, const std::pair<double, Key> & b) {
      if (a.second.z != b.second.z) {
        return a.second.z < b.second.z;
      }
      return a.first < b.first;
    });
}

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__TELEPORT_HPP_

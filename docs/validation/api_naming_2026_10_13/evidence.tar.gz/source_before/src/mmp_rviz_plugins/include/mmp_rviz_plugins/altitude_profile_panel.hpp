#ifndef MMP_RVIZ_PLUGINS__ALTITUDE_PROFILE_PANEL_HPP_
#define MMP_RVIZ_PLUGINS__ALTITUDE_PROFILE_PANEL_HPP_

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/panel.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <rmw/qos_profiles.h>

#include <visualization_msgs/msg/marker.hpp>
#include <mmp_traj_msgs/msg/poly_traj.hpp>
#include <std_msgs/msg/float64.hpp>
#include <grid_map_msgs/msg/grid_map.hpp>
#include <std_msgs/msg/float64_multi_array.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <unordered_map>
#include <cstdint>
#include <geometry_msgs/msg/point.hpp>
#include <nav_msgs/msg/odometry.hpp>

#include <QPixmap>
#include <QWidget>
#include <QPainter>
#include <QVBoxLayout>
#include <QLabel>
#include <QSlider>
#include <QPushButton>
#include <QCheckBox>
#include <QTimer>
#include <cstddef>
#include <vector>

namespace mmp_rviz_plugins
{

class AltitudeProfileWidget : public QWidget
{
  Q_OBJECT

public:
  explicit AltitudeProfileWidget(QWidget * parent = nullptr);
  ~AltitudeProfileWidget() override = default;

  // Full optimized trajectory (drawn upfront, never animates)
  void setTrajectoryData(
    const std::vector<geometry_msgs::msg::Point> & trajectory_points,
    const std::vector<double> & distances,
    const std::vector<double> & terrain_heights,
    const std::vector<double> & obstacle_top,
    const std::vector<double> & obstacle_bot,
    const std::vector<double> & combined_risk,
    const std::vector<std::vector<double>> & risk_band_lower,
    const std::vector<std::vector<double>> & risk_band_floor,
    const std::vector<std::vector<double>> & risk_band_top);

  // Current drone progress along the pre-drawn trajectory
  void setCurrentProgress(double distance_travelled, double current_altitude);

  // [CHAIN-VIZ] Per-segment profile coloring + junction markers, mirroring
  // the 3D /viz/chain_segments view (same palette order). junction_s_m are
  // arc positions (metres) along the current profile; seg_colors has one
  // entry per segment (terminal phase included, white). Empty = single-
  // trajectory mode, default drawing.
  void setChainSegments(const std::vector<double> & junction_s_m,
                        const QVector<QColor> & seg_colors);

  void clearData();

protected:
  void paintEvent(QPaintEvent * event) override;
  // Preferred 3x height (opens big when the screen allows) but a SMALL
  // minimum: a 450px floor overflowed the dock on landscape monitors and the
  // plot clipped off-screen — RViz cannot shrink a panel below its minimum.
  QSize sizeHint() const override { return QSize(800, 600); }
  QSize minimumSizeHint() const override { return QSize(400, 180); }

private:
  void drawGrid(QPainter & painter, const QRect & plot_area);
  void drawTerrainProfile(QPainter & painter, const QRect & plot_area);
  void drawObstacles(QPainter & painter, const QRect & plot_area);
  void drawTrajectoryProfile(QPainter & painter, const QRect & plot_area);
  // Dynamic overlays, drawn between the cached layers every repaint (their
  // z-order relative to the risk overlay / axes is what forces the 3-layer
  // cache below).
  void drawElapsedOverlay(QPainter & painter, const QRect & plot_area);
  void reportElapsedDrawCost(size_t cut, size_t drawn);
  void drawRiskAndEndpoints(QPainter & painter, const QRect & plot_area);
  std::vector<QPointF> trajScreenPoints(const QRect & plot_area) const;
  void drawCurrentPosition(QPainter & painter, const QRect & plot_area);
  void drawAxes(QPainter & painter, const QRect & plot_area);
  void drawLegend(QPainter & painter, const QRect & plot_area);
  // Recompute y-axis range/ticks from the stored data. Overlay channels only
  // count when shown, so hidden diagnostics don't inflate the axis.
  void refreshYRange();
  // [Y-SPLIT] Piecewise altitude -> pixel-y mapping. The terrain/trajectory
  // band [min_altitude_, max_altitude_] keeps the lower fraction
  // of the plot at full resolution; [max_altitude_, y_upper_max_] (km-scale
  // zone-visible tops) is compressed into the top fraction so the bands'
  // real extents stay on screen without squashing the mission band. Inactive
  // (pure linear) when nothing overtops the main axis.
  double altToY(double alt_m, const QRect & plot_area) const;

  std::vector<geometry_msgs::msg::Point> trajectory_points_;
  std::vector<double> distances_;
  std::vector<double> terrain_heights_;
  // [RISK-PROFILE] Combined trajectory risk and each zone's independent
  // visible vertical interval along the path. NaN means "not provided /
  // outside this zone", not zero risk.
  std::vector<double> combined_risk_;
  // Per-zone geometric lower bound of the cross-section (v4; NaN on older
  // payloads -> the shadow-safe fill falls back to the terrain surface).
  std::vector<std::vector<double>> risk_band_lower_;
  std::vector<std::vector<double>> risk_band_floor_;
  std::vector<std::vector<double>> risk_band_top_;
  // Obstacle (ship/box) vertical extents under the path, metres; NaN = none.
  std::vector<double> obstacle_top_;
  std::vector<double> obstacle_bot_;

  double max_distance_;
  double min_altitude_;
  double max_altitude_;
  // Round tick steps (1-2-5 ladder) so gridlines and labels land on clean
  // values; both are derived from the data range in setTrajectoryData.
  double y_tick_step_{100.0};   // meters
  double x_tick_step_{50.0};    // kilometers
  // [Y-SPLIT] compressed upper band (see altToY). Adaptive split: mission
  // band pinned near 200px, zone region takes the rest — converges to the
  // preferred 1/3 : 2/3 on tall docks (user preference 2026-07-24).
  bool has_upper_band_{false};
  double y_upper_max_{0.0};
  bool has_data_;

  double current_distance_;
  double current_altitude_;
  bool has_current_;

  // [PERF] Layered static caches: the live progress marker arrives at feed
  // rate, and repainting the whole antialiased profile per marker move made
  // the marker cost the entire rviz frame loop ~half its frame rate. The
  // static content is rendered once into pixmaps; per-repaint work is three
  // blits + the marker/elapsed lines. Three layers because the z-order is
  // base < elapsed < risk overlay < marker < axes/legend.
  QPixmap base_cache_;    // white bg + grid + terrain + obstacles + planned path/chain
  QPixmap risk_cache_;    // transparent: risk overlay + start/end endpoints
  // Screen points and their column-decimated indices, rebuilt with the
  // caches above. drawElapsedOverlay runs on EVERY repaint -- setCurrentProgress
  // does not dirty the caches -- so rebuilding N QPointF and drawing an
  // N-point polyline there is what makes the panel cost grow with distance
  // travelled: fine at 200 km, 8 fps at 700 km. These make that per-frame
  // work proportional to the plot WIDTH instead.
  std::vector<QPointF> traj_px_;
  std::vector<size_t> env_idx_;
  // Scratch for the prefix actually drawn this frame. A member so the repaint
  // path stops allocating once it has warmed up.
  std::vector<size_t> prefix_idx_;
  QPixmap deco_cache_;    // transparent: axes + legend
  bool cache_dirty_ = true;

  // [CHAIN-VIZ] segment boundaries (metres along profile) + palette.
  std::vector<double> chain_junction_s_;
  QVector<QColor> chain_seg_colors_;
};

class AltitudeProfilePanel : public rviz_common::Panel
{
  Q_OBJECT

public:
  explicit AltitudeProfilePanel(QWidget * parent = nullptr);
  ~AltitudeProfilePanel() override;

  void onInitialize() override;

private:
  void trajectoryCallback(const visualization_msgs::msg::Marker::SharedPtr msg);
  void gridMapCallback(const grid_map_msgs::msg::GridMap::SharedPtr msg);
  void dynObstacleArrayCallback(const visualization_msgs::msg::MarkerArray::SharedPtr msg);
  // Sample obstacle vertical extents under the cached trajectory (frame units).
  void sampleObstacles();
  void currentPositionCallback(const nav_msgs::msg::Odometry::SharedPtr msg);

  void rebuildProfile();
  // [CHAIN-VIZ] latched /viz/chain_segments array (same one the 3D display
  // consumes): segment tube colors + junction spheres. Clear-only publishes
  // (DELETEALL, no tubes) empty the overlay.
  void chainSegmentsCallback(const visualization_msgs::msg::MarkerArray::SharedPtr msg);
  // Map cached junction positions onto the current profile's arc axis and
  // hand the result to the widget (empty when either side is missing).
  void pushChainToWidget();
  // Refill terrain_heights_ / the risk overlays for the cached trajectory.
  void resampleTerrain();
  void riskProfileCallback(const std_msgs::msg::Float64MultiArray::SharedPtr msg);
  float getElevationAt(double x, double y);

  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<visualization_msgs::msg::Marker>::SharedPtr trajectory_sub_;
  rclcpp::Subscription<grid_map_msgs::msg::GridMap>::SharedPtr grid_map_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr current_pos_sub_;

  grid_map_msgs::msg::GridMap::SharedPtr terrain_map_;
  bool terrain_map_received_;
  // All planning-frame axes use 1 unit = 100 m. This default must also apply
  // before a non-empty GridMap arrives (trajectory and odometry can arrive
  // while world=none).
  double elev_scale_ = 100.0;

  // Cached full trajectory (populated once when /opt_trajectory arrives)
  std::vector<geometry_msgs::msg::Point> trajectory_points_;
  std::vector<double> distances_;
  std::vector<double> terrain_heights_;
  // [RISK-PROFILE] v3:
  //   header [3, zone_count], then dense records
  //   [s, x, y, z, combined_risk, floor_0, top_0, ...] in planning units.
  // xyz bind the profile to the trajectory which produced it, preventing a
  // same-length or same-ground-track stale profile from being overlaid.
  // v2 [s,x,y,risk,...] and legacy quads remain readable during rolling
  // upgrades, with the strongest validation their payload permits.
  // Legacy quads [s, roof, dome_top, dome_bot] remain readable as one band,
  // but have neither xy validation nor a quantitative risk channel.
  int risk_profile_version_{0};  // 3=current, 2=xy-only, 0=legacy/none
  size_t risk_zone_count_{0};
  std::vector<double> risk_s_m_;
  std::vector<double> risk_x_u_;
  std::vector<double> risk_y_u_;
  std::vector<double> risk_z_u_;
  std::vector<double> risk_combined_;
  std::vector<std::vector<double>> risk_band_lower_m_;
  std::vector<std::vector<double>> risk_band_floor_m_;
  std::vector<std::vector<double>> risk_band_top_m_;
  std::vector<double> risk_combined_r_;  // resampled onto trajectory samples
  std::vector<std::vector<double>> risk_band_lower_r_;
  std::vector<std::vector<double>> risk_band_floor_r_;
  std::vector<std::vector<double>> risk_band_top_r_;
  rclcpp::Subscription<std_msgs::msg::Float64MultiArray>::SharedPtr risk_profile_sub_;
  bool trajectory_ready_;

  // Obstacle overlay: exact collision geometry. Ships come from the
  // invisible CUBE companions on /viz/dynamic_obstacles (the visible mesh
  // markers cannot be decoded — their scale is relative to unknown native
  // mesh dims). Without this, box-avoidance climbs looked unmotivated
  // ("why is it climbing over open water?" — invisible ships).
  struct ProfileObstacle {
    bool is_box = true;                 // false = elliptic footprint (cylinder)
    double cx = 0, cy = 0, cz = 0;      // center, frame units
    double sx = 0, sy = 0, sz = 0;      // full extents; sz <= 0 = full column
    double yaw = 0;
  };
  std::unordered_map<int64_t, ProfileObstacle> obstacles_;  // key: source<<32 | id
  std::vector<double> obstacle_top_;    // frame units; NaN = no obstacle here
  std::vector<double> obstacle_bot_;
  rclcpp::Subscription<visualization_msgs::msg::MarkerArray>::SharedPtr dyn_obs_sub_;

  // [CHAIN-VIZ] cached chain view: junction positions (frame units) and one
  // color per segment, in publish order.
  rclcpp::Subscription<visualization_msgs::msg::MarkerArray>::SharedPtr chain_seg_sub_;
  std::vector<geometry_msgs::msg::Point> chain_junctions_;
  QVector<QColor> chain_seg_colors_;

  // Speed estimation from /current_position
  bool has_prev_pos_;
  geometry_msgs::msg::Point prev_pos_;
  rclcpp::Time prev_pos_stamp_;
  double speed_mps_;
  bool has_progress_{false};
  double last_progress_m_{0.0};

  AltitudeProfileWidget * profile_widget_;
  QLabel * status_label_;
  // Live-telemetry GUI coalescing (50 Hz sim feed -> 10 Hz repaint) and
  // last-applied stylesheet (setStyleSheet re-polishes even on identical
  // text — skip repeats).
  int64_t last_live_push_ms_ = 0;
  QString status_style_;
  void setStatusStyle(const QString & sheet);

  // ---- Embedded trajectory scrubber (slider + play) ----
  // Lives inside this panel so the slider thumb and the plot's
  // current-position marker share the same widget width and margins —
  // pixel-aligned by construction (RViz couldn't stack two panels
  // vertically in the bottom dock area).
  void onTrajectoryMsg(const mmp_traj_msgs::msg::PolyTraj::SharedPtr msg);
  bool evalAt(double t_abs, double & x, double & y, double & z) const;
  double tToS(double t) const;
  double sToT(double s) const;
  void onSliderChanged(int value);
  void onPlayToggled(bool checked);
  void onTick();
  void refreshScrub();
  void clearScrubber(const QString & reason);

  static constexpr int kSteps = 1000;        // slider resolution
  static constexpr int kArcN = 512;          // t->arc-length table samples
  static constexpr double kPlaySpeed = 1.0;  // playback rate (x real-time)

  QSlider * scrub_slider_;
  QPushButton * play_button_;
  QLabel * time_label_;
  QTimer * scrub_timer_;

  rclcpp::Subscription<mmp_traj_msgs::msg::PolyTraj>::SharedPtr poly_traj_sub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr cursor_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr flown_pub_;
  rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr scrub_pub_;

  mmp_traj_msgs::msg::PolyTraj traj_;
  bool has_traj_ = false;
  double total_duration_ = 0.0;
  double cur_t_ = 0.0;        // scrub time [s] — source of truth
  std::vector<double> arc_s_; // xy arc length at uniform-t samples
  double total_len_ = 0.0;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__ALTITUDE_PROFILE_PANEL_HPP_

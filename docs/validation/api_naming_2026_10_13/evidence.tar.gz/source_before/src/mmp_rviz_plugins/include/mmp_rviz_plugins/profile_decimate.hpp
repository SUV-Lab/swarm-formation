#ifndef MMP_RVIZ_PLUGINS__PROFILE_DECIMATE_HPP_
#define MMP_RVIZ_PLUGINS__PROFILE_DECIMATE_HPP_

// Column decimation for the altitude profile, extracted PURE so a gtest can
// pin it without Qt.
//
// Why it exists: the profile draws one QPainter call per trajectory SEGMENT
// for the risk overlay -- antialiased, 3.5 px, round-capped -- plus an
// N-point polyline for the plan. An 800 km plan carries tens of thousands of
// samples into a plot a few hundred pixels wide, so the panel spends the
// whole frame drawing detail that lands on the same pixel column. Measured:
// with the panel open the main thread sat at 82% and rviz2 fell to 8 fps at
// 700 km while the GPU idled at 5%; closing the panel recovered it at once.
//
// It returns INDICES, not points. Every consumer pairs traj_points[i] with
// distances_[i] and combined_risk_[i], and one of them guards on
// combined_risk_.size() == traj_points.size() -- decimating the points alone
// would silently drop the risk overlay instead of speeding it up.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <vector>

namespace mmp_rviz_plugins
{

/// Indices to draw so the plotted envelope is unchanged at pixel resolution.
///
/// Per pixel column the drawn shape is fully determined by where the line
/// enters, how far it reaches in each direction, and where it leaves. So each
/// column contributes its first, min-y, max-y and last sample, in index order
/// -- at most four, usually two. The first and last samples overall are
/// always kept, and `must_keep` (chain junctions, and anything else whose
/// exact position carries meaning) is merged in.
///
/// `xs` must be non-decreasing, which it is: x is distance along the path.
inline std::vector<size_t> column_envelope(
  const std::vector<double> & xs, const std::vector<double> & ys,
  double column_px = 1.0, const std::vector<size_t> & must_keep = {})
{
  std::vector<size_t> out;
  const size_t n = std::min(xs.size(), ys.size());
  if (n == 0) {
    return out;
  }
  if (n <= 4) {                       // nothing to gain; keep it exact
    out.resize(n);
    for (size_t i = 0; i < n; ++i) {out[i] = i;}
    return out;
  }
  const double w = column_px > 0.0 ? column_px : 1.0;
  out.reserve(n / 2 + must_keep.size() + 4);

  size_t start = 0;
  auto flush = [&](size_t lo, size_t hi) {          // [lo, hi]
      size_t imin = lo, imax = lo;
      for (size_t i = lo; i <= hi; ++i) {
        if (ys[i] < ys[imin]) {imin = i;}
        if (ys[i] > ys[imax]) {imax = i;}
      }
      size_t four[4] = {lo, std::min(imin, imax), std::max(imin, imax), hi};
      for (size_t k = 0; k < 4; ++k) {
        if (out.empty() || out.back() != four[k]) {
          out.push_back(four[k]);
        }
      }
    };
  for (size_t i = 1; i < n; ++i) {
    if (std::floor(xs[i] / w) != std::floor(xs[start] / w)) {
      flush(start, i - 1);
      start = i;
    }
  }
  flush(start, n - 1);

  for (size_t k : must_keep) {
    if (k < n) {out.push_back(k);}
  }
  std::sort(out.begin(), out.end());
  out.erase(std::unique(out.begin(), out.end()), out.end());
  return out;
}

/// Indices to draw for the PREFIX [0, cut) of the series, given `env` =
/// column_envelope(xs, ys, column_px, ...) over the WHOLE series.
///
/// Filtering `env` by `idx < cut` is NOT enough, and that is a real hole and
/// not a pedantic one. column_envelope picked each column's min-y and max-y
/// over the whole column. When the cut lands inside a column and those
/// extremes lie past it, the filter leaves that column holding only its entry
/// sample, so a peak the vehicle has ALREADY passed vanishes from the drawn
/// head -- and reappears the moment the cut crosses into the next column. The
/// error is bounded by one column horizontally but by the column's full y
/// span vertically, which on steep ground is most of the plot.
///
/// Completed columns are safe, so exactly one column is recomputed: the one
/// containing `cut - 1`, over [column start, cut - 1]. Everything `env`
/// already holds in that column is kept as well, so must_keep entries (chain
/// junctions) inside the partial column survive.
///
/// Cost stays proportional to the plot width plus one column's samples.
template<typename XAt, typename YAt>
inline void envelope_prefix(
  XAt xat, YAt yat, size_t n, const std::vector<size_t> & env, size_t cut,
  double column_px, std::vector<size_t> & out)
{
  out.clear();
  if (n == 0 || cut == 0) {
    return;
  }
  if (cut > n) {cut = n;}

  const double w = column_px > 0.0 ? column_px : 1.0;
  // Column of the last drawn sample, and the first env entry that lands in it.
  // Every column's entry index is in env (column_envelope pushes `lo` first),
  // so one pass finds both the prefix and that column's start.
  const double col = std::floor(xat(cut - 1) / w);
  bool have_lo = false;
  size_t lo = 0;
  for (size_t e : env) {
    if (e >= cut) {break;}
    if (!have_lo && std::floor(xat(e) / w) == col) {have_lo = true; lo = e;}
    out.push_back(e);
  }
  if (cut == n || std::floor(xat(cut) / w) != col) {
    return;               // that column is complete; env already describes it
  }
  if (!have_lo) {         // env said nothing about this column -- walk back
    lo = cut - 1;
    while (lo > 0 && std::floor(xat(lo - 1) / w) == col) {--lo;}
  }

  size_t imin = lo, imax = lo;
  for (size_t i = lo; i < cut; ++i) {
    if (yat(i) < yat(imin)) {imin = i;}
    if (yat(i) > yat(imax)) {imax = i;}
  }
  const size_t four[4] = {lo, std::min(imin, imax), std::max(imin, imax), cut - 1};

  // Merge, do not replace: env's own entries in this column may include
  // must_keep indices that the four do not.
  size_t tail = out.size();
  while (tail > 0 && out[tail - 1] >= lo) {--tail;}
  for (size_t k = 0; k < 4; ++k) {out.push_back(four[k]);}
  std::sort(out.begin() + tail, out.end());
  out.erase(std::unique(out.begin() + tail, out.end()), out.end());
  // Everything before `tail` is < lo <= every element after it, so the whole
  // vector is still ascending.
}

/// Convenience overload for tests and vector-backed callers.
inline std::vector<size_t> envelope_prefix(
  const std::vector<double> & xs, const std::vector<double> & ys,
  const std::vector<size_t> & env, size_t cut, double column_px = 1.0)
{
  std::vector<size_t> out;
  envelope_prefix(
    [&](size_t i) {return xs[i];}, [&](size_t i) {return ys[i];},
    std::min(xs.size(), ys.size()), env, cut, column_px, out);
  return out;
}

/// Worst value over (a, b], for aggregating a per-sample quantity onto a
/// decimated segment. NaN is skipped, never treated as zero: an unknown risk
/// must not be drawn as a safe one. Returns NaN when nothing is known.
inline double worst_between(
  const std::vector<double> & v, size_t a, size_t b)
{
  double worst = std::numeric_limits<double>::quiet_NaN();
  for (size_t i = a; i <= b && i < v.size(); ++i) {
    const double x = v[i];
    if (!std::isfinite(x)) {continue;}
    if (!std::isfinite(worst) || x > worst) {worst = x;}
  }
  return worst;
}

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__PROFILE_DECIMATE_HPP_

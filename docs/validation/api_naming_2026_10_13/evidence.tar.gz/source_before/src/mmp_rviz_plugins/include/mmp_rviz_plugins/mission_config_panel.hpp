#ifndef MMP_RVIZ_PLUGINS__MISSION_CONFIG_PANEL_HPP_
#define MMP_RVIZ_PLUGINS__MISSION_CONFIG_PANEL_HPP_

#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTimer>
#include <QVBoxLayout>

#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "rviz_common/panel.hpp"
#include "rviz_common/display_context.hpp"
#include "rviz_common/ros_integration/ros_node_abstraction.hpp"

#include "mmp_mission_msgs/msg/trajectory_command.hpp"
#include "mmp_rviz_plugins/mission_command.hpp"
#include "mmp_mission_msgs/srv/load_map.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"

namespace mmp_rviz_plugins
{

// Runs a mission yaml through the resolver and publishes
// /mission/trajectory_command. This panel does NOT parse mission yaml:
// coordinates (including lonlat derivation), initial/final state and
// formation all come from the /terrain/load_map response's ResolvedMission.
// gateResolvedResponse checks the answer against this Run's request token
// and the file's sha256, fromResolved carries it verbatim. Any refusal —
// gate, missing receipt, service down/failed/timed out — publishes nothing;
// there is no local-parse fallback and no publish-anyway path.
class MissionConfigPanel : public rviz_common::Panel
{
  Q_OBJECT

public:
  explicit MissionConfigPanel(QWidget * parent = nullptr);
  ~MissionConfigPanel() override = default;

  void onInitialize() override;

protected Q_SLOTS:
  void onBrowseClicked();
  void onRunClicked();

private Q_SLOTS:
  // Polls the ROS graph for replan_fsm_drone_* nodes so Run only enables
  // when a path_manager is actually up to receive the mission command.
  void pollReadiness();
  // Polls the single in-flight /terrain/load_map call: once the typed response
  // is back (the map is latched before the service returns) the mission is
  // published and the response's actual geometry goes to the status label.
  void pollCorridor();

private:
  // Combined gate: yaml selected AND a path_manager node is in the graph.
  void refreshRunButtonEnabled();
  bool pathManagerUp() const;

  void publish(const ParsedMission & m);
  void setStatus(const QString & text, bool error);

  // UI
  QLineEdit *   file_path_edit_     = nullptr;
  QPushButton * browse_button_      = nullptr;
  QPushButton * run_button_         = nullptr;
  QCheckBox *   corridor_check_     = nullptr;
  QLabel *      status_label_       = nullptr;
  QTimer *      readiness_timer_    = nullptr;
  bool          path_manager_up_    = false;

  // Mission-corridor auto-load (see pollCorridor). ONE typed call carries the
  // whole request: the selected mission yaml is LoadMap.mission_path, which
  // puts terrain_publisher in corridor mode — it crops the fine DEM around the
  // mission so the planner sees 30-40 m terrain and the full nationwide
  // grid_map load disappears from the workflow. (The old untyped dance — set
  // world/corridor_mission parameters, then fire a payload-free
  // std_srvs/Trigger — is gone, and with it the two-stage state machine.)
  rclcpp::Client<mmp_mission_msgs::srv::LoadMap>::SharedPtr load_map_client_;
  QTimer * corridor_timer_ = nullptr;
  rclcpp::Client<mmp_mission_msgs::srv::LoadMap>::SharedFuture corridor_future_;
  bool corridor_pending_ = false;  // a load_map call is in flight
  int corridor_ticks_ = 0;         // watchdog (100 ms each)
  ParsedMission pending_mission_;   // fromResolved(response); published after the receipt
  QString pending_name_;
  // Gate inputs: this Run's request token and the mission file's sha256 at
  // request time (see gateResolvedResponse).
  std::string pending_token_;
  std::string pending_sha_;
  // The gated response, kept so the receipt-release re-check runs the SAME
  // gate function (one decision, one gtest surface) instead of a hand-rolled
  // comparison next to publish().
  mmp_mission_msgs::srv::LoadMap::Response::SharedPtr accepted_resp_;
  QString pending_warnings_;        // response warnings, shown verbatim on publish
  int request_counter_ = 0;         // token source, incremented per Run
  // Any edit of the file field bumps selection_generation_; a Run captures
  // it into pending_generation_. The gate (and the pre-publish check in the
  // receipt phase) refuses in-flight work whose generation is stale — its
  // own token/sha still match, so nothing else can.
  int selection_generation_ = 0;
  int pending_generation_ = 0;

  // ROS
  rclcpp::Node::SharedPtr node_;
  rclcpp::Publisher<mmp_mission_msgs::msg::TrajectoryCommand>::SharedPtr trajectory_cmd_pub_;
  // No /terrain/grid_map subscription here on purpose. This panel used to
  // keep one to learn the terrain resolution for the yaml z conversion, but
  // publish() converts with a fixed z_unit (1 u = 100 m on every axis, since
  // the publisher z-scale fix), so the resolution was written and never
  // read. The cost was not zero: the corridor map is a single ~38.5 MB
  // message and every panel holding a subscription deserializes its own copy
  // on rviz2's main thread, which is what stalls the Qt timer that drives
  // the [TERRAIN-READY] gate below.

  // [TERRAIN-READY] Command gate: LoadMap replying only proves the corridor
  // was PUBLISHED — the planner may still be digesting it (SDF + risk masks,
  // seconds on big crops). The FSM publishes a latched ingestion receipt
  // [resolution_u, origin_x_u, origin_y_u]; Run holds the mission until the
  // receipt matches the corridor the service just described, then releases.
  // Timeout publishes NOTHING (fail-closed): a planner that cannot produce
  // the receipt cannot prove it holds this corridor. The old 30 s
  // publish-anyway path is gone; the status line names the cause.
  rclcpp::Subscription<std_msgs::msg::Float64MultiArray>::SharedPtr terrain_ready_sub_;
  double ready_res_u_ = -1.0, ready_ox_u_ = 0.0, ready_oy_u_ = 0.0;
  double ready_lx_u_ = -1.0, ready_ly_u_ = -1.0;
  bool ready_pending_ = false;   // waiting for a matching receipt
  int ready_ticks_ = 0;          // watchdog (100 ms each)
  double expect_res_u_ = 0.0, expect_ox_u_ = 0.0, expect_oy_u_ = 0.0;
  double expect_lx_u_ = 0.0, expect_ly_u_ = 0.0;
  QString pending_geom_;

  // ReplanFSM ignores a TrajectoryCommand whose sequence <= the last one
  // it processed, so each Run must use a strictly increasing sequence.
  int sequence_counter_ = 0;
};

}  // namespace mmp_rviz_plugins

#endif  // MMP_RVIZ_PLUGINS__MISSION_CONFIG_PANEL_HPP_

"""Fail-closed pairing between a tile cache directory and the FULL recipe
that cut it — including the verified bake manifest's CONTENT.

A tile address (z, x, y) only means something relative to one frame AND one
recipe: anchor raster, DEM, scene index, render schema, encoder quality.
Guard history:
  v1 pinned the anchor only;
  v2 added DEM/scenes/render-schema hard keys and BOUND `.bake_manifest.json`
     by file sha — but never read it, so any unrelated manifest could be
     installed once and become "the" manifest, and the scenes key hashed the
     RAW index json while the bake fingerprint uses a SEMANTIC digest of the
     resolved scene set (same granules, different bytes -> spurious refusal;
     different granules behind an unchanged file is impossible, but the two
     digests measured different things);
  v3 (this) parses the manifest and cross-checks its fingerprint against the
     running recipe (frame, grid, zoom range, CRS, input shas, semantic
     scenes digest, schema, quality, deep zoom) and its completeness claims
     (limited=false, zero failures/strays/drift, per-zoom counts summing to
     the expected keyset), uses the same semantic scenes digest as the bake,
     and still refuses on manifest drift/disappearance by sha.

The manifest's PRESENCE marks the cache as fully baked: the server serves it
read-only and treats a miss as an error. Extending a sealed cache is refused
outright (grow a manifest-less staging cache instead).

stdlib-only on purpose: every branch is unit-testable without rasterio.
"""
import gzip
import hashlib
import json
import os
import sys

GUARD_NAME = ".map_fingerprint.json"
MANIFEST_NAME = ".bake_manifest.json"
# Written by map/audit_cache.py at the cache ROOT. Named here so the recorder
# and the two gates cannot drift apart: verify_bake_tree calls every file it
# does not recognise a stray, and refused the real v3 cache over these two.
CHECKSUM_LIST = ".tile_checksums.tsv.gz"
CHECKSUM_DIGEST = ".tile_checksums.digest.json"
# The first recorder wrote them undotted. Recognised, never written: a tree
# carrying one is still SEALED, so an old record cannot be quietly overwritten
# by pointing the recorder at it.
_LEGACY_CHECKSUMS = ("tile_checksums.tsv.gz", "tile_checksums.digest.json")
_ROOT_METADATA = ((GUARD_NAME, MANIFEST_NAME, CHECKSUM_LIST, CHECKSUM_DIGEST)
                  + _LEGACY_CHECKSUMS)
GUARD_SCHEMA = 6

# Without these the tile ADDRESSES and the payload LAYOUT mean something
# different, so the recorded bytes cannot be served at all. Compared against
# the running server for EVERY cache, sealed or not.
SERVING_KEYS = ("crs_sha256", "root", "Lx", "Ly", "maxz", "grid")

# What the RENDERER chose. Compared against the running server only while a
# cache can still GROW, because what they prevent is MIXING two renderers'
# output into one tree -- and a sealed cache cannot grow (a miss is a 404,
# see server.py SEALED_CACHE). They are still compared sidecar<->manifest:
# two frozen records of one bake must agree with each other.
#   jpeg_quality  -> encode_jpeg, cut path only
#   render_schema / scenes_sha256 / tone_sha256 -> the granule branch of the
#     tile cutter, cut path only. scenes_sha256 is the SEMANTIC digest, which
#     folds each granule's [size, mtime_ns] and its RESOLVED ABSOLUTE path:
#     the tracked 102-scene index digests differently under two mount points,
#     so as a serving key it pins a cache to one filesystem layout.
#   deep_zoom_min -> round(log2(root / DEEP_TILE_SPAN_U)), and
#     DEEP_TILE_SPAN_U is a module constant in frame.py, NOT a property of
#     the anchor: it moves while root/Lx/Ly/maxz/grid hold still.
RECIPE_KEYS = ("deep_zoom_min", "jpeg_quality", "render_schema",
               "scenes_sha256", "tone_sha256", "land_mask_sha256")

# Everything a CURRENT sidecar writes down. Same tuple, same order, as before
# the split -- no sidecar bytes move.
HARD_KEYS = SERVING_KEYS + RECIPE_KEYS
_V1_HARD_KEYS = ("crs_sha256", "root", "Lx", "Ly", "maxz", "jpeg_quality")
# v2 compared a raw-file scenes sha; its meaning changed in v3, so upgrades
# re-derive it instead of comparing.
_V2_HARD_KEYS = _V1_HARD_KEYS + ("render_schema",)
# v3 sidecars never recorded a tone: an upgrade cannot compare what was not
# written down, so it re-derives instead.
_V3_HARD_KEYS = tuple(k for k in HARD_KEYS
                      if k not in ("tone_sha256", "land_mask_sha256"))
_V4_HARD_KEYS = tuple(k for k in HARD_KEYS if k != "land_mask_sha256")
# v5 records the same keys; what changed is what its manifest_sha256 points
# at -- a sealed manifest, which carries the input pins the bake could not.
_V5_HARD_KEYS = _V4_HARD_KEYS
_V6_HARD_KEYS = HARD_KEYS

# ONE spelling of the rung set. It used to be spelled twice two lines apart,
# so a rung could be accepted-but-unmapped (KeyError) or mapped-but-rejected.
#
# WARNING for whoever adds the next key: adding it by EXCLUSION from the old
# rungs (the tone_sha256 idiom above) is right only for a key describing
# something the old caches genuinely did not record. A key describing
# something every old cache HAS -- an on-disk format number, say -- must
# instead be normalised onto the loaded record with a known default and
# compared at EVERY rung, or the guard is disabled on exactly the caches it
# exists to catch.
_RECORDED = {1: _V1_HARD_KEYS, 2: _V2_HARD_KEYS, 3: _V3_HARD_KEYS,
             4: _V4_HARD_KEYS, 5: _V5_HARD_KEYS, 6: _V6_HARD_KEYS}


# Guard key -> bake-manifest fingerprint key, where the two names differ.
# The only asymmetry: the baker writes the zoom ceiling as zmax.
_MANIFEST_ALIAS = {"maxz": "zmax"}


RECORDED_SCHEMAS = frozenset(_RECORDED)


def recorded_keys(schema):
    """What a sidecar of this schema actually wrote down."""
    return _RECORDED[schema]


def compared_keys(schema, sealed):
    """Keys compared against the RUNNING server. A sealed cache serves misses
    as 404, so its render recipe is out of scope; a staging cache can still
    grow, so all of it is in scope. Intersected with the rung, because a
    comparison against a value that was never written down is a comparison
    against None."""
    base = SERVING_KEYS if sealed else HARD_KEYS
    return tuple(k for k in base if k in _RECORDED[schema])


def manifest_recipe(fp, keys=HARD_KEYS):
    """The guard's view of a bake-manifest fingerprint: {guard key: value}.
    DERIVED from the key tuples, never hand-listed -- the sealer, the install
    gate and the serving guard all compare through here, so a key added to
    HARD_KEYS cannot be forgotten by one of the three. tone_sha256 was:
    scripts/verify_bundle_frame.py never compared it."""
    return {k: fp.get(_MANIFEST_ALIAS.get(k, k)) for k in keys}


def recipe_mismatch(want, got, keys):
    """[key, ...] where two recipe views disagree -- one comparison rule for
    sidecar-vs-server, manifest-vs-server and sidecar-vs-manifest."""
    return [k for k in keys if want.get(k) != got.get(k)]


class CacheMismatch(SystemExit):
    """Startup refusal (not a bug): the cache's recorded recipe disagrees
    with the inputs the server loaded."""


def role_of(name):
    """Input role from a raster basename (staging or installed) — the ONE
    name->role rule, shared with scripts/verify_bundle_frame.py. 'dem' is
    tested first so 'full_map_dem30.tif' maps to dem, not anchor. Returns
    'dem' / 'anchor' / None (unmappable)."""
    if "dem" in name:
        return "dem"
    if "full_map" in name or "anchor" in name:
        return "anchor"
    return None


def file_identity(path):
    """[size, mtime_ns] or None — byte-for-byte the bake's identity notion
    (map/bake_tiles.file_identity), because the semantic scenes digest folds
    it in and the two implementations must agree (test-pinned)."""
    try:
        st = os.stat(path)
        return [st.st_size, st.st_mtime_ns]
    except OSError:
        return None


def scenes_semantic_digest(scenes_path):
    """Semantic digest of the RESOLVED scene set — mirrors
    map/bake_tiles.scenes_digest over the same resolution rule the server
    applies (relative hrefs resolve against the index file's directory;
    URLs//vsi//absolute pass through). Returns "absent" when there is no
    readable index, which is itself a recipe state worth pinning."""
    try:
        with open(scenes_path) as fp:
            scenes = json.load(fp)
    except (OSError, ValueError):
        return "absent"
    base = os.path.dirname(os.path.abspath(scenes_path))
    resolved = []
    for sc in scenes:
        href = sc.get("href", "")
        if not ("://" in href or href.startswith("/vsi") or
                os.path.isabs(href)):
            href = os.path.normpath(os.path.join(base, href))
        resolved.append(dict(sc, href=href))
    h = hashlib.sha256()
    for sc in sorted(resolved, key=lambda s: s.get("href", "")):
        href = sc.get("href", "")
        if "://" in href or href.startswith("/vsi"):
            ident = "remote"
        else:
            ident = str(file_identity(href))
        h.update(("%s|%.6f|%.6f|%.6f|%.6f|%s\n" % (
            href, sc.get("w", 0), sc.get("s", 0), sc.get("e", 0),
            sc.get("n", 0), ident)).encode())
    return h.hexdigest()


def _write(path, record):
    tmp = path + ".tmp"
    with open(tmp, "w") as fp:
        json.dump(record, fp, indent=1, sort_keys=True)
    os.replace(tmp, path)


def _cache_has_tiles(cache_dir):
    if not os.path.isdir(cache_dir):
        return False
    for name in os.listdir(cache_dir):
        if not name.startswith("."):
            return True
    return False


def _default_memo_path():
    """Where to remember content hashes, outside the cache on purpose: a sealed
    asset must not change to make a boot faster.

    Under the repo, not $HOME. In the container the workspace is the only mount,
    so a $HOME path is thrown away with the container and every launch re-hashes
    27 GB. Keyed by (bytes, mtime_ns), so a file that actually changes still
    gets re-identified.
    """
    repo = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))))
    return os.path.join(repo, ".cache", "guard-hashes.json")


def _memo():
    """{key: sha} from MMP_GUARD_HASH_CACHE, or the repo default. Set the
    variable to an empty string to disable memoisation entirely."""
    p = os.environ.get("MMP_GUARD_HASH_CACHE", _default_memo_path())
    if not p:
        return None, None
    try:
        with open(p) as fp:
            return p, json.load(fp)
    except (OSError, ValueError):
        return p, {}


def _memo_key(name, ident):
    return f"{name}|{ident['bytes']}|{ident['mtime_ns']}"


def _check_file(name, stored, ident, changed):
    """One input raster: bytes must match; mtime drift re-identifies by
    content once. Returns the (possibly updated) stored dict."""
    if stored.get("bytes") != ident["bytes"]:
        raise CacheMismatch(
            f"cache input '{name}' is {ident['bytes']} bytes but the sidecar "
            f"records {stored.get('bytes')} — the file changed under a cache "
            f"cut from the old one. Re-bake, or restore the matching file.")
    if stored.get("mtime_ns") != ident["mtime_ns"]:
        path, memo = _memo()
        key = _memo_key(name, ident)
        sha = memo.get(key) if memo else None
        if sha is None:
            gb = ident["bytes"] / 1e9
            if gb >= 1.0:
                print(f"[guard] identifying '{name}' by content ({gb:.1f} GB) — "
                      f"its timestamp changed, which a fresh install always does. "
                      f"The server does not answer until this finishes; RViz "
                      f"will say 'Connection refused' until then. Runs once.",
                      file=sys.stderr, flush=True)
            sha = ident["hash"]()
            if memo is not None:
                memo[key] = sha
                try:
                    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                    tmp = path + ".tmp"
                    with open(tmp, "w") as fp:
                        json.dump(memo, fp)
                    os.replace(tmp, path)
                except OSError as exc:
                    # Not fatal, but say it. Swallowing this silently is how the
                    # 27 GB re-read came back on every launch with no clue why.
                    print(f"[guard] could not save the hash memo to {path} "
                          f"({exc}); the next launch will read {name} again",
                          file=sys.stderr, flush=True)
        if sha != stored.get("sha256"):
            raise CacheMismatch(
                f"cache input '{name}' hashes {sha[:12]}… but the sidecar "
                f"records {str(stored.get('sha256'))[:12]}… — same size, "
                f"different pixels. The cached tiles no longer match; "
                f"re-bake or restore the file.")
        stored = dict(stored, mtime_ns=ident["mtime_ns"])
        changed.append(name)
    return stored


def list_digest(pairs):
    """One digest over the whole (rel, sha) list -- the number a release
    descriptor pins. ORDER-DEPENDENT over a sorted list, and it covers names
    and shas only: it can prove a recorded file moved or vanished, and it
    CANNOT see a file that was added but never listed. That case is caught by
    walking the tree and differencing, not by this number."""
    h = hashlib.sha256()
    for rel, sha in pairs:
        h.update(f"{rel}\t{sha}\n".encode())
    return h.hexdigest()


_SHA_HEX = frozenset("0123456789abcdef")


def audit_checksum_list(cache_dir, pairs, expect_files=None):
    """[problem, ...] with the RECORD itself, before it is used as evidence.

    list_digest cannot do this job: it hashes whatever it is given, so a list
    naming ../../etc/passwd, naming one tile twice, or carrying a sha that is
    not a sha, has a perfectly good digest. The record has to be checked as a
    record before its digest means anything, and the last two checks are the
    only ones that can see a tile PRESENT on disk but ABSENT from the list.
    """
    bad, seen = [], set()

    def note(msg):
        if len(bad) < 20:
            bad.append(msg)

    for rel, sha in pairs:
        if rel in seen:
            note(f"{rel}: listed more than once")
        seen.add(rel)
        if os.path.isabs(rel) or rel.startswith(("/", "\\")):
            note(f"{rel}: absolute path in a cache-relative record")
            continue
        parts = rel.replace("\\", "/").split("/")
        if ".." in parts or "." in parts or "" in parts:
            note(f"{rel}: traversal or empty component")
            continue
        stem, _dot, ext = parts[-1].rpartition(".")
        ok = len(parts) == 3 and ext in ("jpg", "hgt")
        if ok:
            try:
                int(parts[0]), int(parts[1]), int(stem)
            except ValueError:
                ok = False
        if not ok:
            note(f"{rel}: not a z/x/y.jpg|hgt tile path")
        if len(sha) != 64 or set(sha) - _SHA_HEX:
            note(f"{rel}: {sha[:16]!r} is not a lowercase 64-hex sha256")
    if expect_files is not None and len(pairs) != expect_files:
        note(f"list holds {len(pairs)} entries, the release expects "
             f"{expect_files}")
    listed = {r for r, _ in pairs}
    on_disk = set()
    for root, _dirs, files in os.walk(cache_dir):
        rel_dir = os.path.relpath(root, cache_dir)
        for name in files:
            rel = name if rel_dir == "." else os.path.join(rel_dir, name)
            if rel in _ROOT_METADATA:
                continue
            on_disk.add(rel.replace(os.sep, "/"))
    for rel in sorted(on_disk - listed)[:20]:
        note(f"{rel}: on disk but never recorded")
    for rel in sorted(listed - on_disk)[:20]:
        note(f"{rel}: recorded but missing from disk")
    return bad


def checksum_list_path(cache_dir):
    """The record's path, canonical name first, legacy accepted."""
    for name in (CHECKSUM_LIST,) + _LEGACY_CHECKSUMS[:1]:
        p = os.path.join(cache_dir, name)
        if os.path.exists(p):
            return p
    return os.path.join(cache_dir, CHECKSUM_LIST)


def read_checksums(cache_dir, path=None):
    """[(rel, sha256), ...] as recorded, in file order. `path` reads a record
    kept OUTSIDE the cache (see map/audit_cache.py --out-record)."""
    p = path or checksum_list_path(cache_dir)
    if not os.path.exists(p):
        raise CacheMismatch(f"{p} missing — record checksums before "
                            f"verifying them")
    pairs = []
    with gzip.open(p, "rt") as fp:
        for line in fp:
            rel, sha = line.rstrip("\n").split("\t")
            pairs.append((rel, sha))
    return pairs


def _load_manifest(cache_dir):
    p = os.path.join(cache_dir, MANIFEST_NAME)
    if not os.path.exists(p):
        return None, None
    try:
        with open(p) as fp:
            raw = fp.read()
        return json.loads(raw), hashlib.sha256(raw.encode()).hexdigest()
    except (OSError, ValueError) as ex:
        raise CacheMismatch(
            f"{p} is unreadable ({ex}) — a sealed cache without a readable "
            f"manifest cannot prove what it contains. Restore it "
            f"(map/reports carries a copy).")


def manifest_roles(cache_dir, man):
    """{role: sha256} the manifest pins for its input rasters.

    A bake that ran without raster build sidecars wrote nulls here, and the
    v3 manifest is one of those. The repair is NOT to edit that manifest --
    it recorded truthfully what it could measure, and rewriting it would make
    it look as though it had always known. A SEALER adds `sealed_inputs_sha256`
    alongside the untouched fingerprint, filled only from a three-way
    agreement it can show its work for. Where the bake DID pin them, the two
    must agree: a sealed block is a completion, never an override.
    """
    fp = man.get("fingerprint") or {}
    roles = {}
    for name, sha in (fp.get("inputs_sha256") or {}).items():
        role = role_of(name)
        if role is None or role in roles:
            raise CacheMismatch(
                f"{cache_dir}/{MANIFEST_NAME}: fingerprint.inputs_sha256 "
                f"name {name!r} cannot be role-mapped unambiguously "
                f"(mapped so far: {sorted(roles)}) — the manifest must "
                f"carry exactly one anchor and one DEM.")
        roles[role] = sha
    sealed = man.get("sealed_inputs_sha256") or {}
    for role, sha in sealed.items():
        if role not in ("anchor", "dem"):
            raise CacheMismatch(
                f"{cache_dir}/{MANIFEST_NAME}: sealed_inputs_sha256 names "
                f"{role!r}, which is not an input role.")
        was = roles.get(role)
        if was and was != sha:
            raise CacheMismatch(
                f"{cache_dir}/{MANIFEST_NAME}: sealed_inputs_sha256[{role}] "
                f"{str(sha)[:12]}… overrides the bake's own "
                f"{str(was)[:12]}… — a seal may COMPLETE an unpinned input, "
                f"never contradict a pinned one. This manifest was edited.")
        roles[role] = sha
    return roles


def _validate_manifest(cache_dir, man, hard_fp, file_shas, sidecar=None):
    """The manifest must describe THIS recipe and claim a complete, clean
    bake — binding an unrelated (or failed/partial) manifest must refuse."""
    def bad(field, got, want):
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME} does not match the running recipe: "
            f"{field} is {got!r} but the server loaded {want!r}. This "
            f"manifest belongs to a different bake — restore the right one "
            f"or re-bake.")
    fp = man.get("fingerprint")
    if not isinstance(fp, dict):
        bad("fingerprint", type(fp).__name__, "a fingerprint object")
    # Against the RUNNING server: serving keys only, for the same reason the
    # sidecar comparison drops the recipe -- a sealed cache serves misses as
    # 404. This is not redundant with the sidecar check: schemas 1 and 2
    # never recorded `grid`, and the manifest always does.
    for k in recipe_mismatch(manifest_recipe(fp, SERVING_KEYS), hard_fp,
                             SERVING_KEYS):
        bad(f"fingerprint.{_MANIFEST_ALIAS.get(k, k)}",
            manifest_recipe(fp, SERVING_KEYS).get(k), hard_fp.get(k))
    # Against the SIDECAR: everything that schema wrote down, recipe
    # included. Two frozen records of one bake must agree with each other
    # even though neither is compared to the running server -- this is what
    # catches a tampered sidecar tone, which nothing compared before.
    if sidecar is not None:
        schema = sidecar.get("guard_schema") or 1
        keys = recorded_keys(schema)
        drift = recipe_mismatch(sidecar, manifest_recipe(fp, keys), keys)
        if drift:
            raise CacheMismatch(
                f"{cache_dir}: the guard sidecar and {MANIFEST_NAME} "
                f"disagree about {drift} — two records of ONE bake cannot "
                f"differ. One of them was edited; restore the pair from the "
                f"release, or re-seal.")
    if fp.get("zmin") != 0:
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: fingerprint.zmin is "
            f"{fp.get('zmin')!r} — a sealed cache must carry the FULL "
            f"pyramid (zmin 0).")
    if fp.get("strict_s2") is not True:
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: fingerprint.strict_s2 is "
            f"{fp.get('strict_s2')!r} — a sealed cache must come from a "
            f"strict-S2 bake (deep-zoom scene resolution enforced, not "
            f"best-effort).")
    roles = manifest_roles(cache_dir, man)
    missing = sorted(r for r, sha in roles.items() if not sha)
    if missing:
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: fingerprint.inputs_sha256 pins "
            f"nothing for {missing} — an unpinned raster is a wildcard any "
            f"file satisfies, which is the opposite of what this field is "
            f"for. Seal the cache with scripts/seal_staged_cache.py, which "
            f"fills them from an approved release.")
    if roles != file_shas:
        diff = {r: (str(roles.get(r))[:12], str(file_shas.get(r))[:12])
                for r in sorted(set(roles) | set(file_shas))}
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: fingerprint.inputs_sha256 does "
            f"not match the loaded inputs role-wise "
            f"{{role: (manifest, loaded)}} = {diff} — the tiles were baked "
            f"from different rasters.")
    keys = man.get("keys") or {}
    for field in ("failed", "bad_on_disk", "stray_files"):
        if keys.get(field) != 0:
            raise CacheMismatch(
                f"{cache_dir}/{MANIFEST_NAME}: keys.{field} is "
                f"{keys.get(field)!r} — a sealed cache must come from a "
                f"clean bake.")
    if keys.get("limited"):
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: keys.limited is set — a partial "
            f"bake cannot seal a cache.")
    per_zoom = man.get("per_zoom_expected") or {}
    total = sum(per_zoom.values())
    if keys.get("expected") != total or total <= 0:
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: keys.expected "
            f"{keys.get('expected')!r} != per-zoom sum {total} — the "
            f"manifest's own keyset is inconsistent.")
    if man.get("inputs_drift"):
        raise CacheMismatch(
            f"{cache_dir}/{MANIFEST_NAME}: inputs_drift is recorded — the "
            f"bake itself flagged its inputs as having moved.")


def assert_cache_mutable(cache_dir):
    """Refuse BEFORE any write into a cache that claims to be verified.

    The sealed invariant is about WRITES, not about rendering. Three callers
    reach the tile cutter directly and bypass the server's miss=404 rule
    (map/bake_tiles.py, map/audit_cache.py, map/swap_and_rebake.py);
    rendering is fine -- the auditor re-renders in memory and writes nothing.
    Writing is what desynchronises a tree from the manifest, the checksum
    record and the release that pins them.

    A finished release cache is not a repair-in-place target. Restore it from
    the bundle, or bake a NEW staging root and promote it as a new release.
    Removing the seal to repair in place is the one route that must not
    exist, so every marker refuses, not just the manifest.
    """
    claims = []
    if os.path.exists(os.path.join(cache_dir, MANIFEST_NAME)):
        claims.append(MANIFEST_NAME)
    for name in (CHECKSUM_LIST, CHECKSUM_DIGEST) + _LEGACY_CHECKSUMS:
        if os.path.exists(os.path.join(cache_dir, name)):
            claims.append(name)
    guard = os.path.join(cache_dir, GUARD_NAME)
    if os.path.exists(guard):
        try:
            with open(guard) as fp:
                if json.load(fp).get("manifest_sha256"):
                    claims.append(f"{GUARD_NAME} binding a bake manifest")
        except (OSError, ValueError):
            claims.append(f"{GUARD_NAME} (unreadable — assume sealed)")
    if claims:
        raise CacheMismatch(
            f"{cache_dir} is a SEALED release cache ({', '.join(claims)}) — "
            f"writing into it would desynchronise the tiles from the records "
            f"that attest them. Bake into a NEW staging root and promote it "
            f"as a new release; do not remove the seal and repair in place.")


def ensure_pairing(cache_dir, hard_fp, files, adopt_ok=False, warn=print):
    """Verify (or establish) the cache<->recipe pairing.

    hard_fp: dict with HARD_KEYS for the inputs the server loaded.
    files: {name: {"bytes": int, "mtime_ns": int, "hash": () -> sha256,
                   "extras": None | () -> dict}}   (extras merge into the
      sidecar top level, e.g. elev_max_m — computed only when the file is
      (re)identified).
    Returns the guard record. Raises CacheMismatch on any conflict. Never
    deletes or rewrites tiles.
    """
    path = os.path.join(cache_dir, GUARD_NAME)
    man, man_sha = _load_manifest(cache_dir)

    if os.path.exists(path):
        try:
            with open(path) as fp:
                rec = json.load(fp)
        except (ValueError, OSError) as ex:
            raise CacheMismatch(
                f"{path} is unreadable ({ex}) — refusing to guess the "
                f"cache's recipe. Restore it from the bake, or delete the "
                f"cache and re-bake.")
        schema = rec.get("guard_schema") or 1
        if schema not in _RECORDED:
            raise CacheMismatch(
                f"{path} carries guard_schema {schema!r}, newer than this "
                f"server understands — update the code, not the sidecar.")
        # A cache carrying its manifest is SEALED: a miss is a 404, so the
        # render recipe it was cut under is history, not a compatibility
        # requirement. Comparing it would pin the cache to one checkout and
        # one filesystem layout -- scenes_sha256 folds resolved absolute
        # paths, so the same tracked index digests differently under two
        # mounts, and the tone file moves with an ordinary git checkout.
        sealed = man is not None
        bad = recipe_mismatch(rec, hard_fp, compared_keys(schema, sealed))
        if bad:
            raise CacheMismatch(
                f"tile cache {cache_dir} was cut for a DIFFERENT recipe "
                f"(mismatched: {', '.join(bad)}). Refusing to serve or "
                f"extend it — point MMP_FTILE_CACHE at a cache baked for "
                f"these inputs, or re-bake.")
        changed = []
        if schema == 1:
            stored_files = {"anchor": {"bytes": rec.get("anchor_bytes"),
                                       "mtime_ns": rec.get("anchor_mtime_ns"),
                                       "sha256": rec.get("anchor_sha256")}}
            carry_extras = {k: rec[k] for k in ("elev_max_m",) if k in rec}
        else:
            stored_files = dict(rec.get("files") or {})
            carry_extras = {k: rec[k] for k in ("elev_max_m",) if k in rec}
        # A sealed record is evidence, not a cache of the current process:
        # it is carried forward verbatim, never rebuilt from hard_fp and
        # never upgraded. Its schema is whatever sealed it -- scripts/
        # seal_staged_cache.py is the only thing that may write one.
        new = dict(rec) if sealed else {k: hard_fp[k] for k in HARD_KEYS}
        if not sealed:
            new["guard_schema"] = GUARD_SCHEMA
        new["files"] = {}
        for name, ident in files.items():
            stored = stored_files.get(name)
            if stored is None:
                if sealed or schema == GUARD_SCHEMA:
                    raise CacheMismatch(
                        f"{path} lacks the identity of input '{name}' — "
                        f"sidecar and server disagree about the recipe "
                        f"shape. Re-bake.")
                stored = {"bytes": ident["bytes"],
                          "mtime_ns": ident["mtime_ns"],
                          "sha256": ident["hash"]()}
                changed.append(name)
            else:
                stored = _check_file(name, stored, ident, changed)
                # extras (elev_max_m) cost a full band scan of a 1.7 GB
                # anchor. A sealed record already carries the value, and its
                # authority -- the sha -- just matched.
                if name in changed and ident.get("extras") and not sealed:
                    carry_extras.update(ident["extras"]())
            new["files"][name] = stored
        new.update(carry_extras)
        file_shas = {n: f["sha256"] for n, f in new["files"].items()}
        if man is not None:
            _validate_manifest(cache_dir, man, hard_fp, file_shas, rec)
        old_man_sha = rec.get("manifest_sha256")
        if old_man_sha != man_sha:
            if old_man_sha is None and man_sha:
                raise CacheMismatch(
                    f"{cache_dir} carries {MANIFEST_NAME} but its sidecar "
                    f"does not bind it — dropping a manifest next to a "
                    f"staging cache does not make it a verified one. Seal "
                    f"it with scripts/seal_staged_cache.py, which checks "
                    f"the tiles against an approved release first.")
            elif man_sha is None:
                raise CacheMismatch(
                    f"{cache_dir}/{MANIFEST_NAME} disappeared but the "
                    f"sidecar still binds it — a verified cache lost its "
                    f"manifest. Restore it (map/reports carries a copy).")
            else:
                raise CacheMismatch(
                    f"{cache_dir}/{MANIFEST_NAME} changed (sha "
                    f"{man_sha[:12]}… vs recorded {old_man_sha[:12]}…) — a "
                    f"verified cache's manifest must not drift. Restore "
                    f"the original.")
        new["manifest_sha256"] = man_sha
        if schema != GUARD_SCHEMA and not sealed:
            changed.append("guard_schema")
            warn(f"[cache-guard] upgraded {path} to schema {GUARD_SCHEMA} "
                 f"(manifest content validation, semantic scenes digest, "
                 f"tone and land-mask rules hard-keyed)")
        if sealed:
            # NOTHING is written. "The server reads sidecars, it does not
            # author them" has no exceptions, or the exception becomes the
            # contract. An mtime drift is still checked -- by sha, every boot
            # -- it is just not recorded here. Keeping that cheap is the
            # installer's job (cp -p, and the seal is taken on the incoming
            # set so the promoted mtimes are the sealed ones); when it cannot
            # be, MMP_GUARD_HASH_CACHE holds the memo OUTSIDE the sealed
            # asset, where rewriting it costs nothing.
            if changed:
                warn(f"[cache-guard] {path} is SEALED and stays as sealed; "
                     f"re-identified {sorted(changed)} by content this boot. "
                     f"The result is memoised outside the cache, so the next "
                     f"boot skips the read.")
        elif changed:
            _write(path, new)
        return new

    # No sidecar.
    if man is not None or os.path.exists(
            os.path.join(cache_dir, CHECKSUM_LIST)):
        raise CacheMismatch(
            f"{cache_dir} carries {MANIFEST_NAME} or a recorded checksum "
            f"list but no {GUARD_NAME} — adopting it would mint a recipe "
            f"for a tree that already claims to be verified, blessing it "
            f"against whatever happens to be checked out. Seal it with "
            f"scripts/seal_staged_cache.py.")
    if _cache_has_tiles(cache_dir):
        if not adopt_ok:
            raise CacheMismatch(
                f"tile cache {cache_dir} has tiles but no {GUARD_NAME} — "
                f"its recipe is unknown and adopting it silently would bless "
                f"whatever it contains. If you are CERTAIN it was baked for "
                f"the current inputs, run once with MMP_ADOPT_TILE_CACHE=1; "
                f"otherwise point MMP_FTILE_CACHE elsewhere or re-bake.")
        warn(f"[cache-guard] {cache_dir} has tiles and no {GUARD_NAME}; "
             f"adopting the CURRENT inputs as its recipe of record "
             f"(explicitly approved).")
    rec = {k: hard_fp[k] for k in HARD_KEYS}
    rec["guard_schema"] = GUARD_SCHEMA
    rec["files"] = {}
    for name, ident in files.items():
        rec["files"][name] = {"bytes": ident["bytes"],
                              "mtime_ns": ident["mtime_ns"],
                              "sha256": ident["hash"]()}
    for name, ident in files.items():
        if ident.get("extras"):
            rec.update(ident["extras"]())
    if man is not None:
        _validate_manifest(cache_dir, man, hard_fp,
                           {n: f["sha256"] for n, f in rec["files"].items()})
    rec["manifest_sha256"] = man_sha
    os.makedirs(cache_dir, exist_ok=True)
    _write(path, rec)
    return rec


def verify_bake_tree(cache_dir, man):
    """Structural keyset + integrity audit of a FULLY baked cache tree
    against its manifest — used by the asset installer on a STAGED cache
    before promotion (and reusable for offline audits). Checks, per the
    manifest's own claims:

      - every tile path is {z}/{x}/{y}.jpg|.hgt with integer parts and a
        zoom the manifest expects; anything else (stray extensions, foreign
        paths) refuses — except the two dot-metadata files at the root;
      - the .jpg and .hgt RELATIVE KEYSETS are exactly identical (a count
        alone cannot tell 2N jpgs from N jpg+hgt pairs);
      - per-zoom pair counts equal per_zoom_expected, totalling keys.expected;
      - every .hgt is exactly 4*grid^2 bytes;
      - every .jpg starts with SOI (ffd8) and ends with EOI (ffd9).

    Raises CacheMismatch naming the first violation class (with samples).
    """
    fp = man.get("fingerprint") or {}
    grid = fp.get("grid")
    if not isinstance(grid, int) or grid < 2:
        raise CacheMismatch(
            f"{cache_dir}: manifest fingerprint.grid is {grid!r} — cannot "
            f"derive the HGT payload size to audit against.")
    hgt_bytes = 4 * grid * grid
    per_zoom = {int(z): n
                for z, n in (man.get("per_zoom_expected") or {}).items()}
    jpg_keys, hgt_keys = set(), set()
    bad = {"stray": [], "hgt_size": [], "jpg_marker": []}

    def note(kind, item):
        if len(bad[kind]) < 5:
            bad[kind].append(item)

    for root, _dirs, files in os.walk(cache_dir):
        rel_dir = os.path.relpath(root, cache_dir)
        for name in files:
            rel = name if rel_dir == "." else os.path.join(rel_dir, name)
            # Exact relative path at the ROOT, never a basename or a dot
            # prefix: metadata dropped inside 11/5/ is a stray, and that is
            # the only thing standing between an unlisted tile and a pass.
            if rel in _ROOT_METADATA:
                continue
            parts = rel.split(os.sep)
            stem, dot, ext = name.rpartition(".")
            key = None
            if len(parts) == 3 and dot and ext in ("jpg", "hgt"):
                try:
                    key = (int(parts[0]), int(parts[1]), int(stem))
                except ValueError:
                    key = None
            if key is None or key[0] not in per_zoom:
                note("stray", rel)
                continue
            path = os.path.join(root, name)
            if ext == "hgt":
                hgt_keys.add(key)
                if os.path.getsize(path) != hgt_bytes:
                    note("hgt_size", rel)
            else:
                jpg_keys.add(key)
                with open(path, "rb") as fpb:
                    head = fpb.read(2)
                    fpb.seek(-2, os.SEEK_END) if os.path.getsize(path) >= 4 \
                        else None
                    tail = fpb.read(2) if os.path.getsize(path) >= 4 else b""
                if head != b"\xff\xd8" or tail != b"\xff\xd9":
                    note("jpg_marker", rel)
    for kind, msg in (("stray", "unexpected files in the cache tree"),
                      ("hgt_size", f"HGT files not {hgt_bytes} bytes"),
                      ("jpg_marker", "JPEGs without SOI/EOI markers")):
        if bad[kind]:
            raise CacheMismatch(
                f"{cache_dir}: {msg}: {bad[kind]} …")
    if jpg_keys != hgt_keys:
        only_j = sorted(jpg_keys - hgt_keys)[:5]
        only_h = sorted(hgt_keys - jpg_keys)[:5]
        raise CacheMismatch(
            f"{cache_dir}: jpg/hgt keysets differ — jpg-only {only_j}, "
            f"hgt-only {only_h} … every key needs BOTH payloads.")
    counts = {}
    for z, _x, _y in jpg_keys:
        counts[z] = counts.get(z, 0) + 1
    if counts != per_zoom:
        raise CacheMismatch(
            f"{cache_dir}: per-zoom pair counts {counts} != manifest "
            f"per_zoom_expected {per_zoom}.")
    expected = (man.get("keys") or {}).get("expected")
    if len(jpg_keys) != expected:
        raise CacheMismatch(
            f"{cache_dir}: {len(jpg_keys)} pairs on disk != keys.expected "
            f"{expected}.")

#!/usr/bin/env python3
"""RViz terrain-tile backend: on-demand height + imagery tiles for the
mmp_rviz_plugins TerrainTilesDisplay (frame-native /ftile tree).

The CesiumJS web viewer (quantized-mesh /terrain, web-mercator /img, static
app) was removed 2026-07: the project renders terrain in RViz, not a browser.

Endpoints
  /ftile/meta                   grid + frame descriptor for the display
  /ftile/hgt/{z}/{x}/{y}        float32 height tile from the 30 m full-map DEM
  /ftile/img/{z}/{x}/{y}.png    frame-native imagery from full_map.tif; z >= 6
                                cuts 10 m RGB live from the Sentinel-2 granules
                                (degrades to the 250 m base if the index is absent)

Everything is served locally: no API keys, no external requests at runtime.
"""
import asyncio
import hashlib
import io
import json
import math
import os
import sys
import threading

import numpy as np
import rasterio
from aiohttp import web
from PIL import Image
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT
from rasterio.windows import from_bounds

# [TERRAIN-FRAME] The frame math is shared with terrain_publisher and lives in
# the ament package next door. This server is started standalone (run.sh, plain
# python3 + a PYTHONPATH pointing at tiles/pydeps), so the package is usually
# NOT importable: fall back to the source tree relative to this file —
# tiles/../ is the mmp_terrain package root, which contains the mmp_terrain/
# python package dir.
try:
    from mmp_terrain.frame import (load_frame, crs_digest, quadtree_levels,
                                   frame_bbox_to_en)
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from mmp_terrain.frame import (load_frame, crs_digest, quadtree_levels,
                                   frame_bbox_to_en)

# Everything resolves relative to this file, so the server keeps working no
# matter where the package sits in the workspace (or outside a container).
_TILES_DIR = os.path.dirname(os.path.abspath(__file__))
_PKG_DIR = os.path.dirname(_TILES_DIR)
# Overridable so a BAKE can point at staging rasters (a new frame, a new CRS)
# without touching the shipped ones. Unset, they resolve where they always did.
DEM_PATH = os.environ.get(
    "MMP_DEM", os.path.join(_PKG_DIR, "data", "full_map_dem30.tif"))
FULL_MAP_PATH = os.environ.get(
    "MMP_FULL_MAP", os.path.join(_PKG_DIR, "data", "full_map.tif"))
# Both are env-overridable so a BAKE can run against a staging index and a
# staging cache without touching the tracked s2_scenes.json or the live tiles.
# Unset, they resolve exactly where they always did.
SCENES_PATH = os.environ.get(
    "MMP_SCENES", os.path.join(_TILES_DIR, "data", "s2_scenes.json"))
LAND_MASK_PATH = os.environ.get("MMP_LAND_MASK")
IMGCACHE = os.path.join(_TILES_DIR, "data", "imgcache")           # deep-zoom tile disk cache
FIMGCACHE = os.environ.get("MMP_FTILE_CACHE", IMGCACHE + "_f")    # frame-native tile cache
# Fail closed on the half-configured staging combination: overriding any
# tile INPUT (anchor, DEM, scene index) while leaving the cache at the live
# default would serve stale-frame tiles as current and write new-frame cuts
# into the live cache — a mix only a full re-bake removes.
_STAGING_INPUTS = [v for v in ("MMP_FULL_MAP", "MMP_DEM", "MMP_SCENES",
                               "MMP_LAND_MASK")
                   if os.environ.get(v)]
if _STAGING_INPUTS and not os.environ.get("MMP_FTILE_CACHE"):
    raise SystemExit(
        f"{'/'.join(_STAGING_INPUTS)} override(s) set but MMP_FTILE_CACHE is "
        f"not — refusing to mix staging inputs with the live tile cache "
        f"({FIMGCACHE}). Set MMP_FTILE_CACHE to a cache for THAT map.")
# Pin the RESOLVED paths: the installer swaps the whole asset set by
# retargeting ONE assets/current symlink, and old versions stay on disk —
# resolving once at import keeps this process on the version it started
# with, so a mid-run install can never present it a mixed set (the
# install/serve half of the swap TOCTOU; the installer's flock covers the
# install/install half).
DEM_PATH = os.path.realpath(DEM_PATH)
FULL_MAP_PATH = os.path.realpath(FULL_MAP_PATH)
SCENES_PATH = os.path.realpath(SCENES_PATH)
LAND_MASK_PATH = os.path.realpath(LAND_MASK_PATH) if LAND_MASK_PATH else None
FIMGCACHE = os.path.realpath(FIMGCACHE)

# Sealed S2 tone rule (render_schema 3): per-channel affine fitted so S2
# imagery lowpassed to BMNG's 500 m GSD matches BMNG at the SAME locations.
# Applied ONLY on the granule branch of render_tile_rgb — anchor/BMNG RGB is
# untouched. The file's sha256 goes into the cache fingerprint (tone_sha256)
# so a cache can PROVE which tone rule made its pixels. Tracked next to this
# file, not env-overridable: a tone swap is a recipe change and must arrive
# as a commit + re-bake, never as an environment variable.
S2_TONE_PATH = os.path.join(_TILES_DIR, "s2_tone.json")
try:
    with open(S2_TONE_PATH, "rb") as _fp:
        _tone_raw = _fp.read()
    S2_TONE = json.loads(_tone_raw)["coefficients"]
    for _ch in ("R", "G", "B"):
        float(S2_TONE[_ch]["a"]), float(S2_TONE[_ch]["b"])
except (OSError, ValueError, KeyError, TypeError) as _ex:
    raise SystemExit(
        f"s2_tone.json unusable at {S2_TONE_PATH}: {_ex} — the S2 tone rule "
        f"is a sealed render input; restore the tracked file.")
S2_TONE_SHA = hashlib.sha256(_tone_raw).hexdigest()
del _tone_raw
DEEP_ZOOM_MIN = 11          # z >= this: tiles cut live from the 10 m granules
                            # (z11 is ~76 m/px — the 250 m baked mosaic is 3x
                            # too coarse there, so mid-zoom looked soft)

GRID = 257          # martini grid (2^k + 1)
MAX_TERRAIN_ZOOM = 13
MERC = 20037508.342789244
SEA_RGB = (25, 55, 95)
# One place says what quality the shipped tiles are encoded at. The bake
# driver stamps this into the cache fingerprint, so a change here invalidates
# the caches it would otherwise silently disagree with.
JPEG_QUALITY = 90
# Which renderer recipe the shipped tiles embody. CANONICAL HOME of the
# constant — map/bake_tiles.py carries the same value for its journal
# fingerprint and map/test_cache_guard.py pins the two equal. Bump BOTH when
# the pixels or the provenance rules change: the cache guard hard-keys it, so
# an old cache refuses to serve under a new recipe instead of mixing.
# 3 (2026-08-20): S2 tone = sealed BMNG-matched affine (s2_tone.json,
# fingerprinted as tone_sha256) replacing the one-sided 255*clip(g/160)**0.8
# gamma that produced 50-100 RGB seams at the S2/BMNG boundary.
# 4 (2026-08-22): sea/land comes from elevation UNION a sealed independent
# GSHHG mask. GLO-30 uses 0 m for both ocean and genuine sea-level land.
RENDER_SCHEMA = 4

_local = threading.local()

# One cut per tile, ever. Without this, N concurrent requests for an uncached
# tile all pass the cache-miss check and cut it N times — and with client-side
# timeouts re-requesting slow tiles, duplicate work snowballed into a backlog
# that kept ~25 cores busy long after every client had disconnected.
_cut_locks = {}
_cut_mutex = threading.Lock()


def _cached_cut(cache, cut):
    """Serve `cache` if present; else run cut() exactly once (per-tile lock),
    write atomically, return the bytes."""
    if os.path.exists(cache):
        with open(cache, "rb") as fp:
            return fp.read()
    if SEALED_CACHE and cache.startswith(FIMGCACHE + os.sep):
        raise FileNotFoundError(
            f"sealed cache miss: {cache} — this cache carries its verified "
            f"bake manifest and is served strictly read-only; extend a "
            f"manifest-less staging cache instead")
    with _cut_mutex:
        lk = _cut_locks.setdefault(cache, threading.Lock())
    try:
        with lk:
            if os.path.exists(cache):    # cut by whoever held the lock first
                with open(cache, "rb") as fp:
                    return fp.read()
            data = cut()
            os.makedirs(os.path.dirname(cache), exist_ok=True)
            tmp = cache + ".tmp%d" % threading.get_ident()
            with open(tmp, "wb") as fp:
                fp.write(data)
            os.replace(tmp, cache)
            return data
    finally:
        # Drop the per-path entry once the cut settles: the dict previously
        # only ever grew (one permanent Lock per unique tile path requested,
        # for the life of the server). Late twins re-create it harmlessly —
        # the file-exists fast path above makes the re-cut race benign.
        with _cut_mutex:
            _cut_locks.pop(cache, None)


def _ds(name, path, vrt3857=False, vrt_crs=None):
    """Per-thread dataset handles (rasterio handles are not thread-safe)."""
    cache = getattr(_local, "cache", None)
    if cache is None:
        cache = _local.cache = {}
    if name not in cache:
        src = rasterio.open(path)
        crs = "EPSG:3857" if vrt3857 else vrt_crs
        cache[name] = WarpedVRT(src, crs=crs,
                                resampling=Resampling.bilinear) if crs else src
    return cache[name]






# ---------------- deep-zoom imagery (10 m, live from Sentinel-2 COGs) -------

def _resolve_href(href, base_dir):
    """Scene href -> openable path/URL.

    RELATIVE paths resolve against the index file's own directory, so an index
    travels with its granules and survives a tree reorg. Absolute paths and
    URLs (http(s)://, s3://, /vsicurl/...) are passed through untouched, which
    keeps the remote STAC index working.
    """
    if "://" in href or href.startswith("/vsi") or os.path.isabs(href):
        return href
    return os.path.normpath(os.path.join(base_dir, href))


def _load_scenes(path):
    """Read the granule index, resolving hrefs. Missing local granules are
    REPORTED: a silent degradation to the 250 m base is exactly the failure
    that hid a stale index for months (every href pointed at a directory the
    tree reorg had left behind, and nothing said so)."""
    try:
        with open(path) as fp:
            scenes = json.load(fp)
    except Exception as ex:
        print("[scenes] no index at %s (%s) — deep zoom stays on the 250 m "
              "base" % (path, ex), file=sys.stderr, flush=True)
        return []
    base = os.path.dirname(os.path.abspath(path))
    missing = 0
    for sc in scenes:
        sc["href"] = _resolve_href(sc["href"], base)
        if "://" not in sc["href"] and not sc["href"].startswith("/vsi") \
                and not os.path.exists(sc["href"]):
            missing += 1
    if missing:
        print("[scenes] %d/%d granules in %s do not exist — those tiles will "
              "fall back to the 250 m base" % (missing, len(scenes), path),
              file=sys.stderr, flush=True)
    return scenes


SCENES = _load_scenes(SCENES_PATH)


def _scene_vrt(href, crs="EPSG:3857"):
    """Per-thread LRU of warped remote-COG handles (locality: one view area
    touches only a couple of granules)."""
    lru = getattr(_local, "scene_lru", None)
    if lru is None:
        lru = _local.scene_lru = {}
    key = (href, crs)
    if key not in lru:
        if len(lru) >= 8:
            _, (osrc, ovrt) = lru.popitem()
            ovrt.close(); osrc.close()
        src = rasterio.open(href)
        lru[key] = (src, WarpedVRT(src, crs=crs,
                                   resampling=Resampling.bilinear))
    return lru[key][1]


# ---------------- frame-native tiles (RViz TerrainTiles display) -----------
# Quadtree DIRECTLY in the planner world frame (units of 100 m): tile (z,x,y)
# covers [x*S,(x+1)*S] x [y*S,(y+1)*S], S = FRAME_ROOT / 2^z. The C++ display
# then needs zero map-projection code. Arrays are oriented i = wx ascending,
# j = wy ascending for BOTH the heightmap and the texture, so uv mapping in
# the plugin is trivial (u = j/(G-1), v = i/(G-1)).

FGRID = 65

# The frame anchor is what this server IS: without full_map.tif there is no
# frame to serve tiles in, so read it at import and fail loudly rather than
# fall back to a constant that would quietly describe a different map.
try:
    _FRAME = load_frame(FULL_MAP_PATH)
except Exception as _ex:                                  # pragma: no cover
    raise SystemExit(f"cannot read the frame anchor {FULL_MAP_PATH}: {_ex}\n"
                     f"(run scripts/fetch_assets.sh, or set MMP_FULL_MAP)")

# DERIVED, not maintained. The finest level stays 12.5 m/px and deep zoom
# still starts at 100 m/px whatever the frame's size — bumping FRAME_ROOT by
# hand and leaving FDEEP_ZOOM_MIN alone would have the baker cutting 10 m
# granules for 400 m/px tiles.
FRAME_ROOT, FDEEP_ZOOM_MIN, FMAXZ = quadtree_levels(_FRAME.anchor)

# Cache<->recipe pairing guard: the cache directory records the FULL recipe
# it was cut in (anchor, DEM, scene index, render schema, quality); serve
# only when everything matches. See cache_guard.
try:
    from cache_guard import ensure_pairing, scenes_semantic_digest
except ImportError:                                        # package-style import
    from tiles.cache_guard import ensure_pairing, scenes_semantic_digest


def _sha256_file(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(1 << 22), b""):
            h.update(chunk)
    return h.hexdigest()


def _validate_land_mask(path):
    if not path:
        return None
    if not os.path.isfile(path):
        raise SystemExit(f"MMP_LAND_MASK={path} does not exist")
    with rasterio.open(path) as ds, rasterio.open(FULL_MAP_PATH) as anchor_ds:
        same = (ds.count == 1 and ds.dtypes == ("uint8",)
                and ds.width == anchor_ds.width and ds.height == anchor_ds.height
                and ds.crs == anchor_ds.crs
                and ds.transform == anchor_ds.transform)
        if not same:
            raise SystemExit(
                f"MMP_LAND_MASK={path} is not a one-band uint8 raster on "
                f"the exact anchor grid {anchor_ds.width}x{anchor_ds.height}")
        tags = ds.tags()
        if tags.get("MMP_LAND_MASK_SCHEMA") != "1":
            raise SystemExit(f"MMP_LAND_MASK={path} lacks schema 1 tag")
    build = path + ".build.json"
    if not os.path.isfile(build):
        raise SystemExit(f"MMP_LAND_MASK={path} lacks {build}")
    rec = json.load(open(build))
    got = _sha256_file(path)
    if rec.get("sha256") != got:
        raise SystemExit(f"MMP_LAND_MASK={path} hashes {got[:12]} but its "
                         f"build record says {str(rec.get('sha256'))[:12]}")
    audit_path = path + ".audit.json"
    if not os.path.isfile(audit_path):
        raise SystemExit(f"MMP_LAND_MASK={path} lacks {audit_path}")
    audit = json.load(open(audit_path))
    if (audit.get("verdict") != "pass"
            or audit.get("land_mask_sha256") != got
            or audit.get("gshhg_only_missing_mask_overlap") != 0):
        raise SystemExit(f"MMP_LAND_MASK={path} has no passing independent "
                         f"coverage audit")
    return got


LAND_MASK_SHA = _validate_land_mask(LAND_MASK_PATH)


def _anchor_extras():
    """Real elevation ceiling for /ftile/meta (the C++ display sizes its
    frustum-cull boxes from it; a constant authored for one map broke on the
    next — Korea's 3000 m ceiling vs Fuji at ~3776 m). Runs only when the
    guard (re)identifies the anchor."""
    emax = 0.0
    with rasterio.open(FULL_MAP_PATH) as ds:
        # Anchor band layout is [elev, hillshade, R, G, B] — the assembler
        # writes terrain first; the serve path reorders with [3,4,5,2,1]
        # (see full_map_data below). Elevation is band ONE.
        eband = 1
        for _, win in ds.block_windows(eband):
            arr = ds.read(eband, window=win)
            m = np.nanmax(arr)
            if np.isfinite(m):
                emax = max(emax, float(m))
    return {"elev_max_m": round(emax, 1)}


_ANCHOR_ST = os.stat(FULL_MAP_PATH)
_DEM_ST = os.stat(DEM_PATH)
_CACHE_REC = ensure_pairing(
    FIMGCACHE,
    {"crs_sha256": crs_digest(_FRAME.crs_wkt), "root": FRAME_ROOT,
     "Lx": _FRAME.anchor.Lx, "Ly": _FRAME.anchor.Ly, "maxz": FMAXZ,
     "grid": FGRID, "deep_zoom_min": FDEEP_ZOOM_MIN,
     "jpeg_quality": JPEG_QUALITY, "render_schema": RENDER_SCHEMA,
     "tone_sha256": S2_TONE_SHA,
     "land_mask_sha256": LAND_MASK_SHA,
     # SEMANTIC digest of the resolved scene set — the same measure the bake
     # fingerprint records, so the manifest cross-check compares like with
     # like (a raw-file sha measured different bytes for the same granules).
     "scenes_sha256": scenes_semantic_digest(SCENES_PATH)},
    {"anchor": {"bytes": _ANCHOR_ST.st_size,
                "mtime_ns": _ANCHOR_ST.st_mtime_ns,
                "hash": lambda: _sha256_file(FULL_MAP_PATH),
                "extras": _anchor_extras},
     "dem": {"bytes": _DEM_ST.st_size, "mtime_ns": _DEM_ST.st_mtime_ns,
             "hash": lambda: _sha256_file(DEM_PATH), "extras": None}},
    adopt_ok=os.environ.get("MMP_ADOPT_TILE_CACHE") == "1")

# A cache carrying its (content-validated) bake manifest is COMPLETE: serve
# it read-only, and a miss is an error — cutting a fresh tile into a
# verified set would un-verify it silently. There is NO override on a sealed
# cache: extending happens in a manifest-less staging cache, never here.
# Dev/staging caches (no manifest) keep cut-on-miss as always.
SEALED_CACHE = _CACHE_REC.get("manifest_sha256") is not None
if SEALED_CACHE and os.environ.get("MMP_TILE_CUT_ON_MISS"):
    raise SystemExit(
        f"MMP_TILE_CUT_ON_MISS is set but {FIMGCACHE} is SEALED (it carries "
        f"its verified bake manifest) — extending it would desynchronise the "
        f"tiles from the manifest. Bake into a separate staging cache "
        f"(MMP_FTILE_CACHE) instead.")


def frame_consts():
    """Cached [TERRAIN-FRAME] anchor."""
    return _FRAME.anchor


def frame_crs():
    """The CRS the frame is expressed in, read off the anchor raster."""
    return _FRAME.crs


def frame_crs_wkt():
    return _FRAME.crs_wkt


def _frame_bbox_en(wx0, wy0, wx1, wy1):
    return frame_bbox_to_en(wx0, wy0, wx1, wy1,
                            _FRAME.anchor)   # (Emin, Nmin, Emax, Nmax)


# ONE definition of "which scenes does this tile touch". The cutter used to
# spell it inline, so anything auditing the choice -- a coverage survey, a cap
# study -- had to re-spell it and could get a DIFFERENT answer. It is a
# lon/lat AABB test, not a footprint test: the AABB of a granule is strictly
# larger than its footprint, so a scene can be selected here and contribute
# nothing to the tile.
# Width of the ramp between two overlapping composites, in metres.
# The cutter weighted every intersecting composite equally, which makes an
# overlap band a boxcar: inside it the value is (A+B)/2 and outside it is A or
# B, so the seam is a STEP at each end of the band. Measured on the v4 set the
# worst was 122 DN and it read as two maps stitched together.
# A SHIPPED CONSTANT, not a knob. The width is part of what the pixels are,
# and the only thing fingerprinting it is render_schema -- so if it could be
# read from the environment, a 5 km bake and an 8 km bake would carry the
# same cache identity while holding different imagery. Changing it is a code
# change with a render_schema bump, and the env var is refused rather than
# ignored: whoever set it believes it took effect.
S2_FEATHER_M = 8000.0
_QUAD_CACHE = {}


def refuse_feather_override():
    if os.environ.get("MMP_S2_FEATHER_M"):
        raise SystemExit(
            "MMP_S2_FEATHER_M is set but the feather width is a shipped "
            "constant (%.0f m): it changes the pixels and is fingerprinted "
            "only by render_schema (%d), so an environment override would "
            "give two different images one cache identity. Change "
            "S2_FEATHER_M in tiles/server.py and bump RENDER_SCHEMA instead."
            % (S2_FEATHER_M, RENDER_SCHEMA))


refuse_feather_override()


def scene_quad(href, crs):
    """A composite's own extent as a quadrilateral in frame coordinates.

    An S2 composite fills a full MGRS square in ITS OWN UTM grid, so the four
    transformed corners of its bounds ARE the granule footprint -- no index
    field, no extra read. Cached: it never changes.
    """
    key = (href, str(crs))
    got = _QUAD_CACHE.get(key)
    if got is None:
        from rasterio.warp import transform as _t
        with rasterio.open(href) as d:
            b = d.bounds
            ex, ny = _t(d.crs, crs,
                        [b.left, b.right, b.right, b.left],
                        [b.bottom, b.bottom, b.top, b.top])
        got = np.asarray(list(zip(ex, ny)), dtype=float)
        _QUAD_CACHE[key] = got
    return got


def feather_weight(quad, bbox, size, feather_m=None):
    """Per-pixel weight: 0 on the composite's own edge, 1 `feather_m` inside.

    The distance is GEOMETRIC, not a distance transform on a padded read: at
    z11 an 8 km pad is a 36x read amplification across 872,712 tiles, which no
    bake can afford. For a convex quadrilateral the distance to the boundary
    is the smallest perpendicular distance to its edge lines -- four
    vectorised terms, and the read window is untouched.
    """
    f = S2_FEATHER_M if feather_m is None else feather_m
    if f <= 0:
        return np.ones((size, size), np.float32)
    e0, n0, e1, n1 = bbox
    # Match _read_frame exactly: i = wx ascending (northing ascending) and
    # j = wy ascending, and wy = Ly - (E - E0)/100, so COLUMN 0 is the
    # LARGEST easting. Building this with easting ascending mirrors the ramp
    # east-west and blends in the far edge of the granule.
    half_e, half_n = (e1 - e0) / (2.0 * size), (n1 - n0) / (2.0 * size)
    ee = np.linspace(e1, e0, size, endpoint=False) - half_e
    nn = np.linspace(n0, n1, size, endpoint=False) + half_n
    E, N = np.meshgrid(ee, nn)
    inside = np.full(E.shape, np.inf, dtype=np.float64)
    cx, cy = quad[:, 0].mean(), quad[:, 1].mean()
    for k in range(len(quad)):
        ax, ay = quad[k]
        bx, by = quad[(k + 1) % len(quad)]
        dx, dy = bx - ax, by - ay
        ln = float(np.hypot(dx, dy))
        if ln < 1e-9:
            continue
        d = ((E - ax) * dy - (N - ay) * dx) / ln
        if ((cx - ax) * dy - (cy - ay) * dx) / ln < 0:
            d = -d
        inside = np.minimum(inside, d)
    return np.clip(inside / f, 0.0, 1.0).astype(np.float32)


def blend_sources(sources):
    """Weighted mean of (values, valid, weight) triples -> (rgb, count).

    A pixel covered by ONE composite keeps that composite exactly, whatever
    its weight: the weights are normalised, so a lone small weight is the
    whole of the sum. Pixels no composite covers stay NaN.
    """
    if not sources:
        return None, None
    shape = sources[0][1].shape
    acc = np.zeros((3,) + shape, np.float64)
    wsum = np.zeros(shape, np.float64)
    cnt = np.zeros(shape, np.uint16)
    for values, valid, weight in sources:
        if not valid.any():
            continue
        wt = np.where(valid, np.maximum(np.asarray(weight, np.float64), 1e-6),
                      0.0)
        for b in range(3):
            acc[b][valid] += np.nan_to_num(values[b][valid]) * wt[valid]
        wsum += wt
        cnt += valid.astype(np.uint16)
    out = np.where(wsum[None] > 0, acc / np.maximum(wsum[None], 1e-12), np.nan)
    return out, cnt


def scene_hits(scenes, w, s, e, n):
    return [sc for sc in scenes
            if sc["w"] < e and sc["e"] > w and sc["s"] < n and sc["n"] > s]


def _read_frame(ds, bands, bbox, size, boundless_ok,
                resampling=Resampling.bilinear):
    """Read bands over a frame-CRS bbox at size x size, NaN-filled outside.
    Output oriented i = wx asc (native rows flipped), j = wy asc (cols flipped)."""
    e0, n0, e1, n1 = bbox
    n = len(bands)
    if boundless_ok:
        win = from_bounds(e0, n0, e1, n1, ds.transform)
        raw = ds.read(bands, window=win, out_shape=(n, size, size),
                      boundless=True, fill_value=float("nan"),
                      resampling=resampling).astype(np.float32)
    else:                       # WarpedVRT: clip + paste
        raw = np.full((n, size, size), np.nan, dtype=np.float32)
        vb = ds.bounds
        ix0, iy0 = max(e0, vb.left), max(n0, vb.bottom)
        ix1, iy1 = min(e1, vb.right), min(n1, vb.top)
        if ix0 < ix1 and iy0 < iy1:
            px0 = max(0, int(round((ix0 - e0) / (e1 - e0) * size)))
            px1 = min(size, int(round((ix1 - e0) / (e1 - e0) * size)))
            py0 = max(0, int(round((n1 - iy1) / (n1 - n0) * size)))
            py1 = min(size, int(round((n1 - iy0) / (n1 - n0) * size)))
            if px1 > px0 and py1 > py0:
                win = from_bounds(ix0, iy0, ix1, iy1, ds.transform)
                part = ds.read(bands, window=win,
                               out_shape=(n, py1 - py0, px1 - px0),
                               resampling=resampling).astype(np.float32)
                raw[:, py0:py1, px0:px1] = part
    return raw[:, ::-1, ::-1]   # rows: N desc -> wx asc; cols: E asc -> wy asc


def ftile_hgt_bytes(z, x, y):
    # Disk-cache the heightmaps too. The image prewarm left hgt UNCACHED, so
    # every RViz session re-cut all of them from the 2 GB DEM — 40 concurrent
    # cuts, client timeouts, re-requests: a feedback storm that kept ~25 cores
    # busy long after RViz closed (to_thread work is uncancellable).
    def cut():
        S = FRAME_ROOT / (1 << z)
        bbox = _frame_bbox_en(x * S, y * S, (x + 1) * S, (y + 1) * S)
        dem = _ds("dem_frame", DEM_PATH, vrt3857=False, vrt_crs=frame_crs())
        h = _read_frame(dem, [1], bbox, FGRID, boundless_ok=False)[0]
        np.nan_to_num(h, copy=False)
        return np.ascontiguousarray(h, dtype="<f4").tobytes()
    return _cached_cut(f"{FIMGCACHE}/{z}/{x}/{y}.hgt", cut)


def strict_bake():
    """The ONE definition of bake strictness.

    The bake driver stamps this into the coverage journal's fingerprint, so it
    has to be the same predicate the cut consults — reading the environment in
    two places let a run inherit STRICT_BAKE=1, fail tiles strictly, and still
    record its provenance as non-strict.
    """
    return bool(os.environ.get("STRICT_BAKE"))


def ftile_img_png(z, x, y):
    # Cache EVERY level. z<6 was excluded (only ~1.4k tiles, "cheap"), but
    # cheap-per-tile is not cheap-per-session: the pinned z0..4 pyramid gets
    # re-cut from the full map and legacy local overlay on every RViz start.
    # New bakes are JPEG (3-5x smaller on photographic tiles AND faster to
    # decode in the RViz plugin — QImage::fromData sniffs the format, so the
    # ".png" in the URL is only a name). Legacy PNGs keep being served until
    # the re-bake replaces them.
    jpg = f"{FIMGCACHE}/{z}/{x}/{y}.jpg"
    if os.path.exists(jpg):
        with open(jpg, "rb") as fp:
            return fp.read()
    png = f"{FIMGCACHE}/{z}/{x}/{y}.png"
    if os.path.exists(png):
        with open(png, "rb") as fp:
            return fp.read()
    # _ftile_img_cut also reports where each pixel's colour came from; the
    # server needs only the bytes (the bake driver takes the stats).
    return _cached_cut(jpg, lambda: _ftile_img_cut(z, x, y)[0])


def _s2_tone(g):
    """Sealed S2 tone (s2_tone.json, fingerprinted as tone_sha256): affine
    per channel, clipped to [0,255]. NaN (no-granule pixels) passes through
    untouched — the caller substitutes only where the granule mask holds."""
    for i, ch in enumerate(("R", "G", "B")):
        co = S2_TONE[ch]
        g[i] = g[i] * co["a"] + co["b"]
    return np.clip(g, 0.0, 255.0)


def _shown_land(elev, have_rgb, independent_land=None):
    """Pixels rendered as land.

    Positive elevation remains an independent land authority.  When present,
    the sealed GSHHG mask adds true sea-level and below-sea-level land; it
    never removes a DEM-positive pixel.  `have_rgb` keeps pixels outside the
    frame or without a base source out of both the picture and the coverage
    denominator.
    """
    dem_land = np.isfinite(elev) & (elev > 0.0)
    if independent_land is not None:
        dem_land |= np.asarray(independent_land, dtype=bool)
    return dem_land & np.asarray(have_rgb, dtype=bool)


def render_tile_rgb(z, x, y, stats_window=None):
    """Render one frame-native imagery tile -> (rgb uint8 HxWx3, stats).

    Split from the JPEG encode so a quality study can encode the SAME pixels
    at two settings instead of re-decoding an already-lossy tile — comparing
    against a decoded q90 would fold q90's own loss into the baseline and
    flatter whatever it is compared with.

    Returns ``(rgb, stats, masks)``. `stats` is SCALARS ONLY — the bake
    driver pickles it between processes and keeps one per tile, and a 256x256
    bool mask is 64 KiB (128 KiB for the pair), which does not survive being
    multiplied by a pyramid. The diagnostic masks come back as a separate
    value that `_ftile_img_cut` drops on the floor.

    `stats_window` is an (i0, i1, j0, j1) slice in the tile's own array space
    (i = wx ascending, j = wy ascending) that restricts ONLY the provenance
    counters, never the rendering. The bake driver passes the part of the tile
    that lies inside an AOI, so a tile clipped by the AOI boundary contributes
    just its inside pixels to the coverage ratio instead of all 65 536.
    """
    S = FRAME_ROOT / (1 << z)
    bbox = _frame_bbox_en(x * S, y * S, (x + 1) * S, (y + 1) * S)
    full_map_data = _read_frame(
        _ds("full_map", FULL_MAP_PATH),
        [3, 4, 5, 2, 1], bbox, 256, True)
    rgb, hs, elev = full_map_data[:3], full_map_data[3], full_map_data[4]
    independent_land = None
    if LAND_MASK_PATH:
        independent_land = _read_frame(
            _ds("land_mask", LAND_MASK_PATH), [1], bbox, 256, True,
            Resampling.nearest)[0] > 0.5
    # NOTE: the legacy local overlay was retired (2026-07). It predated the
    # region-wide 10 m summer composites and, being outside the granule
    # harmonization, rendered as a conspicuous dark AOI square. The granules
    # cover its area at the same 10 m, so the overlay and /img2 endpoint are
    # gone entirely.

    # Region-wide 10 m: live from the Sentinel-2 granule COGs (same source the
    # globe deep zoom uses), with graceful degradation to the 250 m mosaic.
    s2_mask = None      # [BAKE-GRADE] pixels whose RGB came from a 10 m granule
    n_hits = 0
    if z >= FDEEP_ZOOM_MIN and SCENES:
        try:
            from rasterio.warp import transform_bounds
            w, s, e, n = transform_bounds(frame_crs(), "EPSG:4326",
                                          bbox[0], bbox[1], bbox[2], bbox[3])
            hits = scene_hits(SCENES, w, s, e, n)
            n_hits = len(hits)
            if hits:
                with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR",
                                  GDAL_HTTP_MAX_RETRY="3",
                                  GDAL_HTTP_RETRY_DELAY="1"):
                    # Read every intersecting composite.  AABB overlap is
                    # only a candidate test: an earlier four-item cap could
                    # spend all four reads on footprint/nodata pixels and
                    # silently discard the fifth composite that actually
                    # covered the tile.  The sealed staging index is finite;
                    # strict bake turns any failed read into a failed tile.
                    sources = []
                    for sc in hits:
                        g = _read_frame(_scene_vrt(sc["href"], frame_crs()),
                                       [1, 2, 3], bbox, 256, boundless_ok=False)
                        g[g == 0] = np.nan          # TCI nodata triple
                        m = np.isfinite(g).all(axis=0)
                        if not m.any():
                            continue
                        wt = feather_weight(
                            scene_quad(sc["href"], frame_crs()), bbox, 256)
                        sources.append((g, m, wt))
                blended, cnt = blend_sources(sources)
                gm = cnt is not None and (cnt > 0)
                if blended is not None and gm.any():
                    g = _s2_tone(blended)
                    for b in range(3):
                        rgb[b] = np.where(gm, g[b], rgb[b])
                    s2_mask = gm
        except Exception:
            # Live serving degrades gracefully to the 250 m base (offline).
            # During a BAKE that would silently freeze the degradation into
            # the cache, so the rebake runs with STRICT_BAKE=1 and fails the
            # tile instead (counted + retried by the bake driver).
            if strict_bake():
                raise
            pass                                     # offline: 250 m fallback

    have = np.isfinite(rgb).all(axis=0)
    shade = 0.7 + 0.3 * np.clip(np.nan_to_num(hs, nan=180.0) / 255.0, 0.0, 1.0)
    out = np.clip(np.nan_to_num(rgb) * shade[None], 0, 255).astype(np.uint8)
    out = out.transpose(1, 2, 0)
    # Sea -> flat blue for all sources: per-scene water glint/date otherwise
    # checkerboards. Elevation alone is not the classifier: 0 m is both ocean
    # and real reclaimed/delta land, recovered by the sealed GSHHG mask.
    land = _shown_land(elev, have, independent_land)
    sea = ~land
    out[sea | ~have] = SEA_RGB

    # [BAKE-GRADE] Where did each SHOWN pixel's colour come from? Only land
    # counts: everything at or below sea level was just overwritten with flat
    # blue, so granule coverage over water says nothing about tile quality.
    # A tile is not 10 m or 250 m — a granule can overlap and still leave part
    # of the tile uncovered (footprint edge, cloud/nodata triple), so the grade
    # is three-valued and carries the ratio the AOI gate actually tests.
    s2_land = (s2_mask & land) if s2_mask is not None else np.zeros_like(land)
    land_px = int(land.sum())
    s2_px = int(s2_land.sum())
    ratio = (s2_px / land_px) if land_px else 0.0
    stats = {"grade": "s2_full" if ratio >= 0.999 else ("mixed" if s2_px else "base"),
             "s2_ratio": round(ratio, 6), "land_px": land_px,
             "s2_px": s2_px, "hits": n_hits,
             "win_land_px": land_px, "win_s2_px": s2_px}
    if stats_window is not None:
        i0, i1, j0, j1 = stats_window
        stats["win_land_px"] = int(land[i0:i1, j0:j1].sum())
        stats["win_s2_px"] = int(s2_land[i0:i1, j0:j1].sum())

    return out, stats, {"land": land, "s2_land": s2_land}


def encode_jpeg(rgb, quality=JPEG_QUALITY):
    """The one encoder call. Pillow's defaults for subsampling and optimize
    are left alone: changing them would move every byte for reasons unrelated
    to the quality setting under study."""
    buf = io.BytesIO()
    Image.fromarray(rgb, "RGB").save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def _ftile_img_cut(z, x, y, stats_window=None):
    """Render + encode, the shape the bake driver and the server expect.

    The masks are dropped here on purpose: nothing past this point may carry
    a per-tile array into the bake driver's result list.
    """
    rgb, stats, _masks = render_tile_rgb(z, x, y, stats_window)
    return encode_jpeg(rgb), stats   # caching/locking handled by _cached_cut


async def h_ftile_meta(request):
    # _asdict() keeps the wire format the C++ display expects: flat
    # E0/N0/Lx/Ly keys alongside the grid descriptor.
    c = frame_consts()
    return web.json_response({**c._asdict(), "root": FRAME_ROOT, "grid": FGRID,
                              "maxz": FMAXZ, "deep_min": FDEEP_ZOOM_MIN,
                              # crs is informational — the C++ display works in
                              # frame units and ignores keys it does not know.
                              # It lets a consumer prove which projection a
                              # cache was cut in.
                              "crs_wkt": frame_crs_wkt(),
                              "crs_sha256": crs_digest(frame_crs_wkt()),
                              # real terrain ceiling of THIS anchor — the C++
                              # display sizes frustum-cull boxes from it
                              "elev_max_m": _CACHE_REC.get("elev_max_m")},
                             headers={"Access-Control-Allow-Origin": "*"})


def _ftile_in_range(z, x, y):
    if z < 0 or z > FMAXZ or x < 0 or y < 0:
        return False
    S = FRAME_ROOT / (1 << z)
    c = frame_consts()
    import math
    return x < max(1, math.ceil(c.Lx / S)) and y < max(1, math.ceil(c.Ly / S))


async def h_ftile_hgt(request):
    z = int(request.match_info["z"]); x = int(request.match_info["x"]); y = int(request.match_info["y"])
    if not _ftile_in_range(z, x, y):
        raise web.HTTPNotFound()
    try:
        data = await asyncio.to_thread(ftile_hgt_bytes, z, x, y)
    except FileNotFoundError as ex:
        raise web.HTTPNotFound(reason=str(ex))
    return web.Response(body=data, content_type="application/octet-stream",
                        headers={"Access-Control-Allow-Origin": "*"})


async def h_ftile_img(request):
    z = int(request.match_info["z"]); x = int(request.match_info["x"]); y = int(request.match_info["y"])
    if not _ftile_in_range(z, x, y):
        raise web.HTTPNotFound()
    try:
        data = await asyncio.to_thread(ftile_img_png, z, x, y)
    except FileNotFoundError as ex:
        raise web.HTTPNotFound(reason=str(ex))
    # cache now holds a JPEG/PNG mix — label by the bytes actually served
    ctype = "image/jpeg" if data[:3] == b"\xff\xd8\xff" else "image/png"
    return web.Response(body=data, content_type=ctype,
                        headers={"Access-Control-Allow-Origin": "*"})






def main():
    app = web.Application()
    app.router.add_get("/ftile/meta", h_ftile_meta)
    app.router.add_get("/ftile/hgt/{z}/{x}/{y}", h_ftile_hgt)
    app.router.add_get("/ftile/img/{z}/{x}/{y}.png", h_ftile_img)
    # aiohttp's banner is stdout, which mmp.launch.py used to hide. Say it on
    # stderr so "is it up yet?" is answerable from the launch output instead of
    # from an RViz display that says "Connection refused" either way.
    print("[tiles] listening on http://0.0.0.0:8085  (cache %s)"
          % ("sealed" if SEALED_CACHE else "growable"),
          file=sys.stderr, flush=True)
    web.run_app(app, host="0.0.0.0", port=8085, print=None)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Mosaic DEM tiles into one map tif for mmp_terrain.

Reprojects to a METRIC CRS (default EPSG:5179) so cells
are truly square: a geographic (EPSG:4326) grid spanning 33-43N stretches ~14%
more north-south at the top than at the bottom, which a square-cell grid_map
cannot express — the terrain publisher would silently squash the map.

Resampling is AVERAGE (not nearest/decimation): point-sampling a finer DEM
aliases ridges and can be WORSE than a natively coarse source. Averaging keeps
the coarse cell an honest mean of the fine data.

Usage:
  make_dem_mosaic.py --tiles DIR --out full_map.tif --res 250
  make_dem_mosaic.py --tiles DIR --out aoi.tif --res 30 \
      --bbox-lonlat 127.5 35.15 127.95 35.50
"""
import argparse
import glob
import json
import math
import os
import sys

import numpy as np
import rasterio
from rasterio.merge import merge
from rasterio.warp import calculate_default_transform, reproject, Resampling


# [HILLSHADE] One implementation, shared with the map probe. This script is
# routinely run straight out of the tree with no installed ament package, so
# fall back to the source layout the way tiles/server.py does.
try:
    from mmp_terrain.hillshade import hillshade_geographic
except ImportError:                                            # pragma: no cover
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from mmp_terrain.hillshade import hillshade_geographic

# Grids the coverage gate will arm for, with per-grid pins. Adding a name
# here is a deliberate act: the gate refuses everything else so that a typo
# cannot run the unproven directory-glob path under a production name.
#
# max_glo90_fallback=0: the glo90 materialization is proven only against
# glo90 neighbours; at a glo90<->ocean or glo90<->glo30 boundary it still
# holds its own edge instead of the true source. This coverage has zero
# fallback tiles, so the pin costs nothing — widening it is a work item
# that ends with mixed-boundary tests against a full-source reference.
PRODUCTION_GRIDS = {"east-asia-lcc-v1": {
    "max_glo90_fallback": 0,
    # corridor WarpedVRT grid resolution, stamped into the anchor as
    # MMP_DEM_VRT_RES metadata: matches the shipped Korea map's warp
    # grid density so the same corridor costs the same work (left to
    # the automatic extent-derived grid, r5 measured +25% wall).
    "dem_vrt_res": 28.213,
}}


def run_coverage_gate(args):
    """Prove the sources; build the plan; MAKE NOTHING.

    The full east-asia raster cannot be built by this in-RAM path at all
    (the widened geographic mosaic alone is tens of GiB), so until the
    windowed implementation lands, coverage mode is a gate: it either
    proves that every source the sealed grid needs is present, locked,
    aligned and complete — or it says exactly why not, non-zero.
    """
    try:
        from mmp_terrain import source_coverage as SC
    except ImportError:                                        # pragma: no cover
        sys.path.insert(0, os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))
        from mmp_terrain import source_coverage as SC

    if args.grid_name not in PRODUCTION_GRIDS:
        raise SystemExit(f"--grid-name {args.grid_name!r} is not a "
                         f"production grid {tuple(PRODUCTION_GRIDS)}")
    try:
        plan = SC.preflight(
            args.coverage_root, args.grid_name,
            workers=args.gate_workers, progress=print,
            max_glo90_fallback=PRODUCTION_GRIDS[
                args.grid_name]["max_glo90_fallback"])
    except SC.PreflightError as ex:
        print("COVERAGE GATE REFUSED:", file=sys.stderr)
        for p in ex.problems:
            print("  - " + p, file=sys.stderr)
        raise SystemExit(1)
    t = plan["target"]
    counts = {}
    for d in plan["cells"].values():
        counts[d["grade"]] = counts.get(d["grade"], 0) + 1
    print(f"[gate ] {plan['grid_name']}: target {t['width']} x {t['height']} "
          f"@ {t['resolution_m']:g} m — transform sealed, not recomputed")
    print(f"[gate ] sources: " + "  ".join(
        f"{g}={counts.get(g, 0)}" for g in ("glo30", "glo90_fallback",
                                            "ocean")))
    if args.plan_out:
        plan_json = dict(plan, cells=[
            dict(d, cell=list(d["cell"])) for _, d in
            sorted(plan["cells"].items())])
        tmp = args.plan_out + ".tmp"
        with open(tmp, "w") as fp:
            json.dump(plan_json, fp, indent=1)
        os.replace(tmp, args.plan_out)
        print(f"[gate ] plan written to {args.plan_out}")
    if not args.dem_out and not args.dem30_out and not args.full_map_out:
        print("[gate ] sources proven; pass --dem-out, --dem30-out and/or "
              "--full-map-out to write the staging rasters")
        return
    # the SC import above already put the source layout on sys.path
    from mmp_terrain import windowed_mosaic as WM
    if args.dem_out:
        if args.dem_hillshade_z is None:
            raise SystemExit("--dem-out needs an explicit --dem-hillshade-z "
                             "(the shipped recipe bakes shading at source "
                             "resolution; there is no silent default)")
        try:
            WM.write_dem(plan, args.dem_out, args.dem_hillshade_z,
                         max_rss_gib=args.dem_max_rss_gib, progress=print,
                         dem_vrt_res=PRODUCTION_GRIDS[
                             args.grid_name].get("dem_vrt_res"))
        except WM.WindowedError as ex:
            print("WINDOWED WRITE REFUSED:", file=sys.stderr)
            for p in ex.problems:
                print("  - " + p, file=sys.stderr)
            raise SystemExit(1)
        print(f"[write] staging DEM/hillshade at {args.dem_out} — this is "
              f"NOT full_map.tif; RGB bands are an unmade decision")
    if args.dem30_out:
        try:
            WM.write_dem30(plan, args.dem30_out,
                           max_rss_gib=args.dem_max_rss_gib, progress=print)
        except WM.WindowedError as ex:
            print("DEM30 WRITE REFUSED:", file=sys.stderr)
            for p in ex.problems:
                print("  - " + p, file=sys.stderr)
            raise SystemExit(1)
        print(f"[dem30] staging fine DEM at {args.dem30_out} — this is NOT "
              f"the live full_map_dem30.tif")
    if args.full_map_out:
        if not (args.anchor and args.bmng):
            raise SystemExit("--full-map-out needs --anchor and --bmng "
                             "(--korea-rgb is optional: omit for a uniform "
                             "BMNG base)")
        from mmp_terrain import full_map_assembler as FA
        # the sealed grid is the arbiter: the anchor being consumed must
        # BE the plan's target, or the assembly is for some other map
        import rasterio as _rio
        with _rio.open(args.anchor) as _a:
            got = tuple(_a.transform)[:6]
        if any(abs(g - x) > 1e-6 for g, x in zip(got,
                                                 t["transform"])):
            raise SystemExit(f"{args.anchor} is not on the sealed target "
                             f"grid this gate proved")
        bmng_sha = None
        rman = args.bmng_manifest or os.path.normpath(os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "..", "..", "map", "rgb_base_source.json"))
        if os.path.exists(rman):
            bmng_sha = json.load(open(rman))["object"].get("sha256")
        try:
            FA.write_full_map(args.anchor, args.bmng, args.korea_rgb,
                              args.full_map_out, bmng_sha=bmng_sha,
                              max_rss_gib=args.dem_max_rss_gib,
                              progress=print)
        except FA.WindowedError as ex:
            print("FULL-MAP ASSEMBLY REFUSED:", file=sys.stderr)
            for p in ex.problems:
                print("  - " + p, file=sys.stderr)
            raise SystemExit(1)
        print(f"[rgb  ] staging 5-band full_map at {args.full_map_out} — "
              f"STAGING, not the live map")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiles", help="dir of source .tif tiles (legacy path)")
    ap.add_argument("--out", help="output .tif (legacy path)")
    ap.add_argument("--res", type=float,
                    help="output cell size in METRES (legacy path)")
    ap.add_argument("--coverage-root", default=None,
                    help="root of a proven DEM coverage (manifests/, glo30/, "
                         "...). Arms the coverage gate INSTEAD of the legacy "
                         "directory-glob path; requires --grid-name.")
    ap.add_argument("--grid-name", default=None,
                    help="sealed production grid the gate is armed for; "
                         "must be one of %s" % (PRODUCTION_GRIDS,))
    ap.add_argument("--plan-out", default=None,
                    help="coverage mode: also write the source plan as JSON")
    ap.add_argument("--gate-workers", type=int, default=8)
    ap.add_argument("--dem-out", default=None,
                    help="coverage mode: write the STAGING DEM+hillshade "
                         "pair (band 1 elev float32, band 2 hillshade) "
                         "windowed, verified whole, then promoted "
                         "atomically. Never full_map.tif.")
    ap.add_argument("--dem-hillshade-z", type=float, default=None,
                    help="vertical exaggeration for the baked hillshade; "
                         "required with --dem-out, must be > 0. There is "
                         "no window-size knob: the compute tiling is part "
                         "of the sealed recipe (windowed_mosaic.WARP_TILE) "
                         "because the warped result depends on it.")
    ap.add_argument("--dem30-out", default=None,
                    help="coverage mode: write the fine STAGING corridor "
                         "DEM (band 1 only, source grid pasted, internal "
                         "overviews). Never the live full_map_dem30.tif.")
    ap.add_argument("--full-map-out", default=None,
                    help="coverage mode: assemble the 5-band STAGING "
                         "full_map from --anchor + --bmng + --korea-rgb. "
                         "Never the live full_map.tif.")
    ap.add_argument("--anchor", default=None,
                    help="the 2-band staging anchor the assembler consumes")
    ap.add_argument("--bmng", default=None,
                    help="the pinned BMNG base GeoTIFF (sha checked "
                         "against map/rgb_base_source.json)")
    ap.add_argument("--korea-rgb", default=None,
                    help="the shipped Korea full_map.tif whose RGB core "
                         "is preserved")
    ap.add_argument("--bmng-manifest", default=None,
                    help="pin manifest for the BMNG object (default: the "
                         "repo's map/rgb_base_source.json)")
    ap.add_argument("--dem-max-rss-gib", type=float, default=12.0,
                    help="hard peak-RSS ceiling for the windowed write; "
                         "exceeding it aborts without promoting")
    ap.add_argument("--crs", default="EPSG:5179",
                    help="output CRS (metric). The DEFAULT is deliberately "
                         "the CRS the shipped map was built in, so re-running "
                         "this command reproduces it; pass --crs-file to "
                         "build a map in another projection.")
    ap.add_argument("--crs-file", default=None,
                    help="read the output CRS from a WKT/PROJJSON file "
                         "(overrides --crs). One file is the build-time "
                         "authority; runtime reads full_map.tif.crs.")
    ap.add_argument("--bbox-lonlat", nargs=4, type=float, default=None,
                    metavar=("W", "S", "E", "N"),
                    help="optional crop in lon/lat before reprojecting")
    ap.add_argument("--keep-gaps", action="store_true",
                    help="leave missing-tile ocean gaps as nodata instead of "
                         "filling them with sea level (0 m)")
    ap.add_argument("--imagery", default=None,
                    help="optional satellite true-color GeoTIFF (3x uint8, any "
                         "CRS, e.g. a Sentinel-2 TCI subset). Averaged onto "
                         "the output grid and baked into bands 3/4/5 (RGB, "
                         "0..255 float32, NaN outside coverage) after a "
                         "fixed Google-Earth-like enhancement "
                         "(clip 0..160, gamma 0.8). terrain_publisher uses "
                         "these as the color layer instead of hypsometric "
                         "tint.")
    ap.add_argument("--hillshade-z", type=float, default=0.0,
                    help="if > 0, bake a hillshade computed at the SOURCE "
                         "resolution (e.g. 30 m) into band 2, averaged onto "
                         "the output grid, with this vertical exaggeration. "
                         "A hillshade computed from the coarse output DEM "
                         "loses the ridge/valley texture (slopes flatten as "
                         "cells grow); baking it from the fine source keeps "
                         "the terrain readable at map scale.")
    args = ap.parse_args()
    if args.coverage_root or args.grid_name:
        if not (args.coverage_root and args.grid_name):
            raise SystemExit("--coverage-root and --grid-name go together")
        # Refused, not ignored: a flag that silently does nothing today
        # becomes a silent lie the day the windowed writer lands.
        stray = [n for n, hit in (
            ("--tiles", args.tiles), ("--out", args.out),
            ("--res", args.res is not None),
            ("--crs", args.crs != "EPSG:5179"),
            ("--crs-file", args.crs_file is not None),
            ("--bbox-lonlat", args.bbox_lonlat is not None),
            ("--imagery", args.imagery is not None),
            ("--hillshade-z", args.hillshade_z != 0.0),
            ("--keep-gaps", args.keep_gaps)) if hit]
        if stray:
            raise SystemExit("coverage mode proves sources and builds "
                             "nothing; these belong to the legacy path: "
                             + ", ".join(stray))
        return run_coverage_gate(args)
    # Legacy path (the shipped EPSG:5179 map): unchanged, and deliberately
    # NOT gated — it predates the sealed-profile pipeline and re-running it
    # must keep reproducing the map it shipped.
    if not (args.tiles and args.out and args.res):
        raise SystemExit("--tiles, --out and --res are required "
                         "(or use --coverage-root/--grid-name)")
    if args.crs_file:
        # One file is the build-time authority for a map's projection; copying
        # a proj string into several tools is how they drift apart.
        with open(args.crs_file) as _fp:
            args.crs = _fp.read().strip()

    paths = sorted(glob.glob(os.path.join(args.tiles, "*.tif")))
    if not paths:
        raise SystemExit(f"no tiles in {args.tiles}")
    print(f"[1/3] merging {len(paths)} tiles ...")

    srcs = [rasterio.open(p) for p in paths]
    bounds = tuple(args.bbox_lonlat) if args.bbox_lonlat else None
    mosaic, mosaic_tf = merge(srcs, bounds=bounds)
    src_crs = srcs[0].crs
    nodata = srcs[0].nodata
    for s in srcs:
        s.close()
    band = mosaic[0]
    print(f"      mosaic {band.shape} in {src_crs}")

    # Sea is nodata/negative in Copernicus; make it an explicit NaN so the
    # average resampler does not drag coastal cells down toward -32767.
    band = band.astype(np.float32)
    if nodata is not None:
        band[band == nodata] = np.nan
    band[band < -1000.0] = np.nan

    # Hillshade at SOURCE resolution (before any downsampling). Same formula
    # as the classic Horn hillshade formula, but with a latitude-dependent
    # east-west cell size (geographic grids shrink dx with cos(lat); a single
    # mid-map value would skew slopes by ~7% at the N/S edges of a large map).
    hs_fine = None
    if args.hillshade_z > 0.0:
        print(f"[2a] hillshade at source res (z x{args.hillshade_z:g}) ...")
        hs_fine = hillshade_geographic(band, mosaic_tf, args.hillshade_z)

    # DOWNSAMPLING (usual case) must be AVERAGE; UPSAMPLING (e.g. a 10 m
    # imagery-matched grid from the 30 m DEM) must be CUBIC — average
    # degenerates to blocky nearest when each output cell sees at most one
    # source cell.
    lat_mid = mosaic_tf.f + mosaic_tf.e * band.shape[0] / 2.0
    src_res_m = abs(mosaic_tf.a) * math.pi / 180.0 * 6371000.0 * math.cos(math.radians(lat_mid))
    dem_resampling = Resampling.average if args.res >= 0.9 * src_res_m else Resampling.cubic
    print(f"[2/3] reprojecting to {args.crs} @ {args.res} m "
          f"({dem_resampling.name}; source ~{src_res_m:.0f} m) ...")
    dst_tf, dst_w, dst_h = calculate_default_transform(
        src_crs, args.crs, band.shape[1], band.shape[0],
        *rasterio.transform.array_bounds(band.shape[0], band.shape[1], mosaic_tf),
        resolution=(args.res, args.res))
    dst = np.full((dst_h, dst_w), np.nan, dtype=np.float32)
    reproject(
        source=band, destination=dst,
        src_transform=mosaic_tf, src_crs=src_crs, src_nodata=np.nan,
        dst_transform=dst_tf, dst_crs=args.crs, dst_nodata=np.nan,
        resampling=dem_resampling, num_threads=os.cpu_count() or 4)

    hs_dst = None
    if hs_fine is not None:
        hs_dst = np.full((dst_h, dst_w), np.nan, dtype=np.float32)
        reproject(
            source=hs_fine, destination=hs_dst,
            src_transform=mosaic_tf, src_crs=src_crs, src_nodata=np.nan,
            dst_transform=dst_tf, dst_crs=args.crs, dst_nodata=np.nan,
            resampling=dem_resampling, num_threads=os.cpu_count() or 4)
        del hs_fine

    rgb_dst = None
    if args.imagery:
        print(f"[2c] baking imagery {args.imagery} ...")
        with rasterio.open(args.imagery) as img:
            rgb_dst = np.full((3, dst_h, dst_w), np.nan, dtype=np.float32)
            for i in range(3):
                b = img.read(i + 1).astype(np.float32)
                # TCI nodata is the (0,0,0) triple; NaN it so averaging
                # never bleeds black into the coverage edge.
                b[b == 0] = np.nan
                reproject(
                    source=b, destination=rgb_dst[i],
                    src_transform=img.transform, src_crs=img.crs,
                    src_nodata=np.nan,
                    dst_transform=dst_tf, dst_crs=args.crs, dst_nodata=np.nan,
                    resampling=Resampling.average,
                    num_threads=os.cpu_count() or 4)
        # Google-Earth-like look for Sentinel-2 true color (dark forests):
        # fixed clip 0..160 then gamma 0.8. Fixed (not percentile) so the
        # result does not depend on the crop extent.
        rgb_dst = 255.0 * np.clip(rgb_dst / 160.0, 0.0, 1.0) ** 0.8
        cov = np.isfinite(rgb_dst[0]).mean()
        print(f"      imagery coverage {100.0*cov:.1f}% of grid")

    # Gaps: Copernicus simply has no tile for a pure-ocean 1-degree cell, so a
    # country-scale mosaic ends up with rectangular NO-DATA holes out at sea
    # (example: 19 of 80 tiles absent = 7% of the grid). Left as nodata they
    # become NaN in every published layer and render as black blocks / holes.
    # They are ALL open ocean, so filling them with sea level (0 m) is
    # physically correct and gives the publisher a hole-free map — its own
    # "elevation <= 0 is water" rule then paints them as sea like any other
    # water cell. --keep-gaps opts out.
    if args.keep_gaps:
        out = np.where(np.isnan(dst), -9999.0, dst).astype(np.float32)
    else:
        n_gap = int(np.isnan(dst).sum())
        out = np.where(np.isnan(dst), 0.0, dst).astype(np.float32)
        print(f"      filled {n_gap/1e6:.1f}M no-data cells "
              f"({100.0*n_gap/dst.size:.1f}%) with sea level (0 m)")
    finite = out[out > -9000.0]
    print(f"      grid {dst_w} x {dst_h} = {dst_w*dst_h/1e6:.1f}M cells; "
          f"elev {finite.min():.0f}..{finite.max():.0f} m "
          f"({100.0*finite.size/out.size:.0f}% land)")

    print(f"[3/3] writing {args.out} ...")
    if rgb_dst is not None and hs_dst is None:
        raise SystemExit("--imagery requires --hillshade-z (bands are ordered "
                         "1=elev, 2=hillshade, 3/4/5=RGB)")
    n_bands = 1 + (1 if hs_dst is not None else 0) + (3 if rgb_dst is not None else 0)
    with rasterio.open(
            args.out, "w", driver="GTiff", height=dst_h, width=dst_w,
            count=n_bands, dtype="float32", crs=args.crs, transform=dst_tf,
            nodata=(-9999.0 if args.keep_gaps else None),
            compress="deflate", tiled=True) as dst_ds:
        dst_ds.write(out, 1)
        if hs_dst is not None:
            # band 2 = source-resolution hillshade (0..255, NaN over sea);
            # terrain_publisher uses it instead of re-shading the coarse DEM.
            dst_ds.write(hs_dst, 2)
        if rgb_dst is not None:
            # bands 3/4/5 = enhanced true-color RGB (0..255, NaN = no imagery)
            for i in range(3):
                dst_ds.write(rgb_dst[i].astype(np.float32), 3 + i)
    print(f"done: {args.out} ({n_bands} band{'s' if n_bands > 1 else ''})")


if __name__ == "__main__":
    main()

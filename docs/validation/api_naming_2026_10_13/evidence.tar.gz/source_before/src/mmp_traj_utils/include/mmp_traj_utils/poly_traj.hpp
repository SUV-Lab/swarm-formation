#ifndef MMP_TRAJ_UTILS__POLY_TRAJ_HPP_
#define MMP_TRAJ_UTILS__POLY_TRAJ_HPP_

#include <mmp_traj_msgs/msg/poly_traj.hpp>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <string>

// The single shared reading of the PolyTraj wire contract. Piece i spans
// [sum(duration[0..i)), sum(duration[0..i])); each piece has (order + 1)
// coefficients per axis, highest power first, so coefficient j carries
// power (order - j) of the piece-local time.
//
// Three C++ consumers (mmp_visualization_node, AltitudeProfilePanel,
// TrajectoryMetricsPanel) used to re-derive validation and evaluation
// independently and had drifted on validation strength and junction
// handling; this header is the single authority.
namespace mmp_traj_utils
{

inline std::size_t coefficientsPerPiece(const mmp_traj_msgs::msg::PolyTraj & msg)
{
  return static_cast<std::size_t>(msg.order) + 1;
}

// Strict wire-contract validation — the union of the checks the consumers
// historically ran: non-empty, no size_t overflow, coefficient arrays sized
// duration.size() * (order + 1), every duration finite and positive, every
// coefficient finite.
inline bool validate(
  const mmp_traj_msgs::msg::PolyTraj & msg, std::string * reason = nullptr)
{
  if (msg.duration.empty()) {
    if (reason) {*reason = "trajectory has no pieces";}
    return false;
  }
  const std::size_t per_piece = coefficientsPerPiece(msg);
  if (msg.duration.size() >
    std::numeric_limits<std::size_t>::max() / per_piece)
  {
    if (reason) {*reason = "coefficient count overflows size_t";}
    return false;
  }
  const std::size_t expected = msg.duration.size() * per_piece;
  if (msg.coef_x.size() != expected || msg.coef_y.size() != expected ||
    msg.coef_z.size() != expected)
  {
    if (reason) {*reason = "coefficient-array size does not match duration/order";}
    return false;
  }
  for (const double duration : msg.duration) {
    if (!std::isfinite(duration) || duration <= 0.0) {
      if (reason) {*reason = "piece duration must be finite and positive";}
      return false;
    }
  }
  for (std::size_t i = 0; i < expected; ++i) {
    if (!std::isfinite(msg.coef_x[i]) || !std::isfinite(msg.coef_y[i]) ||
      !std::isfinite(msg.coef_z[i]))
    {
      if (reason) {*reason = "trajectory contains a non-finite coefficient";}
      return false;
    }
  }
  return true;
}

// Sum of piece durations. Assumes a validated message.
inline double totalDuration(const mmp_traj_msgs::msg::PolyTraj & msg)
{
  double total = 0.0;
  for (const double duration : msg.duration) {
    total += duration;
  }
  return total;
}

// Absolute time -> (piece index, piece-local time). t_abs is clamped into
// [0, total]. An exact junction belongs to the EARLIER piece — for a
// continuous trajectory both pieces evaluate identically there, and this
// matches the panels' historical walk (`t_rem <= duration[piece]`).
inline std::size_t locatePiece(
  const mmp_traj_msgs::msg::PolyTraj & msg, double t_abs, double * t_local)
{
  const std::size_t piece_count = msg.duration.size();
  double t = std::max(t_abs, 0.0);
  std::size_t piece = 0;
  for (; piece + 1 < piece_count; ++piece) {
    const double duration = msg.duration[piece];
    if (t <= duration) {break;}
    t -= duration;
  }
  t = std::clamp(t, 0.0, static_cast<double>(msg.duration[piece]));
  if (t_local) {*t_local = t;}
  return piece;
}

// Piece-local position evaluation (pos must point at 3 doubles). Used by
// dense samplers that walk pieces themselves.
inline void evalPieceLocal(
  const mmp_traj_msgs::msg::PolyTraj & msg, std::size_t piece, double t_local,
  double * pos)
{
  const int order = static_cast<int>(msg.order);
  const std::size_t offset = piece * coefficientsPerPiece(msg);
  pos[0] = pos[1] = pos[2] = 0.0;
  for (int j = 0; j <= order; ++j) {
    const double t_pow = std::pow(t_local, order - j);
    pos[0] += msg.coef_x[offset + j] * t_pow;
    pos[1] += msg.coef_y[offset + j] * t_pow;
    pos[2] += msg.coef_z[offset + j] * t_pow;
  }
}

// Position (and optionally analytic velocity/acceleration) at absolute time.
// pos is required; vel/acc may be nullptr. Each output points at 3 doubles
// (frame units, /s, /s^2). Assumes a validated message.
inline void evalAt(
  const mmp_traj_msgs::msg::PolyTraj & msg, double t_abs,
  double * pos, double * vel = nullptr, double * acc = nullptr)
{
  double t_local = 0.0;
  const std::size_t piece = locatePiece(msg, t_abs, &t_local);
  const int order = static_cast<int>(msg.order);
  const std::size_t offset = piece * coefficientsPerPiece(msg);
  pos[0] = pos[1] = pos[2] = 0.0;
  if (vel) {vel[0] = vel[1] = vel[2] = 0.0;}
  if (acc) {acc[0] = acc[1] = acc[2] = 0.0;}
  for (int j = 0; j <= order; ++j) {
    const int p = order - j;
    const double cx = msg.coef_x[offset + j];
    const double cy = msg.coef_y[offset + j];
    const double cz = msg.coef_z[offset + j];
    const double t_pow = std::pow(t_local, p);
    pos[0] += cx * t_pow;
    pos[1] += cy * t_pow;
    pos[2] += cz * t_pow;
    if (vel && p >= 1) {
      const double d = p * std::pow(t_local, p - 1);
      vel[0] += cx * d;
      vel[1] += cy * d;
      vel[2] += cz * d;
    }
    if (acc && p >= 2) {
      const double dd = p * (p - 1) * std::pow(t_local, p - 2);
      acc[0] += cx * dd;
      acc[1] += cy * dd;
      acc[2] += cz * dd;
    }
  }
}

}  // namespace mmp_traj_utils

#endif  // MMP_TRAJ_UTILS__POLY_TRAJ_HPP_

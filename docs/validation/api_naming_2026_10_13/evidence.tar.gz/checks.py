from pathlib import Path
import json, subprocess, time, shutil, os

root = Path('/tmp/mmp_api_naming_implementation_20261013/after')
prior = Path('/tmp/mmp_deep_final_audit_20261011')
summary = {'build': 'passed', 'fresh_checks': {}}
def run(name, command, cwd=None, timeout=600):
    started = time.time()
    with (root / (name + '.log')).open('w') as log:
        try:
            status = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            status = 124
    summary['fresh_checks'][name] = {'exit_code': status, 'elapsed_s': time.time()-started}
    (root/'summary.json').write_text(json.dumps(summary, indent=2))
    print(name, status, round(time.time()-started, 2), flush=True)
    return status == 0

for package in ['path_manager','path_optimizer','mmp_vehicle_dynamics']:
    build = prior/'build'/package
    discovery = subprocess.run(['ctest','--show-only=json-v1'],cwd=build,capture_output=True,text=True,check=True)
    (root/(package+'_discovery.json')).write_text(discovery.stdout)
    run('ctest_'+package,['ctest','--output-on-failure'],cwd=build,timeout=900)
    shutil.copy2(build/'Testing/Temporary/LastTest.log',root/(package+'_details.log'))

consumer = prior/'install/path_manager/share/path_manager/examples/library_consumer'
consumer_build = root/'consumer_build'
if run('consumer_configure',['cmake','-S',str(consumer),'-B',str(consumer_build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']):
    if run('consumer_build',['cmake','--build',str(consumer_build),'-j2']):
        for name in ['flight_evaluator','trajectory_simulation','planning_visualization','mission_planner']:
            cmd=[str(consumer_build/(name+'_client'))]
            if name=='mission_planner': cmd.append(str(prior/'install/path_manager/share/path_manager/config/optimizer_params.yaml'))
            run('consumer_'+name,cmd)

header_project = root/'header_project'
if (prior/'header_project').exists():
    shutil.copytree(prior/'header_project',header_project)
    if run('headers_configure',['cmake','-S',str(header_project),'-B',str(root/'header_build'),'-DCMAKE_BUILD_TYPE=Release']):
        run('headers_compile',['cmake','--build',str(root/'header_build'),'-j2'])

summary['pass']=all(x['exit_code']==0 for x in summary['fresh_checks'].values())
(root/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)
raise SystemExit(0 if summary['pass'] else 1)

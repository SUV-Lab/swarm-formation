from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(sys.argv[1]).resolve(); out=Path(__file__).resolve().parent
snapshot=json.loads((out/'source_before.json').read_text())
renames={'planFromGlobalTraj':'publishExecutionTrajectory','invalidateStoredTrajectory':'recordExecutionInvalidation','planRouteParallel':'planFromRoute','planDirect':'computeDirect'}
def tokens(s):
    # Preserve string/character/raw literals; discard only whitespace and comments.
    pattern=re.compile(r'R"([^\s()\\]{0,16})\(.*?\)\1"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*.*?\*/|[A-Za-z_][A-Za-z_0-9]*|[^\s]',re.S)
    return [m.group() for m in pattern.finditer(s) if not m.group().startswith(('//','/*'))]
def normalize(s,path):
    for old,new in renames.items(): s=re.sub(r'\b'+old+r'\b',new,s)
    if Path(path).name in ('replan_fsm.h','replan_fsm.cpp'):
        s=s.replace('publishExecutionTrajectory(int trial_times = 1)','publishExecutionTrajectory()').replace('publishExecutionTrajectory(int trial_times)','publishExecutionTrajectory()').replace('publishExecutionTrajectory(1)','publishExecutionTrajectory()')
    return tokens(s)
rows=[];unchanged=0
for e in snapshot['files']:
    rel=Path(e['path']); assert not {'reports','experiments'}&set(rel.parts)
    p=root/rel; b=p.read_bytes(); h=hashlib.sha256(b).hexdigest()
    if h==e['sha256']: unchanged+=1;continue
    before=(out/'source_before'/rel).read_text(); after=b.decode()
    rows.append({'path':str(rel),'sha256':h,'comments_only':tokens(before)==tokens(after),'allowed_normalized_tokens_equal':normalize(before,str(rel))==tokens(after)})
heads={k:subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip() for k,p in [('main',root),('planner',root/'src/mmp_path_planning')]}
result={'source_files_checked':len(snapshot['files']),'unchanged':unchanged,'changed':rows,'heads_unchanged':heads==snapshot['heads'],'pass':heads==snapshot['heads'] and all(r['allowed_normalized_tokens_equal'] for r in rows)}
(out/'source_scope_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(snapshot['files']),'changed':len(rows),'comments_only':sum(x['comments_only'] for x in rows),'pass':result['pass']}))
assert result['pass']

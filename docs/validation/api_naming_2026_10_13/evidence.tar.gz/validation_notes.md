# Validation scope notes

- Actual pre-change build used the unchanged binary before rebuilding modified source.
- The initial pre-change API run was numerically identical but its full-source fingerprint changed because a header comment edit overlapped the run. Raw failure evidence is retained in before/r2.
- Repeated against the same pre-change installed binary after editing stopped: before/r2_frozen passed numerical and source/input stability checks.
- Before/after GUI runs used README launch + RViz Start + R2 mission path + Run mission. Both verify the running node executable against the current overlay executable.
- API and GUI comparisons are within each invocation path, not a claim that the two independent harness inputs are identical. API duration 521.0625247312521; GUI duration 521.0625259429216; both 190 pieces.
- Source token comparison is supporting evidence only; it does not replace compile/runtime tests.
- No performance benchmark or general mission success-rate estimate.
- GUI processes and this run's ROS nodes were terminated after capture.
- Existing reports/ and experiments/ directories were excluded throughout.

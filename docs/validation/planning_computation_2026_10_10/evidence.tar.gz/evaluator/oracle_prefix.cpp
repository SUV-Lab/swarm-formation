#include "path_manager/flight_evaluator.h"
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>
namespace path_manager {
struct OracleLog {
  std::vector<FlightEvaluationLogLine> lines;
  template<class... A> void put(FlightEvaluationLogLevel level, const char *fmt, A... args) {
    int n = snprintf(nullptr, 0, fmt, args...);
    std::vector<char> s(n+1); snprintf(s.data(),s.size(),fmt,args...);
    lines.push_back({level,std::string(s.data(),n)});
  }
  template<class... A> void infof(const char*f,A...a){put(FlightEvaluationLogLevel::INFO,f,a...);}
  template<class... A> void warnf(const char*f,A...a){put(FlightEvaluationLogLevel::WARNING,f,a...);}
  template<class... A> void errorf(const char*f,A...a){put(FlightEvaluationLogLevel::ERROR,f,a...);}
};
class PathManager {
 public:
  using ZonePolicySnapshot = path_manager::ZonePolicySnapshot;
  using ZoneContactResult = path_manager::ZoneContactResult;
  using ZoneDisposition = path_manager::ZoneDisposition;
  const FlightEvaluationInput &i;
  explicit PathManager(const FlightEvaluationInput &in):i(in){}
  auto vehicleModel() const { return i.model; }
  size_t numRiskZones() const{return i.environment.zone_count;}
  auto zonePolicySnapshot() const{return i.plan_policy;}
  const auto &legPolicySnapshots() const{return i.leg_policies;}
  uint64_t zonePolicyEpoch() const{return i.policy_epoch;}
  bool terrainElevation(double x,double y,double*z)const{return i.environment.terrain_elevation?i.environment.terrain_elevation(x,y,z):false;}
  double getEffectiveRisk(size_t z,const Eigen::Vector3d&p)const{return i.environment.effective_risk(z,p);}
  double getZoneEllipsoidRadius(size_t z,const Eigen::Vector3d&p)const{return i.environment.ellipsoid_radius(z,p);}
  double getRiskVisibility(size_t z,const Eigen::Vector3d&p)const{return i.environment.risk_visibility(z,p);}
  auto zoneContact(const ZonePolicySnapshot&s,size_t z,const Eigen::Vector3d&p)const{return i.environment.zone_contact(s,z,p);}
  bool zoneContactAuthored(const ZonePolicySnapshot&s,size_t z,const Eigen::Vector3d&p)const{return i.environment.authored_contact(s,z,p);}
};
double readNumParam(const FlightEvaluationSettings *s, const char*n,double d){
  if(!strcmp(n,"optimization/dynamics_unit_xy_m"))return s->unit_xy_m;
  if(!strcmp(n,"optimization/dynamics_unit_z_m"))return s->unit_z_m;
  if(!strcmp(n,"optimization/obstacle_clearance"))return s->obstacle_clearance;
  if(!strcmp(n,"optimization/audit_envelope_violation_max"))return s->envelope_violation_max;
  if(!strcmp(n,"optimization/audit_envelope_peak_max"))return s->envelope_peak_max;
  return d;
}
class SegmentChainPlanner {
 public:
  using FlightVerdict = path_manager::FlightVerdict;
  const FlightEvaluationSettings *node_;
  PathManager *pm_;
  OracleLog *log_;
  mutable FlightVerdict last_verdict_;
  mutable std::vector<PhaseSpan> last_spans_;
  FlightVerdict evaluateFlight(const poly_traj::Trajectory &,const std::vector<PhaseSpan>&,const std::vector<size_t>*,uint64_t)const;
};

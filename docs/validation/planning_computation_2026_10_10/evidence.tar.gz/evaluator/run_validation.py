#!/usr/bin/env python3
"""Standalone evaluator checks. No ROS, installed MMP target, or CMake used."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
records = []
def run(name, argv):
    started = time.time()
    result = subprocess.run(argv, cwd=root, capture_output=True, text=True)
    (root / (name + '.stdout')).write_text(result.stdout)
    (root / (name + '.stderr')).write_text(result.stderr)
    records.append({'name': name, 'argv': argv, 'cwd': str(root),
                    'exit_code': result.returncode, 'elapsed_seconds': time.time()-started,
                    'stdout': name+'.stdout', 'stderr': name+'.stderr'})
    return result

compiler = run('compiler', ['g++', '--version'])
eigen = run('eigen', ['dpkg-query', '-W', '-f=${Version}\n', 'libeigen3-dev'])
common = ['g++', '-std=c++17', '-O2', '-Wall', '-Wextra', '-Wpedantic',
          '-I/usr/include/eigen3', '-Isnapshot/include']
sources = ['snapshot/flight_evaluator.cpp', 'snapshot/flight_dynamics.cpp']
unit_compile = run('unit_compile', common + ['snapshot/flight_evaluator_test.cpp'] + sources + ['-o', 'flight_evaluator_test'])
unit = run('unit_run', ['./flight_evaluator_test']) if unit_compile.returncode == 0 else None
oracle_compile = run('oracle_compile', common + ['oracle.cpp'] + sources + ['-o', 'flight_evaluator_oracle'])
oracle = run('oracle_run', ['./flight_evaluator_oracle']) if oracle_compile.returncode == 0 else None
unit_checks = unit.stdout.count('[OK] ') if unit else 0
oracle_exact = bool(oracle and oracle.returncode == 0 and
    'Baseline differential fixtures: 152 all verdict fields and formatted log lines EXACT' in oracle.stdout)
passed = bool(unit and unit.returncode == 0 and unit_checks == 67 and oracle_exact)
summary = {'passed': passed, 'unit_checks_passed': unit_checks, 'unit_checks_expected': 67,
           'baseline_differential_fixtures': 152, 'all_verdict_fields_and_log_lines_exact': oracle_exact,
           'commands': records}
(root / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
manifest = []
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name != 'sha256_manifest.json':
        manifest.append({'path':str(path.relative_to(root)), 'bytes':path.stat().st_size,
                         'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(root / 'sha256_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k != 'commands'},indent=2))
sys.exit(0 if passed else 1)

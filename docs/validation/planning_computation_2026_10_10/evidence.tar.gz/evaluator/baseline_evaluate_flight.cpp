SegmentChainPlanner::FlightVerdict SegmentChainPlanner::evaluateFlight(
    const poly_traj::Trajectory &flight,
    const std::vector<PhaseSpan> &spans,
    const std::vector<size_t> *piece_leg_in, uint64_t piece_epoch) const
{
  // Clear FIRST, so an early return can never leave the PREVIOUS flight's
  // verdict readable through lastFlightVerdict(). A regression that asserts
  // on a stale verdict is worse than one that has none: it reports on a
  // flight that is not the one under test.
  last_verdict_ = FlightVerdict{};
  last_spans_.clear();
  const double T = flight.getTotalDuration();
  if (T <= 1e-9 || spans.empty()) return {};
  // [S13] Span input contract, fail-closed to UNEVALUATED (the direct
  // fallback gate treats that as FAILED; the stitched paths build their
  // own spans, so a violation here is a programming error to surface):
  //  - every t_end finite and strictly increasing
  //  - the last t_end covers the whole flight
  //  - TRANSITION only as the LEADING contiguous spans (a transition in
  //    the middle of a cruise flight is not a thing this contract knows)
  //  - TERMINAL only as the last span
  {
    double prev = 0.0;
    bool cruise_seen = false;
    for (size_t i = 0; i < spans.size(); ++i) {
      const PhaseSpan &sp = spans[i];
      if (!std::isfinite(sp.t_end) || sp.t_end <= prev + 1e-9) {
        log_->errorf("[FINAL-EVAL] span contract: t_end not finite/strictly "
                     "increasing at span %zu", i);
        return {};
      }
      prev = sp.t_end;
      if (sp.kind == PhaseKind::TRANSITION) {
        if (cruise_seen) {
          log_->errorf("[FINAL-EVAL] span contract: TRANSITION after a "
                       "non-transition span (%zu)", i);
          return {};
        }
      } else {
        cruise_seen = true;
      }
      if (sp.kind == PhaseKind::TERMINAL && i + 1 != spans.size()) {
        log_->errorf("[FINAL-EVAL] span contract: TERMINAL not last (%zu)",
                     i);
        return {};
      }
    }
    if (std::abs(spans.back().t_end - T) > 1e-6) {
      log_->errorf("[FINAL-EVAL] span contract: last t_end %.6f != flight "
                   "duration %.6f", spans.back().t_end, T);
      return {};
    }
  }

  const auto model = pm_->vehicleModel();
  // Was a has_parameter probe with a literal fallback — the same shape that
  // made the FSM's unit guard compare 100 against 100. readNumParam declares
  // the name if it is absent, so a value that arrives later cannot leave this
  // reader holding the literal.
  const auto param_or = [&](const char *n, double def) {
    return readNumParam(node_, n, def);
  };
  const double um_xy = param_or("optimization/dynamics_unit_xy_m", 100.0);
  const double um_z = param_or("optimization/dynamics_unit_z_m", 100.0);
  const double clr_band = param_or("optimization/obstacle_clearance", 0.3);
  const Eigen::Vector3d S(um_xy, um_xy, um_z);

  struct PhaseStat {
    double min_agl{std::numeric_limits<double>::infinity()};
    double min_agl_t{0.0};
    double agl_sum{0.0};
    int n{0}, n_below_band{0}, n_below_ground{0};
    int env_n{0}, env_viol{0};
    double util_peak{0.0};
    mmp_vehicle_dynamics::EnvelopeLimit peak_limit{
        mmp_vehicle_dynamics::EnvelopeLimit::None};
    double risk_max{0.0}, risk_int{0.0};
    // Zone contact of the delivered flight. Containment alone is NOT the
    // question — policy lives in the per-zone DISPOSITION, exactly as the
    // transition candidate filter reads it: only HARD_AVOID contact is a
    // violation, while SOFT_UNAVOIDABLE / SOFT_ENDPOINT / SOFT_FALLBACK are
    // crossings the 3-pass policy deliberately allowed. Counting every
    // containment as "hard" reported 3 hard contacts on an r5 flight whose
    // final field was pass-2 all-soft — a permitted crossing dressed up as a
    // safety breach. The two are kept apart and both are reported.
    // Sampled at the dt below (0.1 s), so these are SAMPLE counts.
    int zone_hard_n{0};       // inside the AUTHORED volume (q < 1.0)
    double zone_hard_s{0.0};
    int zone_standoff_n{0};   // in the 1.0-1.05 routing standoff shell
    double zone_standoff_s{0.0};
    int zone_soft_n{0};
    double zone_soft_s{0.0};
    bool zone_contact_measurable{true};
    // [ZONE-CONTACT] WHERE and HOW DEEP, not just how many. A count alone
    // cannot separate a 2 m graze of the 1.05x standoff shell from a
    // traverse of the authored volume, and those two call for opposite
    // responses. q < 1 is inside the authored ellipsoid; the gate fires at
    // q < 1.05, so q_min is the number that says which one happened.
    double zone_hard_t_first{-1.0};
    double zone_hard_t_last{-1.0};
    int zone_hard_runs{0};       // contiguous contact intervals
    bool zone_hard_prev{false};  // sampler state behind the run count
    // Closest approach to any HARD_AVOID zone over the whole span, contact
    // or not. Distinct from zone_hard_qmin, which only exists when a contact
    // occurred.
    double zone_clear_qmin{1e9};
    Eigen::Vector3d zone_clear_p{Eigen::Vector3d::Zero()};
    double zone_clear_t{-1.0};
    int zone_clear_zone{-1};
    double zone_hard_qmin{1e9};
    Eigen::Vector3d zone_hard_qmin_p{Eigen::Vector3d::Zero()};
    double zone_hard_qmin_vis{-1.0};
    int zone_hard_qmin_zone{-1};
    // [LEG-POLICY] Piece boundaries where the leg changes hands, audited
    // EXHAUSTIVELY and separately from the 0.1 s grid. They are instants,
    // not dwell: they contribute counts and the refusal, never seconds.
    int zone_junction_n{0};        // leg-change boundaries examined
    int zone_junction_hard_n{0};   // ...of which entered an authored volume
  };
  std::vector<PhaseStat> st(spans.size());

  const double dt = 0.1;
  const size_t nz = pm_->numRiskZones();
  const auto eval_snap = pm_->zonePolicySnapshot();

  // [LEG-POLICY] A multi-leg mission has no plan-wide policy — the front end
  // runs one search per leg and the same zone can be HARD_AVOID on one and
  // SOFT_ENDPOINT on the next, so eval_snap above is INVALID for it and every
  // sample reads as unmeasurable. It is measurable; it just has to be asked
  // per piece. Route edge i became MINCO piece i, so the piece a sample falls
  // in names the leg that was flying there, and that leg's captured policy is
  // the one in force.
  //
  // Every condition below is a refusal, not a repair: a map that does not
  // describe THIS trajectory, a leg with no capture, a capture that is not
  // valid, a leg list with a hole or a repeat, or a policy that does not cover
  // the current zones. Any of them and this falls back to eval_snap, which
  // then refuses in the usual way. Notably a STITCHED flight lands here — the
  // manager's map describes the last segment only, and the piece counts
  // disagree, which is exactly the disagreement that must not be papered over.
  static const std::vector<size_t> kNoPieceLeg;
  const auto &piece_leg = piece_leg_in ? *piece_leg_in : kNoPieceLeg;
  const auto &leg_pols = pm_->legPolicySnapshots();
  bool per_piece = !piece_leg.empty() && !leg_pols.empty() &&
                   piece_leg.size() ==
                       static_cast<size_t>(flight.getPieceNum()) &&
                   // The map and the captures must come from the SAME
                   // front-end run. Sizes agreeing is not that: a map minted
                   // one epoch ago names legs of a different search, and
                   // nothing in a vector of indices says which.
                   piece_epoch != 0 && piece_epoch == pm_->zonePolicyEpoch();
  if (per_piece) {
    // ORDER. A route is walked once, front to back, so its legs appear in
    // flight order and each hands over to the NEXT one. A map that goes
    // backwards, jumps a leg, or lets a leg reappear after another has taken
    // over is not a route this planner can have produced — and every one of
    // those shapes would still pass a size-and-range check while attributing
    // stretches of the flight to the wrong policy.
    //
    // The first entry is NOT required to be leg 0: a slice of a committed
    // route legitimately starts mid-route, so its tags begin at whichever leg
    // the cut landed on.
    for (size_t i = 1; i < piece_leg.size() && per_piece; ++i) {
      const size_t prev = piece_leg[i - 1], cur = piece_leg[i];
      if (cur != prev && cur != prev + 1) per_piece = false;
    }
    for (size_t i = 0; i < leg_pols.size() && per_piece; ++i) {
      // leg i at index i, and serial exactly i + 1. The searcher increments
      // its per-epoch counter once per leg search and captures with the new
      // value, so a clean run is 1, 2, 3, ... — CONTIGUOUS. Testing only that
      // serials increase accepts [1, 3], which is a set with a hole in the
      // middle, and this code's whole promise is that it refuses those. A
      // hole or a double-write is a programming error, and "some legs" is not
      // a set this may average over.
      if (leg_pols[i].leg != i || !leg_pols[i].policy.valid ||
          leg_pols[i].policy.zones.size() != nz ||
          leg_pols[i].search_serial != i + 1)
        per_piece = false;
    }
    for (size_t leg : piece_leg)
      if (leg >= leg_pols.size()) per_piece = false;
  }
  // Warn only where it COSTS something. A chained single-goal flight is
  // stitched, so the map never matches its piece count — but its plan-wide
  // snapshot is valid and is the right answer, not a fallback. The case worth
  // saying out loud is the one where neither is available.
  if (nz > 0 && !per_piece && !eval_snap.valid)
    log_->warnf("[LEG-POLICY] no per-piece attribution (%zu tags, %d pieces, "
                "%zu legs) and no valid plan-wide policy — this flight cannot "
                "be cleared",
                piece_leg.size(), flight.getPieceNum(), leg_pols.size());
  else if (per_piece)
    log_->infof("[LEG-POLICY] audit reads policy per piece: %zu pieces over "
                "%zu legs", piece_leg.size(), leg_pols.size());

  // The policy in force at time t, for the ordinary 0.1 s samples: whichever
  // piece the sample falls in.
  //
  // This deliberately does NOT try to detect boundaries. locatePieceIdx
  // advances only while `t > duration` (poly_traj_utils.hpp), so at exactly a
  // seam it returns the PREVIOUS piece with the remainder equal to that
  // piece's whole duration — not the next piece at remainder zero. A boundary
  // test written against the second (wrong) reading is dead code, which is
  // what the first version of this was: `rem <= 1e-9` never held. And a
  // 0.1 s grid lands on an exact seam only by coincidence, so even a correct
  // test here would go unexercised. Seams are handled exhaustively below
  // instead, where their times are known exactly rather than sampled for.
  const auto policyAt =
      [&](double t) -> const PathManager::ZonePolicySnapshot & {
    if (!per_piece) return eval_snap;
    double rem = t;
    const int pi = flight.locatePieceIdx(rem);
    // Out of range is a refusal, not a clamp. Pinning it to 0 or to the last
    // index hands those samples leg 0's or the LAST leg's policy — which is
    // the exact failure this whole mechanism exists to prevent, arriving
    // through the back door. eval_snap is INVALID for a multi-leg mission, so
    // returning it here refuses in the usual way.
    if (pi < 0 || pi >= static_cast<int>(piece_leg.size())) return eval_snap;
    return leg_pols[piece_leg[static_cast<size_t>(pi)]].policy;
  };
  // Same counting doctrine as the solver's [CONV-REJECT] audit, latch
  // included: the pre-cruise ramp (a rest-start mission legitimately
  // begins below stall) stays out of the statistics, but sub-min-speed
  // dwell AFTER cruise entry counts into BOTH counters — dropping it from
  // both made the evaluator blind to mid-flight speed collapse, the exact
  // ~0%-scored failure the solver's latch was built to kill (review find:
  // a sub-stall arrival contract fed a 300 s helix that scored "0.0%").
  bool reached_cruise = false;
  for (double t = 0.0; t < T; t += dt) {
    size_t ph = 0;
    while (ph + 1 < spans.size() && t >= spans[ph].t_end) ++ph;
    PhaseStat &s = st[ph];
    // Judgment selection by CONTRACT TYPE, never by the display name. A
    // TRANSITION span is outside the cruise model by definition: its
    // samples never enter the cruise envelope statistics (its own
    // evaluator attaches with the generator, per ADR-0002 — v0 limits are
    // experimental, not gates). Terrain/zone/risk below stay: those are
    // model-agnostic.
    const bool cruise_judged = spans[ph].kind != PhaseKind::TRANSITION;
    const Eigen::Vector3d p = flight.getPos(t);
    double g = 0.0;
    pm_->terrainElevation(p.x(), p.y(), &g);  // false: sea level 0
    const double agl = p.z() - g;
    if (agl < s.min_agl) { s.min_agl = agl; s.min_agl_t = t; }
    s.agl_sum += agl;
    ++s.n;
    if (agl < clr_band) ++s.n_below_band;
    if (agl < 0.0) ++s.n_below_ground;
    if (model && cruise_judged) {
      const auto ev = model->evaluate(
          S.cwiseProduct(p), S.cwiseProduct(flight.getVel(t)),
          S.cwiseProduct(flight.getAcc(t)));
      if (ev.valid && model->domain(ev).cruise) {
        reached_cruise = true;
        ++s.env_n;
        mmp_vehicle_dynamics::EnvelopeLimit lim;
        const double u =
            model->utilization(ev, &lim);
        if (!model->withinEnvelope(ev)) ++s.env_viol;
        if (u > s.util_peak) { s.util_peak = u; s.peak_limit = lim; }
      } else if (reached_cruise) {
        ++s.env_n;
        ++s.env_viol;
      }
    }
    if (nz > 0) {
      double keep = 1.0;
      for (size_t zi = 0; zi < nz; ++zi)
        keep *= 1.0 - pm_->getEffectiveRisk(zi, p);
      const double r = 1.0 - keep;
      s.risk_max = std::max(s.risk_max, r);
      s.risk_int += r * dt;

      bool hard = false, standoff = false, soft = false;
      int hard_zi = -1;
      double hard_q = 1e9;
      // [LEG-POLICY] The policy that was in force WHERE THIS SAMPLE FLIES.
      // Identical to eval_snap when there is one plan-wide policy to have.
      const PathManager::ZonePolicySnapshot &snap = policyAt(t);
      // Closest approach to a HARD_AVOID zone, tracked on EVERY sample and
      // not only on contact. "No contact" is a threshold answer; how close
      // the flight came is the measurement, and without it two products on
      // the same route cannot be compared at all — which is exactly the
      // question a contact on one and not the other raises.
      for (size_t zi = 0; zi < nz; ++zi) {
        if (zi >= snap.zones.size() ||
            snap.zones[zi].disposition !=
                PathManager::ZoneDisposition::HARD_AVOID)
          continue;
        const double q = pm_->getZoneEllipsoidRadius(zi, p);
        if (q < s.zone_clear_qmin) {
          s.zone_clear_qmin = q;
          s.zone_clear_p = p;
          s.zone_clear_t = t;
          s.zone_clear_zone = static_cast<int>(zi);
        }
      }
      for (size_t zi = 0; zi < nz; ++zi) {
        switch (pm_->zoneContact(snap, zi, p)) {
          case PathManager::ZoneContactResult::CONTACT:
            if (zi < snap.zones.size() &&
                snap.zones[zi].disposition ==
                    PathManager::ZoneDisposition::HARD_AVOID) {
              // WHICH BAND. zoneContact() reports the 1.05x standoff volume,
              // which is the surface a ROUTE is kept out of; only the
              // authored volume refuses a finished flight.
              if (pm_->zoneContactAuthored(snap, zi, p)) hard = true;
              else standoff = true;
              // Only on contact, so the deep-sample cost never touches the
              // common path.
              const double q = pm_->getZoneEllipsoidRadius(zi, p);
              if (q < hard_q) { hard_q = q; hard_zi = static_cast<int>(zi); }
            } else {
              soft = true;
            }
            break;
          case PathManager::ZoneContactResult::STALE:
          case PathManager::ZoneContactResult::INVALID:
            // A snapshot that cannot be judged must not read as "clear" —
            // that is how a zero contact count becomes a claim nobody
            // checked. The verdict below refuses CLEAN on this.
            s.zone_contact_measurable = false;
            break;
          case PathManager::ZoneContactResult::CLEAR:
            break;
        }
      }
      if (standoff) { ++s.zone_standoff_n; s.zone_standoff_s += dt; }
      // The contact-detail fields track EITHER band, so the emitted line can
      // say which one the deepest sample was in; the counters above are what
      // decide refusal.
      if (hard || standoff) {
        if (hard) { ++s.zone_hard_n; s.zone_hard_s += dt; }
        if (s.zone_hard_t_first < 0.0) s.zone_hard_t_first = t;
        s.zone_hard_t_last = t;
        if (!s.zone_hard_prev) ++s.zone_hard_runs;
        if (hard_q < s.zone_hard_qmin) {
          s.zone_hard_qmin = hard_q;
          s.zone_hard_qmin_p = p;
          s.zone_hard_qmin_zone = hard_zi;
          s.zone_hard_qmin_vis =
              hard_zi >= 0 ? pm_->getRiskVisibility(hard_zi, p) : -1.0;
        }
      }
      s.zone_hard_prev = hard || standoff;
      if (soft) { ++s.zone_soft_n; s.zone_soft_s += dt; }
    }
  }

  // [LEG-POLICY] Leg handovers, audited exhaustively and off the grid.
  //
  // A seam between two legs is one instant. The 0.1 s sampler will land on it
  // only by coincidence, so the sampler cannot be the thing that enforces the
  // handover rule — the times have to be enumerated. They are known exactly:
  // the cumulative duration at every piece i where piece_leg[i-1] differs
  // from piece_leg[i].
  //
  // At that instant the point belongs to both legs, so it is judged under the
  // STRICTER of the two policies. Stricter means HARD_AVOID and nothing else:
  // that is the only distinction drawn below, and inventing an order among
  // the SOFT_* kinds would be an ordering no consumer reads. The effect is
  // that an exemption earned on one leg — a start or goal containment — stops
  // at the junction instead of leaking into a leg that never had it.
  //
  // These feed their own counters. Folding them into the 0.1 s totals would
  // add dwell seconds to an instant and make `n` mean two different things.
  if (per_piece && nz > 0) {
    PathManager::ZonePolicySnapshot merged;
    double t_seam = 0.0;
    for (size_t i = 0; i + 1 < piece_leg.size(); ++i) {
      t_seam += flight[static_cast<int>(i)].getDuration();
      const size_t a = piece_leg[i], b = piece_leg[i + 1];
      if (a == b) continue;
      size_t ph = 0;
      while (ph + 1 < spans.size() && t_seam >= spans[ph].t_end) ++ph;
      PhaseStat &s = st[ph];
      ++s.zone_junction_n;

      merged = leg_pols[b].policy;
      const auto &other = leg_pols[a].policy;
      for (size_t zi = 0; zi < merged.zones.size() && zi < other.zones.size();
           ++zi) {
        if (other.zones[zi].disposition ==
            PathManager::ZoneDisposition::HARD_AVOID)
          merged.zones[zi].disposition =
              PathManager::ZoneDisposition::HARD_AVOID;
      }

      const Eigen::Vector3d p = flight.getPos(t_seam);
      bool jhard = false;
      for (size_t zi = 0; zi < nz; ++zi) {
        switch (pm_->zoneContact(merged, zi, p)) {
          case PathManager::ZoneContactResult::CONTACT:
            if (zi < merged.zones.size() &&
                merged.zones[zi].disposition ==
                    PathManager::ZoneDisposition::HARD_AVOID &&
                pm_->zoneContactAuthored(merged, zi, p))
              jhard = true;
            break;
          case PathManager::ZoneContactResult::STALE:
          case PathManager::ZoneContactResult::INVALID:
            s.zone_contact_measurable = false;
            break;
          case PathManager::ZoneContactResult::CLEAR:
            break;
        }
      }
      if (jhard) {
        ++s.zone_junction_hard_n;
        log_->warnf("[LEG-POLICY] leg %zu -> %zu handover at t=%.3f s is "
                    "inside an authored volume under the stricter of the two "
                    "policies",
                    a, b, t_seam);
      }
    }
  }

  log_->infof("[FINAL-EVAL] ===== whole-flight evaluation: %.1f s, %d "
              "pieces, %zu phase(s) =====",
              T, flight.getPieceNum(), spans.size());
  double t0 = 0.0;
  PhaseStat tot;
  for (size_t ph = 0; ph < spans.size(); ++ph) {
    const PhaseStat &s = st[ph];
    if (s.n > 0) {
      // A phase with dynamics on but ZERO cruise-domain samples has no
      // measurement — "0.0%" would print no-data as a clean reading.
      char env[96];
      if (!model) {
        snprintf(env, sizeof env, "env model off");
      } else if (spans[ph].kind == PhaseKind::TRANSITION) {
        snprintf(env, sizeof env,
                 "env n/a (TRANSITION — cruise judgment not applicable)");
      } else if (s.env_n == 0) {
        snprintf(env, sizeof env, "env NO CRUISE DATA (pre-cruise ramp)");
      } else {
        snprintf(env, sizeof env, "env viol %5.1f%% peak %5.1f%% (%s)",
                 100.0 * s.env_viol / s.env_n, 100.0 * s.util_peak,
                 mmp_vehicle_dynamics::envelopeLimitName(s.peak_limit));
      }
      log_->infof(
          "[FINAL-EVAL] %-9s %6.1f s | AGL min %7.3f@%.0fs mean %6.2f u, "
          "<band %4.1f%%, underground %s | %s | risk max %.3f, "
          "exposure %.1f s, zone contact hard %d (%.1f s) soft %d (%.1f s) "
          "@0.1s sampling%s",
          spans[ph].name.c_str(), spans[ph].t_end - t0, s.min_agl,
          s.min_agl_t, s.agl_sum / s.n, 100.0 * s.n_below_band / s.n,
          s.n_below_ground ? "YES" : "no", env, s.risk_max, s.risk_int,
          s.zone_hard_n, s.zone_hard_s, s.zone_soft_n, s.zone_soft_s,
          s.zone_contact_measurable ? "" : " [UNMEASURABLE: stale/invalid "
                                           "zone snapshot]");
    }
    t0 = spans[ph].t_end;
    if (s.min_agl < tot.min_agl) {
      tot.min_agl = s.min_agl;
      tot.min_agl_t = s.min_agl_t;
    }
    tot.n += s.n;
    tot.n_below_band += s.n_below_band;
    tot.n_below_ground += s.n_below_ground;
    tot.env_n += s.env_n;
    tot.env_viol += s.env_viol;
    tot.risk_max = std::max(tot.risk_max, s.risk_max);
    tot.risk_int += s.risk_int;
    tot.zone_hard_n += s.zone_hard_n;
    tot.zone_hard_s += s.zone_hard_s;
    tot.zone_standoff_n += s.zone_standoff_n;
    tot.zone_standoff_s += s.zone_standoff_s;
    tot.zone_hard_runs += s.zone_hard_runs;
    if (s.zone_hard_t_first >= 0.0 &&
        (tot.zone_hard_t_first < 0.0 ||
         s.zone_hard_t_first < tot.zone_hard_t_first))
      tot.zone_hard_t_first = s.zone_hard_t_first;
    if (s.zone_hard_t_last > tot.zone_hard_t_last)
      tot.zone_hard_t_last = s.zone_hard_t_last;
    if (s.zone_hard_qmin < tot.zone_hard_qmin) {
      tot.zone_hard_qmin = s.zone_hard_qmin;
      tot.zone_hard_qmin_p = s.zone_hard_qmin_p;
      tot.zone_hard_qmin_vis = s.zone_hard_qmin_vis;
      tot.zone_hard_qmin_zone = s.zone_hard_qmin_zone;
    }
    if (s.zone_clear_qmin < tot.zone_clear_qmin) {
      tot.zone_clear_qmin = s.zone_clear_qmin;
      tot.zone_clear_p = s.zone_clear_p;
      tot.zone_clear_t = s.zone_clear_t;
      tot.zone_clear_zone = s.zone_clear_zone;
    }
    tot.zone_soft_n += s.zone_soft_n;
    tot.zone_soft_s += s.zone_soft_s;
    tot.zone_junction_n += s.zone_junction_n;
    tot.zone_junction_hard_n += s.zone_junction_hard_n;
    tot.zone_contact_measurable &= s.zone_contact_measurable;
    if (s.util_peak > tot.util_peak) {
      tot.util_peak = s.util_peak;
      tot.peak_limit = s.peak_limit;
    }
  }
  const double viol_pct =
      tot.env_n ? 100.0 * tot.env_viol / tot.env_n : 0.0;
  // A flight that never once reaches cruise is unflyable for this airframe
  // — the solver's own degenerate rule (viol := 1.0), mirrored here so
  // no-data can never read as clean. The envelope threshold is the SAME
  // configurable gate the per-solve audit uses, not a second number.
  const double viol_max_pct =
      100.0 * param_or("optimization/audit_envelope_violation_max", 0.25);
  const bool no_cruise = model != nullptr && tot.env_n == 0;
  // [PHASE-DEP] peak joins the verdict: 0.7% violation TIME hid a 299%
  // instantaneous thrust demand as CLEAN (review find). Same parameter the
  // departure acceptance gate uses.
  const double peak_chk =
      param_or("optimization/audit_envelope_peak_max", 1.30);
  const bool peak_bad = tot.util_peak > peak_chk;
  // A flight that entered a HARD_AVOID volume, or one whose zone policy could
  // not be judged at all, must not read CLEAN. Leaving these out of the
  // condition is what let the new metric be printed beside a CLEAN verdict it
  // had no influence over — the number was reported, not enforced. An
  // unjudgeable snapshot is treated like a contact rather than like clear:
  // "we could not check" is not evidence of safety.
  // [LEG-POLICY] A handover that sits inside an authored volume under the
  // stricter of the two policies refuses the flight exactly as a sampled
  // contact does. It is one instant rather than 0.1 s of dwell, which is why
  // it is counted apart — not why it is treated more leniently.
  const bool zone_bad = tot.zone_hard_n > 0 || tot.zone_junction_hard_n > 0 ||
                        !tot.zone_contact_measurable;
  // Envelope alone, kept apart from the zone reasons: a caller that has to
  // NAME the cause cannot recover it from `clean`.
  const bool envelope_bad = viol_pct >= viol_max_pct || peak_bad;
  const bool clean = tot.n_below_ground == 0 && !no_cruise &&
                     !envelope_bad && !zone_bad;
  if (clean) {
    log_->infof("[FINAL-EVAL] verdict: CLEAN — AGL min %.3f u, env viol "
                "%.1f%% (peak %.1f%% %s), risk exposure %.1f s, "
                "zone contact hard 0 standoff %d (%.1f s) soft %d (%.1f s) "
                "@0.1s sampling",
                tot.min_agl, viol_pct, 100.0 * tot.util_peak,
                mmp_vehicle_dynamics::envelopeLimitName(tot.peak_limit),
                tot.risk_int, tot.zone_standoff_n, tot.zone_standoff_s,
                tot.zone_soft_n, tot.zone_soft_s);
  } else {
    log_->warnf("[FINAL-EVAL] verdict: CHECK — %s%s%s%s%s%s(AGL min %.3f u "
                "@%.0fs, env viol %.1f%%) — the stitched flight carries "
                "hazards no per-solve audit saw",
                tot.n_below_ground ? "TERRAIN OVERLAP " : "",
                no_cruise ? "NEVER REACHES CRUISE " : "",
                tot.zone_hard_n > 0 ? "AUTHORED ZONE ENTERED " : "",
                tot.zone_junction_hard_n > 0 ? "LEG HANDOVER IN ZONE " : "",
                !tot.zone_contact_measurable ? "ZONE POLICY UNEVALUATED " : "",
                !no_cruise && viol_pct >= viol_max_pct ? "ENVELOPE " : "",
                tot.min_agl, tot.min_agl_t, viol_pct);
  }
  FlightVerdict v;
  v.evaluated = true;
  v.clean = clean;
  v.envelope_bad = envelope_bad;
  v.underground = tot.n_below_ground != 0;
  v.no_cruise = no_cruise;
  v.zone_hard_n = tot.zone_hard_n;
  v.zone_standoff_n = tot.zone_standoff_n;
  v.zone_soft_n = tot.zone_soft_n;
  v.zone_junction_n = tot.zone_junction_n;
  v.zone_junction_hard_n = tot.zone_junction_hard_n;
  v.policy_measurable = tot.zone_contact_measurable;
  v.viol_pct = viol_pct;
  v.util_peak = tot.util_peak;
  // Machine-readable, always emitted, one line. A reader (and the A/B
  // parser) must not have to infer zone safety from the ABSENCE of a
  // warning word — that is fail-open by construction: a reworded log or a
  // dropped call both read as "measurable, no contact".
  log_->infof("[ZONE-AUDIT] hard=%d hard_s=%.1f standoff=%d standoff_s=%.1f "
              "soft=%d soft_s=%.1f measurable=%s sample_dt=%.2f "
              "risk_max=%.4f risk_exposure_s=%.1f junctions=%d "
              "junction_hard=%d",
              v.zone_hard_n, tot.zone_hard_s,
              v.zone_standoff_n, tot.zone_standoff_s,
              v.zone_soft_n, tot.zone_soft_s,
              v.policy_measurable ? "true" : "false", dt,
              tot.risk_max, tot.risk_int, tot.zone_junction_n,
              tot.zone_junction_hard_n);
  // The count above says a breach happened; this says WHICH breach. Without
  // it, a 2 m graze of the 1.05x standoff shell and a traverse of the
  // authored volume are the same line — and they are not the same event.
  // q_min < 1.00 means the flight was inside the zone the mission authored;
  // 1.00 <= q_min < 1.05 means it stayed in the routing standoff margin,
  // where the optimizer's risk term is zero by construction and risk_max
  // above is therefore 0.0000 whatever the flight did.
  // runs= is summed per phase, so a contact straddling a phase boundary
  // reads as two.
  // Emitted for every flight that had a HARD_AVOID zone to stay clear of,
  // whether or not it touched anything. q_min is on the same scale the two
  // thresholds use: < 1.00 entered the authored volume, < 1.05 entered the
  // routing standoff, and anything above is the margin that was actually
  // kept.
  if (tot.zone_clear_zone >= 0) {
    log_->infof("[ZONE-CLEARANCE] zone=%d q_min=%.5f t=%.2fs "
                "at (%.2f, %.2f, %.2f)",
                tot.zone_clear_zone, tot.zone_clear_qmin, tot.zone_clear_t,
                tot.zone_clear_p.x(), tot.zone_clear_p.y(),
                tot.zone_clear_p.z());
  }
  if (tot.zone_hard_n > 0 || tot.zone_standoff_n > 0) {
    log_->infof("[ZONE-CONTACT] zone=%d t=[%.2f, %.2f]s runs=%d q_min=%.5f "
                "%s vis=%.3f at (%.2f, %.2f, %.2f)",
                tot.zone_hard_qmin_zone, tot.zone_hard_t_first,
                tot.zone_hard_t_last, tot.zone_hard_runs, tot.zone_hard_qmin,
                tot.zone_hard_qmin < 1.0 ? "INSIDE-AUTHORED" : "standoff-shell",
                tot.zone_hard_qmin_vis, tot.zone_hard_qmin_p.x(),
                tot.zone_hard_qmin_p.y(), tot.zone_hard_qmin_p.z());
  }
  // LAST, and only once every field is filled: an earlier assignment left
  // viol_pct/util_peak at zero in the recorded copy.
  last_verdict_ = v;
  last_spans_ = spans;
  return v;
}

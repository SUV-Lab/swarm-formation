} // namespace path_manager
#define main unused_unit_test_main
#include "/ws/src/mmp_path_planning/src/path_manager/test/flight_evaluator_test.cpp"
#undef main
bool equalVerdicts(const pm::FlightVerdict &a,const pm::FlightVerdict &b){
 return a.evaluated==b.evaluated && a.clean==b.clean && a.underground==b.underground && a.no_cruise==b.no_cruise && a.viol_pct==b.viol_pct && a.util_peak==b.util_peak && a.envelope_bad==b.envelope_bad && a.zone_hard_n==b.zone_hard_n && a.zone_standoff_n==b.zone_standoff_n && a.zone_soft_n==b.zone_soft_n && a.zone_junction_n==b.zone_junction_n && a.zone_junction_hard_n==b.zone_junction_hard_n && a.policy_measurable==b.policy_measurable;
}
int main(){
 int compared=0;
 auto compare=[&](const pm::FlightEvaluationInput &input){
  pm::PathManager manager(input);pm::OracleLog log;
  pm::SegmentChainPlanner old{&input.settings,&manager,&log,{}, {}};
  auto v=old.evaluateFlight(input.trajectory,input.phases,input.piece_leg,input.piece_epoch);
  auto r=pm::evaluateFlight(input);auto lines=pm::formatFlightEvaluation(r);
  bool same=equalVerdicts(v,r.verdict)&&lines.size()==log.lines.size();
  for(size_t k=0;k<lines.size()&&k<log.lines.size();++k){
   if(lines[k].level!=log.lines[k].level||lines[k].text!=log.lines[k].text){
    same=false;std::cerr<<"OLD "<<log.lines[k].text<<"\nNEW "<<lines[k].text<<'\n';
   }
  }
  if(!same){std::cerr<<"Mismatch fixture "<<compared<<'\n';return false;}
  ++compared;return true;
 };
 for(double duration:{0.25,1.0,1.17}) for(int zone=0;zone<6;++zone)for(int model=0;model<2;++model)for(int phase=0;phase<4;++phase){
  auto flight=line(duration);auto spans=phases(flight);
  if(phase==1)spans={{0.1,pm::PhaseKind::TRANSITION,"transition"},{duration,pm::PhaseKind::CRUISE,"cruise"}};
  if(phase==2)spans={{0.1,pm::PhaseKind::CRUISE,"cruise"},{duration,pm::PhaseKind::TERMINAL,"terminal"}};
  if(phase==3)spans[0].kind=pm::PhaseKind::TRANSITION;
  pm::FlightEvaluationInput input{flight,spans};input.settings.unit_z_m=3.0;
  if(model)input.model=std::make_shared<DomainVehicle>();
  if(zone){
   input.environment=zoneEnvironment([zone](const Eigen::Vector3d&p){return zone==1?p.x()*10.0:zone==2?1.02:0.9;});
   input.plan_policy=policy(zone==3?pm::ZoneDisposition::SOFT_ENDPOINT:pm::ZoneDisposition::HARD_AVOID);
   if(zone==4)input.plan_policy.valid=false;
   if(zone==5)input.plan_policy.epoch=2;
  }
  if(!compare(input))return 1;
 }
 auto flight=line(0.15);flight.append(line(0.1,0.15));auto spans=phases(flight);
 pm::FlightEvaluationInput input{flight,spans};input.environment=zoneEnvironment([](const Eigen::Vector3d&p){return std::abs(p.x()-0.15)*100.0;});
 input.plan_policy=policy(pm::ZoneDisposition::HARD_AVOID);input.plan_policy.valid=false;
 input.leg_policies={{0,1,policy(pm::ZoneDisposition::HARD_AVOID)},{1,2,policy(pm::ZoneDisposition::SOFT_ENDPOINT)}};
 input.policy_epoch=input.piece_epoch=3;
 for(std::vector<size_t> tags:std::vector<std::vector<size_t>>{{0,1},{1,0},{0},{0,0}}){input.piece_leg=&tags;if(!compare(input))return 1;}
 for(auto invalid:std::vector<std::vector<pm::PhaseSpan>>{{},{{0.1,pm::PhaseKind::CRUISE,"short"}},{{0.0,pm::PhaseKind::CRUISE,"zero"}},{{0.1,pm::PhaseKind::CRUISE,"a"},{0.25,pm::PhaseKind::TRANSITION,"b"}}}){
  pm::FlightEvaluationInput bad{flight,invalid};if(!compare(bad))return 1;
 }
 std::cout<<"Baseline differential fixtures: "<<compared<<" all verdict fields and formatted log lines EXACT\n";
}

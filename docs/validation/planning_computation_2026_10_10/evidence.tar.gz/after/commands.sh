#!/usr/bin/env bash
# Prepared only. Root agent owns build readiness; run each stage only after signal.
set -euo pipefail
# 1) Stable implementation snapshot (host), then root performs build.
python3 /tmp/mmp_next_modularization_20261010/after/snapshot_source.py --tag before
# 2) Copy prepared harnesses and baseline references to container before running.
docker cp /tmp/mmp_next_modularization_20261010/after mmp_dev:/tmp/mmp_next_modularization_20261010/after
# Baseline output paths already exist inside container; host-only source snapshots not needed there.
# 3) Capture newly installed binary identities.
docker exec -u user mmp_dev python3 /tmp/mmp_next_modularization_20261010/after/snapshot_installed.py
# 4) Run all registered tests. No other CTest discovery may run concurrently in these build folders.
docker exec -u user mmp_dev bash -lc 'export ROS_DOMAIN_ID=85; source /opt/ros/humble/setup.bash; source /ws/install/setup.bash; python3 /tmp/mmp_next_modularization_20261010/after/run_fresh_tests.py > /tmp/mmp_next_modularization_20261010/after/tests_driver.log 2>&1'
# 5) Fresh installed-target external consumer build + strict R2 result comparison (3 modes).
docker exec -u user mmp_dev bash -lc 'export ROS_DOMAIN_ID=84; source /opt/ros/humble/setup.bash; source /ws/install/setup.bash; python3 /tmp/mmp_next_modularization_20261010/after/r2_consumer/run.py > /tmp/mmp_next_modularization_20261010/after/r2_driver.log 2>&1'
# 6) Existing isolated Xephyr :99; existing harness verifies no other ROS GUI/planner process first.
MMP_GUI_DISPLAY=:99 python3 /tmp/mmp_next_modularization_20261010/after/gui_harness.py /tmp/mmp_next_modularization_20261010/after > /tmp/mmp_next_modularization_20261010/after/gui_driver.log 2>&1
# 7) Source still matches tested snapshot. Transfer logs and generate combined validation index.
python3 /tmp/mmp_next_modularization_20261010/after/snapshot_source.py --tag after

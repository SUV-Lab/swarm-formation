from pathlib import Path
import datetime,hashlib,json
root=Path('/tmp/mmp_next_modularization_20261010/after');root.mkdir(exist_ok=True)
paths=['/ws/install/path_manager/lib/path_manager/path_manager_node','/ws/install/path_manager/lib/libpath_manager_lib.a','/ws/install/path_optimizer/lib/libpath_optimizer_lib.a','/ws/install/path_planner/lib/libpath_planner_sdf.a','/ws/install/path_planner/lib/libpath_planner_lib.a','/ws/install/mmp_vehicle_dynamics/lib/libmmp_vehicle_dynamics.a','/ws/install/path_manager/share/path_manager/config/optimizer_params.yaml','/ws/install/path_manager/share/path_manager/config/drone_hardware.yaml']
entries=[]
for raw in paths:
 p=Path(raw);h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 entries.append({'path':raw,'sha256':h.hexdigest(),'bytes':p.stat().st_size})
(root/'installed_manifest_end.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':entries},indent=2)+'\n')
print(json.dumps(entries))

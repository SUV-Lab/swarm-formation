#ifndef PATH_MANAGER_PLANNING_RESULT_H
#define PATH_MANAGER_PLANNING_RESULT_H

#include <string>

namespace path_manager {

// [PHASE] The planner <-> FSM contract for one mission plan. A bool cannot
// say "there is a flyable trajectory, but a stated requirement was relaxed
// under an approved policy" — and a log line is not a return value (review
// find: the FSM only ever read the bool, so DEGRADED existed nowhere the
// caller could see). Lives in path_manager, not the FSM header, so planners
// do not depend on the state machine.
//
// Outcome doctrine (2026-08-06 design review, frozen):
//   SUCCESS  — every stated requirement met.
//   DEGRADED — a flyable trajectory exists; a SOFT requirement was dropped
//              or an approved relaxation applied. The FSM executes it and
//              reports the reason. (soft profile loss, safe single-shot
//              fallback, phase-boundary fallback, opt-in final-boundary
//              relaxation, phase-mode mission too short for phases)
//   FAILED   — no trajectory the caller may fly: planning failed outright,
//              an explicit final state is invalid without the relaxation
//              opt-in, or a HARD limit could not be preserved (a hard
//              requirement is never traded for a flight).
enum class PlanOutcome { FAILED, SUCCESS, DEGRADED };

// Single reason, priority-ordered (higher wins when several apply):
//   FINAL_BOUNDARY_RELAXED > SINGLE_PLAN_FALLBACK > PHASE_BOUNDARY_FALLBACK
// `detail` carries the full story when reasons stack.
//
// The last two are FAILED-only (contract 1, 2026-08-08): they name WHY no
// trajectory exists, not what was traded for one. They never enter the
// degrade ladder — degrade() cannot run on a FAILED result.
enum class PlanReason {
  NONE,
  PHASE_BOUNDARY_FALLBACK,
  SINGLE_PLAN_FALLBACK,
  // The whole-flight audit could not judge zone policy AT ALL, because the
  // mission's shape puts it outside what the snapshot mechanism can express
  // — a multi-leg front end runs one search per leg and the snapshot is
  // deliberately plan-wide-or-nothing (path_manager.cpp:3775). That is a
  // SCOPE statement, not a hazard reading: refusing on it took out every
  // multi-waypoint mission that had a zone anywhere on the map, including
  // zones 50 km off the route. The caller is told what was not checked.
  ZONE_POLICY_UNEVALUATED,
  // The flight entered the 1.05x routing standoff shell around a HARD_AVOID
  // zone WITHOUT entering the zone itself. Reported, never refused: the shell
  // is a margin the route planner keeps so a geodesic does not hug the rim,
  // not a volume any mission forbids, and it is the exact surface where the
  // optimizer's zone force is zero in both value and gradient — a hard
  // refusal there flips between CLEAN and FAILED on numerical noise (it did:
  // docs/design/zone_gate_surface.md).
  // Ranked BELOW the envelope budget deliberately. degrade() picks the
  // surviving reason by enum order, and "the airframe is hotter than
  // requested" is the more urgent thing to tell an operator than "we passed
  // nearer a zone than the route planner would have chosen".
  STITCHED_ZONE_STANDOFF,
  // The whole-flight evaluation of the STITCHED product reads worse than
  // any per-solve audit did — a limit budget the caller is knowingly
  // spending. Above the fallbacks: "the flight you are getting is hotter
  // than requested" outranks "you are getting it a different way".
  STITCHED_ENVELOPE_BUDGET,
  FINAL_BOUNDARY_RELAXED,
  // An EXPLICITLY commanded initial state outside the cruise model's
  // validity region (speed range / flight-path cone). The launch regime
  // needs a transition planner (contract 2), not a clamp: rewriting the
  // operator's stated start into a different flyable one is a lie.
  INITIAL_MODE_UNSUPPORTED,
  // A transition mission with more than one waypoint AND a risk zone. The
  // transition coordinator screens entry candidates and judges its arc
  // against ONE plan-wide zone policy, and a multi-leg front end does not
  // have one — the same zone can be HARD_AVOID on one leg and SOFT_ENDPOINT
  // on the next. Per-leg policy exists for the single-shot audit, but the
  // coordinator's product is a STITCHED flight whose piece-to-leg map is not
  // built, so nothing downstream could attribute a contact either.
  //
  // This is a SCOPE statement, not a hazard report. It used to arrive as
  // TRANSITION_GENERATION_FAILED, which named a stage that had not run and
  // read as "the generator tried and could not" when the truth is "this
  // combination is not supported yet". Lifting it means building the
  // stitched map — see the leg-policy handoff doc.
  TRANSITION_MULTI_LEG_UNSUPPORTED,
  // The command could not be READ: two stated initial-state sources at once,
  // a non-finite or negative speed, a value with no claim bit. Distinct from
  // INITIAL_STATE_UNSPECIFIED, which means the command was read and said
  // nothing. The distinction matters to a publisher author: one is "you sent
  // something contradictory", the other is "you sent nothing".
  // An initial_speed value with use_initial_speed false is THIS, not
  // UNSPECIFIED — a stale field from an un-updated publisher must break
  // loudly rather than be flown.
  INITIAL_STATE_MALFORMED,
  // A phase-mode direct fallback that failed the whole-flight fitness gate
  // (the same evaluation the stitched chain gets). "No phase labels" must
  // never mean "no audit".
  DIRECT_FALLBACK_UNSAFE,
  // The STITCHED chain flight is unflyable on the unambiguous counts —
  // terrain overlap, or a flight that never reaches cruise. Per-solve
  // audits cannot see these: they judge one span at a time and the
  // prescribed terminal phase not at all.
  STITCHED_FLIGHT_UNSAFE,
  // [S13] Transition coordinator outcomes. GENERATION_FAILED: no primitive
  // candidate survived the propagation gates (or the zone policy could not
  // be judged); ADAPTER_UNSOUND: a captured candidate failed the
  // polynomial adapter's interior checks; JUNCTION_UNSOUND: the solved
  // chain head did not sit on the transition tail within tolerance.
  TRANSITION_GENERATION_FAILED,
  TRANSITION_ADAPTER_UNSOUND,
  TRANSITION_JUNCTION_UNSOUND,
  // The mission stated no initial state at all — neither an initial
  // velocity vector nor an initial speed. This planner covers the initial
  // phase as well as the midcourse one, so "nothing was said" is an
  // incomplete mission, not a request to begin at cruise. It used to be
  // silently completed: the derived rest state fell below the margin-backed cruise floor
  // and was rewritten to it (~132 m/s) with only a WARN, so a flight the
  // operator never described was published as if they had.
  INITIAL_STATE_UNSPECIFIED,
};

struct PlanResult {
  PlanOutcome outcome{PlanOutcome::FAILED};
  PlanReason reason{PlanReason::NONE};
  std::string detail;

  bool hasTrajectory() const { return outcome != PlanOutcome::FAILED; }

  static PlanResult success() { return {PlanOutcome::SUCCESS, PlanReason::NONE, {}}; }
  static PlanResult failed(std::string why)
  {
    return {PlanOutcome::FAILED, PlanReason::NONE, std::move(why)};
  }
  // FAILED with a machine-readable cause (the FAILED-only reasons above).
  static PlanResult failedBecause(PlanReason r, std::string why)
  {
    return {PlanOutcome::FAILED, r, std::move(why)};
  }
  // Priority-respecting degrade accumulator: outcome drops to DEGRADED,
  // the strongest reason wins, details concatenate.
  void degrade(PlanReason r, const std::string &why)
  {
    if (outcome == PlanOutcome::FAILED) return;  // FAILED is terminal
    outcome = PlanOutcome::DEGRADED;
    if (static_cast<int>(r) > static_cast<int>(reason)) reason = r;
    if (!detail.empty()) detail += "; ";
    detail += why;
  }
};

}  // namespace path_manager

#endif  // PATH_MANAGER_PLANNING_RESULT_H

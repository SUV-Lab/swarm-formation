from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument, ExecuteProcess, OpaqueFunction, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
import os

# Workspace root: container default /ws, overridable for native checkouts.
_WS = os.environ.get('MMP_WS', '/ws')


def _rviz_node(context, *args, **kwargs):
    # DEBUG MODE switch. debug:=true does two things:
    #  1. loads rviz/mmp_debug.rviz (debugging layout: Pipeline Debug display
    #     on, Global Trajectory on) instead of the product layout;
    #  2. MMP_DEBUG=1 is exported (SetEnvironmentVariable below), which the
    #     MMP Control panel's forked planner launch inherits — the planner
    #     then comes up with /debug/pipeline + verbose logs without any
    #     panel-side change.
    pkg_share = get_package_share_directory('mmp_launch')
    debug = context.perform_substitution(
        LaunchConfiguration('debug')).lower() in ('1', 'true')
    rviz_config_file = os.path.join(
        pkg_share, 'rviz', 'mmp_debug.rviz' if debug else 'mmp.rviz')
    additional_env = {}
    if debug:
        # The .so is gitignored and built by nothing in the build — it is a
        # developer instrument that rviz_debug.sh compiles on demand. Preloading
        # a path that does not exist made the loader print
        # "cannot be preloaded ... ignored" into the RViz noise and carry on, so
        # debug:=true looked instrumented while catching nothing. Say what to do
        # instead, and do not set a preload that cannot work.
        catcher = os.path.join(_WS, 'src', 'mmp_launch', 'debug',
                               'crashcatch.so')
        if os.path.exists(catcher):
            additional_env['LD_PRELOAD'] = catcher
            print(f'debug: crash catcher preloaded ({catcher}); '
                  f'backtraces go to /tmp/smash_bt_<pid>.txt')
        else:
            print(f'debug: no crash catcher at {catcher} — RViz runs without '
                  f'it. Build it with '
                  f'`bash src/mmp_launch/debug/rviz_debug.sh` (it compiles to '
                  f'that exact path) if you want backtraces.')
    return [Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
        output='screen',
        additional_env=additional_env,
    )]


def generate_launch_description():
    # Declare launch argument for world name
    world_arg = DeclareLaunchArgument(
        'world',
        default_value='none',
        description="World identifier ('full_map' uses full_map.tif; "
                    "'none' disables terrain)"
    )
    debug_arg = DeclareLaunchArgument(
        'debug',
        default_value='0',
        description='Debug mode: load mmp_debug.rviz and export MMP_DEBUG=1 '
                    'so the Start-button-forked planner publishes '
                    '/debug/pipeline stage geometry + verbose logs'
    )
    transition_arg = DeclareLaunchArgument(
        'transition',
        default_value='',
        description='Override transition/enable in the Start-button-forked '
                    'planner (MMP_TRANSITION): 1 on, 0 off, empty (default) '
                    'leaves optimizer_params.yaml in charge, where it ships '
                    'ON. Governs missions whose commanded initial state '
                    'leaves the +/-30 deg validity cone, e.g. '
                    'r5_transition_success_probe (32 deg)'
    )
    # Mission-corridor mode: crop the fine 30 m DEM around the mission
    # start->goal (same full-map-frame coordinates; planner sees ~30-40 m terrain
    # instead of the region-wide 250 m). Empty = normal full-world load.
    corridor_arg = DeclareLaunchArgument(
        'corridor_mission',
        default_value='',
        description='Mission yaml path; when set (with world:=full_map), publish a '
                    'fine-DEM corridor crop around its start/goal instead of the full map'
    )

    # TerrainTiles tile server (globe/server.py): the RViz display streams
    # from it, and `docker exec`-started instances die with the container —
    # so the launch guarantees one is up. The guard curl makes a double
    # start a silent no-op (an already-running server keeps the port).
    tile_server = ExecuteProcess(
        cmd=['bash', '-c',
             'curl -s -m 2 -o /dev/null http://localhost:8085/ftile/meta || '
             f'exec env PYTHONPATH={_WS}/src/mmp_terrain/tiles/pydeps '
             'OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 GDAL_NUM_THREADS=2 '
             f'python3 {_WS}/src/mmp_terrain/tiles/server.py'],
        name='tile_server',
        # Not 'log'. The line that says the port is open is the tile server's
        # own output, and hiding it left the only visible sign in RViz -- a
        # display reading "Connection refused", which looks identical whether
        # the server is still hashing 27 GB or died three minutes ago.
        output='screen',
    )

    return LaunchDescription([
        world_arg,
        corridor_arg,
        debug_arg,
        transition_arg,
        # MMP_DEBUG rides the environment because the MMP Control panel forks
        # the planner launch WITHOUT arguments — env is the only channel that
        # survives rviz2 -> fork. path_manager.launch.py reads it as the
        # default of its own `debug` argument.
        SetEnvironmentVariable('MMP_DEBUG', LaunchConfiguration('debug')),
        # Same channel, same reason: the panel's fork gets no arguments.
        SetEnvironmentVariable('MMP_TRANSITION',
                               LaunchConfiguration('transition')),
        tile_server,

        # Terrain publisher node
        Node(
            package='mmp_terrain',
            executable='terrain_publisher',
            name='terrain_publisher',
            output='screen',
            parameters=[
                {'world': LaunchConfiguration('world')},
                {'corridor_mission': LaunchConfiguration('corridor_mission')},
            ]
        ),

        # RViz2 (config chosen by debug mode inside _rviz_node)
        # 간헐 stack-smashing 크래시 추적 계측 (원인 확정 시 제거 예정):
        #  - crashcatch.so: 크래시 신호를 가로채 백트레이스를 /ws/logs/crashes/에
        #    남기고 그대로 죽는다. 수동적(타이밍 무변)이라 debug:=true 에서는 유지.
        #  - MALLOC_CHECK_/MALLOC_PERTURB_는 2026-07-20 수사 종결로 제거:
        #    이 힙 디버그 옵션들이 Qt jpeg 디코드 경로의 잠재 버그(stale-read,
        #    Qt 5.15.3/libjpeg-turbo 2.1.2 내부, 우리 코드 아님)를 60% 확률로
        #    발화시키는 증폭기였음이 콘솔 최소재현 A/B로 확정됨
        #    (PERTURB+CHECK: 18-30/30 크래시, 제거: 0/30). 소임(백트레이스
        #    확보→범인 경로 특정)을 다했으므로 프로덕션 launch에서 뺀다.
        #    재발 시 buildTile의 /tmp/mmp_last_tile.img 덤프가 payload를 남긴다.
        OpaqueFunction(function=_rviz_node),
    ])

#!/usr/bin/env python3
"""Gate for the Python face of the shared model.

Catches the failure modes a pure-C++ gtest cannot: a broken/renamed binding
surface (ImportError), a shim export list that drifted from the module, and —
most importantly — a parameter-mapping regression: parameters_from_ros /
load_planner_parameters must keep producing the SAME numbers the C++
consumers hand-map from optimization/dynamics_* (deg->rad, margin, units).

Runs under ament_add_test with PYTHONPATH pointing at the install space; the
planner yaml path arrives via OPTIMIZER_YAML (skipped gracefully if the
submodule is absent in a standalone build).

WHAT THE SKIP ACTUALLY LOSES — narrower than it looks, and worth stating so
nobody over- or under-trusts a green run without the yaml. The deg->rad and
margin assertions do NOT depend on it: parameters_from_ros is exercised with a
literal dict below and runs in BOTH paths, so an inverted conversion fails
either way. The skip loses only the yaml-derived half: load_planner_parameters
itself, parameters_are_valid on yaml-derived values, speed_min 122.0, and
FrameUnits(100, 100). CTest always passes OPTIMIZER_YAML, so in-tree the skip
is inert; it fires only for a non-recursive clone, which README does not
instruct.
"""
import math
import os
import sys

import numpy as np

import mmp_vehicle_dynamics as md

failures = 0


def check(cond, label):
    global failures
    print(('[OK]   ' if cond else '[FAIL] ') + label)
    if not cond:
        failures += 1


# --- surface ---------------------------------------------------------------
for name in ('Parameters', 'Evaluation', 'CostGradient', 'EnvelopeLimit',
             'BANK_MEANINGFUL_LOAD_FACTOR', 'BANK_NEGATIVE_NZ',
             'parameters_are_valid', 'air_density',
             'evaluate_inverse_dynamics', 'flight_envelope_penalty',
             'envelope_utilization', 'is_within_envelope',
             'envelope_limit_name', 'parameters_from_ros',
             'load_planner_parameters', 'FrameUnits'):
    check(hasattr(md, name), f'export: {name}')

# --- physics smoke (header defaults) ---------------------------------------
p = md.Parameters()
check(md.parameters_are_valid(p), 'default Parameters are valid')

cruise = md.evaluate_inverse_dynamics(
    p, np.array([0.0, 0.0, 500.0]), np.array([160.0, 0.0, 0.0]), np.zeros(3))
check(cruise.valid and md.is_within_envelope(p, cruise),
      'cruise 160 m/s sits inside the envelope')
check(p.thrust_min_n < cruise.thrust_required_n < p.thrust_max_n,
      'cruise thrust between limits')
check(abs(cruise.load_factor - 1.0) < 0.05, 'level cruise load factor ~1')

slow = md.evaluate_inverse_dynamics(
    p, np.array([0.0, 0.0, 500.0]), np.array([80.0, 0.0, 0.0]), np.zeros(3))
u, lim = md.envelope_utilization(p, slow)
check(not md.is_within_envelope(p, slow) and
      lim == md.EnvelopeLimit.MINIMUM_SPEED,
      'sub-stall 80 m/s flagged as minimum-speed violation')

cg = md.flight_envelope_penalty(
    p, np.array([0.0, 0.0, 500.0]), np.array([80.0, 0.0, 0.0]),
    np.zeros(3), 1.0)
check(cg.cost > 0.0 and cg.velocity[0] < 0.0,
      'sub-stall penalty positive, gradient favors speeding up')

# --- parameter mapping vs the authoritative planner yaml -------------------
yaml_path = os.environ.get('OPTIMIZER_YAML', '')
if yaml_path and os.path.exists(yaml_path):
    lp, units = md.load_planner_parameters(yaml_path)
    check(md.parameters_are_valid(lp), 'planner-yaml Parameters are valid')
    check(abs(lp.constraint_margin - 0.08) < 1e-12,
          'margin follows the LIVE config (0.08, not the header 0.02)')
    check(abs(lp.speed_min_mps - 122.0) < 1e-12,
          'speed_min follows the live config (122)')
    check(abs(lp.bank_angle_max_rad - math.radians(65.0)) < 1e-12,
          'bank limit deg->rad conversion')
    check(units == md.FrameUnits(100.0, 100.0),
          'frame units read from config (100/100 today)')
else:
    print('[SKIP] OPTIMIZER_YAML not available — mapping checks skipped '
          '(standalone build)')

# bare-suffix form of the same mapping
p2, _ = md.parameters_from_ros({'dynamics_margin': 0.08,
                                'dynamics_bank_max_deg': 65.0})
check(abs(p2.constraint_margin - 0.08) < 1e-12 and
      abs(p2.bank_angle_max_rad - math.radians(65.0)) < 1e-12,
      'parameters_from_ros accepts bare suffixes')

print(f'==== python_binding_test: failures={failures} ====')
sys.exit(0 if failures == 0 else 1)

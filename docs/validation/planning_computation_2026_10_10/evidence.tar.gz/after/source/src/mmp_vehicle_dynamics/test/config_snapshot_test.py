#!/usr/bin/env python3
"""[V-13] config/vehicle_dynamics.yaml is a reference snapshot — check it.

The file is loaded by nothing. It exists so a reader of this package can see
the model's parameter set in one place, and python/__init__.py plus this
package's README both point at it. That makes drift worse than absence: the
reader gets a confident wrong number.

Two keys HAD drifted before this test existed — dynamics_margin sat at the
pre-fix 0.02 while the live value was 0.08, and dynamics_speed_min_mps at 120.0
against a live 122.0. The file's own header even warned that values "may
drift", which documents the problem instead of preventing it.

Every optimization/* key the snapshot declares must equal the authoritative
planner yaml. Keys the authority has and the snapshot omits are fine — a
snapshot may be partial. A key the snapshot invents is not: it would describe a
parameter that does not exist.

No ROS, no yaml library: the values are scalars on their own lines, and a
regex reader keeps this runnable from a bare python3.
"""

import os
import re
import sys

KEY_RE = re.compile(r'^\s*(optimization/[A-Za-z_0-9]+):\s*([-+0-9.eE]+)\s*(?:#.*)?$')


def read_scalars(path):
    out = {}
    with open(path, encoding='utf-8') as fh:
        for lineno, line in enumerate(fh, 1):
            m = KEY_RE.match(line)
            if m:
                out[m.group(1)] = (float(m.group(2)), lineno)
    return out


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    snapshot = os.path.join(here, '..', 'config', 'vehicle_dynamics.yaml')
    authority = os.environ.get('OPTIMIZER_YAML')
    if not authority:
        # Same relative walk the CMakeLists uses for python_binding_test.
        authority = os.path.join(
            here, '..', '..', 'mmp_path_planning', 'src', 'path_manager',
            'config', 'optimizer_params.yaml')

    for label, path in (('snapshot', snapshot), ('authority', authority)):
        if not os.path.isfile(path):
            print(f'[FAIL] {label} not found: {path}')
            return 2

    snap = read_scalars(snapshot)
    auth = read_scalars(authority)
    print(f'  snapshot {len(snap)} optimization/* scalars  '
          f'authority {len(auth)}')

    if not snap:
        print('[FAIL] the snapshot declares no optimization/* scalar at all — '
              'either the file moved or the key format changed, and this test '
              'would otherwise pass by measuring nothing')
        return 1

    failures = 0

    invented = sorted(k for k in snap if k not in auth)
    for k in invented:
        print(f'[FAIL] {k} exists only in the snapshot (line {snap[k][1]}) — '
              f'it describes a parameter the planner does not have')
        failures += 1

    drift = [(k, snap[k][0], auth[k][0], snap[k][1])
             for k in sorted(snap) if k in auth and snap[k][0] != auth[k][0]]
    for k, s_val, a_val, lineno in drift:
        print(f'[FAIL] {k}: snapshot {s_val} (line {lineno}) != authority '
              f'{a_val}. The snapshot is reference-only; fix the authoritative '
              f'file first, then sync this one.')
        failures += 1

    if failures == 0:
        print(f'  [OK]   all {len(snap)} snapshot values equal the authority')
        print('PASS: 0 failed check(s)')
        return 0
    print(f'FAIL: {failures} failed check(s)')
    return 1


if __name__ == '__main__':
    sys.exit(main())

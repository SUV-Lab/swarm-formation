#ifndef MMP_VEHICLE_DYNAMICS__VEHICLE_MODEL_HPP_
#define MMP_VEHICLE_DYNAMICS__VEHICLE_MODEL_HPP_

#include <memory>
#include "mmp_vehicle_dynamics/flight_dynamics.hpp"

namespace mmp_vehicle_dynamics {

struct VehicleLimits {
  double speed_min_mps;
  double speed_max_mps;
  double activation_speed_mps;
  double cruise_floor_mps;
  double flight_path_angle_max_rad;
  double load_factor_max;
};

struct EnvelopeDomain {
  bool active;
  bool cruise;
  bool low_lift;
};

// Necessary geometric screening bounds, not a trajectory feasibility proof.
struct PlanningGeometry {
  double climb_grade;
  double turn_radius_m;
  double acceleration_distance_m;
};

// Immutable planning dynamics strategy. All state arguments and derivatives
// use SI units. Implementations must support concurrent const calls: the same
// owned model is shared by independent segment optimizers and the coordinator.
// Evaluation's aerodynamic fields are optional diagnostics for other models;
// domain(), utilization(), withinEnvelope() and the verdicts define acceptance.
// This interface does not replace the execution follower or a transition law.
class VehicleModel {
 public:
  using Ptr = std::shared_ptr<const VehicleModel>;
  virtual ~VehicleModel() = default;
  virtual bool valid() const = 0;
  virtual VehicleLimits limits() const = 0;
  virtual Evaluation evaluate(const Eigen::Vector3d &position_m,
                              const Eigen::Vector3d &velocity_mps,
                              const Eigen::Vector3d &acceleration_mps2) const = 0;
  virtual CostGradient penalty(const Eigen::Vector3d &position_m,
                               const Eigen::Vector3d &velocity_mps,
                               const Eigen::Vector3d &acceleration_mps2,
                               double weight) const = 0;
  virtual EnvelopeDomain domain(const Evaluation &evaluation) const = 0;
  virtual double utilization(const Evaluation &evaluation,
                             EnvelopeLimit *limiting = nullptr) const = 0;
  virtual bool withinEnvelope(const Evaluation &evaluation) const = 0;
  virtual HandoffVerdict velocityVerdict(const Eigen::Vector3d &velocity_mps,
                                        double floor_mps,
                                        double maximum_mps) const = 0;
  virtual HandoffVerdict handoffVerdict(const Eigen::Vector3d &position_m,
                                       const Eigen::Vector3d &velocity_mps,
                                       const Eigen::Vector3d &acceleration_mps2,
                                       double floor_mps,
                                       double maximum_mps) const = 0;
  virtual PlanningGeometry planningGeometry(double cruise_speed_mps,
                                             double initial_speed_mps,
                                             double turn_radius_margin) const = 0;

  // Opt-in capability for the existing fixed-wing 3DOF transition generator.
  // Null means unsupported: a different model must never silently inherit
  // that generator's force closure, state representation or control law.
  virtual const Parameters *fixedWingTransitionParameters() const {
    return nullptr;
  }
};

// Delegates to the established free functions without changing their math.
// Parameters are copied; later caller edits cannot change a running solve.
class FixedWingModel final : public VehicleModel {
 public:
  explicit FixedWingModel(Parameters parameters = {});
  bool valid() const override;
  VehicleLimits limits() const override;
  Evaluation evaluate(const Eigen::Vector3d &, const Eigen::Vector3d &,
                      const Eigen::Vector3d &) const override;
  CostGradient penalty(const Eigen::Vector3d &, const Eigen::Vector3d &,
                       const Eigen::Vector3d &, double) const override;
  EnvelopeDomain domain(const Evaluation &) const override;
  double utilization(const Evaluation &, EnvelopeLimit * = nullptr) const override;
  bool withinEnvelope(const Evaluation &) const override;
  HandoffVerdict velocityVerdict(const Eigen::Vector3d &, double,
                                double) const override;
  HandoffVerdict handoffVerdict(const Eigen::Vector3d &, const Eigen::Vector3d &,
                               const Eigen::Vector3d &, double,
                               double) const override;
  PlanningGeometry planningGeometry(double, double, double) const override;
  const Parameters *fixedWingTransitionParameters() const override {
    return &parameters_;
  }
 private:
  const Parameters parameters_;
};

}  // namespace mmp_vehicle_dynamics
#endif

#include "mmp_vehicle_dynamics/flight_dynamics.hpp"

#include <gtest/gtest.h>

#include <cmath>

namespace md = mmp_vehicle_dynamics;

TEST(FlightDynamics, StraightLevelTrimIncludesGravity)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 100.0);
  const Eigen::Vector3d velocity(200.0, 0.0, 0.0);
  const Eigen::Vector3d acceleration = Eigen::Vector3d::Zero();
  const md::Evaluation e =
      md::evaluateInverseDynamics(p, position, velocity, acceleration);

  ASSERT_TRUE(e.valid);
  EXPECT_NEAR(e.load_factor, 1.0, 1.0e-10);
  EXPECT_NEAR(e.lift_acceleration_mps2, p.gravity_mps2, 1.0e-10);
  EXPECT_NEAR(e.thrust_required_n, e.drag_n, 1.0e-9);
  EXPECT_NEAR(e.bank_angle_rad, 0.0, 1.0e-10);
}

TEST(FlightDynamics, NearZeroLiftArcDoesNotTriggerBankLimit)
{
  // Zero-g pushover: |a - g| ~ 0 so the required lift vanishes and the raw
  // lift DIRECTION is numerical noise. The bank entries of the audit
  // metrics must ignore it ([BANK-GATE]); every other limit still applies.
  mmp_vehicle_dynamics::Parameters p;
  const Eigen::Vector3d pos(0.0, 0.0, 1000.0);
  const Eigen::Vector3d vel(180.0, 0.0, 0.0);
  const Eigen::Vector3d acc(0.0, 1.0e-6, -p.gravity_mps2);
  const auto e = mmp_vehicle_dynamics::evaluateInverseDynamics(p, pos, vel, acc);
  ASSERT_TRUE(e.valid);
  EXPECT_LT(e.load_factor, mmp_vehicle_dynamics::kBankMeaningfulLoadFactor);
  mmp_vehicle_dynamics::EnvelopeLimit limit;
  const double util = mmp_vehicle_dynamics::envelopeUtilization(p, e, &limit);
  EXPECT_NE(limit, mmp_vehicle_dynamics::EnvelopeLimit::BankAngle);
  EXPECT_LT(util, 1.0);
  EXPECT_TRUE(mmp_vehicle_dynamics::isWithinEnvelope(p, e));
}

TEST(FlightDynamics, CoordinatedTurnMatchesClosedForm)
{
  md::Parameters p;
  const double speed = 200.0;
  const double lateral_acceleration = p.gravity_mps2;
  const Eigen::Vector3d velocity(speed, 0.0, 0.0);
  const Eigen::Vector3d acceleration(0.0, lateral_acceleration, 0.0);
  const md::Evaluation e = md::evaluateInverseDynamics(
      p, Eigen::Vector3d::Zero(), velocity, acceleration);

  ASSERT_TRUE(e.valid);
  EXPECT_NEAR(e.load_factor, std::sqrt(2.0), 1.0e-10);
  EXPECT_NEAR(e.bank_angle_rad, M_PI / 4.0, 1.0e-10);
}

TEST(FlightDynamics, SteadyClimbMatchesEnergyBalance)
{
  md::Parameters p;
  const double speed = 200.0;
  const double gamma = 10.0 * M_PI / 180.0;
  const Eigen::Vector3d velocity(
      speed * std::cos(gamma), 0.0, speed * std::sin(gamma));
  const md::Evaluation e = md::evaluateInverseDynamics(
      p, Eigen::Vector3d(0.0, 0.0, 1000.0), velocity,
      Eigen::Vector3d::Zero());

  ASSERT_TRUE(e.valid);
  EXPECT_NEAR(e.lift_acceleration_mps2,
              p.gravity_mps2 * std::cos(gamma), 1.0e-10);
  EXPECT_NEAR(e.thrust_required_n,
              e.drag_n + p.mass_kg * p.gravity_mps2 * std::sin(gamma),
              1.0e-9);
  EXPECT_NEAR(e.flight_path_angle_rad, gamma, 1.0e-12);
}

TEST(FlightDynamics, PenaltyGradientMatchesFiniteDifference)
{
  md::Parameters p;
  p.constraint_margin = 0.02;
  const Eigen::Vector3d position(10.0, -20.0, 2500.0);
  const Eigen::Vector3d velocity(225.0, 18.0, 40.0);
  const Eigen::Vector3d acceleration(6.0, 30.0, 8.0);
  const double weight = 3.0;
  const md::CostGradient analytic =
      md::flightEnvelopePenalty(p, position, velocity, acceleration, weight);
  ASSERT_GT(analytic.cost, 0.0);

  const double eps[3] = {1.0e-3, 1.0e-5, 1.0e-5};
  for (int group = 0; group < 3; ++group) {
    for (int axis = 0; axis < 3; ++axis) {
      Eigen::Vector3d pp = position, pm = position;
      Eigen::Vector3d vp = velocity, vm = velocity;
      Eigen::Vector3d ap = acceleration, am = acceleration;
      if (group == 0) { pp(axis) += eps[group]; pm(axis) -= eps[group]; }
      if (group == 1) { vp(axis) += eps[group]; vm(axis) -= eps[group]; }
      if (group == 2) { ap(axis) += eps[group]; am(axis) -= eps[group]; }
      const double cp = md::flightEnvelopePenalty(p, pp, vp, ap, weight).cost;
      const double cm = md::flightEnvelopePenalty(p, pm, vm, am, weight).cost;
      const double numeric = (cp - cm) / (2.0 * eps[group]);
      const double expected = group == 0 ? analytic.position(axis) :
          (group == 1 ? analytic.velocity(axis) : analytic.acceleration(axis));
      EXPECT_NEAR(numeric, expected,
                  2.0e-4 * std::max(1.0, std::abs(expected)));
    }
  }
}

TEST(FlightDynamics, RepresentativeLevelCruiseIsInsideEnvelope)
{
  md::Parameters p;
  const md::Evaluation e = md::evaluateInverseDynamics(
      p, Eigen::Vector3d(0.0, 0.0, 100.0),
      Eigen::Vector3d(200.0, 0.0, 0.0), Eigen::Vector3d::Zero());
  EXPECT_TRUE(md::isWithinEnvelope(p, e));
  EXPECT_LT(md::envelopeUtilization(p, e), 1.0);
}

// Cone-form bank limit: still ENFORCES at meaningful lift (a real 2g-class
// turn past 65 deg must be penalized with finite-difference-exact gradients).
TEST(FlightDynamics, ConeBankEnforcesAtHighLift)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 1000.0);
  const Eigen::Vector3d velocity(200.0, 0.0, 0.0);
  // u = a - g = (0, 25, 9.81): bank = atan2(25, 9.81) = 68.6 deg > 65 deg.
  const Eigen::Vector3d acceleration(0.0, 25.0, 0.0);
  const md::Evaluation e = md::evaluateInverseDynamics(
      p, position, velocity, acceleration);
  EXPECT_GT(e.bank_angle_rad, p.bank_angle_max_rad);
  const md::CostGradient g = md::flightEnvelopePenalty(
      p, position, velocity, acceleration, 1000.0);
  EXPECT_GT(g.cost, 0.0);
  EXPECT_GT(g.acceleration.norm(), 0.0);
}

// REGRESSION for the pushover blowup: near zero lift the old bank_cos-space
// penalty produced gradients of O(1e4) (1/L^2 divergence). The force-space
// cone form must keep every gradient bounded and the penalty negligible —
// with no required lift, any bank is physically admissible.
TEST(FlightDynamics, BankPenaltyBoundedNearZeroLift)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 2000.0);
  const Eigen::Vector3d velocity(200.0, 0.0, 0.0);
  for (double s : {0.01, 0.004, 0.002, 0.001, 0.0001}) {
    const Eigen::Vector3d acceleration(
        0.0, 0.05, -p.gravity_mps2 * (1.0 - s));
    const md::CostGradient g = md::flightEnvelopePenalty(
        p, position, velocity, acceleration, 1000.0);
    EXPECT_LT(g.velocity.norm(), 50.0);
    EXPECT_LT(g.acceleration.norm(), 50.0);
    EXPECT_LT(g.cost, 1.0);
  }
}

// Flight-path limit in velocity-component space: a steep dive beyond the
// 30 deg limit must be penalized with bounded, FD-exact gradients, and the
// old 1/cos(gamma) divergence near vertical must be gone.
TEST(FlightDynamics, FlightPathComponentFormBoundedAndActive)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 3000.0);
  // 40-deg dive at 180 m/s: |gamma| > 30-deg limit.
  const double gamma = -40.0 * M_PI / 180.0;
  const Eigen::Vector3d velocity(
      180.0 * std::cos(gamma), 0.0, 180.0 * std::sin(gamma));
  const Eigen::Vector3d acceleration(0.0, 0.0, 0.0);
  const md::CostGradient g = md::flightEnvelopePenalty(
      p, position, velocity, acceleration, 1000.0);
  EXPECT_GT(g.cost, 0.0);
  EXPECT_LT(g.velocity.norm(), 1.0e3);
  // Near-vertical: gradient must stay bounded (old form spiked as 1/cos).
  const double gv = -85.0 * M_PI / 180.0;
  const Eigen::Vector3d vv(150.0 * std::cos(gv), 0.0, 150.0 * std::sin(gv));
  const md::CostGradient g2 = md::flightEnvelopePenalty(
      p, position, vv, acceleration, 1000.0);
  EXPECT_LT(g2.velocity.norm(), 1.0e3);
}

// REGRESSION for the activation-ramp barrier (the reason `sigma` was removed;
// see README.md design decision 1, the q-floor). The penalty must never push the
// vehicle to fly SLOWER: d(cost)/dV_x <= 0 throughout initial acceleration, at
// every tangential acceleration the optimiser might explore. The gated version
// failed this at up to +1.2e4.
//
// This is also the coverage hole that let the barrier ship: every other test in
// this file sits at 150-229 m/s, so nothing exercised sub-stall flight at all.
TEST(FlightDynamics, NoDeceleratingBarrierDuringInitialAcceleration)
{
  md::Parameters p;
  p.constraint_margin = 0.08;                 // the loaded runtime margin
  const Eigen::Vector3d position(0.0, 0.0, 0.0);
  for (double a_t : {0.0, 1.0, 2.0, 5.0, 15.0, 30.0, 50.0}) {
    for (double v = 0.5; v <= 145.0; v += 0.5) {
      const Eigen::Vector3d velocity(v, 0.0, 0.0);
      const Eigen::Vector3d acceleration(a_t, 0.0, 0.0);
      const md::CostGradient g = md::flightEnvelopePenalty(
          p, position, velocity, acceleration, 1.0e4);
      // gradient DESCENT moves along -g, so g.velocity.x() > 0 == "slow down".
      EXPECT_LE(g.velocity.x(), 1.0)
          << "decelerating barrier at V = " << v << " m/s, a_t = " << a_t;
    }
  }
}

// The dynamic-pressure floor must be INERT in the cruise regime. That regime
// starts at speed_min*sqrt(1 + kBlend), NOT at speed_min — smoothFloor returns
// its argument exactly only from floor*(1.05). This comment used to state the
// weaker boundary, which made it the fifth place in the tree asserting a false
// invariant. The blend itself is pinned by QFloorBlendBoundaries below.
TEST(FlightDynamics, QFloorIsInertAboveStall)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 2000.0);
  const Eigen::Vector3d velocity(190.0, 30.0, 12.0);   // |v| = 192.8 > speed_min
  const Eigen::Vector3d acceleration(3.0, 18.0, -4.0);
  const md::Evaluation e =
      md::evaluateInverseDynamics(p, position, velocity, acceleration);
  // q_eff must equal the TRUE q, so CL must equal (m/S)*L/q exactly.
  const double q_true = 0.5 * md::airDensity(p, position.z()) *
      velocity.squaredNorm();
  EXPECT_NEAR(e.dynamic_pressure_pa, q_true, 1.0e-9);
  EXPECT_NEAR(e.lift_coefficient,
              (p.mass_kg / p.wing_area_m2) * e.lift_acceleration_mps2 / q_true,
              1.0e-12);
}

// [V-9] The blend is a real regime with real consequences, and nothing looked
// at it. The one q-floor test sampled |v| = 192.8 and asserted
// dynamic_pressure_pa == q_true — which holds at EVERY speed, because
// dynamic_pressure_pa is assigned the true q unconditionally and is never
// floored. That assertion is a tautology, not a check of the floor.
//
// The floor is only observable through q_eff, and q_eff is only observable by
// back-deriving it from the reported CL:  q_eff = (m/S) * a_lift / CL.
//
// Three points, all computed from the parameter set and kBlend, never from a
// literal speed: below the floor, the middle of the blend, and the end of it.
TEST(FlightDynamics, QFloorBlendBoundaries)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 1500.0);
  const double rho = md::airDensity(p, position.z());
  const double floor2 = p.speed_min_mps * p.speed_min_mps;
  constexpr double kBlend = 0.05;              // must match smoothFloor
  const double blend_end2 = floor2 + kBlend * floor2;
  const double q_floor = 0.5 * rho * floor2;

  // Level-ish acceleration so lift is well away from zero and CL is a clean
  // divisor. Velocity along +x only, so squaredNorm() is exactly v*v.
  const Eigen::Vector3d accel(0.0, 0.0, 2.0);

  const auto qEffOf = [&](double v) {
    const Eigen::Vector3d velocity(v, 0.0, 0.0);
    const md::Evaluation e =
        md::evaluateInverseDynamics(p, position, velocity, accel);
    EXPECT_TRUE(e.valid);
    EXPECT_GT(e.lift_coefficient, 0.0);
    return (p.mass_kg / p.wing_area_m2) * e.lift_acceleration_mps2 /
           e.lift_coefficient;
  };
  const auto qTrueOf = [&](double v) { return 0.5 * rho * v * v; };

  // ── below the floor ────────────────────────────────────────────────
  // The PUBLIC dynamic_pressure_pa is the true q here, not the floor. If the
  // two fields were ever conflated this is where it shows: q_true is ~4 % of
  // q_floor at this speed.
  {
    const double v = 0.2 * p.speed_min_mps;
    const Eigen::Vector3d velocity(v, 0.0, 0.0);
    const md::Evaluation e =
        md::evaluateInverseDynamics(p, position, velocity, accel);
    EXPECT_NEAR(e.dynamic_pressure_pa, qTrueOf(v), 1.0e-9)
        << "the published dynamic pressure is the TRUE q at every speed";
    EXPECT_LT(e.dynamic_pressure_pa, 0.1 * q_floor)
        << "...and is therefore nowhere near the floor down here";
    // The floor is what CL was computed against.
    EXPECT_NEAR(qEffOf(v), q_floor, 1.0e-6 * q_floor)
        << "CL is computed against the FLOOR below speed_min";
  }

  // ── middle of the blend ────────────────────────────────────────────
  // This is the point the whole finding rests on, and the point that dies if
  // the exact-passthrough condition is widened back to x >= floor.
  {
    const double v = std::sqrt(0.5 * (floor2 + blend_end2));
    const double q_eff = qEffOf(v), q_true = qTrueOf(v);
    EXPECT_GT(q_eff, q_floor)
        << "inside the blend the effective q is ABOVE the floor";
    EXPECT_LT(q_eff, q_true)
        << "...and BELOW the true q — strictly between the two";
    // Same statement as a CL consequence. Dividing by a SMALLER q makes the
    // reported CL read HIGH, which is the direction that matters: it is what
    // flips isWithinEnvelope for a trajectory that is physically inside it.
    const Eigen::Vector3d velocity(v, 0.0, 0.0);
    const md::Evaluation e =
        md::evaluateInverseDynamics(p, position, velocity, accel);
    const double cl_unregularised =
        (p.mass_kg / p.wing_area_m2) * e.lift_acceleration_mps2 / q_true;
    EXPECT_GT(e.lift_coefficient, cl_unregularised)
        << "the reported CL is HIGH by the q_true/q_eff ratio";
  }

  // ── end of the blend ───────────────────────────────────────────────
  // From here up the model is the unregularised one, exactly. Step to the
  // first representable speed whose square reaches the threshold, so the
  // point is AT the boundary and not a safe distance past it.
  {
    double v = std::sqrt(blend_end2);
    while (v * v < blend_end2) v = std::nextafter(v, 2.0 * v);
    const double q_eff = qEffOf(v), q_true = qTrueOf(v);
    EXPECT_EQ(q_eff, q_true)
        << "at speed_min*sqrt(1+kBlend) the effective q IS the true q, exactly";
    EXPECT_GT(v, p.speed_min_mps)
        << "the exact regime starts strictly above speed_min — that gap is the "
           "finding";
  }
}

// Below stall the aero quantities must be BOUNDED (the 1/q blowup is gone) and
// FLAT in |v| — that flatness is what makes the barrier impossible.
TEST(FlightDynamics, SubStallAeroIsBoundedAndSpeedFlat)
{
  md::Parameters p;
  const Eigen::Vector3d position(0.0, 0.0, 0.0);
  const Eigen::Vector3d acceleration(0.0, 0.0, 0.0);
  double cl_ref = -1.0;
  for (double v : {5.0, 20.0, 60.0, 100.0, 119.0}) {
    const md::Evaluation e = md::evaluateInverseDynamics(
        p, position, Eigen::Vector3d(v, 0.0, 0.0), acceleration);
    EXPECT_LT(e.lift_coefficient, 2.0) << "CL blew up at " << v << " m/s";
    EXPECT_TRUE(std::isfinite(e.thrust_required_n));
    if (cl_ref < 0.0) cl_ref = e.lift_coefficient;
    // Level flight below the floor: CL is pinned at its speed_min value.
    EXPECT_NEAR(e.lift_coefficient, cl_ref, 1.0e-9)
        << "CL is not speed-flat below the floor (at " << v << " m/s)";
  }
}

// The negative-lift / negative-g pushover regime must be guarded by the BANK
// cone, not a CL floor (which was deleted as provably dead). This is the
// physics that justifies deleting lift_coefficient_min: every downward-lift
// state must incur a bank penalty, continuously from N = 0.
TEST(FlightDynamics, BankConeGuardsNegativeLiftPushover)
{
  md::Parameters p;
  p.constraint_margin = 0.08;
  const Eigen::Vector3d position(0.0, 0.0, 0.0);
  const Eigen::Vector3d velocity(200.0, 0.0, 0.0);   // wings-level cruise
  const double g = p.gravity_mps2;
  // a_z < -g => required perpendicular lift points DOWN (N < 0). The bank cone
  // must fire, and CL must report its magnitude with a NEGATIVE sign.
  for (double az_g : {-1.25, -1.5, -2.0, -2.5}) {
    const Eigen::Vector3d acceleration(0.0, 0.0, az_g * g);
    const md::Evaluation e =
        md::evaluateInverseDynamics(p, position, velocity, acceleration);
    EXPECT_LT(e.vertical_load_factor, 0.0) << "n_z should be negative at az=" << az_g;
    EXPECT_LT(e.signed_lift_coefficient, 0.0)
        << "signed CL should be negative on a pushover at az=" << az_g;
    EXPECT_GT(e.lift_coefficient, 0.0) << "CL magnitude is still positive";
    const md::CostGradient cg = md::flightEnvelopePenalty(
        p, position, velocity, acceleration, 1.0e4);
    EXPECT_GT(cg.cost, 0.0)
        << "bank cone must penalise the downward-lift state at az=" << az_g;
    md::EnvelopeLimit lim;
    md::envelopeUtilization(p, e, &lim);
    EXPECT_EQ(lim, md::EnvelopeLimit::BankAngle)
        << "bank must be the limiter for downward lift at az=" << az_g;
  }
}

// A gentle pushover that does NOT invert the lift (a_z > -g, N > 0) must stay
// clean — the guard fires only in the genuine negative-lift regime.
TEST(FlightDynamics, GentlePushoverStaysClean)
{
  md::Parameters p;
  p.constraint_margin = 0.08;
  const Eigen::Vector3d velocity(200.0, 0.0, 0.0);
  const Eigen::Vector3d acceleration(0.0, 0.0, -0.5 * p.gravity_mps2);  // n_z = +0.5
  const md::Evaluation e = md::evaluateInverseDynamics(
      p, Eigen::Vector3d::Zero(), velocity, acceleration);
  EXPECT_GT(e.vertical_load_factor, 0.0);
  EXPECT_GT(e.signed_lift_coefficient, 0.0);   // lift still points up
  EXPECT_NEAR(e.bank_angle_rad, 0.0, 1.0e-9);
}

// ─── handoffVerdict — the shared handoff gate ────────────────────────────
// These pin the properties an off-line harness relies on. Until this gate
// existed each caller re-derived them, and at least one re-derivation
// ("envelopeUtilization() <= 1.0") certified every sub-activation state.

namespace {

md::Parameters liveParams()
{
  // The SHIPPED configuration, not the header defaults: optimizer_params.yaml
  // sets speed_min 122.0 and margin 0.08, which is what makes the cruise
  // floor 131.76 rather than the default 122.4.
  md::Parameters p;
  p.speed_min_mps = 122.0;
  p.constraint_margin = 0.08;
  return p;
}

// A level trim the envelope accepts with room to spare (utilization 0.74,
// limited only by the speed-window ratio).
const Eigen::Vector3d kTrimPos(0.0, 0.0, 1000.0);
const Eigen::Vector3d kTrimVel(170.0, 0.0, 0.0);
const Eigen::Vector3d kTrimAcc(0.0, 0.0, 0.0);

}  // namespace

TEST(HandoffVerdict, MarginBackedFloorIsSpeedMinTimesOnePlusMargin)
{
  const md::Parameters p = liveParams();
  EXPECT_NEAR(md::marginBackedSpeedFloorMps(p), 122.0 * 1.08, 1.0e-12);
}

TEST(HandoffVerdict, KnownTrimPasses)
{
  const md::Parameters p = liveParams();
  const md::HandoffVerdict v = md::handoffVerdict(
      p, kTrimPos, kTrimVel, kTrimAcc, md::marginBackedSpeedFloorMps(p), 200.0);
  EXPECT_TRUE(v.ok());
  EXPECT_EQ(v.reject, md::HandoffReject::None);
  EXPECT_LT(v.utilization, 1.0);
  EXPECT_TRUE(v.evaluation.valid);
}

// THE fail-open this gate exists to close. Below model_activation_speed_mps
// envelopeUtilization is DEFINED to return 0.0 while isWithinEnvelope is
// false, so a caller comparing utilization alone certifies the state.
TEST(HandoffVerdict, SubActivationSpeedIsRefusedThoughUtilizationReadsZero)
{
  md::Parameters p = liveParams();
  p.speed_min_mps = 1.0;      // take the floor out of the way on purpose,
  p.constraint_margin = 0.0;  // so ONLY the activation gate can refuse
  const Eigen::Vector3d slow(20.0, 0.0, 0.0);   // < 40 m/s activation
  const md::Evaluation e =
      md::evaluateInverseDynamics(p, kTrimPos, slow, kTrimAcc);
  ASSERT_TRUE(e.valid);
  md::EnvelopeLimit lim = md::EnvelopeLimit::MaximumThrust;
  EXPECT_DOUBLE_EQ(md::envelopeUtilization(p, e, &lim), 0.0)
      << "utilization is 0.0 below the activation speed — reading it as "
         "'no constraint used' is exactly the trap";
  EXPECT_FALSE(md::isWithinEnvelope(p, e));

  const md::HandoffVerdict v =
      md::handoffVerdict(p, kTrimPos, slow, kTrimAcc, 1.0, 230.0);
  EXPECT_FALSE(v.ok());
  EXPECT_EQ(v.reject, md::HandoffReject::EnvelopeExceeded);
}

TEST(HandoffVerdict, SpeedBoundariesAreInclusiveWithinOneMicrometrePerSecond)
{
  const md::Parameters p = liveParams();
  const double floor_mps = md::marginBackedSpeedFloorMps(p);
  const double cap = 200.0;
  const Eigen::Vector3d dir = Eigen::Vector3d(1.0, 1.0, 0.0).normalized();

  // Exactly at each boundary, and half an epsilon outside, must pass.
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * floor_mps, kTrimAcc,
                               floor_mps, cap).reject,
            md::HandoffReject::None);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * (floor_mps - 0.5e-6),
                               kTrimAcc, floor_mps, cap).reject,
            md::HandoffReject::None);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * cap, kTrimAcc,
                               floor_mps, cap).reject,
            md::HandoffReject::None);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * (cap + 0.5e-6), kTrimAcc,
                               floor_mps, cap).reject,
            md::HandoffReject::None);
  // Two epsilons out is refused on BOTH sides — pins the tolerance value,
  // not merely its sign.
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * (floor_mps - 2.0e-6),
                               kTrimAcc, floor_mps, cap).reject,
            md::HandoffReject::SpeedBelowFloor);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, dir * (cap + 2.0e-6), kTrimAcc,
                               floor_mps, cap).reject,
            md::HandoffReject::SpeedAboveMaximum);
}

TEST(HandoffVerdict, FlightPathConeIsInclusiveExactlyAtTheLimit)
{
  const md::Parameters p = liveParams();
  const double floor_mps = md::marginBackedSpeedFloorMps(p);
  const double gmax = p.flight_path_angle_max_rad;
  const double vh = 150.0;

  // Building the fixture from cos/sin of the limit does NOT land on it: the
  // atan2 round trip comes back a few ULPs low, so the state sits inside the
  // cone and a > vs >= mutation is invisible. (Measured: that fixture left
  // the mutation alive.) Walk vz by ULPs until atan2 returns the limit
  // EXACTLY, so the boundary itself is the thing under test.
  double vz = vh * std::tan(gmax);
  int walked = 0;
  while (std::atan2(vz, vh) < gmax && walked < 4096) {
    vz = std::nextafter(vz, 1.0e300);
    ++walked;
  }
  while (std::atan2(vz, vh) > gmax && walked < 4096) {
    vz = std::nextafter(vz, 0.0);
    ++walked;
  }
  ASSERT_EQ(std::atan2(vz, vh), gmax)
      << "fixture must sit exactly on the cone or it cannot test the "
         "boundary at all";

  // Velocity-only, so the cone is isolated from the envelope: a genuine 30
  // deg climb also busts the thrust limit, which would mask this.
  for (const double sign : {1.0, -1.0}) {
    const Eigen::Vector3d at_cone(vh, 0.0, sign * vz);
    EXPECT_EQ(md::speedConeVerdict(p, at_cone, floor_mps, 230.0).reject,
              md::HandoffReject::None)
        << "exactly at the cone must pass, sign " << sign;
    const Eigen::Vector3d outside(vh, 0.0,
                                  sign * std::nextafter(vz, 1.0e300));
    EXPECT_EQ(md::speedConeVerdict(p, outside, floor_mps, 230.0).reject,
              md::HandoffReject::FlightPathOutsideCone)
        << "one ULP outside must be refused, sign " << sign;
  }
}

// Finiteness is judged before anything else, and each component names ITSELF.
// A gate that reported "speed below floor" for a NaN position would send the
// caller after the wrong quantity.
TEST(HandoffVerdict, NonFiniteComponentsAreNamedAndBeatOtherViolations)
{
  const md::Parameters p = liveParams();
  const double floor_mps = md::marginBackedSpeedFloorMps(p);
  const double nan = std::nan("");
  // Each NaN is paired with a velocity that ALSO violates the floor, so the
  // test fails if finiteness is checked after the speed comparison.
  const Eigen::Vector3d too_slow(1.0, 0.0, 0.0);
  EXPECT_EQ(md::handoffVerdict(p, Eigen::Vector3d(nan, 0.0, 1000.0), too_slow,
                               kTrimAcc, floor_mps, 200.0).reject,
            md::HandoffReject::NonFinitePosition);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, too_slow,
                               Eigen::Vector3d(0.0, nan, 0.0), floor_mps,
                               200.0).reject,
            md::HandoffReject::NonFiniteAcceleration);
  EXPECT_EQ(md::handoffVerdict(p, kTrimPos, Eigen::Vector3d(nan, 0.0, 0.0),
                               kTrimAcc, floor_mps, 200.0).reject,
            md::HandoffReject::NonFiniteVelocity);
}

// The state a 6DOF segment with zero aerodynamics hands over: the mid-phase
// model must supply the same tangential acceleration AND its own drag, so it
// demands more thrust than the 6DOF applied. Pins the named reason, since
// "rejected" alone would not distinguish this from a speed violation.
TEST(HandoffVerdict, ThrustExceededIsReportedByName)
{
  const md::Parameters p = liveParams();
  const Eigen::Vector3d vel(169.9, 0.0, 5.9);
  const Eigen::Vector3d acc(2.46, 0.0, -9.69);
  const md::HandoffVerdict v = md::handoffVerdict(
      p, Eigen::Vector3d(0.0, 0.0, 1000.0), vel, acc,
      md::marginBackedSpeedFloorMps(p), 200.0);
  EXPECT_EQ(v.reject, md::HandoffReject::EnvelopeExceeded);
  EXPECT_EQ(v.limit, md::EnvelopeLimit::MaximumThrust);
  EXPECT_GT(v.utilization, 1.0);
  EXPECT_GT(v.evaluation.thrust_required_n, p.thrust_max_n);
}

TEST(HandoffVerdict, DragPolarIsOneDefinitionSharedWithTheModel)
{
  const md::Parameters p = liveParams();
  // The free function and the model's own drag_coefficient must agree at the
  // state the model actually evaluated -- otherwise a 6DOF supplier burning
  // dragCoefficient() and the envelope judging the same state would disagree,
  // which is the 551 N gap this exists to close.
  const md::Evaluation e =
      md::evaluateInverseDynamics(p, kTrimPos, kTrimVel, kTrimAcc);
  ASSERT_TRUE(e.valid);
  EXPECT_DOUBLE_EQ(md::dragCoefficient(p, e.lift_coefficient),
                   e.drag_coefficient);
  // And it is the stated polar, not merely self-consistent: pin CD0 at CL = 0
  // and the induced term's curvature separately, so dropping either survives
  // nothing.
  EXPECT_DOUBLE_EQ(md::dragCoefficient(p, 0.0),
                   p.zero_lift_drag_coefficient);
  EXPECT_DOUBLE_EQ(md::dragCoefficient(p, 1.0),
                   p.zero_lift_drag_coefficient + p.induced_drag_factor);
  EXPECT_DOUBLE_EQ(md::dragCoefficient(p, 2.0),
                   p.zero_lift_drag_coefficient + 4.0 * p.induced_drag_factor);
  // Even in CL: the polar must not acquire a linear term.
  EXPECT_DOUBLE_EQ(md::dragCoefficient(p, -1.3), md::dragCoefficient(p, 1.3));
}

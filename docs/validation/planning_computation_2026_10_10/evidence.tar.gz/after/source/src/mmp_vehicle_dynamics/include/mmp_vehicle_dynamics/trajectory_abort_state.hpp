#pragma once

// The consumer half of the trajectory-abort contract, as one implementation.
//
// A follower must: remember which trajectory id it is executing, stop only for
// an abort naming THAT id, and refuse to begin a trajectory whose id has
// already been withdrawn. The last one matters because both topics are
// TRANSIENT_LOCAL, so a follower that connects late receives the latched
// trajectory and its abort in an order it does not control.
//
// This lives in a header, free of rclcpp and of any trajectory representation,
// so the simulator and the regression that checks the contract run the SAME
// code. They used to have a copy each, which meant the test could pass while
// the simulator did the wrong thing — or did nothing at all.

#include <cstdint>
#include <set>

namespace mmp_vehicle_dynamics {

class TrajectoryAbortState {
 public:
  // A trajectory arrived. Returns true if it should be executed.
  //
  // A REJECTION CHANGES NOTHING. A withdrawn trajectory can be redelivered at
  // any time — TRANSIENT_LOCAL keeps it latched, a consumer can reconnect,
  // a bag can replay it — and by then the aircraft may be flying a newer one.
  // Clearing the execution state here stopped that newer flight: abort(9),
  // trajectory(10) accepted, then a redelivered trajectory(9) grounded 10.
  // Refusing an input is not a reason to abandon what is already running.
  bool acceptTrajectory(uint64_t trajectory_id) {
    if (aborted_.count(trajectory_id)) return false;
    current_ = trajectory_id;
    executing_ = true;
    return true;
  }

  // An ABORT arrived for `trajectory_id`. Returns true if it stops what is
  // currently being executed — false means it named something else, which
  // includes a replayed abort for a trajectory already superseded.
  bool applyAbort(uint64_t trajectory_id) {
    aborted_.insert(trajectory_id);
    if (!executing_ || current_ != trajectory_id) return false;
    executing_ = false;
    return true;
  }

  bool executing() const { return executing_; }
  uint64_t current() const { return current_; }
  bool wasAborted(uint64_t id) const { return aborted_.count(id) != 0; }

 private:
  std::set<uint64_t> aborted_;
  uint64_t current_ = 0;
  bool executing_ = false;
};

}  // namespace mmp_vehicle_dynamics

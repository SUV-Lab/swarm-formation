#include <gtest/gtest.h>

#include <array>
#include <cmath>
#include <cstring>
#include <limits>
#include "mmp_vehicle_dynamics/vehicle_model.hpp"

namespace dyn = mmp_vehicle_dynamics;
namespace {

void exact(double actual, double expected) {
  EXPECT_EQ(0, std::memcmp(&actual, &expected, sizeof(double)));
}

void exactVector(const Eigen::Vector3d &actual, const Eigen::Vector3d &expected) {
  for (int i = 0; i < 3; ++i) exact(actual(i), expected(i));
}

void exactEvaluation(const dyn::Evaluation &a, const dyn::Evaluation &b) {
  EXPECT_EQ(a.valid, b.valid);
  const std::array<double dyn::Evaluation::*, 14> fields{{
      &dyn::Evaluation::density_kgpm3, &dyn::Evaluation::speed_mps,
      &dyn::Evaluation::dynamic_pressure_pa, &dyn::Evaluation::flight_path_angle_rad,
      &dyn::Evaluation::lift_acceleration_mps2, &dyn::Evaluation::load_factor,
      &dyn::Evaluation::lift_coefficient, &dyn::Evaluation::signed_lift_coefficient,
      &dyn::Evaluation::vertical_load_factor, &dyn::Evaluation::drag_coefficient,
      &dyn::Evaluation::drag_n, &dyn::Evaluation::thrust_required_n,
      &dyn::Evaluation::bank_angle_rad, &dyn::Evaluation::bank_cosine}};
  for (auto member : fields) exact(a.*member, b.*member);
}

void exactVerdict(const dyn::HandoffVerdict &a, const dyn::HandoffVerdict &b) {
  EXPECT_EQ(a.reject, b.reject);
  EXPECT_EQ(a.limit, b.limit);
  exact(a.utilization, b.utilization);
  exact(a.speed_mps, b.speed_mps);
  exact(a.flight_path_angle_rad, b.flight_path_angle_rad);
  exactEvaluation(a.evaluation, b.evaluation);
}

TEST(VehicleModel, FixedWingDelegationPreservesEveryNumericalOutput) {
  dyn::Parameters p;
  p.mass_kg = 930.0;
  p.wing_area_m2 = 1.7;
  p.constraint_margin = 0.08;
  const dyn::FixedWingModel model(p);
  ASSERT_TRUE(model.valid());
  // Cruise, climb/turn, low-lift pushover, sub-activation and nonfinite input.
  const std::array<Eigen::Vector3d, 5> velocities{{
      {180, 0, 0}, {135, 20, 65}, {170, 0, 0}, {20, 0, 0},
      {std::numeric_limits<double>::quiet_NaN(), 0, 0}}};
  const std::array<Eigen::Vector3d, 5> accelerations{{
      {0, 0, 0}, {3, 13, 9}, {0, 0, -9.7}, {1, 0, 0}, {0, 0, 0}}};
  const Eigen::Vector3d position(500, -900, 1300);
  for (size_t i = 0; i < velocities.size(); ++i) {
    const auto &v = velocities[i];
    const auto &a = accelerations[i];
    const auto reference = dyn::evaluateInverseDynamics(p, position, v, a);
    const auto actual = model.evaluate(position, v, a);
    exactEvaluation(actual, reference);
    dyn::EnvelopeLimit lhs, rhs;
    exact(model.utilization(actual, &lhs), dyn::envelopeUtilization(p, reference, &rhs));
    EXPECT_EQ(lhs, rhs);
    EXPECT_EQ(model.withinEnvelope(actual), dyn::isWithinEnvelope(p, reference));
    const auto penalty = model.penalty(position, v, a, 2.3);
    const auto expected = dyn::flightEnvelopePenalty(p, position, v, a, 2.3);
    exact(penalty.cost, expected.cost);
    exactVector(penalty.position, expected.position);
    exactVector(penalty.velocity, expected.velocity);
    exactVector(penalty.acceleration, expected.acceleration);
    exactVerdict(model.velocityVerdict(v, 130, 200),
                 dyn::speedConeVerdict(p, v, 130, 200));
    exactVerdict(model.handoffVerdict(position, v, a, 130, 200),
                 dyn::handoffVerdict(p, position, v, a, 130, 200));
  }
  const auto limits = model.limits();
  exact(limits.cruise_floor_mps, dyn::marginBackedSpeedFloorMps(p));
  exact(limits.flight_path_angle_max_rad, p.flight_path_angle_max_rad);
  exact(limits.speed_min_mps, p.speed_min_mps);
  exact(limits.speed_max_mps, p.speed_max_mps);
}

TEST(VehicleModel, GeometryUsesVehicleForcesAndNotOnlySpeedLimits) {
  dyn::Parameters p;
  p.mass_kg = 1;
  p.gravity_mps2 = 10;
  p.wing_area_m2 = 1;
  p.sea_level_density_kgpm3 = 2;
  p.zero_lift_drag_coefficient = 0.25;
  p.induced_drag_factor = 0;
  p.thrust_max_n = 5;
  p.constraint_margin = 0;
  p.flight_path_angle_max_rad = 1;
  const dyn::FixedWingModel model(p);
  const auto geometry = model.planningGeometry(2, 1, 1.5);
  // q=4, D=1, W=10: excess thrust supports sin(gamma)=0.4;
  // acceleration=4, giving (2^2-1^2)/(2*4)=0.375 m.
  exact(geometry.climb_grade, std::tan(std::asin(0.4)));
  exact(geometry.turn_radius_m, 1.5 / (10 * std::sqrt(2.5 * 2.5 - 1)));
  exact(geometry.acceleration_distance_m, 0.375);
  p.thrust_max_n = 1;
  const auto powerless = dyn::FixedWingModel(p).planningGeometry(2, 1, 1.5);
  exact(powerless.climb_grade, 0);
  exact(powerless.acceleration_distance_m, 3);  // existing 0.5 m/s² floor
  p.flight_path_angle_max_rad = 0.1;
  p.thrust_max_n = 50;
  exact(dyn::FixedWingModel(p).planningGeometry(2, 1, 1.5).climb_grade,
        std::tan(0.1));
}

TEST(VehicleModel, OwnedImmutableParametersAndExplicitTransitionCapability) {
  dyn::VehicleModel::Ptr retained;
  {
    dyn::Parameters p;
    p.speed_max_mps = 211;
    retained = std::make_shared<dyn::FixedWingModel>(p);
    p.speed_max_mps = 999;
  }
  exact(retained->limits().speed_max_mps, 211);
  ASSERT_NE(retained->fixedWingTransitionParameters(), nullptr);
  exact(retained->fixedWingTransitionParameters()->speed_max_mps, 211);
  dyn::Evaluation e;
  e.speed_mps = 10;
  e.load_factor = 0.2;
  EXPECT_FALSE(retained->domain(e).active);
  EXPECT_FALSE(retained->domain(e).cruise);
  EXPECT_TRUE(retained->domain(e).low_lift);
  e.speed_mps = 180;
  e.load_factor = 1;
  EXPECT_TRUE(retained->domain(e).active);
  EXPECT_TRUE(retained->domain(e).cruise);
  EXPECT_FALSE(retained->domain(e).low_lift);
  dyn::Parameters invalid;
  invalid.mass_kg = -1;
  EXPECT_FALSE(dyn::FixedWingModel(invalid).valid());
}

}  // namespace

#ifndef MMP_VEHICLE_DYNAMICS__FLIGHT_DYNAMICS_HPP_
#define MMP_VEHICLE_DYNAMICS__FLIGHT_DYNAMICS_HPP_

#include <Eigen/Core>

namespace mmp_vehicle_dynamics
{

// Publicly reproducible point-mass model for a high-subsonic fixed-wing
// vehicle. Geometry and aerodynamic coefficients remain parameters because a
// complete coefficient/thrust/inertia data set is not available publicly.
struct Parameters
{
  double mass_kg = 1300.0;
  double wing_area_m2 = 1.0;
  double gravity_mps2 = 9.80665;
  double sea_level_density_kgpm3 = 1.225;
  double density_scale_height_m = 8500.0;
  double altitude_reference_m = 0.0;

  double zero_lift_drag_coefficient = 0.035;
  double induced_drag_factor = 0.080;
  double lift_coefficient_min = -0.40;
  double lift_coefficient_max = 1.40;
  double load_factor_max = 2.50;
  double thrust_min_n = 0.0;
  double thrust_max_n = 3200.0;
  double speed_min_mps = 120.0;
  double speed_max_mps = 230.0;
  double model_activation_speed_mps = 40.0;
  double dynamic_pressure_max_pa = 45000.0;
  double bank_angle_max_rad = 1.1344640137963142;       // 65 deg
  double flight_path_angle_max_rad = 0.5235987755982988; // 30 deg
  double constraint_margin = 0.02;

  // Relative weights inside the single optimizer dynamics term.
  double penalty_speed = 5.0;
  double penalty_lift = 2.0;
  double penalty_load = 2.0;
  double penalty_thrust = 2.0;
  double penalty_dynamic_pressure = 1.0;
  double penalty_bank = 1.0;
  double penalty_flight_path = 1.0;
};

struct Evaluation
{
  bool valid = false;
  double density_kgpm3 = 0.0;
  double speed_mps = 0.0;
  double dynamic_pressure_pa = 0.0;
  double flight_path_angle_rad = 0.0;
  double lift_acceleration_mps2 = 0.0;
  double load_factor = 0.0;
  double lift_coefficient = 0.0;         // MAGNITUDE, >= 0 (used for the limit)
  // Reporting-only signed CL: lift_coefficient with the sign of the vertical
  // lift component N = L_vec.up, so a pushover (downward lift) prints as
  // negative instead of a spurious positive. Never used in the penalty (a
  // sign(N)*|CL| constraint would be discontinuous at N=0); display/audit only.
  double signed_lift_coefficient = 0.0;
  double vertical_load_factor = 0.0;     // n_z = N/g0 (reporting; sign of lift)
  double drag_coefficient = 0.0;
  double drag_n = 0.0;
  double thrust_required_n = 0.0;
  double bank_angle_rad = 0.0;
  double bank_cosine = 1.0;
};

struct CostGradient
{
  double cost = 0.0;
  Eigen::Vector3d position = Eigen::Vector3d::Zero();
  Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
  Eigen::Vector3d acceleration = Eigen::Vector3d::Zero();
};

enum class EnvelopeLimit
{
  None,
  MinimumSpeed,
  MaximumSpeed,
  LiftCoefficient,
  LoadFactor,
  MinimumThrust,
  MaximumThrust,
  DynamicPressure,
  BankAngle,
  FlightPathAngle
};

bool parametersAreValid(const Parameters &p);

double airDensity(const Parameters &p, double altitude_m);

Evaluation evaluateInverseDynamics(
    const Parameters &p,
    const Eigen::Vector3d &position_m,
    const Eigen::Vector3d &velocity_mps,
    const Eigen::Vector3d &acceleration_mps2);

// Smooth flight-envelope penalty and exact first derivatives with respect to
// physical position [m], velocity [m/s], and acceleration [m/s^2].
// [BANK-GATE] Bank readings need meaningful lift. A coordinated turn obeys
// n = 1/cos(phi) >= 1 whenever it banks at all, so above this load factor
// the raw angle-vs-limit ratio is trustworthy. Below it the raw direction is
// dominated by noise (observed: acos of a near-zero lift vector reported
// "bank 177 deg, 272% utilization" on a benign zero-g pushover arc), so the
// audit metrics switch domains:
//   L/g >= kBankMeaningfulLoadFactor  -> raw angle / limit (unchanged)
//   n_z <  kBankNegativeNz            -> cone-consistent measure (the
//        penalty's force-space bank cone in g units) — genuine inverted-lift
//        pushovers stay flagged, matching flightEnvelopePenalty which fires
//        for every N < 0
//   otherwise                          -> skipped (near-zero-lift noise band)
// The PENALTY itself needs no gate: its cone (cphi*L*w - N) vanishes with L.
constexpr double kBankMeaningfulLoadFactor = 0.5;
constexpr double kBankNegativeNz = -0.1;

CostGradient flightEnvelopePenalty(
    const Parameters &p,
    const Eigen::Vector3d &position_m,
    const Eigen::Vector3d &velocity_mps,
    const Eigen::Vector3d &acceleration_mps2,
    double outer_weight);

// Raw (unmargined) envelope audit helpers used by logs and RViz.
double envelopeUtilization(
    const Parameters &p,
    const Evaluation &evaluation,
    EnvelopeLimit *limiting = nullptr);

bool isWithinEnvelope(const Parameters &p, const Evaluation &evaluation);

const char *envelopeLimitName(EnvelopeLimit limit);

// ─── Handoff suitability ────────────────────────────────────────────────
// The single definition of "can the cruise chain fly this exact state".
// PathManager::stateEnvelopeProblem / pvaEnvelopeProblem resolve the two
// ROS-parameterised scalars (floor, ceiling) and phrase the refusal in their
// own vocabulary, but the JUDGEMENT lives here so that off-line harnesses
// cannot drift from the production gate by re-deriving it.
//
// Why this is not "envelopeUtilization() <= 1.0": below
// model_activation_speed_mps the utilization is defined to be 0.0 while
// isWithinEnvelope is false. A caller comparing utilization alone certifies
// every sub-activation state.
enum class HandoffReject
{
  None,
  NonFinitePosition,
  NonFiniteVelocity,
  NonFiniteAcceleration,
  SpeedBelowFloor,
  SpeedAboveMaximum,
  FlightPathOutsideCone,
  InverseDynamicsUndefined,
  EnvelopeExceeded
};

struct HandoffVerdict
{
  HandoffReject reject = HandoffReject::None;
  // Meaningful only when reject == EnvelopeExceeded.
  EnvelopeLimit limit = EnvelopeLimit::None;
  double utilization = 0.0;
  double speed_mps = 0.0;
  double flight_path_angle_rad = 0.0;   // magnitude, as the cone is tested
  Evaluation evaluation{};
  bool ok() const { return reject == HandoffReject::None; }
};

// [SPEED-BOUNDARY] Commanding exactly the floor or the cap must pass whatever
// the direction: the planner's unit round trip puts some directions a few
// times 1e-14 m/s off. Mirrored by PathManager's static helpers of the same
// name, which this replaces as the definition.
constexpr double kSpeedBoundaryEpsMps = 1e-6;

inline bool belowSpeedBoundary(double v_mps, double floor_mps)
{
  return v_mps < floor_mps - kSpeedBoundaryEpsMps;
}

inline bool aboveSpeedBoundary(double v_mps, double ceiling_mps)
{
  return v_mps > ceiling_mps + kSpeedBoundaryEpsMps;
}

// The drag polar, as ONE definition. A 6DOF segment that means to hand over
// to this model must burn the same polar: with zero drag in the 6DOF and
// CD0 = 0.035 in here, the mid-phase model has to supply the 6DOF's tangential
// acceleration AND its own drag, so it demands more thrust than the 6DOF ever
// applied (measured on the v0 handoff: 3752.1 N against a 3200 N limit, of
// which 551 N was exactly this term).
double dragCoefficient(const Parameters &p, double lift_coefficient);

// speed_min_mps with constraint_margin applied — the cruise floor a handoff
// must clear. Formed here once; PolyTrajOptimizer divides it by its frame
// unit rather than restating the product.
double marginBackedSpeedFloorMps(const Parameters &p);

// Velocity-only half: finiteness, the two speed boundaries, the validity cone.
HandoffVerdict speedConeVerdict(
    const Parameters &p,
    const Eigen::Vector3d &velocity_mps,
    double floor_mps,
    double maximum_mps);

// Full PVA: the velocity half, then inverse dynamics and the flight envelope.
// Finiteness of every component is judged BEFORE anything else, so a caller
// cannot certify a NaN by short-circuiting.
HandoffVerdict handoffVerdict(
    const Parameters &p,
    const Eigen::Vector3d &position_m,
    const Eigen::Vector3d &velocity_mps,
    const Eigen::Vector3d &acceleration_mps2,
    double floor_mps,
    double maximum_mps);

const char *handoffRejectName(HandoffReject reject);

}  // namespace mmp_vehicle_dynamics

#endif  // MMP_VEHICLE_DYNAMICS__FLIGHT_DYNAMICS_HPP_

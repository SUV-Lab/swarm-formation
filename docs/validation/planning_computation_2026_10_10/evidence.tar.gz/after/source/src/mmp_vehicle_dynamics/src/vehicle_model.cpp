#include "mmp_vehicle_dynamics/vehicle_model.hpp"

#include <algorithm>
#include <cmath>

namespace mmp_vehicle_dynamics {

FixedWingModel::FixedWingModel(Parameters parameters) : parameters_(parameters) {}

bool FixedWingModel::valid() const { return parametersAreValid(parameters_); }

VehicleLimits FixedWingModel::limits() const {
  return {parameters_.speed_min_mps, parameters_.speed_max_mps,
          parameters_.model_activation_speed_mps,
          marginBackedSpeedFloorMps(parameters_),
          parameters_.flight_path_angle_max_rad, parameters_.load_factor_max};
}

Evaluation FixedWingModel::evaluate(const Eigen::Vector3d &p,
                                    const Eigen::Vector3d &v,
                                    const Eigen::Vector3d &a) const {
  return evaluateInverseDynamics(parameters_, p, v, a);
}

CostGradient FixedWingModel::penalty(const Eigen::Vector3d &p,
                                     const Eigen::Vector3d &v,
                                     const Eigen::Vector3d &a,
                                     double weight) const {
  return flightEnvelopePenalty(parameters_, p, v, a, weight);
}

EnvelopeDomain FixedWingModel::domain(const Evaluation &e) const {
  return {e.speed_mps >= parameters_.model_activation_speed_mps,
          e.speed_mps >= parameters_.speed_min_mps,
          e.load_factor < kBankMeaningfulLoadFactor};
}

double FixedWingModel::utilization(const Evaluation &e,
                                   EnvelopeLimit *limiting) const {
  return envelopeUtilization(parameters_, e, limiting);
}

bool FixedWingModel::withinEnvelope(const Evaluation &e) const {
  return isWithinEnvelope(parameters_, e);
}

HandoffVerdict FixedWingModel::velocityVerdict(const Eigen::Vector3d &v,
                                              double floor,
                                              double maximum) const {
  return speedConeVerdict(parameters_, v, floor, maximum);
}

HandoffVerdict FixedWingModel::handoffVerdict(const Eigen::Vector3d &p,
                                             const Eigen::Vector3d &v,
                                             const Eigen::Vector3d &a,
                                             double floor,
                                             double maximum) const {
  return mmp_vehicle_dynamics::handoffVerdict(parameters_, p, v, a, floor, maximum);
}

PlanningGeometry FixedWingModel::planningGeometry(double cruise_speed,
                                                   double initial_speed,
                                                   double turn_margin) const {
  const auto &p = parameters_;
  // Preserve the coordinator's original expression and evaluation order.
  const double q = 0.5 * airDensity(p, 0.0) * cruise_speed * cruise_speed;
  const double W = p.mass_kg * p.gravity_mps2;
  const double CL = W / std::max(1e-9, q * p.wing_area_m2);
  const double D = (p.zero_lift_drag_coefficient + p.induced_drag_factor * CL * CL) *
                   q * p.wing_area_m2;
  const double sg = std::max(
      0.0, std::min(1.0, (p.thrust_max_n * (1.0 - p.constraint_margin) - D) / W));
  const double nmax = std::max(1.01, p.load_factor_max);
  const double a_avail = std::max(
      0.5, (p.thrust_max_n * (1.0 - p.constraint_margin) - D) / p.mass_kg);
  return {std::min(std::tan(p.flight_path_angle_max_rad), std::tan(std::asin(sg))),
          turn_margin * initial_speed * initial_speed /
              (p.gravity_mps2 * std::sqrt(nmax * nmax - 1.0)),
          std::max(0.0, (cruise_speed * cruise_speed - initial_speed * initial_speed) /
                            (2.0 * a_avail))};
}

}  // namespace mmp_vehicle_dynamics

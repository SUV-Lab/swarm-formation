// Python bindings for the shared fixed-wing model.
//
// Purpose: mmp_vehicle_dynamics is THE model authority — the optimizer's
// dynamics cost term and the metrics panel already evaluate through it, and
// the (Python) dynamics_sim follower must judge trajectories with the SAME
// numbers. Binding the compiled library instead of hand-porting the math
// means there is nothing to keep in sync: Python calls the exact code the
// optimizer ran.
//
// Units are SI throughout (m, m/s, m/s^2, N, Pa, rad) — the planner frame's
// 1 unit = 100 m conversion is the CALLER's job, same contract as the C++
// consumers.

#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>

#include "mmp_vehicle_dynamics/flight_dynamics.hpp"

namespace py = pybind11;
namespace md = mmp_vehicle_dynamics;

PYBIND11_MODULE(_flight_dynamics, m)
{
  m.doc() = "Shared MMP fixed-wing point-mass model (SI units)";

  py::enum_<md::EnvelopeLimit>(m, "EnvelopeLimit")
      .value("NONE", md::EnvelopeLimit::None)
      .value("MINIMUM_SPEED", md::EnvelopeLimit::MinimumSpeed)
      .value("MAXIMUM_SPEED", md::EnvelopeLimit::MaximumSpeed)
      .value("LIFT_COEFFICIENT", md::EnvelopeLimit::LiftCoefficient)
      .value("LOAD_FACTOR", md::EnvelopeLimit::LoadFactor)
      .value("MINIMUM_THRUST", md::EnvelopeLimit::MinimumThrust)
      .value("MAXIMUM_THRUST", md::EnvelopeLimit::MaximumThrust)
      .value("DYNAMIC_PRESSURE", md::EnvelopeLimit::DynamicPressure)
      .value("BANK_ANGLE", md::EnvelopeLimit::BankAngle)
      .value("FLIGHT_PATH_ANGLE", md::EnvelopeLimit::FlightPathAngle);

  py::class_<md::Parameters>(m, "Parameters")
      .def(py::init<>())
      .def_readwrite("mass_kg", &md::Parameters::mass_kg)
      .def_readwrite("wing_area_m2", &md::Parameters::wing_area_m2)
      .def_readwrite("gravity_mps2", &md::Parameters::gravity_mps2)
      .def_readwrite("sea_level_density_kgpm3",
                     &md::Parameters::sea_level_density_kgpm3)
      .def_readwrite("density_scale_height_m",
                     &md::Parameters::density_scale_height_m)
      .def_readwrite("altitude_reference_m",
                     &md::Parameters::altitude_reference_m)
      .def_readwrite("zero_lift_drag_coefficient",
                     &md::Parameters::zero_lift_drag_coefficient)
      .def_readwrite("induced_drag_factor",
                     &md::Parameters::induced_drag_factor)
      .def_readwrite("lift_coefficient_min",
                     &md::Parameters::lift_coefficient_min)
      .def_readwrite("lift_coefficient_max",
                     &md::Parameters::lift_coefficient_max)
      .def_readwrite("load_factor_max", &md::Parameters::load_factor_max)
      .def_readwrite("thrust_min_n", &md::Parameters::thrust_min_n)
      .def_readwrite("thrust_max_n", &md::Parameters::thrust_max_n)
      .def_readwrite("speed_min_mps", &md::Parameters::speed_min_mps)
      .def_readwrite("speed_max_mps", &md::Parameters::speed_max_mps)
      .def_readwrite("model_activation_speed_mps",
                     &md::Parameters::model_activation_speed_mps)
      .def_readwrite("dynamic_pressure_max_pa",
                     &md::Parameters::dynamic_pressure_max_pa)
      .def_readwrite("bank_angle_max_rad", &md::Parameters::bank_angle_max_rad)
      .def_readwrite("flight_path_angle_max_rad",
                     &md::Parameters::flight_path_angle_max_rad)
      .def_readwrite("constraint_margin", &md::Parameters::constraint_margin)
      .def_readwrite("penalty_speed", &md::Parameters::penalty_speed)
      .def_readwrite("penalty_lift", &md::Parameters::penalty_lift)
      .def_readwrite("penalty_load", &md::Parameters::penalty_load)
      .def_readwrite("penalty_thrust", &md::Parameters::penalty_thrust)
      .def_readwrite("penalty_dynamic_pressure",
                     &md::Parameters::penalty_dynamic_pressure)
      .def_readwrite("penalty_bank", &md::Parameters::penalty_bank)
      .def_readwrite("penalty_flight_path",
                     &md::Parameters::penalty_flight_path);

  py::class_<md::Evaluation>(m, "Evaluation")
      .def(py::init<>())
      .def_readonly("valid", &md::Evaluation::valid)
      .def_readonly("density_kgpm3", &md::Evaluation::density_kgpm3)
      .def_readonly("speed_mps", &md::Evaluation::speed_mps)
      .def_readonly("dynamic_pressure_pa", &md::Evaluation::dynamic_pressure_pa)
      .def_readonly("flight_path_angle_rad",
                    &md::Evaluation::flight_path_angle_rad)
      .def_readonly("lift_acceleration_mps2",
                    &md::Evaluation::lift_acceleration_mps2)
      .def_readonly("load_factor", &md::Evaluation::load_factor)
      .def_readonly("lift_coefficient", &md::Evaluation::lift_coefficient)
      .def_readonly("signed_lift_coefficient",
                    &md::Evaluation::signed_lift_coefficient)
      .def_readonly("vertical_load_factor",
                    &md::Evaluation::vertical_load_factor)
      .def_readonly("drag_coefficient", &md::Evaluation::drag_coefficient)
      .def_readonly("drag_n", &md::Evaluation::drag_n)
      .def_readonly("thrust_required_n", &md::Evaluation::thrust_required_n)
      .def_readonly("bank_angle_rad", &md::Evaluation::bank_angle_rad)
      .def_readonly("bank_cosine", &md::Evaluation::bank_cosine);

  py::class_<md::CostGradient>(m, "CostGradient")
      .def(py::init<>())
      .def_readonly("cost", &md::CostGradient::cost)
      .def_readonly("position", &md::CostGradient::position)
      .def_readonly("velocity", &md::CostGradient::velocity)
      .def_readonly("acceleration", &md::CostGradient::acceleration);

  // [BANK-GATE] audit-domain constants (see the header comment).
  m.attr("BANK_MEANINGFUL_LOAD_FACTOR") = md::kBankMeaningfulLoadFactor;
  m.attr("BANK_NEGATIVE_NZ") = md::kBankNegativeNz;

  m.def("parameters_are_valid", &md::parametersAreValid, py::arg("params"));
  m.def("air_density", &md::airDensity,
        py::arg("params"), py::arg("altitude_m"));
  m.def("evaluate_inverse_dynamics", &md::evaluateInverseDynamics,
        py::arg("params"), py::arg("position_m"), py::arg("velocity_mps"),
        py::arg("acceleration_mps2"),
        "Trajectory state -> required lift/thrust/bank (the optimizer's view)");
  m.def("flight_envelope_penalty", &md::flightEnvelopePenalty,
        py::arg("params"), py::arg("position_m"), py::arg("velocity_mps"),
        py::arg("acceleration_mps2"), py::arg("outer_weight"),
        "Smooth envelope penalty + exact gradients (SI)");
  m.def("envelope_utilization",
        [](const md::Parameters &p, const md::Evaluation &e) {
          md::EnvelopeLimit limiting = md::EnvelopeLimit::None;
          const double u = md::envelopeUtilization(p, e, &limiting);
          return py::make_tuple(u, limiting);
        },
        py::arg("params"), py::arg("evaluation"),
        "-> (utilization, limiting EnvelopeLimit)");
  m.def("is_within_envelope", &md::isWithinEnvelope,
        py::arg("params"), py::arg("evaluation"));
  m.def("envelope_limit_name", &md::envelopeLimitName, py::arg("limit"));
}

#include "mmp_vehicle_dynamics/flight_dynamics.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace mmp_vehicle_dynamics
{
namespace
{

constexpr double kEps = 1.0e-9;

struct Differential
{
  double value = 0.0;
  Eigen::Vector3d dp = Eigen::Vector3d::Zero();
  Eigen::Vector3d dv = Eigen::Vector3d::Zero();
  Eigen::Vector3d da = Eigen::Vector3d::Zero();
};

struct ModelDifferentials
{
  Evaluation evaluation;
  Differential speed;
  Differential dynamic_pressure;
  Differential lift_acceleration;
  Differential load_factor;
  Differential lift_coefficient;
  Differential thrust;
  // Force-space cone ingredients for the bank limit (see the penalty):
  //   lw      = L * w           (lift magnitude x |projected up|)
  //   lift_up = N = L_vec . up  (vertical lift component)
  // The bank constraint  angle(L_vec, up_perp) <= phi_max  is EXACTLY
  //   c * L * w - N <= 0   with  c = cos(phi_max)   (for L > 0, w > 0),
  // and this form needs NO division by the vanishing magnitudes L or w —
  // the old bank_cos = N/(L*w) formulation is ill-posed at zero lift
  // (pushover: the direction of a vanishing force is physically
  // unobservable) and its gradients blew up as 1/L^2 (measured 2.1e4 at
  // L = 0.05 m/s^2). Both singular sets now make the violation itself
  // vanish (|c*L*w - N| <= (1+c)*L*w), i.e. the constraint becomes
  // vacuous exactly where the physics says any bank is admissible.
  Differential lw;
  Differential lift_up;
  // [Q-FLOOR] The regularised squared speed and its derivative w.r.t. the TRUE
  // squared speed. speed2_eff = smoothFloor(|v|^2, speed_min^2), so
  //   |v| >= speed_min*sqrt(1+kBlend) : speed2_eff == |v|^2, speed2_grad == 1
  //                      -> IDENTICAL to the unregularised model, exactly
  //                      (not approximately).
  //   speed_min < |v| < that          : inside the C^1 blend. speed2_eff lies
  //                      strictly between speed_min^2 and |v|^2 — SMALLER than
  //                      the true squared speed — so CL and the drag polar
  //                      divide by a smaller q and read slightly HIGH.
  //   |v| <= speed_min                : pinned at speed_min^2, speed2_grad = 0.
  // The old wording said the cruise regime began at speed_min. It does not:
  // smoothFloor returns x exactly only from floor*(1+kBlend), which in speed
  // is speed_min*sqrt(1.05).
  // The flight-path hinge builds its own violation and needs both.
  double speed2_eff = 0.0;
  double speed2_grad = 1.0;
};

// Clamp bounds widened to [-10 km, +60 km] relative altitude. The value was
// clamped for numerical safety but the derivative is gated by a STRICT
// inequality, so at the clamp plane the z-gradient jumps finite->0 (C^0, not
// C^1) — an L-BFGS line-search hazard the moment altitude_reference_m is set to
// a positive mission datum (all configs currently leave it 0, so the old
// [-1km,+20km] planes sat at -1000 m MSL / +20 km, unreachable; this makes the
// "globally C^1" claim in README.md hold unconditionally at negligible cost).
double clampedDensity(const Parameters &p, double altitude_m, double *drho_dh)
{
  const double relative_h = altitude_m - p.altitude_reference_m;
  const double bounded_h = std::max(-10000.0, std::min(relative_h, 60000.0));
  const double rho = p.sea_level_density_kgpm3 *
      std::exp(-bounded_h / p.density_scale_height_m);
  if (drho_dh != nullptr) {
    *drho_dh = (relative_h > -10000.0 && relative_h < 60000.0)
        ? -rho / p.density_scale_height_m : 0.0;
  }
  return rho;
}

// [Q-FLOOR] C^1 smooth floor. Returns m >= floor, with m == x EXACTLY once
// x >= floor*(1 + kBlend) and m == floor exactly for x <= floor; dm/dx is
// correspondingly exactly 1 and exactly 0 in those two regimes. Every quantity
// built on it therefore degenerates to the unregularised formula above the
// floor, and to a CONSTANT (zero velocity-gradient) below it.
//
// WHY THIS EXISTS — the root fix for the activation-ramp barrier.
//
// The inverse model is singular as |v| -> 0: CL = (m/S)L/q and the induced
// drag both go as 1/q ~ 1/|v|^2. The previous code papered over that with a
// multiplicative speed gate sigma(|v|) ramping the whole force-space penalty in
// over [activation_speed, speed_min]. That gate CANNOT work, and no choice of
// gate shape or activation speed fixes it: the cost is sigma(V)*h(viol), so
//     d(cost)/dV = sigma'(V)*h + sigma(V)*h'(V)
// and below stall h is enormous (level flight at 60 m/s needs CL = 5.8 against
// a 1.29 limit), so sigma'*h dominates and the cost RISES with speed — a
// DECELERATING force in exactly the regime the term exists to fix. Measured on
// the shipped code: +1.5e3 at 48 m/s level, +1.2e4 at 70 m/s during initial
// acceleration;
// narrowing the ramp only makes sigma' larger and the barrier worse. On a
// rest-start mission it cost the optimiser convergence outright (20 iterations
// without the term; 2290 and still not converged with it).
//
// So do not gate the singularity — REMOVE it. Evaluating the aerodynamics at no
// less than speed_min bounds CL and the drag, which lets sigma be deleted
// entirely, and with it the barrier. Below the floor the aero quantities are
// constant in |v|, so the force hinges contribute NO longitudinal velocity
// gradient; the (ungated, unchanged) minimum-speed hinge is left to own the
// "you are too slow" push — the only physically meaningful statement available
// down there.
//
// The TANGENT is deliberately NOT regularised. Softening it to v/s_eff was
// tried and is WRONG: it makes u_t = (v.u)/s_eff grow with |v|, manufacturing a
// brand-new decelerating gradient (measured +1.0e4 at V = 120, a_t = 50). With
// the true unit tangent, L_vec _|_ t holds exactly, so the thrust hinge's
// LONGITUDINAL gradient is identically zero and no barrier can form; its 1/|v|
// sensitivity is purely LATERAL (a turning stiffness), which is real physics.
double smoothFloor(double x, double floor_value, double *dm_dx)
{
  constexpr double kBlend = 0.05;                        // blend over [f, 1.05f]
  const double width = kBlend * floor_value;
  if (width <= 0.0 || x >= floor_value + width) {
    if (dm_dx != nullptr) *dm_dx = 1.0;
    return x;
  }
  if (x <= floor_value) {
    if (dm_dx != nullptr) *dm_dx = 0.0;
    return floor_value;
  }
  const double s = (x - floor_value) / width;
  const double shape = s * s * (3.0 - 2.0 * s);          // C^1: 0 and 1 at ends
  const double dshape = 6.0 * s * (1.0 - s) / width;     // 0 at both ends
  if (dm_dx != nullptr) *dm_dx = shape + (x - floor_value) * dshape;
  return floor_value + (x - floor_value) * shape;
}

// want_diff=false computes VALUES only (Evaluation + Differential.value) and
// skips every derivative assignment — the derivative algebra is ~2/3 of the
// cost and is only needed when some hinge is actually active (rare on a
// feasible cruise trajectory). Values are bit-identical between modes.
ModelDifferentials evaluateWithDifferentials(
    const Parameters &p,
    const Eigen::Vector3d &position,
    const Eigen::Vector3d &velocity,
    const Eigen::Vector3d &acceleration,
    bool want_diff)
{
  ModelDifferentials out;
  Evaluation &e = out.evaluation;

  const double speed = velocity.norm();
  e.speed_mps = speed;
  out.speed.value = speed;
  if (speed > kEps && want_diff) {
    out.speed.dv = velocity / speed;
  }

  double drho_dz = 0.0;
  e.density_kgpm3 = clampedDensity(p, position.z(), &drho_dz);

  // TRUE dynamic pressure — what the vehicle actually sees. Reported to the
  // panel/audit and used by the dynamic-pressure hinge. Unchanged.
  e.dynamic_pressure_pa = 0.5 * e.density_kgpm3 * speed * speed;
  out.dynamic_pressure.value = e.dynamic_pressure_pa;
  if (want_diff) {
    out.dynamic_pressure.dp.z() = 0.5 * speed * speed * drho_dz;
    out.dynamic_pressure.dv = e.density_kgpm3 * velocity;
  }

  // [Q-FLOOR] EFFECTIVE dynamic pressure — the same thing evaluated at no less
  // than speed_min, so CL and the drag polar can never blow up as 1/|v|^2.
  // IDENTICAL to the true q from |v| >= speed_min*sqrt(1+kBlend), not from
  // speed_min: between the two it is the blend value, above speed2_grad == 1.
  // out.dynamic_pressure below is the TRUE q and is never floored — the two
  // fields are different quantities and only one of them carries the floor.
  double mp = 1.0;
  const double speed2_eff = smoothFloor(speed * speed,
                                        p.speed_min_mps * p.speed_min_mps, &mp);
  out.speed2_eff = speed2_eff;
  out.speed2_grad = mp;
  const double q_eff = 0.5 * e.density_kgpm3 * speed2_eff;
  const Eigen::Vector3d dq_eff_dv = e.density_kgpm3 * mp * velocity;
  const double dq_eff_dz = 0.5 * speed2_eff * drho_dz;

  if (speed <= kEps) {
    return out;
  }

  const Eigen::Vector3d tangent = velocity / speed;
  const Eigen::Vector3d gravity(0.0, 0.0, -p.gravity_mps2);
  const Eigen::Vector3d required_specific_force = acceleration - gravity;
  const double tangent_force = tangent.dot(required_specific_force);
  const Eigen::Vector3d lift_accel_vector =
      required_specific_force - tangent_force * tangent;
  const double lift_accel = lift_accel_vector.norm();

  // d[(t dot u)]/dv and d[(t dot u)]/da.
  const Eigen::Vector3d dtangent_force_dv = lift_accel_vector / speed;
  const Eigen::Vector3d dtangent_force_da = tangent;

  out.lift_acceleration.value = lift_accel;
  if (lift_accel > kEps && want_diff) {
    out.lift_acceleration.da = lift_accel_vector / lift_accel;
    out.lift_acceleration.dv =
        -tangent_force * lift_accel_vector / (lift_accel * speed);
  }

  e.lift_acceleration_mps2 = lift_accel;
  e.load_factor = lift_accel / p.gravity_mps2;
  out.load_factor.value = e.load_factor;
  if (want_diff) {
    out.load_factor.dv = out.lift_acceleration.dv / p.gravity_mps2;
    out.load_factor.da = out.lift_acceleration.da / p.gravity_mps2;
  }

  // [Q-FLOOR] CL and the drag polar divide by the FLOORED q. From
  // |v| >= speed_min*sqrt(1+kBlend) q_eff == the true q and every line below is
  // bit-identical to the old model; inside the blend q_eff < the true q, so
  // the reported CL is HIGH by the true/effective ratio (measured worst case
  // about +1.3 %, which is enough to flip isWithinEnvelope near the limit).
  const double lift_scale = p.mass_kg / p.wing_area_m2;
  e.lift_coefficient = lift_scale * lift_accel / q_eff;
  out.lift_coefficient.value = e.lift_coefficient;
  if (want_diff) {
    const double dcl_dl = lift_scale / q_eff;
    const double dcl_dq = -e.lift_coefficient / q_eff;
    out.lift_coefficient.dp.z() = dcl_dq * dq_eff_dz;
    out.lift_coefficient.dv =
        dcl_dl * out.lift_acceleration.dv + dcl_dq * dq_eff_dv;
    out.lift_coefficient.da = dcl_dl * out.lift_acceleration.da;
  }

  e.drag_coefficient = dragCoefficient(p, e.lift_coefficient);
  e.drag_n = q_eff * p.wing_area_m2 * e.drag_coefficient;
  e.thrust_required_n = e.drag_n + p.mass_kg * tangent_force;
  out.thrust.value = e.thrust_required_n;
  if (want_diff) {
    const double ddrag_dq = p.wing_area_m2 *
        (p.zero_lift_drag_coefficient -
         p.induced_drag_factor * e.lift_coefficient * e.lift_coefficient);
    const double ddrag_dl = 2.0 * p.induced_drag_factor * p.mass_kg *
        e.lift_coefficient;
    out.thrust.dp.z() = ddrag_dq * dq_eff_dz;
    out.thrust.dv = ddrag_dq * dq_eff_dv +
        ddrag_dl * out.lift_acceleration.dv +
        p.mass_kg * dtangent_force_dv;
    out.thrust.da = ddrag_dl * out.lift_acceleration.da +
        p.mass_kg * dtangent_force_da;
  }

  // Flight-path angle: VALUE ONLY (for the raw-envelope audit/panel). The
  // asin/1/cos(gamma) differential was the sibling of the bank blowup — it
  // diverges as gamma -> +-90 deg and its guard hard-cut the gradient to
  // zero (finite-to-zero jump). The PENALTY now constrains the equivalent
  // velocity-component ratio  (v_z / (s*sin(gamma_max)))^2 <= 1  directly
  // (exact equivalence: asin is monotone), so no angle derivative is needed
  // anywhere in the gradient chain.
  const double sin_gamma = std::max(-1.0, std::min(1.0, tangent.z()));
  e.flight_path_angle_rad = std::asin(sin_gamma);

  // Bank: keep the ANGLE as value-only for the audit/panel; feed the PENALTY
  // with the force-space cone ingredients (no division — see the struct
  // comment). dw_dv looks like it divides by w, but |up_normal| = w cancels:
  // ||dw_dv|| = |t_z|/s, bounded.
  const Eigen::Vector3d up(0.0, 0.0, 1.0);
  const double up_tangent = up.dot(tangent);
  const Eigen::Vector3d up_normal = up - up_tangent * tangent;
  const double up_normal_norm = up_normal.norm();
  const double lift_up = lift_accel_vector.dot(up);  // N = (L_vec)_z

  // Reporting-only signed quantities (value path; never differentiated). The
  // limit uses |CL|; these just give the operator/audit the physical SIGN of
  // the lift so a pushover reads negative instead of a spurious positive.
  e.signed_lift_coefficient =
      (lift_up >= 0.0) ? e.lift_coefficient : -e.lift_coefficient;
  e.vertical_load_factor = lift_up / p.gravity_mps2;

  // Audit-only angle (guarded; never differentiated).
  if (lift_accel > kEps && up_normal_norm > 1.0e-7) {
    double bank_cos = lift_up / (lift_accel * up_normal_norm);
    bank_cos = std::max(-1.0, std::min(1.0, bank_cos));
    e.bank_cosine = bank_cos;
    e.bank_angle_rad = std::acos(bank_cos);
  } else {
    e.bank_cosine = 1.0;
    e.bank_angle_rad = 0.0;
  }

  // Cone ingredients with exact differentials (all bounded):
  //   d(N)/da = P*up = up_normal          (dL_vec/da = P)
  //   d(N)/dv = -(t_z * L_vec + u_t * up_normal) / s
  //   d(L*w)/da = w * dL/da ;  d(L*w)/dv = w * dL/dv + L * dw/dv
  out.lift_up.value = lift_up;
  out.lw.value = lift_accel * up_normal_norm;
  if (want_diff) {
    out.lift_up.da = up_normal;
    out.lift_up.dv =
        -(up_tangent * lift_accel_vector + tangent_force * up_normal) / speed;

    out.lw.da = up_normal_norm * out.lift_acceleration.da;
    Eigen::Vector3d dw_dv = Eigen::Vector3d::Zero();
    if (up_normal_norm > 1.0e-7) {
      dw_dv = -(up_tangent / up_normal_norm) * (up_normal / speed);
    }
    out.lw.dv = up_normal_norm * out.lift_acceleration.dv +
        lift_accel * dw_dv;
  }

  e.valid = std::isfinite(e.lift_coefficient) &&
      std::isfinite(e.thrust_required_n) &&
      std::isfinite(e.bank_angle_rad);
  return out;
}

void hingeShape(double violation, double *shape, double *derivative)
{
  if (violation <= 0.0) {
    *shape = 0.0;
    *derivative = 0.0;
  } else if (violation <= 1.0) {
    *shape = violation * violation * violation;
    *derivative = 3.0 * violation * violation;
  } else {
    *shape = 3.0 * violation - 2.0;
    *derivative = 3.0;
  }
}

// [Q-FLOOR] No activation factor. The old signature carried (activation,
// dactivation_dv) and added `shape * dactivation_dv` to the velocity gradient —
// that term IS the decelerating barrier (see smoothFloor). With the floored q
// the force hinges are bounded and longitudinally flat below stall, so the gate
// is gone and this reduces to the plain weighted hinge.
void addPenalty(
    double violation,
    const Eigen::Vector3d &df_dp,
    const Eigen::Vector3d &df_dv,
    const Eigen::Vector3d &df_da,
    double relative_weight,
    double outer_weight,
    CostGradient *out)
{
  double shape = 0.0;
  double dshape = 0.0;
  hingeShape(violation, &shape, &dshape);
  if (shape <= 0.0 || relative_weight <= 0.0) {
    return;
  }
  const double scale = outer_weight * relative_weight;
  out->cost += scale * shape;
  out->position += scale * dshape * df_dp;
  out->velocity += scale * dshape * df_dv;
  out->acceleration += scale * dshape * df_da;
}

}  // namespace

bool parametersAreValid(const Parameters &p)
{
  return p.mass_kg > 0.0 && p.wing_area_m2 > 0.0 &&
      p.gravity_mps2 > 0.0 && p.sea_level_density_kgpm3 > 0.0 &&
      p.density_scale_height_m > 0.0 &&
      p.zero_lift_drag_coefficient >= 0.0 &&
      p.induced_drag_factor >= 0.0 &&
      p.lift_coefficient_max > 0.0 &&
      p.load_factor_max > 0.0 && p.thrust_max_n > p.thrust_min_n &&
      p.speed_min_mps > p.model_activation_speed_mps &&
      p.speed_max_mps > p.speed_min_mps &&
      p.dynamic_pressure_max_pa > 0.0 &&
      p.bank_angle_max_rad > 0.0 && p.bank_angle_max_rad < M_PI &&
      p.flight_path_angle_max_rad > 0.0 &&
      p.flight_path_angle_max_rad < 0.5 * M_PI &&
      p.constraint_margin >= 0.0 && p.constraint_margin < 0.25;
}

double airDensity(const Parameters &p, double altitude_m)
{
  return clampedDensity(p, altitude_m, nullptr);
}

Evaluation evaluateInverseDynamics(
    const Parameters &p,
    const Eigen::Vector3d &position_m,
    const Eigen::Vector3d &velocity_mps,
    const Eigen::Vector3d &acceleration_mps2)
{
  return evaluateWithDifferentials(p, position_m, velocity_mps,
                                   acceleration_mps2,
                                   /*want_diff=*/false).evaluation;
}

CostGradient flightEnvelopePenalty(
    const Parameters &p,
    const Eigen::Vector3d &position,
    const Eigen::Vector3d &velocity,
    const Eigen::Vector3d &acceleration,
    double outer_weight)
{
  CostGradient out;
  if (outer_weight <= 0.0 || !parametersAreValid(p)) {
    return out;
  }

  // TWO-PHASE evaluation: the derivative algebra is ~2/3 of the model cost
  // but is needed only when some hinge is ACTIVE — on a feasible cruise
  // trajectory that is a fraction of a percent of the samples. Phase 1
  // computes values only, decides which hinges fire, and returns zero
  // without any derivative work when none do; phase 2 recomputes with
  // differentials (values are bit-identical between modes) and assembles
  // the exact same penalties as before. Violation formulas appear ONCE
  // below and are shared by the phase-1 check and the phase-2 penalties.
  ModelDifferentials m =
      evaluateWithDifferentials(p, position, velocity, acceleration,
                                /*want_diff=*/false);
  const double margin = p.constraint_margin;

  // ---- limits (margin-backed) and VIOLATION VALUES: the single source ----
  const double vmin = p.speed_min_mps * (1.0 + margin);
  const double vmax = p.speed_max_mps * (1.0 - margin);
  const double qmax = p.dynamic_pressure_max_pa * (1.0 - margin);
  const double clmax = p.lift_coefficient_max * (1.0 - margin);
  // [CL-MAGNITUDE] No lower CL limit. CL = (m/S)|L_perp|/q_eff is a MAGNITUDE
  // (>= 0 identically), so the old cl_min hinge was provably dead
  // (viol_cllo <= -1 for every reachable state). The negative-lift / negative-g
  // pushover regime is NOT unguarded, though: the bank cone below fires on every
  // downward-lift state — for N = L_vec.up < 0, viol_bank = (cphi*L*w - N)/g > 0
  // unconditionally (cphi*L*w >= 0 > N), continuously from N = 0, reaching its
  // hard region near n_z = -0.66 — TIGHTER than any n_z >= -1 floor would be.
  // A separate signed-CL or n_z_min constraint is therefore redundant (and a
  // sign(N)*|CL| form would be discontinuous at the knife-edge N = 0). See
  // README.md design decision 3 (lift is a magnitude, no lower bound).
  // lift_coefficient_min stays in Parameters as
  // inert data (still loaded, never used) to avoid a lockstep struct/param edit.
  const double nmax = p.load_factor_max * (1.0 - margin);
  const double thrust_max = p.thrust_max_n * (1.0 - margin);
  const double thrust_min = p.thrust_min_n +
      margin * (p.thrust_max_n - p.thrust_min_n);
  const double thrust_scale = p.thrust_max_n - p.thrust_min_n;
  const double bank_limit = p.bank_angle_max_rad * (1.0 - margin);
  const double cphi = std::cos(bank_limit);
  const double inv_g = 1.0 / p.gravity_mps2;
  const double sin_gmax =
      std::sin(p.flight_path_angle_max_rad * (1.0 - margin));

  // [Q-FLOOR] NO activation smoothstep. The force hinges are bounded and
  // longitudinally flat below stall by construction now (see smoothFloor), so
  // the gate that used to ramp them in — and that manufactured a decelerating
  // force across the ramp, wrecking every rest-start — is gone. The only guard
  // left is the one the model genuinely needs: the flight DIRECTION is
  // undefined at exactly |v| = 0, so the direction-dependent (force-space)
  // hinges are skipped there. The minimum-speed hinge, never gated, still
  // covers that point and owns the sub-stall push.
  const bool force_on = m.evaluation.valid && m.speed.value > kEps;

  // Flight-path hinge on the FLOORED speed: r = vz^2/(speed2_eff * sin^2 gmax).
  // Above the floor speed2_eff == |v|^2 and this is exactly the old violation;
  // below it the denominator stops collapsing, so r -> 0 as v -> 0 (the hinge
  // switches itself off) and dr/dv stays bounded instead of going as 1/|v|.
  const double gamma_denom = m.speed2_eff * sin_gmax * sin_gmax;
  const double vz = velocity.z();

  const double viol_vlow  = (vmin - m.speed.value) / vmin;
  const double viol_vhigh = m.speed.value / vmax - 1.0;
  const double viol_q     = m.dynamic_pressure.value / qmax - 1.0;
  const double viol_clhi  = force_on ?
      m.lift_coefficient.value / clmax - 1.0 : 0.0;
  const double viol_n     = force_on ?
      m.load_factor.value / nmax - 1.0 : 0.0;
  const double viol_thi   = force_on ?
      (m.thrust.value - thrust_max) / thrust_scale : 0.0;
  const double viol_tlo   = force_on ?
      (thrust_min - m.thrust.value) / thrust_scale : 0.0;
  const double viol_bank  = force_on ?
      (cphi * m.lw.value - m.lift_up.value) * inv_g : 0.0;
  const double viol_gamma = force_on ?
      vz * vz / gamma_denom - 1.0 : 0.0;

  // Phase-1 early exit: nothing active -> zero cost, no derivative work.
  const bool any_active =
      (viol_vlow > 0.0 && p.penalty_speed > 0.0) ||
      (viol_vhigh > 0.0 && p.penalty_speed > 0.0) ||
      (viol_q > 0.0 && p.penalty_dynamic_pressure > 0.0) ||
      (viol_clhi > 0.0 && p.penalty_lift > 0.0) ||
      (viol_n > 0.0 && p.penalty_load > 0.0) ||
      (viol_thi > 0.0 && p.penalty_thrust > 0.0) ||
      (viol_tlo > 0.0 && p.penalty_thrust > 0.0) ||
      (viol_bank > 0.0 && p.penalty_bank > 0.0) ||
      (viol_gamma > 0.0 && p.penalty_flight_path > 0.0);
  if (!any_active) {
    return out;
  }

  // Phase 2: recompute WITH differentials (values bit-identical).
  m = evaluateWithDifferentials(p, position, velocity, acceleration,
                                /*want_diff=*/true);

  addPenalty(viol_vlow,
             Eigen::Vector3d::Zero(), -m.speed.dv / vmin,
             Eigen::Vector3d::Zero(), p.penalty_speed,
             outer_weight, &out);
  addPenalty(viol_vhigh,
             Eigen::Vector3d::Zero(), m.speed.dv / vmax,
             Eigen::Vector3d::Zero(), p.penalty_speed,
             outer_weight, &out);
  addPenalty(viol_q,
             m.dynamic_pressure.dp / qmax,
             m.dynamic_pressure.dv / qmax,
             Eigen::Vector3d::Zero(), p.penalty_dynamic_pressure,
             outer_weight, &out);

  if (!force_on) {
    return out;
  }

  addPenalty(viol_clhi,
             m.lift_coefficient.dp / clmax,
             m.lift_coefficient.dv / clmax,
             m.lift_coefficient.da / clmax,
             p.penalty_lift, outer_weight, &out);

  addPenalty(viol_n,
             Eigen::Vector3d::Zero(), m.load_factor.dv / nmax,
             m.load_factor.da / nmax, p.penalty_load,
             outer_weight, &out);

  addPenalty(viol_thi,
             m.thrust.dp / thrust_scale, m.thrust.dv / thrust_scale,
             m.thrust.da / thrust_scale, p.penalty_thrust,
             outer_weight, &out);
  addPenalty(viol_tlo,
             -m.thrust.dp / thrust_scale, -m.thrust.dv / thrust_scale,
             -m.thrust.da / thrust_scale, p.penalty_thrust,
             outer_weight, &out);

  // Bank limit, FORCE-SPACE CONE FORM (root fix for the pushover blowup):
  //   angle(L_vec, up_perp) <= phi  <=>  cos(phi)*L*w - L_vec.up <= 0,
  // scaled by the constant 1/g0 to make it dimensionless. The old
  // bank_cos-space hinge divided by the vanishing L*w and its gradient
  // measured 2.1e4 near zero lift; this form is division-free, its
  // gradients are bounded by (1+c)*|u|-class terms, and combined with the
  // cubic hinge (h' = O(viol^2)) the penalty stays globally C^1 through
  // both singular sets (L -> 0 pushover, w -> 0 vertical flight), where the
  // violation itself vanishes — the constraint is vacuous exactly where
  // the physics says any bank produces the required (zero) lift. Same
  // structure as the SCvx thrust-tilt cone  Gamma*cos(theta) <= e^T T.
  addPenalty(viol_bank,
             Eigen::Vector3d::Zero(),
             (cphi * m.lw.dv - m.lift_up.dv) * inv_g,
             (cphi * m.lw.da - m.lift_up.da) * inv_g,
             p.penalty_bank, outer_weight, &out);

  // Flight-path (velocity-component space, on the FLOORED speed):
  //   r     = v_z^2 / (se^2 sin^2 gmax),        se^2 = speed2_eff
  //   dr/dv = (2/denom) * ( v_z ez - (v_z^2 * mp / se^2) v ),  mp = d se^2/d s^2
  // Above the floor mp == 1 and se == |v|, so this is EXACTLY the old form.
  const Eigen::Vector3d ez(0.0, 0.0, 1.0);
  const Eigen::Vector3d dr_dv =
      (2.0 / gamma_denom) *
      (vz * ez - (vz * vz * m.speed2_grad / m.speed2_eff) * velocity);
  addPenalty(viol_gamma,
             Eigen::Vector3d::Zero(), dr_dv,
             Eigen::Vector3d::Zero(), p.penalty_flight_path,
             outer_weight, &out);

  return out;
}

double envelopeUtilization(
    const Parameters &p,
    const Evaluation &e,
    EnvelopeLimit *limiting)
{
  if (limiting != nullptr) {
    *limiting = EnvelopeLimit::None;
  }
  if (!e.valid || e.speed_mps < p.model_activation_speed_mps) {
    return 0.0;
  }

  double maximum = 0.0;
  auto consider = [&](double value, EnvelopeLimit limit) {
    if (std::isfinite(value) && value > maximum) {
      maximum = value;
      if (limiting != nullptr) {
        *limiting = limit;
      }
    }
  };

  consider(p.speed_min_mps / std::max(e.speed_mps, kEps),
           EnvelopeLimit::MinimumSpeed);
  consider(e.speed_mps / p.speed_max_mps, EnvelopeLimit::MaximumSpeed);
  // CL is a magnitude (>= 0), so only the upper (stall) limit exists; the old
  // e.lift_coefficient < 0 branch was unreachable. Negative-lift authority is
  // graded by the bank cone, not a CL floor (see flightEnvelopePenalty).
  consider(e.lift_coefficient / p.lift_coefficient_max,
           EnvelopeLimit::LiftCoefficient);
  consider(e.load_factor / p.load_factor_max, EnvelopeLimit::LoadFactor);
  if (e.thrust_required_n < p.thrust_min_n) {
    consider(1.0 + (p.thrust_min_n - e.thrust_required_n) /
        (p.thrust_max_n - p.thrust_min_n), EnvelopeLimit::MinimumThrust);
  } else {
    consider(e.thrust_required_n / p.thrust_max_n,
             EnvelopeLimit::MaximumThrust);
  }
  consider(e.dynamic_pressure_pa / p.dynamic_pressure_max_pa,
           EnvelopeLimit::DynamicPressure);
  if (e.load_factor >= kBankMeaningfulLoadFactor) {
    consider(e.bank_angle_rad / p.bank_angle_max_rad,
             EnvelopeLimit::BankAngle);
  } else if (e.vertical_load_factor < kBankNegativeNz) {
    // Cone-consistent (see [BANK-GATE]): > 1 for every inverted-lift state,
    // growing with pushover depth; both terms in g units.
    consider(1.0 + std::cos(p.bank_angle_max_rad) * e.load_factor -
                 e.vertical_load_factor,
             EnvelopeLimit::BankAngle);
  }
  consider(std::abs(e.flight_path_angle_rad) /
      p.flight_path_angle_max_rad, EnvelopeLimit::FlightPathAngle);
  return maximum;
}

bool isWithinEnvelope(const Parameters &p, const Evaluation &e)
{
  if (!e.valid || e.speed_mps < p.model_activation_speed_mps) {
    return false;
  }
  return e.speed_mps >= p.speed_min_mps &&
      e.speed_mps <= p.speed_max_mps &&
      e.lift_coefficient <= p.lift_coefficient_max &&
      e.load_factor <= p.load_factor_max &&
      e.thrust_required_n >= p.thrust_min_n &&
      e.thrust_required_n <= p.thrust_max_n &&
      e.dynamic_pressure_pa <= p.dynamic_pressure_max_pa &&
      (e.load_factor >= kBankMeaningfulLoadFactor
           ? e.bank_angle_rad <= p.bank_angle_max_rad
           : e.vertical_load_factor >= kBankNegativeNz) &&
      std::abs(e.flight_path_angle_rad) <= p.flight_path_angle_max_rad;
}

const char *envelopeLimitName(EnvelopeLimit limit)
{
  switch (limit) {
    case EnvelopeLimit::MinimumSpeed: return "minimum speed";
    case EnvelopeLimit::MaximumSpeed: return "maximum speed";
    case EnvelopeLimit::LiftCoefficient: return "lift coefficient";
    case EnvelopeLimit::LoadFactor: return "load factor";
    case EnvelopeLimit::MinimumThrust: return "minimum thrust";
    case EnvelopeLimit::MaximumThrust: return "maximum thrust";
    case EnvelopeLimit::DynamicPressure: return "dynamic pressure";
    case EnvelopeLimit::BankAngle: return "bank angle";
    case EnvelopeLimit::FlightPathAngle: return "flight-path angle";
    case EnvelopeLimit::None: default: return "none";
  }
}

double dragCoefficient(const Parameters &p, double lift_coefficient)
{
  return p.zero_lift_drag_coefficient +
      p.induced_drag_factor * lift_coefficient * lift_coefficient;
}

double marginBackedSpeedFloorMps(const Parameters &p)
{
  return p.speed_min_mps * (1.0 + p.constraint_margin);
}

HandoffVerdict speedConeVerdict(
    const Parameters &p,
    const Eigen::Vector3d &velocity_mps,
    double floor_mps,
    double maximum_mps)
{
  HandoffVerdict v;
  if (!velocity_mps.allFinite()) {
    v.reject = HandoffReject::NonFiniteVelocity;
    return v;
  }
  const double vh = std::hypot(velocity_mps.x(), velocity_mps.y());
  const double vz = velocity_mps.z();
  v.speed_mps = std::hypot(vh, vz);
  // atan2 over asin: the cone is a magnitude test and atan2 stays exact when
  // the horizontal component vanishes, which is the whole vertical case.
  v.flight_path_angle_rad = std::atan2(std::abs(vz), vh);
  if (belowSpeedBoundary(v.speed_mps, floor_mps)) {
    v.reject = HandoffReject::SpeedBelowFloor;
    return v;
  }
  if (aboveSpeedBoundary(v.speed_mps, maximum_mps)) {
    v.reject = HandoffReject::SpeedAboveMaximum;
    return v;
  }
  if (v.flight_path_angle_rad > p.flight_path_angle_max_rad) {
    v.reject = HandoffReject::FlightPathOutsideCone;
    return v;
  }
  return v;
}

HandoffVerdict handoffVerdict(
    const Parameters &p,
    const Eigen::Vector3d &position_m,
    const Eigen::Vector3d &velocity_mps,
    const Eigen::Vector3d &acceleration_mps2,
    double floor_mps,
    double maximum_mps)
{
  HandoffVerdict v;
  // Same ordering doctrine as the planner gate: finiteness of the WHOLE
  // state first. Position and acceleration are judged before the velocity
  // half so that a NaN in either cannot be masked by a velocity refusal.
  if (!position_m.allFinite()) {
    v.reject = HandoffReject::NonFinitePosition;
    return v;
  }
  if (!acceleration_mps2.allFinite()) {
    v.reject = HandoffReject::NonFiniteAcceleration;
    return v;
  }
  v = speedConeVerdict(p, velocity_mps, floor_mps, maximum_mps);
  if (!v.ok()) return v;

  v.evaluation = evaluateInverseDynamics(p, position_m, velocity_mps,
                                         acceleration_mps2);
  if (!v.evaluation.valid) {
    v.reject = HandoffReject::InverseDynamicsUndefined;
    return v;
  }
  // isWithinEnvelope is the predicate; utilization is only the REPORT of how
  // close. They disagree below model_activation_speed_mps by construction,
  // and the predicate is the one that decides.
  if (!isWithinEnvelope(p, v.evaluation)) {
    v.reject = HandoffReject::EnvelopeExceeded;
    v.utilization = envelopeUtilization(p, v.evaluation, &v.limit);
    return v;
  }
  v.utilization = envelopeUtilization(p, v.evaluation, &v.limit);
  return v;
}

const char *handoffRejectName(HandoffReject reject)
{
  switch (reject) {
    case HandoffReject::NonFinitePosition: return "non-finite position";
    case HandoffReject::NonFiniteVelocity: return "non-finite velocity";
    case HandoffReject::NonFiniteAcceleration:
      return "non-finite acceleration";
    case HandoffReject::SpeedBelowFloor: return "speed below cruise floor";
    case HandoffReject::SpeedAboveMaximum: return "speed above maximum";
    case HandoffReject::FlightPathOutsideCone:
      return "flight-path angle outside validity cone";
    case HandoffReject::InverseDynamicsUndefined:
      return "inverse dynamics undefined";
    case HandoffReject::EnvelopeExceeded: return "flight envelope exceeded";
    case HandoffReject::None: default: return "none";
  }
}

}  // namespace mmp_vehicle_dynamics

// Shared-model 3-DoF fixed-wing trajectory follower.
//
// Revived 2026-07 from the parked sim/ source (history: e985041) once the
// mmp_traj_msgs split dissolved the dependency cycle that kept it unbuilt.
// It lives NEXT TO the model on purpose: this node is the shape the
// mmp_dynamics_sim merge converges to — a follower that CONSUMES
// mmp_vehicle_dynamics instead of carrying its own physics.
//
// Integrates position/airspeed/flight-path/heading against
// /planning/trajectory; lift/thrust/bank clamp through the same shared model
// the optimizer's cost term uses (parameters from the authoritative
// optimization/dynamics_* set). Publishes /dynamics/sim_state + sim_path +
// envelope_utilization + tracking_error_m, and TWO TF frames:
//   drone_0_base   true attitude (bank/pitch/heading) — for the vehicle mesh
//   drone_0_chase  same position, SMOOTHED yaw only — the camera target.
//     Following the raw base frame made aggressive maneuvers nauseating: the
//     view whipped with every bank/pitch. The chase yaw is EMA-smoothed
//     (chase_yaw_tau_s) and slew-limited (chase_yaw_rate_max_dps), roll and
//     pitch never transfer.
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/path.hpp>
#include <mmp_traj_msgs/msg/poly_traj.hpp>
#include <mmp_traj_msgs/msg/trajectory_execution_control.hpp>
#include <mmp_vehicle_dynamics/trajectory_abort_state.hpp>
#include <std_msgs/msg/float64.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>

#include <mmp_vehicle_dynamics/flight_dynamics.hpp>
#include <mmp_vehicle_dynamics/point_mass_eom.hpp>

#include <Eigen/Dense>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <vector>

using namespace std::chrono_literals;
namespace md = mmp_vehicle_dynamics;

// A plan whose start_time sits further than this from now is not trusted as an
// anchor (stale bag replay, clock mismatch): the follower falls back to receipt
// time rather than flinging the sim to an offset that is seconds or hours off.
constexpr double kMaxPlanStartSkewS = 10.0;

class DynamicsSimulator : public rclcpp::Node
{
public:
  DynamicsSimulator() : Node("dynamics_sim_node")
  {
    loadParameters();

    // /planning/trajectory is latched (RELIABLE + TRANSIENT_LOCAL, one publish
    // per plan). Match it so a follower that starts (or restarts) after the
    // plan still receives the latched trajectory — a volatile/best-effort sub
    // here would silently miss it.
    rclcpp::QoS traj_qos(1);
    traj_qos.reliable();
    traj_qos.transient_local();
    trajectory_sub_ = create_subscription<mmp_traj_msgs::msg::PolyTraj>(
        "/planning/trajectory", traj_qos,
        std::bind(&DynamicsSimulator::onTrajectory, this, std::placeholders::_1));

    // [ABORT] The planner withdraws a trajectory it has already published
    // when the world under it changes. Same QoS as the trajectory topic, so a
    // follower that starts late receives the latched trajectory AND its
    // abort — and must not begin executing one that was withdrawn.
    rclcpp::QoS ctl_qos(1);
    ctl_qos.reliable();
    ctl_qos.transient_local();
    exec_control_sub_ =
        create_subscription<mmp_traj_msgs::msg::TrajectoryExecutionControl>(
            "/planning/execution_control", ctl_qos,
            std::bind(&DynamicsSimulator::onExecutionControl, this,
                      std::placeholders::_1));

    rclcpp::QoS scrub_qos(1);
    scrub_qos.reliable();
    scrub_qos.transient_local();
    scrub_sub_ = create_subscription<std_msgs::msg::Float64>(
        "/dynamics/scrub_time", scrub_qos,
        [this](const std_msgs::msg::Float64::SharedPtr msg) {
          scrub_time_s_ = msg->data;
        });

    state_pub_ = create_publisher<nav_msgs::msg::Odometry>(
        "/dynamics/sim_state", 10);
    path_pub_ = create_publisher<nav_msgs::msg::Path>(
        "/dynamics/sim_path", 10);
    utilization_pub_ = create_publisher<std_msgs::msg::Float64>(
        "/dynamics/envelope_utilization", 10);
    tracking_error_pub_ = create_publisher<std_msgs::msg::Float64>(
        "/dynamics/tracking_error_m", 10);
    tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
    timer_ = create_wall_timer(20ms, std::bind(&DynamicsSimulator::onTick, this));

    RCLCPP_INFO(get_logger(),
                "3DOF fixed-wing dynamics simulator ready (V=[%.0f, %.0f] m/s, "
                "n<=%.2f, T<=%.0f N)",
                parameters_.speed_min_mps, parameters_.speed_max_mps,
                parameters_.load_factor_max, parameters_.thrust_max_n);
  }

private:
  struct Reference
  {
    Eigen::Vector3d position_m = Eigen::Vector3d::Zero();
    Eigen::Vector3d velocity_mps = Eigen::Vector3d::Zero();
    Eigen::Vector3d acceleration_mps2 = Eigen::Vector3d::Zero();
  };

  struct State
  {
    double time_s = 0.0;
    Eigen::Vector3d position_m = Eigen::Vector3d::Zero();
    double speed_mps = 0.0;
    double flight_path_angle_rad = 0.0;
    double heading_rad = 0.0;
    double bank_rad = 0.0;
  };

  struct Derivative
  {
    Eigen::Vector3d position = Eigen::Vector3d::Zero();
    double speed = 0.0;
    double flight_path_angle = 0.0;
    double heading = 0.0;
  };

  struct Control
  {
    // False when the STATE is outside the 3DOF parameterization's validity
    // (rate floor / near-vertical band) — audit must exclude such steps.
    bool state_representable = true;
    double thrust_n = 0.0;
    double lift_n = 0.0;
    double bank_rad = 0.0;
    double drag_n = 0.0;
    Eigen::Vector3d acceleration_mps2 = Eigen::Vector3d::Zero();
  };

  void declareGet(const char *name, double default_value, double &value)
  {
    declare_parameter(name, default_value);
    get_parameter(name, value);
  }

  void loadParameters()
  {
    declareGet("optimization/dynamics_unit_xy_m", 100.0, unit_xy_m_);
    declareGet("optimization/dynamics_unit_z_m", 100.0, unit_z_m_);
    declareGet("optimization/dynamics_mass_kg", 1300.0, parameters_.mass_kg);
    declareGet("optimization/dynamics_wing_area_m2", 1.0,
               parameters_.wing_area_m2);
    declareGet("optimization/dynamics_g", 9.80665,
               parameters_.gravity_mps2);
    declareGet("optimization/dynamics_rho0_kgpm3", 1.225,
               parameters_.sea_level_density_kgpm3);
    declareGet("optimization/dynamics_density_scale_height_m", 8500.0,
               parameters_.density_scale_height_m);
    declareGet("optimization/dynamics_altitude_reference_m", 0.0,
               parameters_.altitude_reference_m);
    declareGet("optimization/dynamics_cd0", 0.035,
               parameters_.zero_lift_drag_coefficient);
    declareGet("optimization/dynamics_induced_drag_factor", 0.080,
               parameters_.induced_drag_factor);
    declareGet("optimization/dynamics_cl_min", -0.40,
               parameters_.lift_coefficient_min);
    declareGet("optimization/dynamics_cl_max", 1.40,
               parameters_.lift_coefficient_max);
    declareGet("optimization/dynamics_load_factor_max", 2.50,
               parameters_.load_factor_max);
    declareGet("optimization/dynamics_thrust_min_n", 0.0,
               parameters_.thrust_min_n);
    declareGet("optimization/dynamics_thrust_max_n", 3200.0,
               parameters_.thrust_max_n);
    declareGet("optimization/dynamics_speed_min_mps", 120.0,
               parameters_.speed_min_mps);
    declareGet("optimization/dynamics_speed_max_mps", 230.0,
               parameters_.speed_max_mps);
    declareGet("optimization/dynamics_activation_speed_mps", 40.0,
               parameters_.model_activation_speed_mps);
    declareGet("optimization/dynamics_dynamic_pressure_max_pa", 45000.0,
               parameters_.dynamic_pressure_max_pa);
    double bank_deg = 65.0;
    double path_deg = 30.0;
    declareGet("optimization/dynamics_bank_max_deg", 65.0, bank_deg);
    declareGet("optimization/dynamics_flight_path_max_deg", 30.0, path_deg);
    parameters_.bank_angle_max_rad = bank_deg * M_PI / 180.0;
    parameters_.flight_path_angle_max_rad = path_deg * M_PI / 180.0;
    declareGet("optimization/dynamics_margin", 0.02,
               parameters_.constraint_margin);
    // Chase-camera smoothing (see the file header).
    declareGet("chase_yaw_tau_s", 1.5, chase_yaw_tau_s_);
    declareGet("chase_yaw_rate_max_dps", 45.0, chase_yaw_rate_max_dps_);

    declareGet("simulation/integration_step_s", 0.02, integration_step_s_);
    declareGet("simulation/position_gain", 0.04, position_gain_);
    declareGet("simulation/velocity_gain", 0.80, velocity_gain_);
    declareGet("simulation/max_commanded_acceleration_mps2", 30.0,
               max_commanded_acceleration_mps2_);

    if (!md::parametersAreValid(parameters_)) {
      throw std::runtime_error("invalid fixed-wing dynamics parameters");
    }
    if (unit_xy_m_ <= 0.0 || unit_z_m_ <= 0.0 ||
        integration_step_s_ <= 0.0) {
      throw std::runtime_error("invalid dynamics frame/simulation parameters");
    }
  }

  Eigen::Vector3d frameScale() const
  {
    return Eigen::Vector3d(unit_xy_m_, unit_xy_m_, unit_z_m_);
  }

  double totalDuration() const
  {
    double total = 0.0;
    for (double d : durations_) total += d;
    return total;
  }

  Reference sampleReference(double time_s) const
  {
    Reference ref;
    if (durations_.empty()) return ref;

    const double t = std::max(0.0, std::min(time_s, totalDuration()));
    double accumulated = 0.0;
    size_t piece = 0;
    double local_t = t;
    for (size_t i = 0; i < durations_.size(); ++i) {
      if (t <= accumulated + durations_[i] || i + 1 == durations_.size()) {
        piece = i;
        local_t = t - accumulated;
        break;
      }
      accumulated += durations_[i];
    }

    const int stride = order_ + 1;
    const int offset = static_cast<int>(piece) * stride;
    Eigen::Vector3d position = Eigen::Vector3d::Zero();
    Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
    Eigen::Vector3d acceleration = Eigen::Vector3d::Zero();
    for (int j = 0; j <= order_; ++j) {
      const int power = order_ - j;
      const Eigen::Vector3d coefficient(
          coefficients_x_[offset + j], coefficients_y_[offset + j],
          coefficients_z_[offset + j]);
      position += coefficient * std::pow(local_t, power);
      if (power >= 1) {
        velocity += coefficient *
            (power * std::pow(local_t, power - 1));
      }
      if (power >= 2) {
        acceleration += coefficient *
            (power * (power - 1) * std::pow(local_t, power - 2));
      }
    }
    const Eigen::Vector3d scale = frameScale();
    ref.position_m = scale.cwiseProduct(position);
    ref.velocity_mps = scale.cwiseProduct(velocity);
    ref.acceleration_mps2 = scale.cwiseProduct(acceleration);
    return ref;
  }

  // The vehicle-agnostic physics live in point_mass_eom.hpp (shared with
  // the transition generator per ADR-0002); this node keeps only the
  // CONTROLLER — sampling the reference PolyTraj to choose inputs.
  md::PointMassState eomState(const State &state) const
  {
    md::PointMassState s;
    s.position_m = state.position_m;
    s.speed_mps = state.speed_mps;
    s.flight_path_angle_rad = state.flight_path_angle_rad;
    s.heading_rad = state.heading_rad;
    return s;
  }

  Eigen::Vector3d stateVelocity(const State &state) const
  {
    return md::pointMassVelocity(eomState(state));
  }

  Control controller(double time_s, const State &state) const
  {
    const Reference ref = sampleReference(time_s);
    const Eigen::Vector3d velocity = stateVelocity(state);
    Eigen::Vector3d commanded_acceleration = ref.acceleration_mps2 +
        position_gain_ * (ref.position_m - state.position_m) +
        velocity_gain_ * (ref.velocity_mps - velocity);
    const double acceleration_norm = commanded_acceleration.norm();
    if (acceleration_norm > max_commanded_acceleration_mps2_) {
      commanded_acceleration *=
          max_commanded_acceleration_mps2_ / acceleration_norm;
    }

    const double gamma = state.flight_path_angle_rad;
    const double chi = state.heading_rad;
    const Eigen::Vector3d tangent = velocity.normalized();
    const Eigen::Vector3d flight_up(
        -std::sin(gamma) * std::cos(chi),
        -std::sin(gamma) * std::sin(chi), std::cos(gamma));
    const Eigen::Vector3d flight_right(-std::sin(chi), std::cos(chi), 0.0);
    const Eigen::Vector3d gravity(0.0, 0.0, -parameters_.gravity_mps2);
    const Eigen::Vector3d required_specific_force =
        commanded_acceleration - gravity;

    const double tangential_force = required_specific_force.dot(tangent);
    const double vertical_lift_accel = required_specific_force.dot(flight_up);
    const double lateral_lift_accel = required_specific_force.dot(flight_right);
    const double lift_accel =
        std::hypot(vertical_lift_accel, lateral_lift_accel);
    const double requested_bank =
        std::atan2(lateral_lift_accel, vertical_lift_accel);

    // The commanded (CL, thrust, bank) -> realized-forces closure is the
    // SHARED one (point_mass_eom.hpp) — the follower is a caller of the
    // single aero authority, not a second copy of it. A follower riding a
    // limit is normal tracking behaviour, so the saturation flags are
    // accepted silently here; a transition generator must not do that.
    const double rho = md::airDensity(parameters_, state.position_m.z());
    const double q = 0.5 * rho * state.speed_mps * state.speed_mps;
    const double requested_cl = parameters_.mass_kg * lift_accel /
        std::max(q * parameters_.wing_area_m2, 1.0e-6);
    // Thrust request needs the REALIZED drag, which depends on the realized
    // CL — ask the closure twice: once for the aero at the requested CL,
    // then with the drag-aware thrust request. (Same arithmetic as the old
    // inline code, now against the shared formulas.)
    const md::PointMassForceResult aero = md::pointMassForces(
        parameters_, eomState(state), requested_cl, 0.0, requested_bank);
    const double requested_thrust =
        aero.inputs.drag_n + parameters_.mass_kg * tangential_force;
    const md::PointMassForceResult closed = md::pointMassForces(
        parameters_, eomState(state), requested_cl, requested_thrust,
        requested_bank);
    Control control;
    // SATURATION is normal tracking behaviour (riding a limit) and stays
    // silent. UNREPRESENTABLE is different — the state sits outside the
    // 3DOF parameterization's validity — and is FLAGGED here but counted
    // in integrateChunk, once per integration step (review find: counting
    // in this function tallied controller calls, and RK4 makes four of
    // those per step).
    control.state_representable = closed.state_representable;
    control.bank_rad = closed.inputs.bank_rad;
    control.lift_n = closed.inputs.lift_n;
    control.drag_n = closed.inputs.drag_n;
    control.thrust_n = closed.inputs.thrust_n;

    control.acceleration_mps2 = gravity +
        ((control.thrust_n - control.drag_n) / parameters_.mass_kg) * tangent +
        (control.lift_n / parameters_.mass_kg) *
            (std::cos(control.bank_rad) * flight_up +
             std::sin(control.bank_rad) * flight_right);
    return control;
  }

  Derivative derivative(double time_s, const State &state, Control *used) const
  {
    const Control control = controller(time_s, state);
    if (used != nullptr) *used = control;
    md::PointMassInputs u;
    u.thrust_n = control.thrust_n;
    u.lift_n = control.lift_n;
    u.drag_n = control.drag_n;
    u.bank_rad = control.bank_rad;
    const md::PointMassDerivative pd =
        md::pointMassDerivative(parameters_, eomState(state), u);
    Derivative d;
    d.position = pd.position;
    d.speed = pd.speed;
    d.flight_path_angle = pd.flight_path_angle;
    d.heading = pd.heading;
    return d;
  }

  State shifted(const State &state, const Derivative &d, double dt) const
  {
    State out = state;
    out.time_s += dt;
    out.position_m += dt * d.position;
    out.speed_mps = std::max(1.0, state.speed_mps + dt * d.speed);
    out.flight_path_angle_rad = std::clamp(
        state.flight_path_angle_rad + dt * d.flight_path_angle,
        -1.553343034, 1.553343034);
    out.heading_rad = state.heading_rad + dt * d.heading;
    return out;
  }

  State integrateRk4(const State &state, double dt) const
  {
    const Derivative k1 = derivative(state.time_s, state, nullptr);
    const State s2 = shifted(state, k1, 0.5 * dt);
    const Derivative k2 = derivative(s2.time_s, s2, nullptr);
    const State s3 = shifted(state, k2, 0.5 * dt);
    const Derivative k3 = derivative(s3.time_s, s3, nullptr);
    const State s4 = shifted(state, k3, dt);
    const Derivative k4 = derivative(s4.time_s, s4, nullptr);

    State out = state;
    out.time_s += dt;
    out.position_m += (dt / 6.0) *
        (k1.position + 2.0 * k2.position + 2.0 * k3.position + k4.position);
    out.speed_mps = std::max(1.0, state.speed_mps + (dt / 6.0) *
        (k1.speed + 2.0 * k2.speed + 2.0 * k3.speed + k4.speed));
    out.flight_path_angle_rad = std::clamp(
        state.flight_path_angle_rad + (dt / 6.0) *
            (k1.flight_path_angle + 2.0 * k2.flight_path_angle +
             2.0 * k3.flight_path_angle + k4.flight_path_angle),
        -1.553343034, 1.553343034);
    out.heading_rad = state.heading_rad + (dt / 6.0) *
        (k1.heading + 2.0 * k2.heading + 2.0 * k3.heading + k4.heading);
    out.heading_rad = std::atan2(std::sin(out.heading_rad),
                                std::cos(out.heading_rad));
    out.bank_rad = controller(out.time_s, out).bank_rad;
    return out;
  }

  // Playback offset a freshly received plan starts at. ReplanFSM stamps
  // start_time from the same RCL_ROS_TIME clock this node's now() reads, so
  // honoring it keeps a mid-flight replan aligned instead of silently
  // rewinding the sim by the publish/transport latency. An unset (zero) or
  // implausible stamp falls back to receipt time, i.e. offset 0.
  double planStartOffset(const mmp_traj_msgs::msg::PolyTraj &msg) const
  {
    // An unset stamp carries no anchor; a negative one is malformed, and the
    // rclcpp::Time constructor throws on it, so screen both before building.
    if (msg.start_time.sec < 0 ||
        (msg.start_time.sec == 0 && msg.start_time.nanosec == 0)) {
      return 0.0;
    }
    const rclcpp::Time start(msg.start_time, RCL_ROS_TIME);
    const double elapsed = (now() - start).seconds();
    if (std::abs(elapsed) > kMaxPlanStartSkewS) {
      RCLCPP_WARN(get_logger(),
                  "plan start_time is %.1f s from now; anchoring the "
                  "trajectory at receipt time instead", elapsed);
      return 0.0;
    }
    return std::max(0.0, elapsed);
  }

  // [ABORT] Withdraw the named trajectory. Only if it is the one being
  // executed: a late or replayed abort must never stop a NEWER trajectory,
  // which is why the planner stamps an id that does not restart.
  void onExecutionControl(
      const mmp_traj_msgs::msg::TrajectoryExecutionControl::SharedPtr msg)
  {
    using Ctl = mmp_traj_msgs::msg::TrajectoryExecutionControl;
    if (msg->action != Ctl::ACTION_ABORT) return;
    // The decision is the shared state machine's — see the header. Only the
    // consequences below are this node's.
    if (!abort_state_.applyAbort(msg->trajectory_id)) {
      RCLCPP_INFO(get_logger(),
                  "[ABORT] control for trajectory %lu ignored (executing %lu)",
                  static_cast<unsigned long>(msg->trajectory_id),
                  static_cast<unsigned long>(abort_state_.current()));
      return;
    }
    RCLCPP_WARN(get_logger(),
                "[ABORT] trajectory %lu withdrawn by the planner (reason %u: "
                "%s) — stopping polynomial following. The recovery manoeuvre "
                "is NOT the planner's to choose and is not performed here.",
                static_cast<unsigned long>(msg->trajectory_id),
                static_cast<unsigned>(msg->reason), msg->detail.c_str());
    integrating_ = false;
    durations_.clear();
    coefficients_x_.clear();
    coefficients_y_.clear();
    coefficients_z_.clear();
    simulated_states_.clear();
  }

  void onTrajectory(const mmp_traj_msgs::msg::PolyTraj::SharedPtr msg)
  {
    // [ABORT] A trajectory whose id has already been withdrawn must not start
    // executing. With TRANSIENT_LOCAL both are delivered to a late joiner and
    // the order is not guaranteed, so this is checked on arrival too.
    if (!abort_state_.acceptTrajectory(msg->trajectory_id)) {
      // Ignore it, and ONLY it. Whatever is being flown keeps flying: this
      // message may be a redelivery of something withdrawn long ago, and
      // dropping the current coefficients here would let a stale input
      // ground a healthy flight.
      RCLCPP_WARN(get_logger(),
                  "[ABORT] trajectory %lu arrived already withdrawn — "
                  "ignoring it (still executing %lu)",
                  static_cast<unsigned long>(msg->trajectory_id),
                  static_cast<unsigned long>(abort_state_.current()));
      return;
    }
    order_ = msg->order;
    coefficients_x_ = msg->coef_x;
    coefficients_y_ = msg->coef_y;
    coefficients_z_ = msg->coef_z;
    durations_ = msg->duration;
    scrub_time_s_ = planStartOffset(*msg);
    last_path_time_s_ = -1.0;
    simulated_states_.clear();
    integrating_ = false;  // states cleared: never resume a stale integration
    if (durations_.empty()) return;

    const int expected = static_cast<int>(durations_.size()) * (order_ + 1);
    if (static_cast<int>(coefficients_x_.size()) != expected ||
        static_cast<int>(coefficients_y_.size()) != expected ||
        static_cast<int>(coefficients_z_.size()) != expected) {
      RCLCPP_ERROR(get_logger(), "invalid polynomial coefficient array size");
      return;
    }

    const double total = totalDuration();
    Reference initial_ref = sampleReference(0.0);
    Reference direction_ref = initial_ref;
    if (direction_ref.velocity_mps.norm() < 1.0) {
      for (double t = 0.1; t <= total; t += 0.1) {
        direction_ref = sampleReference(t);
        if (direction_ref.velocity_mps.norm() >=
            parameters_.model_activation_speed_mps) break;
      }
    }
    Eigen::Vector3d direction = direction_ref.velocity_mps;
    if (direction.norm() < 1.0e-6) direction = Eigen::Vector3d::UnitX();
    direction.normalize();

    State state;
    state.position_m = initial_ref.position_m;
    state.speed_mps = std::max(parameters_.speed_min_mps,
                               initial_ref.velocity_mps.norm());
    state.flight_path_angle_rad = std::asin(
        std::clamp(direction.z(), -1.0, 1.0));
    state.heading_rad = std::atan2(direction.y(), direction.x());
    state.bank_rad = 0.0;
    simulated_states_.reserve(
        static_cast<size_t>(total / integration_step_s_) + 2);
    simulated_states_.push_back(state);

    // Integrate incrementally from onTick in wall-clock-budgeted chunks: doing
    // the whole trajectory here starved the 50 Hz tick and the scrub callback
    // on the single-threaded executor for seconds per plan.
    integrate_total_s_ = total;
    peak_error_m_ = 0.0;
    peak_utilization_ = 0.0;
    violation_steps_ = 0;
    unrepresentable_steps_ = 0;      // per-trajectory, like the audit stats
    unrepresentable_warned_ = false;
    integrating_ = true;
    have_simulation_ = true;
  }

  void integrateChunk()
  {
    const auto deadline = std::chrono::steady_clock::now() +
        std::chrono::milliseconds(8);
    State state = simulated_states_.back();
    while (state.time_s < integrate_total_s_ - 1.0e-9) {
      const double dt = std::min(
          integration_step_s_, integrate_total_s_ - state.time_s);
      state = integrateRk4(state, dt);
      simulated_states_.push_back(state);

      const Reference ref = sampleReference(state.time_s);
      peak_error_m_ = std::max(
          peak_error_m_, (state.position_m - ref.position_m).norm());
      Control applied;
      derivative(state.time_s, state, &applied);
      if (!applied.state_representable) {
        // Outside the parameterization's validity: the numerical guards
        // keep integration finite, but readings here carry no model
        // meaning — counted (once per integration step) and EXCLUDED from
        // the envelope audit, never silently folded into it.
        if (!unrepresentable_warned_) {
          unrepresentable_warned_ = true;
          RCLCPP_WARN(get_logger(),
                      "[EOM] state outside the 3DOF parameterization's "
                      "validity (V=%.1f m/s, gamma=%.1f deg) — integration "
                      "continues on the numerical guards; such steps are "
                      "counted and excluded from the envelope audit.",
                      state.speed_mps,
                      state.flight_path_angle_rad * 180.0 / M_PI);
        }
        ++unrepresentable_steps_;
      } else {
        const auto eval = md::evaluateInverseDynamics(
            parameters_, state.position_m, stateVelocity(state),
            applied.acceleration_mps2);
        peak_utilization_ = std::max(
            peak_utilization_, md::envelopeUtilization(parameters_, eval));
        if (!md::isWithinEnvelope(parameters_, eval)) ++violation_steps_;
      }

      if (std::chrono::steady_clock::now() >= deadline) return;  // next tick
    }
    integrating_ = false;
    RCLCPP_INFO(get_logger(),
                "integrated %.1f s into %zu states: peak tracking error %.1f m, "
                "peak envelope %.1f%%, violating steps %d, unrepresentable "
                "steps %d (excluded from audit)",
                integrate_total_s_, simulated_states_.size(), peak_error_m_,
                100.0 * peak_utilization_, violation_steps_,
                unrepresentable_steps_);
  }

  size_t stateIndexAt(double time_s) const
  {
    auto it = std::lower_bound(
        simulated_states_.begin(), simulated_states_.end(), time_s,
        [](const State &state, double t) { return state.time_s < t; });
    if (it == simulated_states_.end()) return simulated_states_.size() - 1;
    if (it == simulated_states_.begin()) return 0;
    const size_t upper = static_cast<size_t>(it - simulated_states_.begin());
    const size_t lower = upper - 1;
    return (time_s - simulated_states_[lower].time_s <
            simulated_states_[upper].time_s - time_s) ? lower : upper;
  }

  void onTick()
  {
    if (integrating_) integrateChunk();
    if (!have_simulation_ || simulated_states_.empty()) return;
    const double total = simulated_states_.back().time_s;
    const double t = std::clamp(scrub_time_s_, 0.0, total);
    const size_t index = stateIndexAt(t);
    const State &state = simulated_states_[index];
    const Eigen::Vector3d velocity_mps = stateVelocity(state);
    const Reference ref = sampleReference(state.time_s);
    Control applied;
    derivative(state.time_s, state, &applied);
    const auto eval = md::evaluateInverseDynamics(
        parameters_, state.position_m, velocity_mps,
        applied.acceleration_mps2);

    tf2::Quaternion orientation;
    orientation.setRPY(state.bank_rad, -state.flight_path_angle_rad,
                       state.heading_rad);
    const Eigen::Vector3d scale = frameScale();
    const Eigen::Vector3d position = state.position_m.cwiseQuotient(scale);
    const auto stamp = now();

    nav_msgs::msg::Odometry odometry;
    odometry.header.stamp = stamp;
    odometry.header.frame_id = "map";
    odometry.child_frame_id = "drone_0_base";
    odometry.pose.pose.position.x = position.x();
    odometry.pose.pose.position.y = position.y();
    odometry.pose.pose.position.z = position.z();
    odometry.pose.pose.orientation.x = orientation.x();
    odometry.pose.pose.orientation.y = orientation.y();
    odometry.pose.pose.orientation.z = orientation.z();
    odometry.pose.pose.orientation.w = orientation.w();
    // REP-147: Odometry twist is the BODY-frame velocity in m/s
    // (child_frame_id). The body +X axis is the flight-path tangent here, so
    // the airspeed is the only nonzero component.
    odometry.twist.twist.linear.x = state.speed_mps;
    odometry.twist.twist.linear.y = 0.0;
    odometry.twist.twist.linear.z = 0.0;
    state_pub_->publish(odometry);

    std_msgs::msg::Float64 utilization;
    utilization.data = md::envelopeUtilization(parameters_, eval);
    utilization_pub_->publish(utilization);
    std_msgs::msg::Float64 tracking_error;
    tracking_error.data = (state.position_m - ref.position_m).norm();
    tracking_error_pub_->publish(tracking_error);

    if (std::abs(t - last_path_time_s_) > 1.0e-6) {
      last_path_time_s_ = t;
      nav_msgs::msg::Path path;
      path.header.stamp = stamp;
      path.header.frame_id = "map";
      const size_t count = index + 1;
      const size_t stride = std::max<size_t>(1, count / 500);
      for (size_t i = 0; i < count; i += stride) {
        geometry_msgs::msg::PoseStamped pose;
        pose.header = path.header;
        const Eigen::Vector3d p =
            simulated_states_[i].position_m.cwiseQuotient(scale);
        pose.pose.position.x = p.x();
        pose.pose.position.y = p.y();
        pose.pose.position.z = p.z();
        pose.pose.orientation.w = 1.0;
        path.poses.push_back(pose);
      }
      if (path.poses.empty() || count == 1 ||
          (count - 1) % stride != 0) {
        geometry_msgs::msg::PoseStamped pose;
        pose.header = path.header;
        pose.pose.position.x = position.x();
        pose.pose.position.y = position.y();
        pose.pose.position.z = position.z();
        pose.pose.orientation.w = 1.0;
        path.poses.push_back(pose);
      }
      path_pub_->publish(path);
    }

    geometry_msgs::msg::TransformStamped transform;
    transform.header.stamp = stamp;
    transform.header.frame_id = "map";
    transform.child_frame_id = "drone_0_base";
    transform.transform.translation.x = position.x();
    transform.transform.translation.y = position.y();
    transform.transform.translation.z = position.z();
    transform.transform.rotation.x = orientation.x();
    transform.transform.rotation.y = orientation.y();
    transform.transform.rotation.z = orientation.z();
    transform.transform.rotation.w = orientation.w();
    tf_broadcaster_->sendTransform(transform);

    // drone_0_chase: identical position, smoothed YAW ONLY. Two-stage
    // filter — shortest-arc EMA toward the true heading, then a hard slew
    // cap — so the camera pans instead of whipping, and roll/pitch never
    // reach it at all.
    {
      const double dt = integration_step_s_;
      const double target = state.heading_rad;
      if (!chase_yaw_init_) {
        chase_yaw_rad_ = target;
        chase_yaw_init_ = true;
      }
      double err = std::remainder(target - chase_yaw_rad_, 2.0 * M_PI);
      const double alpha =
          (chase_yaw_tau_s_ > 1e-6) ? (1.0 - std::exp(-dt / chase_yaw_tau_s_))
                                    : 1.0;
      double step = err * alpha;
      const double max_step =
          chase_yaw_rate_max_dps_ * M_PI / 180.0 * dt;
      step = std::clamp(step, -max_step, max_step);
      chase_yaw_rad_ = std::remainder(chase_yaw_rad_ + step, 2.0 * M_PI);

      tf2::Quaternion chase_q;
      chase_q.setRPY(0.0, 0.0, chase_yaw_rad_);
      geometry_msgs::msg::TransformStamped chase;
      chase.header.stamp = stamp;
      chase.header.frame_id = "map";
      chase.child_frame_id = "drone_0_chase";
      chase.transform.translation.x = position.x();
      chase.transform.translation.y = position.y();
      chase.transform.translation.z = position.z();
      chase.transform.rotation.x = chase_q.x();
      chase.transform.rotation.y = chase_q.y();
      chase.transform.rotation.z = chase_q.z();
      chase.transform.rotation.w = chase_q.w();
      tf_broadcaster_->sendTransform(chase);
    }
  }

  md::Parameters parameters_;
  double unit_xy_m_ = 100.0;
  double unit_z_m_ = 100.0;
  double integration_step_s_ = 0.02;
  double chase_yaw_tau_s_ = 1.5;
  double chase_yaw_rate_max_dps_ = 45.0;
  double chase_yaw_rad_ = 0.0;
  bool chase_yaw_init_ = false;
  double position_gain_ = 0.04;
  double velocity_gain_ = 0.80;
  // Integration steps whose state fell outside the 3DOF
  // parameterization's validity (counted once per step in integrateChunk,
  // excluded from the envelope audit, reset per trajectory).
  int unrepresentable_steps_ = 0;
  bool unrepresentable_warned_ = false;
  double max_commanded_acceleration_mps2_ = 30.0;

  bool have_simulation_ = false;
  bool integrating_ = false;
  double integrate_total_s_ = 0.0;
  double peak_error_m_ = 0.0;
  double peak_utilization_ = 0.0;
  int violation_steps_ = 0;
  int order_ = 5;
  double scrub_time_s_ = 0.0;
  double last_path_time_s_ = -1.0;
  std::vector<float> coefficients_x_;
  std::vector<float> coefficients_y_;
  std::vector<float> coefficients_z_;
  std::vector<float> durations_;
  std::vector<State> simulated_states_;

  rclcpp::Subscription<mmp_traj_msgs::msg::PolyTraj>::SharedPtr trajectory_sub_;
  rclcpp::Subscription<
      mmp_traj_msgs::msg::TrajectoryExecutionControl>::SharedPtr
      exec_control_sub_;
  // [ABORT] The contract itself, shared with the regression that checks it.
  mmp_vehicle_dynamics::TrajectoryAbortState abort_state_;
  rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr scrub_sub_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr state_pub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
  rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr utilization_pub_;
  rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr tracking_error_pub_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<DynamicsSimulator>());
  rclcpp::shutdown();
  return 0;
}

"""Python face of the shared MMP fixed-wing model.

The math is re-exported from the compiled _flight_dynamics module, so Python
callers (the dynamics_sim follower, analysis scripts) evaluate the EXACT code
the optimizer's dynamics cost term runs.

The PARAMETERS need the same care: the authoritative runtime config is the
planner yaml's `optimization/dynamics_*` ROS parameters (this package's own
config/vehicle_dynamics.yaml is reference-only and NOT loaded at runtime — its
header says so, and it is already stale: margin 0.02 vs the live 0.08). The
C++ consumers each hand-map those ROS params onto Parameters
(poly_traj_optimizer setParam, trajectory_metrics_panel); this module owns
that mapping for Python so the follower does not grow a third copy:

    params, units = load_planner_parameters(optimizer_yaml_path)   # or
    params, units = parameters_from_ros(node_param_dict)

Units are SI (m, m/s, N, Pa, rad). Planner-frame conversion is the caller's
job, but the scale is NOT a hardcoded 100: it is the returned `units`
(optimization/dynamics_unit_xy_m / _unit_z_m — both 100.0 today, and read
from config precisely so a retune cannot desynchronize a hardcoding).
"""
import math
from typing import Mapping, NamedTuple, Tuple

from mmp_vehicle_dynamics._flight_dynamics import (  # noqa: F401
    Parameters,
    Evaluation,
    CostGradient,
    EnvelopeLimit,
    BANK_MEANINGFUL_LOAD_FACTOR,
    BANK_NEGATIVE_NZ,
    parameters_are_valid,
    air_density,
    evaluate_inverse_dynamics,
    flight_envelope_penalty,
    envelope_utilization,
    is_within_envelope,
    envelope_limit_name,
)


class FrameUnits(NamedTuple):
    """Planner-frame unit sizes in metres (frame value * unit = SI metres)."""
    xy_m: float
    z_m: float


# optimization/dynamics_* ROS param -> Parameters field. Mirrors the mapping
# in trajectory_metrics_panel.cpp / poly_traj_optimizer setParam; the two
# *_deg params convert to radians below.
_PARAM_FIELDS = {
    'dynamics_mass_kg': 'mass_kg',
    'dynamics_wing_area_m2': 'wing_area_m2',
    'dynamics_g': 'gravity_mps2',
    'dynamics_rho0_kgpm3': 'sea_level_density_kgpm3',
    'dynamics_density_scale_height_m': 'density_scale_height_m',
    'dynamics_altitude_reference_m': 'altitude_reference_m',
    'dynamics_cd0': 'zero_lift_drag_coefficient',
    'dynamics_induced_drag_factor': 'induced_drag_factor',
    'dynamics_cl_min': 'lift_coefficient_min',
    'dynamics_cl_max': 'lift_coefficient_max',
    'dynamics_load_factor_max': 'load_factor_max',
    'dynamics_thrust_min_n': 'thrust_min_n',
    'dynamics_thrust_max_n': 'thrust_max_n',
    'dynamics_speed_min_mps': 'speed_min_mps',
    'dynamics_speed_max_mps': 'speed_max_mps',
    'dynamics_activation_speed_mps': 'model_activation_speed_mps',
    'dynamics_dynamic_pressure_max_pa': 'dynamic_pressure_max_pa',
    'dynamics_margin': 'constraint_margin',
    'dynamics_penalty_speed': 'penalty_speed',
    'dynamics_penalty_lift': 'penalty_lift',
    'dynamics_penalty_load': 'penalty_load',
    'dynamics_penalty_thrust': 'penalty_thrust',
    'dynamics_penalty_dynamic_pressure': 'penalty_dynamic_pressure',
    'dynamics_penalty_bank': 'penalty_bank',
    'dynamics_penalty_flight_path': 'penalty_flight_path',
}
_PARAM_DEG_FIELDS = {
    'dynamics_bank_max_deg': 'bank_angle_max_rad',
    'dynamics_flight_path_max_deg': 'flight_path_angle_max_rad',
}
_PREFIX = 'optimization/'


def parameters_from_ros(values: Mapping[str, float]) -> Tuple[Parameters, FrameUnits]:
    """Build Parameters from `optimization/dynamics_*` ROS parameter values.

    `values` maps fully-qualified names (e.g. 'optimization/dynamics_margin')
    or bare suffixes ('dynamics_margin') to numbers. Missing keys keep the
    C++ header defaults. Returns (Parameters, FrameUnits).
    """
    def get(suffix):
        if _PREFIX + suffix in values:
            return values[_PREFIX + suffix]
        return values.get(suffix)

    p = Parameters()
    for suffix, field in _PARAM_FIELDS.items():
        v = get(suffix)
        if v is not None:
            setattr(p, field, float(v))
    for suffix, field in _PARAM_DEG_FIELDS.items():
        v = get(suffix)
        if v is not None:
            setattr(p, field, math.radians(float(v)))
    units = FrameUnits(
        xy_m=float(get('dynamics_unit_xy_m') or 100.0),
        z_m=float(get('dynamics_unit_z_m') or 100.0),
    )
    return p, units


def load_planner_parameters(optimizer_yaml_path: str) -> Tuple[Parameters, FrameUnits]:
    """Load the AUTHORITATIVE dynamics config from the planner yaml
    (path_manager's optimizer_params.yaml) — the same file every C++ consumer
    is parameterized from at runtime."""
    import yaml
    with open(optimizer_yaml_path) as fp:
        root = yaml.safe_load(fp)
    values = root['/**']['ros__parameters']
    return parameters_from_ros(values)

// Direct tests for the shared 3DOF point-mass EOM (point_mass_eom.hpp).
//
// The inverse-dynamics suite next door cannot pin this header: it judges
// states, this header EVOLVES them. Each case here has a closed-form
// expectation derived from the textbook equations, so a regression means
// the extracted formulas drifted from the physics — not that a tolerance
// was tuned wrong.
#include <cmath>

#include <gtest/gtest.h>

#include <mmp_vehicle_dynamics/point_mass_eom.hpp>

namespace md = mmp_vehicle_dynamics;

namespace {

md::Parameters params()
{
  md::Parameters p;  // header defaults = the neutral benchmark assumptions
  return p;
}

md::PointMassState level(double v, double heading = 0.0)
{
  md::PointMassState s;
  s.position_m = Eigen::Vector3d(0.0, 0.0, 1000.0);
  s.speed_mps = v;
  s.flight_path_angle_rad = 0.0;
  s.heading_rad = heading;
  return s;
}

}  // namespace

TEST(PointMassEom, VelocityComponents)
{
  md::PointMassState s;
  s.speed_mps = 200.0;
  s.flight_path_angle_rad = 0.3;
  s.heading_rad = 1.1;
  const Eigen::Vector3d v = md::pointMassVelocity(s);
  EXPECT_NEAR(v.x(), 200.0 * std::cos(0.3) * std::cos(1.1), 1e-12);
  EXPECT_NEAR(v.y(), 200.0 * std::cos(0.3) * std::sin(1.1), 1e-12);
  EXPECT_NEAR(v.z(), 200.0 * std::sin(0.3), 1e-12);
  EXPECT_NEAR(v.norm(), 200.0, 1e-12);
}

// Level steady flight: T = D, L = mg, mu = 0 -> every rate is zero.
TEST(PointMassEom, LevelSteadyFlightAllRatesZero)
{
  const md::Parameters p = params();
  const md::PointMassState s = level(180.0);
  md::PointMassInputs u;
  u.lift_n = p.mass_kg * p.gravity_mps2;
  u.bank_rad = 0.0;
  // Drag at whatever CL that lift needs, thrust exactly cancelling it.
  const double rho = md::airDensity(p, s.position_m.z());
  const double q = 0.5 * rho * s.speed_mps * s.speed_mps;
  const double cl = u.lift_n / (q * p.wing_area_m2);
  u.drag_n = q * p.wing_area_m2 *
             (p.zero_lift_drag_coefficient + p.induced_drag_factor * cl * cl);
  u.thrust_n = u.drag_n;
  const md::PointMassDerivative d = md::pointMassDerivative(p, s, u);
  EXPECT_NEAR(d.speed, 0.0, 1e-9);
  EXPECT_NEAR(d.flight_path_angle, 0.0, 1e-9);
  EXPECT_NEAR(d.heading, 0.0, 1e-9);
  EXPECT_NEAR(d.position.z(), 0.0, 1e-9);
}

// Steady coordinated level turn: L*cos(mu) = mg -> psidot = g*tan(mu)/V,
// gammadot = 0.
TEST(PointMassEom, SteadyTurnHeadingRate)
{
  const md::Parameters p = params();
  const double v = 160.0, mu = 0.5;
  const md::PointMassState s = level(v);
  md::PointMassInputs u;
  u.bank_rad = mu;
  u.lift_n = p.mass_kg * p.gravity_mps2 / std::cos(mu);
  u.thrust_n = u.drag_n = 0.0;  // tangential terms cancel out of these two
  const md::PointMassDerivative d = md::pointMassDerivative(p, s, u);
  EXPECT_NEAR(d.flight_path_angle, 0.0, 1e-9);
  EXPECT_NEAR(d.heading, p.gravity_mps2 * std::tan(mu) / v, 1e-9);
}

// Steady climb: T = D + mg*sin(gamma), L = mg*cos(gamma), mu = 0 ->
// Vdot = 0 and gammadot = 0 (straight climbing line).
TEST(PointMassEom, SteadyClimbRatesZero)
{
  const md::Parameters p = params();
  const double gamma = 0.35;
  md::PointMassState s = level(170.0);
  s.flight_path_angle_rad = gamma;
  md::PointMassInputs u;
  u.bank_rad = 0.0;
  u.lift_n = p.mass_kg * p.gravity_mps2 * std::cos(gamma);
  u.drag_n = 4000.0;  // arbitrary; thrust is set to balance it exactly
  u.thrust_n = u.drag_n + p.mass_kg * p.gravity_mps2 * std::sin(gamma);
  const md::PointMassDerivative d = md::pointMassDerivative(p, s, u);
  EXPECT_NEAR(d.speed, 0.0, 1e-9);
  EXPECT_NEAR(d.flight_path_angle, 0.0, 1e-9);
  EXPECT_NEAR(d.position.z(), 170.0 * std::sin(gamma), 1e-9);
}

// Force closure: realized CL/thrust/drag follow the shared polar exactly.
TEST(PointMassEom, ForceClosureUnsaturated)
{
  const md::Parameters p = params();
  const md::PointMassState s = level(180.0);
  const double cl_cmd = 0.6, thrust_cmd = 2000.0, bank_cmd = 0.2;
  const md::PointMassForceResult r =
      md::pointMassForces(p, s, cl_cmd, thrust_cmd, bank_cmd);
  const double rho = md::airDensity(p, s.position_m.z());
  const double q = 0.5 * rho * 180.0 * 180.0;
  EXPECT_NEAR(r.inputs.lift_n, q * p.wing_area_m2 * cl_cmd, 1e-9);
  EXPECT_NEAR(r.inputs.drag_n,
              q * p.wing_area_m2 *
                  (p.zero_lift_drag_coefficient +
                   p.induced_drag_factor * cl_cmd * cl_cmd),
              1e-9);
  EXPECT_NEAR(r.inputs.thrust_n, thrust_cmd, 1e-12);
  EXPECT_NEAR(r.inputs.bank_rad, bank_cmd, 1e-12);
  EXPECT_FALSE(r.saturated());
  EXPECT_TRUE(r.state_representable);
}

// Saturation is REPORTED, never silent: over-commanded CL/thrust/bank all
// clamp to their limits and raise their flags.
TEST(PointMassEom, SaturationIsExplicit)
{
  const md::Parameters p = params();
  const md::PointMassState s = level(180.0);
  const md::PointMassForceResult r = md::pointMassForces(
      p, s, /*cl=*/p.lift_coefficient_max + 1.0,
      /*thrust=*/p.thrust_max_n * 10.0,
      /*bank=*/p.bank_angle_max_rad + 0.5);
  EXPECT_TRUE(r.cl_saturated);
  EXPECT_TRUE(r.thrust_saturated);
  EXPECT_TRUE(r.bank_saturated);
  EXPECT_TRUE(r.saturated());
  const double rho = md::airDensity(p, s.position_m.z());
  const double q = 0.5 * rho * 180.0 * 180.0;
  EXPECT_NEAR(r.inputs.lift_n, q * p.wing_area_m2 * p.lift_coefficient_max,
              1e-9);
  EXPECT_NEAR(r.inputs.thrust_n, p.thrust_max_n, 1e-12);
  EXPECT_NEAR(r.inputs.bank_rad, p.bank_angle_max_rad, 1e-12);
}

// States outside the parameterization's validity are flagged, not absorbed:
// near-zero speed and near-vertical flight path.
TEST(PointMassEom, RepresentabilityIsExplicit)
{
  const md::Parameters p = params();
  md::PointMassState slow = level(0.5);
  EXPECT_FALSE(md::pointMassForces(p, slow, 0.5, 100.0, 0.0)
                   .state_representable);
  md::PointMassState vertical = level(180.0);
  vertical.flight_path_angle_rad = 1.55;  // ~88.8 deg, inside the guard band
  EXPECT_FALSE(md::pointMassForces(p, vertical, 0.5, 100.0, 0.0)
                   .state_representable);
  EXPECT_TRUE(md::pointMassForces(p, level(180.0), 0.5, 100.0, 0.0)
                  .state_representable);
}

int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

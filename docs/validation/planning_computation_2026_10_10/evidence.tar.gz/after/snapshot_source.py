#!/usr/bin/env python3
"""Explicitly allowed source snapshot. Never traverse reports or experiments."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess
parser=argparse.ArgumentParser();parser.add_argument('--tag',required=True,choices=['before','after']);args=parser.parse_args()
repo=Path('/home/suv/ws/temp/MMP_module/MMP');root=Path('/tmp/mmp_next_modularization_20261010/after')
prior_path=repo/'src/mmp_path_planning/docs/validation/planning_library_2026_10_08/refresh/source_manifest_after.json'
prior=json.loads(prior_path.read_text());excluded={'.git','__pycache__','docs','reports','experiments'}
allowed=prior['allowed_roots']+['src/mmp_terrain/data/scenarios/missions/r2_ridge_crossing.yaml','src/mmp_launch/launch/mmp.launch.py']; paths=set()
for rel in allowed:
 p=repo/rel
 assert not set(p.parts)&{'reports','experiments'}
 if not p.exists():continue
 if p.is_file():paths.add(p);continue
 for current,dirs,files in os.walk(p,followlinks=False):
  dirs[:]=sorted(d for d in dirs if d not in excluded)
  for name in files:
   q=Path(current)/name
   if q.is_file() and '__pycache__' not in q.parts:paths.add(q)
entries=[]
for p in sorted(paths):
 rel=p.relative_to(repo);data=p.read_bytes();entries.append({'path':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 if args.tag=='before':
  dest=root/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allowed_roots':allowed,'excluded_dir_names':sorted(excluded),'file_count':len(entries),'super_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'planning_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo/'src/mmp_path_planning',text=True).strip(),'files':entries}
(root/('source_manifest_'+args.tag+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
if args.tag=='after':
 before=json.loads((root/'source_manifest_before.json').read_text());old={e['path']:e for e in before['files']};new={e['path']:e for e in entries};changed=[p for p in sorted(old.keys()|new.keys()) if old.get(p)!=new.get(p)];comparison={'source_count':len(entries),'changed_during_build_and_validation':changed,'pass':not changed};(root/'source_comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps(comparison));assert not changed
else:print('snapshotted',len(entries),'allowed source/config/test files')

#include <utility>
#include <vector>
#include "path_manager/flight_evaluator.h"

path_manager::FlightEvaluationReport evaluateFlatFlight(
    const poly_traj::Trajectory &flight,
    mmp_vehicle_dynamics::VehicleModel::Ptr model)
{
  using namespace path_manager;
  const std::vector<PhaseSpan> phases{
      {flight.getTotalDuration(), PhaseKind::CRUISE, "flight"}};
  FlightEvaluationInput input(flight, phases);
  input.model = std::move(model);
  input.environment.zone_count = 0;
  input.environment.terrain_elevation =
      [](double, double, double *height) {
        *height = 0.0;  // 기존 frame의 절대 지형 z, u
        return true;
      };
  return evaluateFlight(input);
}

int main() { return 0; }

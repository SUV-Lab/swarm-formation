#include <utility>
#include "path_manager/path_manager.h"
#include "path_manager/ros_planning_backend.h"

namespace pm = path_manager;

void runPreparedMission(pm::RosPlanningOptions options,
                        pm::PlanSettings settings,
                        pm::PlanningEnvironment environment,
                        pm::MissionPlanRequest request)
{
  auto backend = pm::makeRosPlanningBackend(std::move(options));
  backend->initialize(std::move(settings), std::move(environment));

  auto computed = backend->compute(std::move(request));
  // computed.hasTrajectory()인 경우 product의 값을 여기서 검사할 수 있다.
  // 이 계산만으로 후보가 실행 궤적 저장소에 채택되지는 않는다.

  // 기존 실행 호환 정책을 적용하기로 한 경우 명시적으로 호출한다.
  // 실패 결과에도 '기존 실행 무효화' 효과가 있을 수 있으므로 이 예는
  // 실패 여부를 확인하기 전에 그 명시적 효과까지 적용한다.
  const auto receipt =
      backend->executionManager()->applyPlanningComputation(computed);
  if (!receipt.applied) return;             // 오래됐거나 다른 문맥
  if (!computed.hasTrajectory()) return;  // 실행할 새 궤적 없음

  const auto &flight = computed.product->trajectory;
  const auto position_at_start = flight.getPos(0.0);
  (void)position_at_start;
  // receipt.trajectory_id로 현재 실행을 식별한다.
  // 이 예에는 토픽 발행이 없다. 실제 애플리케이션은 backend를 유지한다.
}

int main() { return 0; }

Read-only current modularization review: merge hard-profile precedence reproducer

Standalone copy derived from chain_profile_contract_test.cpp, unchanged repository.
Original production libraries and current headers are used. ROS domain 99, attach_visualization=false.

Mission: flat terrain; start=(30,150,4 AGL), velocity=(2,0,0), goal=(330,150,4 AGL), 4 chain segments.
Both cases set seg2.max_vel=seg3.max_vel=2.0 and one-shot fail_segment=2 to exercise merge.
Case A phase.cruise.max_vel=2.0: trajectory returned, 3 phases, successful merge.
Case B phase.cruise.max_vel=0.5: same effective segment requirements but 1 phase, DEGRADED single-plan fallback.

Expected: segment values override phase defaults, so both merged plans have identical coefficients/times.
Observed: one comparison failed. The log contains exact result detail.
Cause: mergedRetryProfile seeds raw phase values and then min-merges effective segment values,
resurrecting an overridden hard maximum. The existing regression tests only an invalid overridden phase.

Production source references:
- segment_chain_planner.cpp:2150-2186: explicit segment precedence.
- segment_chain_planner.cpp:2329-2331: raw phase hard maximum included.
- segment_chain_planner.cpp:2352-2356: min retains overridden lower phase cap.
- chain_profile_contract_test.cpp:127-146: existing invalid-phase test leaves valid overridden phase uncovered.

Rebuild and run: copy reproduce.py into /tmp/mmp_review_merge_phase_20261013 in mmp_dev,
then run reproduce.sh in that container. It uses existing isolated build/install files.

Additional observation (not counted as a separate confirmed blocker):
With cruise phase cap empty, seg2.max_vel=4.0, compare seg3 explicit2.0 against omitted default2.0.
Both succeed with 3 phases; actual maximum speed changes from 2.01000 to 2.21160 u/s, and x=180..255 span max changes from 2.00932 to 2.21160.
Sparse effective overrides omit default caps from merged min. Existing comments promise explicit hard-limit preservation, so intended treatment of inherited defaults needs confirmation before treating this as a separate contract violation.
Standalone source merge_default_probe.cpp, log default_probe.log, builder reproduce_default.py.

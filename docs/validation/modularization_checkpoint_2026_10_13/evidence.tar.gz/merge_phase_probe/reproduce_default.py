from pathlib import Path
import shlex
import subprocess

# Run inside mmp_dev. The standalone probe does not edit repository source.
work = Path('/tmp/mmp_review_merge_phase_20261013')
build = Path('/tmp/mmp_deep_final_audit_20261011/build/path_manager')
flags = {}
for line in (build/'CMakeFiles/chain_profile_contract_test.dir/flags.make').read_text().splitlines():
    if line.startswith('CXX_'):
        key, value = line.split(' = ', 1)
        flags[key] = shlex.split(value)
obj = work/'default_probe.o'
subprocess.run(['/usr/bin/c++'] + flags['CXX_DEFINES'] + flags['CXX_INCLUDES'] + flags['CXX_FLAGS'] + ['-c', str(work/'merge_default_probe.cpp'), '-o', str(obj)], check=True)
link = shlex.split((build/'CMakeFiles/chain_profile_contract_test.dir/link.txt').read_text())
link = [str(obj) if token == 'CMakeFiles/chain_profile_contract_test.dir/test/chain_profile_contract_test.cpp.o' else token for token in link]
link[link.index('-o') + 1] = str(work/'default_probe')
subprocess.run(link, check=True, cwd=build)

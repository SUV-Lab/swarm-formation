#!/usr/bin/env bash
# Run inside mmp_dev; use existing current install/build artifacts.
set -e
python3 /tmp/mmp_review_merge_phase_20261013/reproduce.py
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
export ROS_DOMAIN_ID=99 ROS_LOCALHOST_ONLY=1
export ROS_LOG_DIR=/tmp/mmp_review_merge_phase_20261013/ros_logs
cd /tmp/mmp_review_merge_phase_20261013
./probe /ws/src/mmp_path_planning/src/path_manager/config/optimizer_params.yaml > probe.log 2>&1

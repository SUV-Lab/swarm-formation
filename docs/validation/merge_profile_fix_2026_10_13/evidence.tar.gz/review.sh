#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export CMAKE_BUILD_PARALLEL_LEVEL=3
export ROS_DOMAIN_ID=96
REVIEW_OUT=/tmp/mmp_merge_fix_20261013_Rya4Pi
cd /ws
colcon --log-base "$REVIEW_OUT/colcon_log" build \
  --base-paths /ws/src/mmp_vehicle_dynamics /ws/src/mmp_path_planning/src/path_optimizer /ws/src/mmp_path_planning/src/path_manager \
  --packages-select mmp_vehicle_dynamics path_optimizer path_manager \
  --build-base /tmp/mmp_deep_final_audit_20261011/build \
  --install-base /tmp/mmp_deep_final_audit_20261011/install \
  --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  > "$REVIEW_OUT/build.log" 2>&1
echo 'BUILD_PASS'
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
python3 -B "$REVIEW_OUT/checks.py"

from pathlib import Path
import shlex
import subprocess

root = Path('/tmp/mmp_merge_fix_20261013_Rya4Pi')
build = Path('/tmp/mmp_deep_final_audit_20261011/build/path_manager')
source = Path('/ws/src/mmp_path_planning/src/path_manager/test/chain_profile_contract_test.cpp')
flags = {}
for line in (build/'CMakeFiles/chain_profile_contract_test.dir/flags.make').read_text().splitlines():
    if line.startswith('CXX_'):
        key, value = line.split(' = ', 1)
        flags[key] = shlex.split(value)
obj = root/'baseline_probe.o'
subprocess.run(['/usr/bin/c++'] + flags['CXX_DEFINES'] + flags['CXX_INCLUDES'] + flags['CXX_FLAGS'] + ['-c', str(source), '-o', str(obj)], check=True)
link = shlex.split((build/'CMakeFiles/chain_profile_contract_test.dir/link.txt').read_text())
link = [str(obj) if token == 'CMakeFiles/chain_profile_contract_test.dir/test/chain_profile_contract_test.cpp.o' else token for token in link]
link[link.index('-o') + 1] = str(root/'baseline_probe')
subprocess.run(link, check=True, cwd=build)

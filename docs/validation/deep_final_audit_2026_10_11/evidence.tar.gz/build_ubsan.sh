set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
cd /ws
export CMAKE_BUILD_PARALLEL_LEVEL=3
colcon --log-base /tmp/mmp_deep_final_audit_20261011/ubsan_colcon_log build --base-paths /ws/src/mmp_path_planning/src/path_manager --packages-select path_manager --build-base /tmp/mmp_deep_final_audit_20261011/ubsan_build --install-base /tmp/mmp_deep_final_audit_20261011/ubsan_install --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DMMP_SANITIZE=ON

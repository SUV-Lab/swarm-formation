#include <mmp_vehicle_dynamics/trajectory_simulation.hpp>

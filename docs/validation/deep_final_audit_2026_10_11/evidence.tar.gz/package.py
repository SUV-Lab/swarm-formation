from pathlib import Path
import hashlib,json,os,tarfile,shutil
r=Path('/tmp/mmp_deep_final_audit_20261011')
s=r/'evidence'
d=Path('/home/suv/ws/temp/MMP_module/MMP/src/mmp_path_planning/docs/validation/deep_final_audit_2026_10_11');d.mkdir(parents=True,exist_ok=True)
for name in ['collect.py','package.py']:
 shutil.copy2(r/name,s/name)
files=[]
for base,dirs,names in os.walk(s):
 assert not {'reports','experiments'}&set(Path(base).parts)
 dirs[:]=[x for x in dirs if x not in {'reports','experiments'}]
 for name in names:
  p=Path(base)/name;assert not p.is_symlink()
  if p.is_file():files.append(p)
files.sort()
a=d/'evidence.tar.gz'
with tarfile.open(a,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
m={'archive':{'path':a.name,'bytes':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()},'files':[{'path':str(p.relative_to(s)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(d/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
shutil.copy2(s/'final_validation.json',d/'summary.json')
print(len(files),'files',a.stat().st_size,'bytes')

import rclpy
from rcl_interfaces.msg import SetParametersResult
from mmp_mission_msgs.srv import LoadMap
from mmp_terrain.terrain_publisher import TerrainPublisher
rclpy.init(args=['--ros-args','-p','world:=none'])
n=TerrainPublisher()
before=n.get_parameter('corridor_mission').value
calls=[]
def gate(params):
    for p in params:
        calls.append(p.name)
        if p.name=='world' and p.value=='full_map':
            raise RuntimeError('parameter adapter failure')
    return SetParametersResult(successful=True)
n.add_on_set_parameters_callback(gate)
r=n.load_map_callback(LoadMap.Request(world='full_map', mission_path='/tmp/nonexistent-mission.yaml'),LoadMap.Response())
print('THROW_ROLLBACK',dict(success=r.success,before=before,after=n.get_parameter('corridor_mission').value,world=n.get_parameter('world').value,calls=calls))
n.destroy_node();rclpy.shutdown()

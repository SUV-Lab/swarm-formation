#include "path_manager/planning_environment_store.h"
#include "path_manager/ros_terrain_grid.h"
#include <rclcpp/rclcpp.hpp>
#include <iostream>
#include <limits>
using namespace path_manager;
auto map(double res=1.) { auto m=std::make_shared<grid_map_msgs::msg::GridMap>(); m->info.resolution=res; m->info.length_x=m->info.length_y=20.*res; m->layers={"elevation"}; m->data.resize(1); m->data[0].layout.dim.resize(2); m->data[0].layout.dim[0].size=m->data[0].layout.dim[1].size=20; m->data[0].data.assign(400,2.f); return m; }
int main(int argc,char**argv){rclcpp::init(argc,argv); auto log=std::make_shared<swarm_formation::LogManager>("probe","/tmp/mmp_deep_environment_probe/logs",swarm_formation::LogManager::ERROR); PlanningEnvironmentOptions opts{1.,.1,true,3.,true,42,true,.35,false,0.,.1,true};
PlanningEnvironmentStore s(opts,log); s.ingestTerrain(map()); s.ensureTerrainDistanceField(); s.refreshRisk(); auto rev=s.revision(); auto bad=map(2.); bad->data[0].data.clear(); auto u=s.ingestTerrain(bad); std::cout << "REJECT_MUTATION rejected="<<!u.accepted()<<" voxel="<<s.voxelSize()<<" terrain_res="<<s.terrain().resolution<<" rev_unchanged="<<(rev==s.revision())<<"\n";
PlanningEnvironmentStore n(opts,log); auto nf=map(); nf->info.length_x=std::numeric_limits<double>::quiet_NaN(); auto d=decodeTerrainGrid(nf); auto nu=n.ingestTerrain(nf); std::cout<<"NONFINITE decode_rejected="<<(d.update==TerrainGridUpdate::REJECTED)<<" store_accepted="<<nu.accepted()<<" valid="<<n.terrain().valid<<"\n";
PlanningEnvironmentStore o(opts,log); o.ingestTerrain(map()); o.ensureTerrainDistanceField(); int id=o.addSphere(Eigen::Vector3d(0,0,0),-1.); std::cout<<"NEG_RADIUS id="<<id<<" active="<<o.distanceField().numActiveObstacles()<<" distance="<<o.distanceField().getDistance(Eigen::Vector3d(0,0,0))<<"\n";
auto malformed=map(2.); malformed->layers={"foo"}; auto rr=decodeTerrainGrid(malformed); bool receipt=malformed->info.resolution>0.&&!malformed->data.empty(); std::cout<<"FALSE_RECEIPT decode_rejected="<<(rr.update==TerrainGridUpdate::REJECTED)<<" fsm_receipt_published="<<receipt<<"\n";
rclcpp::shutdown();}

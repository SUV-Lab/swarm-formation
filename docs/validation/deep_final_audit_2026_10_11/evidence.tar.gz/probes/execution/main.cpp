// [ENV-CHANGE / ABORT] The PRODUCTION plumbing, driven through ReplanFSM.
//
// Everything else about this feature is pinned one layer down: the manager's
// detection (chain_experiment_test `envchange`) and the consumer's rules
// (exec_abort_test). What neither can see is whether the real callbacks pass
// the right things — whether the terrain path really says TERRAIN_BLOCKED,
// whether a zone update really fires once and only on a change, and whether
// a mission after an abort really leaves WAIT_EXTERNAL_RECOVERY and gets
// published. Those are all decided in ReplanFSM, so this stands one up.
//
// ORDER MATTERS AND IS NOT ARBITRARY. The zone set starts EMPTY (the params
// file ships no risk_zones), so the FIRST non-empty batch is itself a change.
// It has to go in BEFORE a trajectory exists, or it aborts the flight the
// no-op case is supposed to be checked against — the first draft of this
// ordering did exactly that.
//
// Registered regression: use a level, feasible flight so safety-gate refusal
// cannot prevent the callback/ABORT scenarios below from being exercised.

#include <chrono>
#include <cmath>
#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <grid_map_msgs/msg/grid_map.hpp>

#include "path_manager/replan_fsm.h"
#include "mmp_mission_msgs/msg/trajectory_command.hpp"
#include "mmp_mission_msgs/msg/risk_zone_array.hpp"
#include "mmp_mission_msgs/msg/risk_zone_spec.hpp"
#include "mmp_mission_msgs/msg/dynamic_obstacle_array.hpp"
#include "mmp_mission_msgs/msg/dynamic_obstacle_spec.hpp"
#include "mmp_traj_msgs/msg/poly_traj.hpp"
#include "mmp_traj_msgs/msg/trajectory_execution_control.hpp"

using Ctl = mmp_traj_msgs::msg::TrajectoryExecutionControl;
using Traj = mmp_traj_msgs::msg::PolyTraj;

namespace {

int g_failed = 0;
void expect(bool c, const std::string &label) {
  std::cout << "  " << (c ? "[OK]   " : "[FAIL] ") << label << "\n";
  if (!c) ++g_failed;
}

// Flat DEM at `height`, identical geometry every time so a re-ingest does not
// take the geometry-changed branch (which clears dynamic obstacles and
// rebuilds the SDF — a different event from "the ground moved").
grid_map_msgs::msg::GridMap::SharedPtr makeFlatMap(double height) {
  auto msg = std::make_shared<grid_map_msgs::msg::GridMap>();
  constexpr double kRes = 2.0, kLx = 360.0, kLy = 300.0;
  constexpr int kRows = static_cast<int>(kLx / kRes);
  constexpr int kCols = static_cast<int>(kLy / kRes);
  msg->info.resolution = kRes;
  msg->info.length_x = kLx;
  msg->info.length_y = kLy;
  msg->info.pose.position.x = kLx / 2.0;
  msg->info.pose.position.y = kLy / 2.0;
  msg->layers.push_back("elevation");
  msg->data.resize(1);
  auto &layer = msg->data.front();
  layer.layout.dim.resize(2);
  layer.layout.dim[0].label = "column_index";
  layer.layout.dim[0].size = kCols;
  layer.layout.dim[0].stride = kCols * kRows;
  layer.layout.dim[1].label = "row_index";
  layer.layout.dim[1].size = kRows;
  layer.layout.dim[1].stride = kRows;
  layer.data.assign(static_cast<size_t>(kCols) * kRows,
                    static_cast<float>(height));
  return msg;
}

mmp_mission_msgs::msg::RiskZoneArray::SharedPtr makeZones(
    const std::vector<std::array<double, 5>> &zs) {
  auto m = std::make_shared<mmp_mission_msgs::msg::RiskZoneArray>();
  m->replace = true;
  for (const auto &z : zs) {
    mmp_mission_msgs::msg::RiskZoneSpec s;
    s.center.x = z[0]; s.center.y = z[1]; s.center.z = z[2];
    s.reach = z[3]; s.peak = z[4];
    m->zones.push_back(s);
  }
  return m;
}

mmp_mission_msgs::msg::TrajectoryCommand::SharedPtr makeMission(
    int seq, const std::string &mission_id, double gx, double gy, double gz) {
  auto m = std::make_shared<mmp_mission_msgs::msg::TrajectoryCommand>();
  m->drone_id = 0;
  m->sequence = seq;
  m->mission_id = mission_id;
  m->target_position.x = gx;
  m->target_position.y = gy;
  m->target_position.z = gz;
  m->use_initial_speed = true;
  m->initial_speed = 200.0;
  m->start_position.x = 30.0;
  m->start_position.y = 150.0;
  m->start_position.z = 4.0;  // AGL; avoid an unintended ground-launch test
  return m;
}

void spin(rclcpp::Node::SharedPtr n, int ms) {
  const auto t0 = std::chrono::steady_clock::now();
  while (std::chrono::steady_clock::now() - t0 < std::chrono::milliseconds(ms)) {
    rclcpp::spin_some(n);
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }
}

}  // namespace

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.arguments({"--ros-args", "--params-file", argv[1]});
  options.parameter_overrides({rclcpp::Parameter("drone_id", 0), rclcpp::Parameter("chain/enable", false)});
  auto node = rclcpp::Node::make_shared("fsm_input_probe", options);
  path_manager::ReplanFSM fsm(node);
  fsm.terrainCallback(makeFlatMap(0.0));
  fsm.trajectoryCommandCallback(makeMission(1, "A", 330.0, 150.0, 4.0));
  Traj initial; fsm.polyTraj2ROSMsg(initial);
  auto bad = makeMission(2, "B", 330.0, 150.0, 4.0);
  bad->initial_speed = 400.0;
  bad->obstacle_clearance = std::numeric_limits<double>::infinity();
  fsm.trajectoryCommandCallback(bad);
  fsm.trajectoryCommandCallback(makeMission(2, "B", 330.0, 150.0, 4.0));
  Traj after; fsm.polyTraj2ROSMsg(after);
  std::cout << "AUDIT_IDS " << initial.trajectory_id << " " << after.trajectory_id << std::endl;
  rclcpp::shutdown();
  return after.trajectory_id > initial.trajectory_id ? 0 : 17;
}

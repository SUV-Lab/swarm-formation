from pathlib import Path
import json, hashlib, shutil, subprocess, re, os
root=Path('/tmp/mmp_deep_final_audit_20261011')
out=root/'evidence';out.mkdir(exist_ok=True)
repo=Path('/home/suv/ws/temp/MMP_module/MMP')
def safe(p):
 assert not {'reports','experiments'} & set(Path(p).parts),p
 return Path(p)
def cp(src,dst):
 src=safe(src);dst=out/safe(dst);dst.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(['docker','cp','mmp_dev:'+str(src),str(dst)],check=True,capture_output=True)
def local(src,dst):
 src=safe(src);dst=out/safe(dst);dst.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(src,dst)
for name in ['before_tests','tests','inputs_before.json','inputs_after.json','build.log','build_final.log','build_registration.log','build_default.log','build_ubsan_final.log','ubsan_tests.log','ctest_final.log','runtime_final.log','examples_final.log','headers_final.log','python_tests.log','all_tests.xml','installed_test_imports.json','chain_metrics.json','fixed_yaw_comparison.json']:
 cp(root/name,name)
for phase in ['before_runtime','runtime']:
 for name in ['summary.json','result.json','result.json.metrics.json','inputs_before.json','inputs_after.json','r2.log','terrain.log','configure.log','build.log','project','build/compile_commands.json']:
  cp(root/phase/name,phase+'/'+name)
for name in ['build.log','vehicle.log']:
 cp(root/'sanitizer'/name,'sanitizer/'+name)
cp(root/'ubsan_build/path_manager/Testing/Temporary/LastTest.log','sanitizer/ubsan_details.log')
cp(root/'ubsan_build/path_manager/CTestTestfile.cmake','sanitizer/CTestTestfile.cmake')
cp(root/'header_build/compile_commands.json','header_compile_commands.json')
cp(root/'examples_build/compile_commands.json','examples_compile_commands.json')
for name in ['comparison.json','before.bin','after.bin','before.log','after.log','fixture.cpp','CMakeLists.txt','run.sh','build_before.log','build_after.log']:
 cp(root/'environment_lifecycle'/name,'environment_lifecycle/'+name)
for name in ['probe.cpp','CMakeLists.txt','run.sh','run_final.log','audit_result.json','source_hashes.json']:
 cp(root/'computation_probe'/name,'computation_probe/'+name)
# Keep the initial registration failure and interrupted stale-registration run distinct.
for name in ['tests/summary.json','tests/path_manager/chain_profile_contract_test.log','ctest_final.log','build_final.log']:
 cp(root/'checkpoint1'/name,'checkpoints/first/'+name)
cp(root/'checkpoint2_interrupted/ctest_final.log','checkpoints/interrupted/ctest.log')
cp(root/'checkpoint2_interrupted/wrong_fixed_yaw_invocation.log','checkpoints/wrong_fixed_yaw_invocation.log')
for name in ['dynprobe.log']:
 cp(root/'fixed_yaw'/name,'chain_comparison/fixed_after/'+name)
 cp(Path('/tmp/mmp_chain_settings_20261011/fixed_yaw_before')/name,'chain_comparison/fixed_before/'+name)
cp('/tmp/mmp_chain_settings_20261011/fixed_yaw_params.yaml','chain_comparison/fixed_yaw_params.yaml')
cp('/tmp/mmp_chain_settings_20261011/compare_metrics.py','chain_comparison/compare_metrics.py')
# Copy only flat, explicitly enumerated variant logs; no nested output traversal.
variants=json.loads((out/'tests/path_manager/ctest_discovery.json').read_text())
for p in (out/'tests/path_manager/chain_variants').glob('*.log'):
 cp('/tmp/mmp_finish_modularization_20261011/tests/path_manager/chain_variants/'+p.name,'chain_comparison/before/'+p.name)
for name in ['gui_harness.py','gui_driver.log','build.sh','build_default.sh','build_ubsan.sh','run_fresh_tests.py','run_tests.sh','run_installed_runtime.py','run_examples.sh','run_pytest_installed.py','freeze_inputs.py','prior_registered_tests.json','before_source_hashes.json','before_worktree.patch']:
 local(root/name,name)
for folder in ['gui','baseline_source','header_project']:
 for base,dirs,names in os.walk(root/folder):
  dirs[:]=[x for x in dirs if x not in {'reports','experiments'}]
  for name in names:
   p=Path(base)/name;local(p,p.relative_to(root))
for group,d in [('environment','/tmp/mmp_deep_environment_probe'),('execution','/tmp/mmp_execution_deep_audit'),('settings','/tmp/mmp_deep_settings_probe')]:
 for p in Path(d).iterdir():
  if p.is_file() and p.suffix in {'.cpp','.txt','.json','.py','.log'}:local(p,'probes/'+group+'/'+p.name)
for name in ['result.log','build.log','fsm_scenarios_test.cpp','replan_fsm.cpp','include/path_manager/replan_fsm.h']:
 local(Path('/tmp/mmp_execution_deep_audit/overlay')/name,'probes/execution/overlay/'+name)
# Exact code snapshot, including prior uncommitted code, never figures or unrelated files.
sub=repo/'src/mmp_path_planning'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=sub,text=True).splitlines()
new=['src/path_manager/'+p for p in ['include/path_manager/direct_plan_settings.h','include/path_manager/planning_execution.h','include/path_manager/planning_environment_store.h','src/planning_execution.cpp','src/planning_environment_store.cpp','src/terrain_grid_validation.h','test/direct_plan_settings_test.cpp','test/planning_execution_test.cpp','test/planning_environment_store_test.cpp','test/chain_profile_contract_test.cpp']]
source={}
for name in sorted(set(changed+new)):
 if not name.startswith('src/'):continue
 p=safe(sub/name);key='src/mmp_path_planning/'+name;local(p,'source_snapshot/'+key)
 source[key]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
for name in ['map/test_terrain_publisher_env.py','src/mmp_terrain/mmp_terrain/terrain_publisher.py']:
 p=repo/name;local(p,'source_snapshot/'+name);source[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(out/'source_snapshot_manifest.json').write_text(json.dumps(source,indent=2)+'\n')
solver='src/path_optimizer/src/poly_traj_optimizer.cpp'
a=subprocess.check_output(['git','show','HEAD:'+solver],cwd=sub);b=(sub/solver).read_bytes();assert a==b
(out/'solver_identity.json').write_text(json.dumps({'unchanged_vs_checkout':True,'sha256':hashlib.sha256(b).hexdigest(),'file':solver},indent=2)+'\n')
t=json.loads((out/'tests/summary.json').read_text());assert t['pass'] and t['total_test_count']==54
assert json.loads((out/'runtime/summary.json').read_text())['pass']
assert (out/'runtime/result.json').read_bytes()==(out/'before_runtime/result.json').read_bytes()
assert json.loads((out/'gui/summary.json').read_text())['pass']
assert json.loads((out/'inputs_before.json').read_text())['files']==json.loads((out/'inputs_after.json').read_text())['files']
ubsan=(out/'ubsan_tests.log').read_text();assert '100% tests passed, 0 tests failed out of 45' in ubsan
assert 'runtime error:' not in (out/'sanitizer/ubsan_details.log').read_text()
assert '[  PASSED  ] 41 tests.' in (out/'sanitizer/vehicle.log').read_text()
assert '70 passed' in (out/'python_tests.log').read_text()
assert 'total checks=4413' in (out/'computation_probe/run_final.log').read_text()
c=json.loads((out/'chain_metrics.json').read_text());assert c['exact_printed_match']==74 and [k for k,v in c['results'].items() if not v['equal']]==['dynprobe.log']
assert json.loads((out/'fixed_yaw_comparison.json').read_text())['exact_printed_match']==1
summary={'pass':True,'ctest':54,'packages':{'path_manager':45,'path_optimizer':3,'mmp_vehicle_dynamics':6},'chain_variants':75,'risk_checks':154,'python_tests':70,'installed_examples':4,'public_headers':21,'independent_computation_assertions':4413,'vehicle_asan_ubsan_tests':41,'path_manager_ubsan_tests':45,'r2_owned_byte_exact':True,'r2_owned_sha256':hashlib.sha256((out/'runtime/result.json').read_bytes()).hexdigest(),'rviz_r2_exact':True,'abort_recovery_exact':True,'input_hashes_unchanged':435,'chain_printed_match':74,'chain_random_yaw_controlled_exact':True,'environment_lifecycle':json.loads((out/'environment_lifecycle/comparison.json').read_text()),'optimizer_cpp_unchanged':True,'defect_groups_fixed':6,'source_snapshot_count':len(source),'performance':'No new timing/performance or general mission success-rate claim.','initial_test_registration_error':'Body passed; missing ament result-generation option corrected. An outdated configured run was interrupted; final reconfigured Release54 and clean UBSan45 passed.','prohibited_directories':'reports and experiments not read or traversed.','source_scope':'Current dirty work preserved; no stash restore, commit, push, or unrelated file edits.'}
(out/'final_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='environment_lifecycle'},ensure_ascii=False,indent=2))

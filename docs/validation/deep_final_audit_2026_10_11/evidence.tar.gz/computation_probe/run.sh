set -e
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
cmake -S /tmp/mmp_deep_final_audit_20261011/computation_probe -B /tmp/mmp_deep_final_audit_20261011/computation_probe/build -DCMAKE_BUILD_TYPE=Release
cmake --build /tmp/mmp_deep_final_audit_20261011/computation_probe/build --parallel 1
/tmp/mmp_deep_final_audit_20261011/computation_probe/build/probe

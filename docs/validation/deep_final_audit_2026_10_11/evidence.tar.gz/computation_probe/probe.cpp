#include <path_manager/flight_evaluator.h>
#include <path_manager/planning_visualization_data.h>
#include <mmp_vehicle_dynamics/trajectory_simulation.hpp>
#include <iostream>
#include <stdexcept>
#include <random>
#include <cmath>
#include <limits>

namespace pm=path_manager;
namespace viz=path_manager::visualization;
namespace vd=mmp_vehicle_dynamics;
int checks=0;
void check(bool c,const char* s) { ++checks; if(!c)throw std::runtime_error(s); }
bool near(double a,double b,double eps=1e-9){return std::abs(a-b)<=eps;}

poly_traj::Trajectory flight(double a,double b,const Eigen::Vector3d&p,const Eigen::Vector3d&v){
 poly_traj::CoefficientMat c=poly_traj::CoefficientMat::Zero(); c.col(5)=p;c.col(4)=v;
 auto d=c;d.col(5)=p+a*v;
 return poly_traj::Trajectory({a,b},{c,d});
}
pm::FlightEvaluationReport report(const poly_traj::Trajectory& t,const Eigen::Vector3d& offset) {
 std::vector<pm::PhaseSpan> phases{{t[0].getDuration(),pm::PhaseKind::CRUISE,"one"},{t.getTotalDuration(),pm::PhaseKind::TERMINAL,"two"}};
 pm::FlightEvaluationInput in{t,phases};
 in.environment.terrain_elevation=[offset](double x,double y,double*z){*z=0.25*(x-offset.x())-0.125*(y-offset.y())+offset.z();return true;};
 return pm::evaluateFlight(in);
}
int main(){
 try {
 std::mt19937 gen(20261011); std::uniform_real_distribution<double> value(-2,2),dur(0.2,3);
 const viz::Stamp stamp=[] {builtin_interfaces::msg::Time s;s.sec=17;return s;};
 for(int iteration=0;iteration<100;++iteration){
  double a=dur(gen),b=dur(gen);Eigen::Vector3d p(value(gen),value(gen),3+value(gen));Eigen::Vector3d v(value(gen),value(gen),value(gen));
  const Eigen::Vector3d offset(128,-256,64);
  auto t=flight(a,b,p,v), shifted=flight(a,b,p+offset,v);
  auto r=report(t,Eigen::Vector3d::Zero()),s=report(shifted,offset);
  int count=0,below=0;double sum=0,min=std::numeric_limits<double>::infinity();
  for(double time=0;time<a+b;time+=0.1){auto point=(p+time*v).eval();double agl=point.z()-0.25*point.x()+0.125*point.y();++count;sum+=agl;min=std::min(min,agl);below+=agl<0;}
  check(r.verdict.evaluated&&s.verdict.evaluated,"evaluation not performed");
  check(r.total.n==count&&r.total.n_below_ground==below,"manual sample count or ground classification");
  check(near(r.total.agl_sum,sum)&&near(r.total.min_agl,min),"manual analytic AGL");
  check(near(r.total.agl_sum,s.total.agl_sum)&&near(r.total.min_agl,s.total.min_agl),"translation changed relative terrain measurements");
  check(r.verdict.clean==s.verdict.clean&&r.verdict.underground==s.verdict.underground,"translation changed verdict");
  for(size_t i=0;i<r.phases.size();++i)check(r.phase_metrics[i].n==s.phase_metrics[i].n&&near(r.phase_metrics[i].agl_sum,s.phase_metrics[i].agl_sum),"translation changed phase partition");
  auto tube=viz::makeTrajectoryTube(t,0,1,"fixture",1,1,1,1,stamp),tube_shift=viz::makeTrajectoryTube(shifted,0,1,"fixture",1,1,1,1,stamp);
  check(tube&&tube_shift&&tube->points.size()==tube_shift->points.size(),"tube sample grid mismatch");
  for(size_t i=0;i<tube->points.size();++i) {
   const auto&x=tube->points[i];const auto&y=tube_shift->points[i];
   check(near(y.x-x.x,offset.x())&&near(y.y-x.y,offset.y())&&near(y.z-x.z,offset.z()),"tube geometry coordinate translation");
  }
 }
 std::cout<<"PASS 100 random two-piece flights: analytic AGL/count/classification, translated environment and phase/tube invariance; checks="<<checks<<"\n";
 auto simulateAt=[](double x,double y){
  vd::PolynomialReference ref;ref.order=1;ref.durations={3};ref.coefficients_x={130,static_cast<float>(x)};ref.coefficients_y={0,static_cast<float>(y)};ref.coefficients_z={0,300};ref.unit_xy_m=1;ref.unit_z_m=1;
  vd::SimulationInput input;input.reference=ref;input.initial_state=vd::makeInitialSimulationState(ref,120,40);input.settings.integration_step_s=0.02;
  input.model=std::make_shared<vd::FixedWingMotionModel>(vd::Parameters{});input.controller=std::make_shared<vd::ReferenceTrackingController>();return vd::simulate(std::move(input));
 };
 auto a=simulateAt(0,0),b=simulateAt(128,-256);
 check(a.status==vd::SimulationStatus::COMPLETED&&b.status==a.status,"simulation completion");check(a.states.size()==b.states.size(),"simulation time grid");
 double maxerr=0;
 for(size_t i=0;i<a.states.size();++i){
  const auto&x=a.states[i];const auto&y=b.states[i];
  double e=(y.position_m-x.position_m-Eigen::Vector3d(128,-256,0)).norm();maxerr=std::max(maxerr,e);
  check(near(x.time_s,y.time_s,0)&&e<1e-8&&near(x.speed_mps,y.speed_mps,1e-8)&&near(x.heading_rad,y.heading_rad,1e-8)&&near(x.flight_path_angle_rad,y.flight_path_angle_rad,1e-8),"physical history changed with horizontal frame origin");
 }
 check(near(a.metrics.peak_tracking_error_m,b.metrics.peak_tracking_error_m,1e-8)&&near(a.metrics.peak_envelope_utilization,b.metrics.peak_envelope_utilization,1e-8)&&a.metrics.violation_steps==b.metrics.violation_steps,"simulation audit changed under origin shift");
 std::cout<<"PASS fixed-wing shared-engine origin shift: "<<a.states.size()<<" states, max positional residual="<<maxerr<<"; total checks="<<checks<<"\n";
 }catch(const std::exception&e){std::cerr<<"FAIL after "<<checks<<" checks: "<<e.what()<<"\n";return 1;}
}

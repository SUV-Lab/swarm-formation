from pathlib import Path
import os,sys,json,time,hashlib,subprocess,signal,shutil,datetime
BASE=Path(sys.argv[1]).resolve();BASE.mkdir(parents=True,exist_ok=True)
OLD=Path('/tmp/mmp_internal_cleanup_20261011/baseline')
assert os.environ.get('ROS_DOMAIN_ID')=='94'
ENV=dict(os.environ)
for k in ['MMP_VALUE_INPUT','MMP_VISUALIZATION_OFF','MMP_REUSE_CONNECTED_COMPLETE']:ENV.pop(k,None)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def inputs():
 out={}
 for key,v in json.loads((OLD/'identity_comparison.json').read_text())['checks'].items():
  p=Path(v['path']);assert not {'reports','experiments'}&set(p.parts)
  out[key]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 p=Path('/tmp/mmp_deep_final_audit_20261011/install/path_manager/lib/path_manager/path_manager_node')
 out['installed_node']={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 return out
summary={'checks':{},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One installed consumer numerical regression run. Measurements are recorded by the identical baseline instrumentation but this checkpoint is NOT used as a performance sample.'}
def run(name,cmd,timeout=900):
 with (BASE/(name+'.log')).open('w') as f:
  x=subprocess.run(cmd,cwd=BASE,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 summary['checks'][name]={'command':cmd,'exit_code':x.returncode}
 print(name,x.returncode,flush=True)
 if x.returncode:raise RuntimeError(name+' failed')
def stop(p):
 if p is None or p.poll() is not None:return
 os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=15)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
terrain=None
try:
 before=inputs();(BASE/'inputs_before.json').write_text(json.dumps(before,indent=2)+'\n')
 project=BASE/'project';project.mkdir(exist_ok=False)
 for n in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']:shutil.copy2(OLD/'project'/n,project/n)
 summary['measurement_source_unchanged']={n:sha(project/n)==sha(OLD/'project'/n) for n in ['CMakeLists.txt','main.cpp','recorded_request.h','value_settings.h']}
 run('configure',['cmake','-S',str(project),'-B',str(BASE/'build'),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run('build',['cmake','--build',str(BASE/'build'),'-j2'])
 commands=json.loads((BASE/'build/compile_commands.json').read_text());summary['installed_only_compile']=all('/ws/src/' not in v['command'] for v in commands)
 assert summary['installed_only_compile']
 binary=BASE/'build/r2_external_consumer';summary['binary_sha256']=sha(binary)
 with (BASE/'terrain.log').open('w') as f:
  terrain=subprocess.Popen(['ros2','run','mmp_terrain','terrain_publisher','--ros-args','-p','world:=none'],cwd=BASE,env=ENV,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  run('r2',[str(binary),'/tmp/mmp_deep_final_audit_20261011/install/path_manager/share/path_manager/config/optimizer_params.yaml','/tmp/mmp_deep_final_audit_20261011/install/path_manager/share/path_manager/config/drone_hardware.yaml','/ws/src/mmp_terrain/data/scenarios/missions/r2_ridge_crossing.yaml',str(BASE/'result.json')])
  stop(terrain);terrain=None
 reference=json.loads((OLD/'run_01/result.json').read_text());current=json.loads((BASE/'result.json').read_text())
 summary['field_exact']={k:v==current.get(k) for k,v in reference.items()};summary['keys_equal']=set(current)==set(reference)
 summary['numeric_exact']=summary['keys_equal'] and all(summary['field_exact'].values());assert summary['numeric_exact']
 after=inputs();(BASE/'inputs_after.json').write_text(json.dumps(after,indent=2)+'\n');summary['inputs_unchanged']=before==after
 summary['pass']=summary['inputs_unchanged'] and summary['numeric_exact']
except Exception as e:summary['error']=repr(e);summary['pass']=False
finally:
 stop(terrain);summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
raise SystemExit(0 if summary['pass'] else 1)

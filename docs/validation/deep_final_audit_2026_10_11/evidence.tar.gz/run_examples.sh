set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
export ROS_DOMAIN_ID=97
cmake -S /tmp/mmp_deep_final_audit_20261011/install/path_manager/share/path_manager/examples/library_consumer -B /tmp/mmp_deep_final_audit_20261011/examples_build -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
cmake --build /tmp/mmp_deep_final_audit_20261011/examples_build -j2
/tmp/mmp_deep_final_audit_20261011/examples_build/flight_evaluator_client
/tmp/mmp_deep_final_audit_20261011/examples_build/trajectory_simulation_client
/tmp/mmp_deep_final_audit_20261011/examples_build/planning_visualization_client
/tmp/mmp_deep_final_audit_20261011/examples_build/mission_planner_client /tmp/mmp_deep_final_audit_20261011/install/path_manager/share/path_manager/config/optimizer_params.yaml

from pathlib import Path
import datetime, hashlib, json, sys
r=Path('/tmp/mmp_deep_final_audit_20261011')
old=json.loads(Path('/tmp/mmp_internal_cleanup_20261011/after/inputs_before.json').read_text())['files']
files={}
for key,entry in old.items():
    name=entry['path']
    for package in ['path_manager','path_optimizer','mmp_vehicle_dynamics']:
        prefix='/ws/install/'+package+'/'
        if name.startswith(prefix):
            name=str(r/'install'/package)+'/'+name[len(prefix):]
            break
    p=Path(name)
    assert not {'reports','experiments'}.intersection(p.parts)
    assert p.is_file(),str(p)
    files[key]={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
# Newly introduced implementation and test files are explicit additions.
for relative in [
    'path_manager/src/terrain_grid_validation.h',
    'path_manager/test/chain_profile_contract_test.cpp',
    'path_manager/include/path_manager/direct_plan_settings.h',
    'path_manager/include/path_manager/planning_environment_store.h',
    'path_manager/include/path_manager/planning_execution.h',
    'path_manager/src/planning_environment_store.cpp',
    'path_manager/src/planning_execution.cpp',
    'path_manager/test/direct_plan_settings_test.cpp',
    'path_manager/test/planning_environment_store_test.cpp',
    'path_manager/test/planning_execution_test.cpp']:
    p=Path('/ws/src/mmp_path_planning/src')/relative
    files['new_source/'+relative]={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    if '/include/' in relative:
        p=r/'install'/relative.split('/')[0]/'include'/relative.split('/include/')[1]
        files['new_install/'+relative]={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
p=Path('/ws/install/path_manager/lib/path_manager/path_manager_node')
files['normal_installed_node']={'path':str(p),'resolved_path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files}
(r/sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
print('Frozen',len(files),'explicit source/install/input files')
if len(sys.argv)>2:
    assert files==json.loads((r/sys.argv[2]).read_text())['files'],'inputs changed during verification'
    print('Inputs unchanged')

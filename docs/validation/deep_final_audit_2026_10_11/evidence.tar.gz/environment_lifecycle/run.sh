set -e
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
export ROS_DOMAIN_ID=91
for stage in before after; do
 if [ "$stage" = before ]; then source /tmp/mmp_finish_modularization_20261011/install/setup.bash; else source /tmp/mmp_deep_final_audit_20261011/install/setup.bash; fi
 cmake -S /tmp/mmp_deep_final_audit_20261011/environment_lifecycle -B /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/build_$stage -DCMAKE_BUILD_TYPE=Release > /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/build_$stage.log 2>&1
 cmake --build /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/build_$stage -j2 >> /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/build_$stage.log 2>&1
 /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/build_$stage/probe /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/$stage.bin > /tmp/mmp_deep_final_audit_20261011/environment_lifecycle/$stage.log 2>&1
done

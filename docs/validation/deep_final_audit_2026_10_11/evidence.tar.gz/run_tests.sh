set -eo pipefail
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
source /tmp/mmp_deep_final_audit_20261011/install/setup.bash
export ROS_DOMAIN_ID=95
python3 /tmp/mmp_deep_final_audit_20261011/run_fresh_tests.py

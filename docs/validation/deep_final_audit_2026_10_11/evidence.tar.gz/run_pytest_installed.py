#!/usr/bin/env python3
"""Preload the installed package before legacy tests add source paths."""
import json
import sys
from pathlib import Path
import hashlib, importlib
MODULES = ['mmp_terrain'] + ['mmp_terrain.' + name for name in ('map_loader','ros_terrain','terrain_publisher','frame','mission','asset_paths')]
EXPECTED_PREFIX = '/tmp/mmp_deep_final_audit_20261011/install/mmp_terrain/'
def check_all_modules():
    values = []
    for name in MODULES:
        module = importlib.import_module(name)
        p = Path(module.__file__).absolute()
        assert str(p).startswith(EXPECTED_PREFIX), str(p)
        filename = '__init__' if name == 'mmp_terrain' else name.split('.')[-1]
        source = Path('/ws/src/mmp_terrain/mmp_terrain') / (filename + '.py')
        assert p.read_bytes() == source.read_bytes(), str(p)
        values.append({'module':name, 'path':str(p), 'source':str(source), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    return values

root = Path(__file__).resolve().parent
before = check_all_modules()
print('Installed package imports verified before collection:')
print(json.dumps(before, indent=2))
import pytest
status = pytest.main([
    '/ws/map/test_terrain_publisher_env.py',
    '/ws/map/test_mission_resolve.py',
    '/ws/map/test_asset_pin.py',
    '/ws/map/test_map_loader.py',
    '/ws/map/test_map_loader_ros.py',
    '-q', '--junitxml=' + str(root/'all_tests.xml'),
    '--basetemp=/tmp/mmp_deep_final_audit_20261011/pytest_temp',
    '-o', 'cache_dir=/tmp/mmp_deep_final_audit_20261011/pytest_cache',
])
after = check_all_modules()
assert before == after, 'Tests changed installed package identities'
(root/'installed_test_imports.json').write_text(
    json.dumps({'before': before, 'after': after}, indent=2) + '\n')
sys.exit(int(status))

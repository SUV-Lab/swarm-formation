#include "path_manager/replan_fsm.h"
#include "path_manager/trajectory_message.h"
#include "path_manager/ros_planning_backend.h"
#include "path_planner/risk_shape.h"
#include <cmath>
#include <sys/resource.h>
#include <numeric>
using namespace std::chrono_literals;

namespace path_manager {

ReplanFSM::~ReplanFSM()
{
    // The ROS adapter owns this subscription to execution events. A retained
    // manager must not keep a callback borrowing a destroyed state machine.
    if (path_manager_) path_manager_->setExecutionRevocationObserver({});
}


ReplanFSM::ReplanFSM(rclcpp::Node::SharedPtr node)
    : node_(node),
      exec_state_(FSM_EXEC_STATE::INIT),
      have_target_(false),
      have_local_traj_(false),
      have_recv_pre_agent_(false),
      drone_id_(0),
      flag_escape_emergency_(false),
      num_drones_(4),
      current_formation_type_("square"),
      current_formation_scale_(2.0),
      last_received_sequence_(-1),
      current_mission_id_(""),
      next_mission_id_(""),
      is_final_mission_(false)
    {
        log_manager_ = std::make_shared<swarm_formation::LogManager>(
            node->get_name(), "./logs/runtime", swarm_formation::LogManager::INFO);

    node_->declare_parameter("enable_debug_logs", false);
    node_->get_parameter("enable_debug_logs", enable_debug_logs_);

    node_->declare_parameter("enable_lbfgs_detail_logs", false);
    // Note: enable_lbfgs_detail_logs will be read by PolyTrajOptimizer::setParam()

    node_->declare_parameter("drone_id", 0);
    node_->get_parameter("drone_id", drone_id_);
    FSM_LOG_INFO("Starting ReplanFSM for drone_id: %d", drone_id_);

    // Formation manager parameters
    node_->declare_parameter("num_drones", 4);
    node_->declare_parameter("formation_type", "square");
    node_->declare_parameter("formation_scale", 2.0);
    node_->declare_parameter("formation_center_x", 80.0);
    node_->declare_parameter("formation_center_y", -1.5);
    node_->declare_parameter("formation_center_z", 0.0);
    
    node_->get_parameter("num_drones", num_drones_);
    node_->get_parameter("formation_type", current_formation_type_);
    node_->get_parameter("formation_scale", current_formation_scale_);
    
    double center_x, center_y, center_z;
    node_->get_parameter("formation_center_x", center_x);
    node_->get_parameter("formation_center_y", center_y);
    node_->get_parameter("formation_center_z", center_z);
    current_formation_center_ = Eigen::Vector3d(center_x, center_y, center_z);

    node_->declare_parameter("enable_waypoint_markers", true);
    node_->get_parameter("enable_waypoint_markers", enable_waypoint_markers_);
    FSM_LOG_INFO("enable_waypoint_markers: %s", enable_waypoint_markers_ ? "true" : "false");

    node_->declare_parameter("enable_global_trajectory_pub", true);
    node_->get_parameter("enable_global_trajectory_pub", enable_global_trajectory_pub_);
    FSM_LOG_INFO("enable_global_trajectory_pub: %s", enable_global_trajectory_pub_ ? "true" : "false");

    // --- TEST: initial-state injection (vel/acc boundary condition demo) ---
    node_->declare_parameter("test/inject_init_state", false);
    node_->get_parameter("test/inject_init_state", inject_init_state_);

    std::vector<double> init_vel_vec{0.0, 0.0, 0.0};
    std::vector<double> init_acc_vec{0.0, 0.0, 0.0};
    node_->declare_parameter("test/init_vel", init_vel_vec);
    node_->declare_parameter("test/init_acc", init_acc_vec);
    node_->get_parameter("test/init_vel", init_vel_vec);
    node_->get_parameter("test/init_acc", init_acc_vec);

    inject_init_vel_.setZero();
    inject_init_acc_.setZero();
    if (init_vel_vec.size() >= 3)
        inject_init_vel_ = Eigen::Vector3d(init_vel_vec[0], init_vel_vec[1], init_vel_vec[2]);
    if (init_acc_vec.size() >= 3)
        inject_init_acc_ = Eigen::Vector3d(init_acc_vec[0], init_acc_vec[1], init_acc_vec[2]);

    node_->declare_parameter("manager/initial_speed_unit_m", 100.0);
    node_->get_parameter("manager/initial_speed_unit_m", initial_speed_unit_m_);
    if (initial_speed_unit_m_ <= 0.0) {
        RCLCPP_WARN(node_->get_logger(),
                    "manager/initial_speed_unit_m must be positive; using 100 m");
        initial_speed_unit_m_ = 100.0;
    }
    // The FSM converts every stated component — including z — with THIS
    // parameter, while the envelope gates convert back with
    // optimization/dynamics_unit_xy_m and _z_m. Nothing cross-checked them,
    // so a drift silently makes the magnitude JUDGED differ from the
    // magnitude STATED — the exact fabrication the message contract forbids.
    // Loud at construction rather than wrong in flight.
    // DECLARE, then read. The guard used to probe with has_parameter and fall
    // back to a literal 100.0 — but the two optimization/* names are declared
    // inside PathManager::initOptimizer, which first runs on the FIRST MISSION,
    // long after this constructor. So has_parameter was false every time, the
    // guard compared 100.0 against 100.0, and a real drift passed silently
    // while a CONSISTENT non-100 setting was the only thing that could make it
    // fire. It was fail-open on the case it exists for and false-positive on
    // the case it does not.
    //
    // Declaring here is what lets it see the value. The optimizer's own
    // declare_once then finds them present and reads the same numbers, so the
    // declaration moves earlier without changing what anything reads.
    {
        double ux = 100.0, uz = 100.0;
        if (!node_->has_parameter("optimization/dynamics_unit_xy_m"))
            node_->declare_parameter("optimization/dynamics_unit_xy_m", 100.0);
        node_->get_parameter("optimization/dynamics_unit_xy_m", ux);
        if (!node_->has_parameter("optimization/dynamics_unit_z_m"))
            node_->declare_parameter("optimization/dynamics_unit_z_m", 100.0);
        node_->get_parameter("optimization/dynamics_unit_z_m", uz);
        if (std::abs(ux - initial_speed_unit_m_) > 1e-9 ||
            std::abs(uz - initial_speed_unit_m_) > 1e-9) {
            RCLCPP_ERROR(node_->get_logger(),
                         "[INITIAL-STATE] unit mismatch: "
                         "manager/initial_speed_unit_m=%.6f but "
                         "optimization/dynamics_unit_xy_m=%.6f, "
                         "dynamics_unit_z_m=%.6f. A stated initial state "
                         "would be judged at a different magnitude than it "
                         "was stated at.", initial_speed_unit_m_, ux, uz);
            log_manager_->errorf(
                "[INITIAL-STATE] unit mismatch: initial_speed_unit_m=%.6f "
                "vs dynamics_unit_xy_m=%.6f dynamics_unit_z_m=%.6f",
                initial_speed_unit_m_, ux, uz);
        }
    }

    if (inject_init_state_) {
        FSM_LOG_WARN("[TEST] inject_init_state ENABLED: init vel=(%.2f,%.2f,%.2f) acc=(%.2f,%.2f,%.2f)",
                     inject_init_vel_(0), inject_init_vel_(1), inject_init_vel_(2),
                     inject_init_acc_(0), inject_init_acc_(1), inject_init_acc_(2));
    }


    // Start position will be received from TrajectoryCommand message
    // Initialize with zero until we receive the command
    RCLCPP_INFO(node_->get_logger(), "ReplanFSM parameters:");
    log_manager_->infof("ReplanFSM parameters:");
    RCLCPP_INFO(node_->get_logger(), "  Start position will be set from TrajectoryCommand");
    log_manager_->infof("  Start position will be set from TrajectoryCommand");
    RCLCPP_INFO(node_->get_logger(), "  Waiting for trajectory command...");
    log_manager_->infof("  Waiting for trajectory command...");

    start_pt_ = Eigen::Vector3d::Zero();
    current_pos_ = Eigen::Vector3d::Zero();  // Updated from TrajectoryCommand
    current_vel_ = Eigen::Vector3d::Zero();  // Initialize velocity to zero
    end_pt_ = Eigen::Vector3d::Zero();  // Initialize end_pt_ to avoid uninitialized access
    have_target_ = false;  // Wait for trajectory command
    start_position_received_ = false;  // Flag to track if we received start position
    
    RCLCPP_INFO(node_->get_logger(), "Initial position set to: (%.2f, %.2f, %.2f)", 
                current_pos_(0), current_pos_(1), current_pos_(2));
    log_manager_->infof("Initial position set to: (%.2f, %.2f, %.2f)", 
                current_pos_(0), current_pos_(1), current_pos_(2));

    // Planning initialization and dispatch belong to the library. Keep a
    // manager alias for the existing ROS execution/environment callbacks.
    auto backend = makeRosPlanningBackend(node_, log_manager_);
    auto *ros_backend = backend.get();
    mission_planner_ = std::make_unique<MissionPlanner>(
        PlanSettings{}, PlanningEnvironment{}, std::move(backend));
    path_manager_ = ros_backend->executionManager();

    RCLCPP_INFO(node_->get_logger(), "PathManager initialized, waiting for trajectory command");
    log_manager_->infof("PathManager initialized, waiting for trajectory command");

    const int chain_segments = ros_backend->configuredSegments();
    if (ros_backend->chainEnabled()) {
        const std::string seg_desc = chain_segments > 0
            ? std::to_string(chain_segments) + " segments per mission"
            : "auto-sized segments";
        FSM_LOG_WARN("[CHAIN] segment-chained planning ENABLED "
                     "(%s) — /planning/"
                     "initial_trajectory carries the baseline OPTIMIZED "
                     "trajectory in this mode (the chained flight itself "
                     "under chain/author_from_route), not the MINCO seed",
                     seg_desc.c_str());
    }

    rmw_qos_profile_t qos_profile = rmw_qos_profile_sensor_data;
    auto sensor_qos = rclcpp::QoS(rclcpp::QoSInitialization(qos_profile.history, 5), qos_profile);

    // Create callback groups with dedicated separation to prevent timer stalls:
    // - timer_callback_group: FSM timer only (MutuallyExclusive, runs independently)
    // - subscription_callback_group: Formation/broadcast callbacks (MutuallyExclusive)
    // - position_callback_group: Position updates (MutuallyExclusive, separate to avoid blocking)
    // With MultiThreadedExecutor, these groups can run in parallel threads
    timer_callback_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    subscription_callback_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    FSM_LOG_INFO("Callback groups created: timer, subscription (all MutuallyExclusive)");

    // Single-drone: topics are flat (no per-drone prefix).
    // For swarm/multiple drones, restore a per-drone prefix here
    // (e.g. "/drone" + std::to_string(drone_id_)) so topics don't collide.
    std::string topic_prefix = "";

    // Keep the latest polynomial available to panels/visualizers opened after
    // planning completed. RELIABLE, not sensor/best-effort: a best-effort
    // WRITER latches its sample but delivers it best-effort, so a late joiner
    // could still miss the one message that matters. Reliable is stricter on
    // the writer side and stays compatible with every best-effort subscriber.
    auto trajectory_qos = rclcpp::QoS(5).reliable();
    trajectory_qos.transient_local();
    optimized_path_pub_ = node_->create_publisher<mmp_traj_msgs::msg::PolyTraj>(
        topic_prefix + "/planning/trajectory", trajectory_qos);
    global_path_pub_ = node_->create_publisher<mmp_traj_msgs::msg::PolyTraj>(
        topic_prefix + "/planning/initial_trajectory", trajectory_qos);
    // [ABORT] Same QoS as the trajectory it withdraws — see the msg comment.
    exec_control_pub_ =
        node_->create_publisher<mmp_traj_msgs::msg::TrajectoryExecutionControl>(
            topic_prefix + "/planning/execution_control", trajectory_qos);
    // PathManager coordinates detection between its environment and execution
    // owners; saying so on the wire lives here (this owns the publishers and
    // the state machine). Every environment-change trigger —
    // the obstacle topic, the deferred-obstacle flush, a new DEM, a zone
    // update — reaches the same hook, so none of them can withdraw a flight
    // quietly.
    if (path_manager_) {
        path_manager_->setExecutionRevocationObserver(
            [this](const ExecutionRevocation &event) {
                publishExecutionAbort(event);
            });
    }

    rclcpp::SubscriptionOptions trajectory_cmd_options;
    trajectory_cmd_options.callback_group = subscription_callback_group_;
    // Reliable: this is THE mission command. A best-effort reader may drop the
    // single Run message on a timing edge and the FSM would just sit there.
    trajectory_cmd_sub_ = node_->create_subscription<mmp_mission_msgs::msg::TrajectoryCommand>(
        topic_prefix + "/mission/trajectory_command", rclcpp::QoS(5).reliable(),
        std::bind(&ReplanFSM::trajectoryCommandCallback, this, std::placeholders::_1),
        trajectory_cmd_options);

    waypoint_marker_pub_ = node_->create_publisher<visualization_msgs::msg::Marker>(
        "/viz/waypoints", 10);

    // Every callback that MUTATES the manager's shared environment owner
    // (terrain, risk zones/masks, the SDF dynamic layer) must sit on
    // subscription_callback_group_, the same MutuallyExclusive group that
    // runs trajectoryCommandCallback (and through it the whole planning
    // pipeline, which READS that state). A subscription created without a
    // group lands on the node DEFAULT group, which the MultiThreadedExecutor
    // runs in parallel with subscription_callback_group_: at startup the
    // latched /terrain/grid_map and the panel's /mission/risk_zones both fired
    // rebuildTerrainRiskMasks() concurrently, and the two unsynchronized
    // std::vector reallocations (risk_zones_, terrain_risk_masks_) segfaulted
    // the node before WAIT_TARGET. None of these are hot paths, so
    // serializing them costs nothing.
    rclcpp::SubscriptionOptions state_mutator_options;
    state_mutator_options.callback_group = subscription_callback_group_;

    // Terrain GridMap subscription (TRANSIENT_LOCAL to receive latched message)
    rclcpp::QoS terrain_qos(1);
    terrain_qos.reliability(rclcpp::ReliabilityPolicy::Reliable);
    terrain_qos.durability(rclcpp::DurabilityPolicy::TransientLocal);
    terrain_sub_ = node_->create_subscription<grid_map_msgs::msg::GridMap>(
        "/terrain/grid_map", terrain_qos,
        std::bind(&ReplanFSM::terrainCallback, this, std::placeholders::_1),
        state_mutator_options);
    // [TERRAIN-READY] latched ingestion receipt (see terrainCallback).
    terrain_ready_pub_ = node_->create_publisher<std_msgs::msg::Float64MultiArray>(
        "/planning/terrain_ready", rclcpp::QoS(1).reliable().transient_local());

    // No separate clear topic: an empty DynamicObstacleArray with replace=true
    // is the clear verb (the /dynamic_obstacles/clear Empty topic was retired).
    // reliable+transient_local, same as the zone sub below: the panel latches
    // the scenario, and a volatile reader never collects a latch — a planner
    // started after Load would silently plan with zero obstacles (the exact
    // bug class fixed for zones in P0).
    load_obstacles_sub_ =
        node_->create_subscription<mmp_mission_msgs::msg::DynamicObstacleArray>(
            "/mission/obstacles", rclcpp::QoS(1).reliable().transient_local(),
            std::bind(&ReplanFSM::loadObstaclesCallback, this,
                      std::placeholders::_1),
            state_mutator_options);
    // Runtime risk-zone reset. Subscribe on the same MutuallyExclusive
    // subscription_callback_group_ used by trajectoryCommandCallback so
    // that publish-order from the mission panel is preserved: the panel
    // publishes RiskZoneArray first, then TrajectoryCommand; the panel's
    // QoS is reliable, ROS preserves FIFO per publisher, and the shared
    // MutuallyExclusive group serializes the two callbacks. No race.
    {
        rclcpp::SubscriptionOptions risk_zone_options;
        risk_zone_options.callback_group = subscription_callback_group_;
        // transient_local: the ObstacleScenario panel LATCHES the zone set for
        // exactly this case (its comment says "a planner restarted after the
        // scenario was loaded still receives the last published zone set") —
        // but a volatile reader never requests the latched sample, so a
        // planner started after Load silently planned with ZERO zones. A TL
        // reader is what actually collects the latch.
        load_risk_zones_sub_ =
            node_->create_subscription<mmp_mission_msgs::msg::RiskZoneArray>(
                "/mission/risk_zones", rclcpp::QoS(1).reliable().transient_local(),
                std::bind(&ReplanFSM::loadRiskZonesCallback, this,
                          std::placeholders::_1),
                risk_zone_options);
    }

    // The FSM timer shares the SUBSCRIPTION group ON PURPOSE (it used to have
    // its own group "to prevent timer stalls"): with separate MutuallyExclusive
    // groups the MultiThreadedExecutor runs the 10 ms tick CONCURRENTLY with
    // trajectoryCommandCallback -> planning, so the tick read execution data
    // and exec_state_ while planning wrote them (data race, proven empirically
    // with a temporary overlap counter). Sharing the group serializes them;
    // ticks during the multi-second plan are only flag-polling, so delaying
    // them until the plan finishes costs nothing in single-shot mode.
    timer_ = node_->create_wall_timer(10ms, std::bind(&ReplanFSM::computeAndPublishPaths, this), subscription_callback_group_);
    FSM_LOG_INFO("FSM timer created on the subscription callback group (10ms period, serialized with planning)");
}

void ReplanFSM::computeAndPublishPaths() {
    static int fsm_num = 0;
    fsm_num++;
    if (fsm_num == 100) {
        fsm_num = 0;
    }

    switch (exec_state_) {
        case INIT: {
            changeFSMExecState(WAIT_POSITION, "FSM");
            break;
        }

        case WAIT_POSITION: {
            if (!have_target_) {
                return;
            }
            changeFSMExecState(SEQUENTIAL_START, "FSM");
            break;
        }

        case SEQUENTIAL_START: {
            if (drone_id_ <= 0 || (drone_id_ >= 1 && have_recv_pre_agent_)) 
            {
                bool success = false;
                try {
                    success = planFromGlobalTraj(1);
                } catch (const std::exception& e) {
                    RCLCPP_ERROR(node_->get_logger(), "Exception during trajectory planning in SEQUENTIAL_START: %s", e.what());
                    log_manager_->errorf("Exception during trajectory planning in SEQUENTIAL_START: %s", e.what());
                    success = false;
                }
                
                static int sequential_start_failures = 0;  // Track consecutive failures

                if (success)
                {
                    sequential_start_failures = 0;  // Reset on success
                    changeFSMExecState(EXEC_TRAJ, "FSM");
                }
                else
                {
                    RCLCPP_ERROR(node_->get_logger(), "MY ID :%d have_recv_pre_agent_: %d, Failed to generate the first trajectory!!!", drone_id_,have_recv_pre_agent_);
                    log_manager_->errorf("MY ID :%d have_recv_pre_agent_: %d, Failed to generate the first trajectory!!!", drone_id_,have_recv_pre_agent_);
                    // Instead of going back to SEQUENTIAL_START immediately, wait a bit
                    sequential_start_failures++;
                    if (sequential_start_failures > 10) {
                        RCLCPP_ERROR(node_->get_logger(), "Too many failures in SEQUENTIAL_START, going to EMERGENCY_STOP");
                        log_manager_->errorf("Too many failures in SEQUENTIAL_START, going to EMERGENCY_STOP");
                        flag_escape_emergency_ = true;  // entry tick commands the hover
                        changeFSMExecState(EMERGENCY_STOP, "FSM");
                        sequential_start_failures = 0;
                    } else {
                        changeFSMExecState(WAIT_POSITION, "FSM");
                    }
                }
            }
            break;
        }

        case GEN_NEW_TRAJ: {
            bool success = planFromGlobalTraj(1);
            if (success) {
                changeFSMExecState(EXEC_TRAJ, "FSM");
            } else {
                have_target_ = false;
                changeFSMExecState(WAIT_POSITION, "FSM");
            }
            break;
        }

        case EXEC_TRAJ:
        {
            if (!path_manager_) {
                RCLCPP_ERROR(node_->get_logger(), "PathManager is not initialized!");
                log_manager_->errorf("PathManager is not initialized!");
                flag_escape_emergency_ = true;  // entry tick commands the hover
                changeFSMExecState(EMERGENCY_STOP, "FSM");
                break;
            }
            auto local_traj = &path_manager_->executionTrajectory();
            // A refused plan zeroes duration and start_time
            // (SegmentChainPlanner::invalidateStoredTrajectory). Without
            // this guard the completion test below reads
            // t_cur = min(0, huge) = 0 and "0 > 0 - 0.2" is TRUE, so a
            // refusal arriving mid-flight was reported as [reached goal]
            // and the FSM parked as though the mission had succeeded.
            // Arrival and invalidation must not share an exit.
            if (local_traj->duration <= 0.0)
            {
                have_target_ = false;
                have_local_traj_ = false;
                changeFSMExecState(WAIT_POSITION, "FSM");
                RCLCPP_ERROR(node_->get_logger(),
                             "[drone %d] stored trajectory invalidated during "
                             "execution — the plan was REFUSED, this is not "
                             "arrival", drone_id_);
                log_manager_->errorf(
                    "[drone %d] stored trajectory invalidated during execution "
                    "— the plan was REFUSED, this is not arrival", drone_id_);
                return;
            }
            double t_cur = rclcpp::Clock(RCL_ROS_TIME).now().seconds() - local_traj->start_time;
            t_cur = std::min(local_traj->duration, t_cur);

            // Single-shot execution: no replan, just check if trajectory completed
            if (t_cur > local_traj->duration - 0.2)
            {
                have_target_ = false;
                have_local_traj_ = false;
                changeFSMExecState(WAIT_POSITION, "FSM");
                RCLCPP_INFO(node_->get_logger(), "[drone %d reached goal]", drone_id_);
                log_manager_->infof("[drone %d reached goal]", drone_id_);
                return;
            }
            break;
        }

        case WAIT_EXTERNAL_RECOVERY: {
            // [ABORT] Deliberately inert. The planner withdrew the flight and
            // said so on /planning/execution_control; the execution layer owns
            // what the aircraft does next. Issuing anything from here would be
            // this node choosing a manoeuvre it has no basis to choose — the
            // only one it can build is a stationary hold, which this airframe
            // cannot fly. A new mission command moves the FSM out of here.
            break;
        }

        case EMERGENCY_STOP: {
            if (flag_escape_emergency_) {
                // Entry tick (flag set on the transition): command the hover
                // ONCE. The flag was never set before, so this state published
                // nothing and fell straight through to GEN_NEW_TRAJ.
                callEmergencyStop(current_pos_);
                flag_escape_emergency_ = false;
            } else {
                // No odometry exists in this architecture (current_vel_ was
                // never written), so a "wait until stopped" gate is
                // unknowable. Park and await the next mission instead.
                have_target_ = false;
                have_local_traj_ = false;
                RCLCPP_WARN(node_->get_logger(), "Emergency hover commanded; awaiting a new mission");
                log_manager_->warnf("Emergency hover commanded; awaiting a new mission");
                changeFSMExecState(WAIT_POSITION, "FSM");
            }
            break;
        }
    }
}

namespace {
builtin_interfaces::msg::Time storedTrajectoryTime(double seconds)
{
    // Preserve the local trajectory wire timestamp's existing rounding.
    builtin_interfaces::msg::Time stamp;
    stamp.sec = static_cast<int32_t>(std::floor(seconds));
    stamp.nanosec = static_cast<uint32_t>(
        std::llround((seconds - stamp.sec) * 1e9));
    return stamp;
}
}  // namespace

void ReplanFSM::polyTraj2ROSMsg(mmp_traj_msgs::msg::PolyTraj &msg)
{
    if (!path_manager_) {
        RCLCPP_ERROR(node_->get_logger(), "PathManager is not initialized!");
        log_manager_->errorf("PathManager is not initialized!");
        return;
    }
    // Emergency replacement and compatibility callers use the current slot.
    const auto &data = path_manager_->executionTrajectory();
    msg = makeTrajectoryMessage(data.traj, drone_id_, data.traj_id,
                                storedTrajectoryTime(data.start_time));
}

void ReplanFSM::globalTraj2ROSMsg(mmp_traj_msgs::msg::PolyTraj &msg)
{
    if (!path_manager_) {
        RCLCPP_ERROR(node_->get_logger(), "PathManager is not initialized!");
        log_manager_->errorf("PathManager is not initialized!");
        return;
    }
    const rclcpp::Time now = rclcpp::Clock(RCL_ROS_TIME).now();
    builtin_interfaces::msg::Time stamp;
    stamp.sec = now.seconds();
    stamp.nanosec = now.nanoseconds() % 1000000000;
    msg = makeTrajectoryMessage(path_manager_->referenceTrajectory().traj,
                                drone_id_, msg.trajectory_id, stamp);
}

bool ReplanFSM::planFromGlobalTraj(int trial_times) {
    // The live execution slot still decides whether a flight was withdrawn.
    // The normal publication consumes the owned library result, so packaging
    // does not depend on the planner's coefficient storage or scratch values.
    const auto &local_traj = path_manager_->executionTrajectory();
    if (local_traj.duration > 0 && local_traj.start_time > 0)
    {
        if (pending_plan_ && pending_plan_->trajectory_id != local_traj.traj_id)
            pending_plan_.reset();  // a legacy caller replaced the live slot
        const auto &trajectory = pending_plan_
            ? pending_plan_->trajectory : local_traj.traj;
        const double start_time = pending_plan_
            ? pending_plan_->start_time : local_traj.start_time;
        const auto &reference = pending_plan_
            ? pending_plan_->reference_trajectory : path_manager_->referenceTrajectory().traj;
        log_manager_->infof("[planFromGlobalTraj] Using pre-optimized trajectory (duration=%.3f)", local_traj.duration);

        const auto msg = makeTrajectoryMessage(
            trajectory, drone_id_, local_traj.traj_id,
            storedTrajectoryTime(start_time));
        optimized_path_pub_->publish(msg);
        have_local_traj_ = true;

        if (enable_global_trajectory_pub_) {
            // Reference messages retain publication time and id zero, rather
            // than adopting the final flight's identity or stored seed time.
            const rclcpp::Time now = rclcpp::Clock(RCL_ROS_TIME).now();
            builtin_interfaces::msg::Time stamp;
            stamp.sec = now.seconds();
            stamp.nanosec = now.nanoseconds() % 1000000000;
            global_path_pub_->publish(
                makeTrajectoryMessage(reference, drone_id_, 0, stamp));
        }
        pending_plan_.reset();
        return true;
    }

    pending_plan_.reset();
    log_manager_->errorf("[planFromGlobalTraj] local_traj not ready — planGlobalTraj() may have failed");
    return false;
}

void ReplanFSM::changeFSMExecState(FSM_EXEC_STATE new_state, std::string pos_call) {
    // Order and length MUST match FSM_EXEC_STATE. Adding a state without
    // extending this indexes past the end — the array was sized 6 while the
    // enum grew to 7, which reads out of bounds for the last state and
    // mislabels the one before it.
    static const std::string state_str[] = {
        "INIT", "WAIT_POSITION", "GEN_NEW_TRAJ", "EXEC_TRAJ",
        "EMERGENCY_STOP", "WAIT_EXTERNAL_RECOVERY", "SEQUENTIAL_START"};
    static_assert(sizeof(state_str) / sizeof(state_str[0]) ==
                      static_cast<size_t>(SEQUENTIAL_START) + 1,
                  "state_str must name every FSM_EXEC_STATE, in order");

    // Throttle frequent state transitions
    static auto last_log_time = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_log_time).count();

    bool should_log = (exec_state_ != new_state) &&  // State actually changed
                      (new_state == WAIT_POSITION || new_state == SEQUENTIAL_START || new_state == GEN_NEW_TRAJ || elapsed >= 2);

    if (should_log) {
        RCLCPP_INFO(node_->get_logger(), "[%s]: from %s to %s", pos_call.c_str(), state_str[static_cast<int>(exec_state_)].c_str(), state_str[static_cast<int>(new_state)].c_str());
        last_log_time = now;
    }

    log_manager_->infof("[%s]: from %s to %s", pos_call.c_str(), state_str[static_cast<int>(exec_state_)].c_str(), state_str[static_cast<int>(new_state)].c_str());
    exec_state_ = new_state;
}

// Single entry point for starting a mission plan. This used to be a pair of
// functions bridged by a ROS message that never went on the wire: the sender
// built the message and then hand-delivered it to the receiver by shared_ptr,
// so no publisher, subscriber or topic ever existed and the message only
// carried arguments across a plain function call. The target and the route
// waypoints are the only values that were ever read back out of it.
void ReplanFSM::startMissionPlan(const Eigen::Vector3d& target,
                                 const std::vector<Eigen::Vector3d>& waypoints,
                                 double length_per_piece, double obstacle_clearance) {
    auto plan_start = std::chrono::high_resolution_clock::now();
    double ros_time_start = rclcpp::Clock(RCL_ROS_TIME).now().seconds();

    if (target.z() < -0.1) {
        return;
    }

    FSM_LOG_INFO("[DEBUG TARGET] startMissionPlan STARTED for drone %d at time %.3f!",
                 drone_id_, ros_time_start);

    // Mission progress: move next_mission to current, clear next
    // This signals that we're working on the "next" mission now (which becomes current)
    if (!next_mission_id_.empty() && next_mission_id_ != "MISSION_END") {
        current_mission_id_ = next_mission_id_;
        next_mission_id_.clear();  // Empty means we need new mission data
        FSM_LOG_INFO("Mission progressed: now executing %s, next mission cleared (will request new data)",
                    current_mission_id_.c_str());
    }

    if (have_local_traj_) {
        const LocalTrajData *info = &path_manager_->executionTrajectory();
        double t_cur = rclcpp::Clock(RCL_ROS_TIME).now().seconds() - info->start_time;
        Eigen::Vector3d theoretical_pos = info->traj.getPos(t_cur);
        Eigen::Vector3d theoretical_vel = info->traj.getVel(t_cur);
        Eigen::Vector3d theoretical_acc = info->traj.getAcc(t_cur);

        // Use trajectory position for smooth formation change
        // This prevents jumps in commanded position during formation transitions
        start_pt_ = theoretical_pos;
        start_vel_ = theoretical_vel;
        start_acc_ = theoretical_acc;
        start_head_.src = path_manager::StartStateSource::TRAJECTORY_DERIVED;
        start_head_.acc_prescribed = false;  // our own state, not a claim

        double pos_error = (current_pos_ - theoretical_pos).norm();
        log_manager_->infof("Formation change - using TRAJECTORY position/vel/acc (error from actual: %.2fm)",
                   pos_error);
        log_manager_->infof("  Trajectory pos: (%.2f, %.2f, %.2f), Actual pos: (%.2f, %.2f, %.2f)",
                   start_pt_(0), start_pt_(1), start_pt_(2),
                   current_pos_(0), current_pos_(1), current_pos_(2));
    } else {
        start_pt_ = current_pos_;
        start_vel_.setZero();
        // Overwritten by whichever branch below reads a stated start. If
        // none does the mission described no beginning, and UNSPECIFIED is
        // what triggerGlobalPlan refuses on — one value, not a source plus a
        // separate "was it stated" bool that could disagree with it.
        start_head_ = path_manager::StartHead{};
        // Provenance tag for the log below: the derived first-leg velocity
        // was repeatedly misread as an applied use_initial_velocity vector.
        const char *vel_src = "rest (zero)";
        if (use_commanded_initial_velocity_) {
            start_vel_ = commanded_initial_velocity_;
            start_head_.src = path_manager::StartStateSource::STATED_VECTOR;
            start_head_.acc_prescribed = use_commanded_initial_acceleration_;
            vel_src = "commanded vector (use_initial_velocity)";
        } else if (mission_start_claim_.src ==
                   path_manager::StartStateSource::STATED_SPEED) {
            // The claim decides, not the value. "> 0.0" sent a STATED zero
            // down the else branch, where it became an UNSPECIFIED mission
            // — so an operator who explicitly asked for a rest start got
            // "you said nothing" instead of "this stack cannot fly that".
            // Aim the initial velocity along the FIRST ROUTE LEG, not the
            // final target: with intermediate waypoints the two differ, and
            // a target-aimed start manufactured an immediate high-load bank
            // onto leg 1 (measured: n=1.65 / 52.6 deg / 113.8% thrust at
            // t=9.3 s on a dogleg whose real corner was 12.8 km away).
            // First waypoint == target for plain missions, so the simple
            // case is unchanged.
            Eigen::Vector3d leg_end(target.x(), target.y(), 0.0);
            for (const auto &wp : waypoints) {
                const double dx = wp.x() - start_pt_.x();
                const double dy = wp.y() - start_pt_.y();
                if (dx * dx + dy * dy > 1.0e-6) {
                    leg_end = Eigen::Vector3d(wp.x(), wp.y(), 0.0);
                    break;
                }
            }
            Eigen::Vector3d initial_direction(
                leg_end.x() - start_pt_.x(),
                leg_end.y() - start_pt_.y(), 0.0);
            if (initial_direction.head<2>().norm() < 1.0e-9) {
                initial_direction = Eigen::Vector3d::UnitX();
            } else {
                initial_direction.normalize();
            }
            start_vel_ = initial_direction * commanded_initial_speed_;
            vel_src = "initial_speed x first-leg direction (level)";
            // Chord is only a PROXY for "cruising along the route" (the route
            // does not exist yet) — mark it so planGlobalTraj can re-aim onto
            // the front-end route's real initial direction ([VEL-ALIGN]).
            start_head_.src = path_manager::StartStateSource::STATED_SPEED;
            start_head_.acc_prescribed = use_commanded_initial_acceleration_;
        }
        start_acc_ = use_commanded_initial_acceleration_
            ? commanded_initial_acceleration_
            : Eigen::Vector3d::Zero();
        log_manager_->infof(
            "Using command start state: pos=(%.2f, %.2f, %.2f), "
            "speed=%.1f m/s, vel_mps=(%.1f, %.1f, %.1f) [src: %s], "
            "acc_mps2=(%.1f, %.1f, %.1f)",
            start_pt_(0), start_pt_(1), start_pt_(2),
            start_vel_.norm() * initial_speed_unit_m_,
            start_vel_(0) * initial_speed_unit_m_,
            start_vel_(1) * initial_speed_unit_m_,
            start_vel_(2) * initial_speed_unit_m_,
            vel_src,
            start_acc_(0) * initial_speed_unit_m_,
            start_acc_(1) * initial_speed_unit_m_,
            start_acc_(2) * initial_speed_unit_m_);
    }

    // TEST: override the resolved start vel/acc with the injected boundary condition.
    // Position is left untouched; only the initial motion state is forced.
    if (inject_init_state_) {
        start_vel_ = inject_init_vel_;
        start_acc_ = inject_init_acc_;
        // A test injection is a FULL PVA injection: the acceleration is
        // supplied here regardless of what the message's flag said, so
        // acc_prescribed is true by construction. Taking it from
        // use_commanded_initial_acceleration_ meant an injected acceleration
        // was judged on the velocity alone whenever the message had not also
        // set the flag — which is every injection driven by test/inject_*.
        start_head_.src = path_manager::StartStateSource::TEST_INJECTED;
        start_head_.acc_prescribed = true;
        log_manager_->infof("[TEST] Injected initial vel=(%.2f,%.2f,%.2f) acc=(%.2f,%.2f,%.2f)",
                   start_vel_(0), start_vel_(1), start_vel_(2),
                   start_acc_(0), start_acc_(1), start_acc_(2));
    }

    // The commanded waypoints are passed through as-is: they are already
    // center points with any formation offset applied.
    std::vector<Eigen::Vector3d> route = waypoints;

    if (!route.empty()) {
        log_manager_->infof(
                   "Drone %d: Using %zu commanded waypoints (already offset-applied)",
                   drone_id_, route.size());

        end_pt_ = route.back();
    } else {
        route = { target };
        end_pt_ = target;

        RCLCPP_INFO(node_->get_logger(),
                   "Drone %d: Using single target as waypoint (already offset-applied)",
                   drone_id_);
        log_manager_->infof(
                   "Drone %d: Using single target as waypoint (already offset-applied)",
                   drone_id_);
    }

    log_manager_->infof("start_pt_: %.2f, %.2f, %.2f", start_pt_(0), start_pt_(1), start_pt_(2));
    log_manager_->infof("waypoints size: %zu", route.size());
    for (const auto& wp : route) {
        log_manager_->infof("waypoint: %.2f, %.2f, %.2f", wp(0), wp(1), wp(2));
    }

    if (enable_waypoint_markers_) {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = "map";
        marker.header.stamp = node_->now();
        marker.ns = "waypoints_drone_" + std::to_string(drone_id_);
        marker.id = drone_id_;
        marker.type = visualization_msgs::msg::Marker::SPHERE_LIST;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.scale.x = marker.scale.y = marker.scale.z = 0.3;  // Sphere size

        if (drone_id_ == 0) {
            marker.color.r = 1.0; marker.color.g = 0.0; marker.color.b = 0.0;  // Red
        } else if (drone_id_ == 1) {
            marker.color.r = 0.0; marker.color.g = 0.0; marker.color.b = 1.0;  // Blue
        } else if (drone_id_ == 2) {
            marker.color.r = 0.0; marker.color.g = 1.0; marker.color.b = 0.0;  // Green
        } else if (drone_id_ == 3) {
            marker.color.r = 1.0; marker.color.g = 1.0; marker.color.b = 0.0;  // Yellow
        }
        marker.color.a = 1.0;

        for (const auto& wp : route) {
            geometry_msgs::msg::Point p;
            p.x = wp(0);
            p.y = wp(1);
            // Waypoint z is AGL ([GOAL AGL]); render the marker at the
            // ABSOLUTE altitude planGlobalTraj will fly (elevation + max(z,
            // min_goal_agl)) — the raw value drew the sphere inside the
            // terrain on any non-flat DEM. Same rule and gate as the
            // conversion in path_manager (water/off-DEM base = 0).
            p.z = wp(2);
            if (path_manager_ && path_manager_->hasTerrainData()) {
                double base = 0.0;
                path_manager_->terrainElevation(wp(0), wp(1), &base);
                p.z = base + std::max(wp(2), path_manager_->minGoalAgl());
            }
            marker.points.push_back(p);
        }

        waypoint_marker_pub_->publish(marker);
        log_manager_->infof("Drone %d: Published %zu waypoint markers to RViz (frame: %s, ns: %s)",
                    drone_id_, route.size(), marker.header.frame_id.c_str(), marker.ns.c_str());
    }

    triggerGlobalPlan(route, length_per_piece, obstacle_clearance);

    auto plan_end = std::chrono::high_resolution_clock::now();
    auto plan_duration = std::chrono::duration_cast<std::chrono::milliseconds>(plan_end - plan_start).count();
    double ros_time_end = rclcpp::Clock(RCL_ROS_TIME).now().seconds();
    FSM_LOG_INFO("[DEBUG TARGET] startMissionPlan COMPLETED in %ld ms at time %.3f (total elapsed: %.3f ms)",
                 plan_duration, ros_time_end, (ros_time_end - ros_time_start) * 1000);
}

// [START AGL] The commanded seed start rides the same AGL contract as
// [GOAL AGL]: mission yaml / panel z is height above terrain (above sea
// level over water), because mission sources cannot know the DEM. Applied
// exactly once, at the first plan attempt — consumed even without terrain
// (kept absolute then, matching goal behavior) so a DEM arriving mid-flight
// can never re-shift a trajectory-derived start.
void ReplanFSM::resolveCommandedStartAgl()
{
    if (!start_seed_agl_pending_) return;
    start_seed_agl_pending_ = false;
    if (!path_manager_) return;
    if (!path_manager_->hasTerrainData()) {
        FSM_LOG_WARN("[START AGL] no terrain at first plan — commanded start "
                     "z=%.2f kept ABSOLUTE", start_pt_.z());
        return;
    }
    double base = 0.0;  // water / off-DEM: AGL == ASL, same as [GOAL AGL]
    path_manager_->terrainElevation(start_pt_.x(), start_pt_.y(), &base);
    const double agl = std::max(start_pt_.z(), path_manager_->minGoalAgl());
    const double z_abs = base + agl;
    if (std::abs(z_abs - start_pt_.z()) > 1e-9) {
        FSM_LOG_INFO("[START AGL] commanded start z=%.2f AGL -> absolute %.2f "
                     "(terrain %.2f + agl %.2f)",
                     start_pt_.z(), z_abs, base, agl);
    }
    start_pt_.z() = z_abs;
    current_pos_.z() = z_abs;
}

void ReplanFSM::triggerGlobalPlan(const std::vector<Eigen::Vector3d>& waypoints,
                                double length_per_piece, double obstacle_clearance) {
    last_plan_succeeded_ = false;
    // Only the ROS adapter consumes the once-per-command AGL flag and
    // updates the execution start position. The library also supports AGL
    // requests directly for callers without this state machine.
    if (start_head_.src != StartStateSource::UNSPECIFIED)
        resolveCommandedStartAgl();
    start_head_.pos_u = start_pt_;
    start_head_.vel_u = start_vel_;
    start_head_.acc_u = start_acc_;

    MissionPlanRequest request;
    request.head = start_head_;
    request.waypoints = waypoints;
    request.tail = mission_tail_;
    request.formation_type = current_formation_type_;
    request.formation_pattern = current_formation_pattern_;
    request.formation_size = num_drones_;
    // The same library boundary validates and applies both persistent
    // overrides for ROS commands and direct callers. Writing the manager
    // first allowed a refused command to leave a nonfinite setting behind.
    request.length_per_piece = length_per_piece;
    request.obstacle_clearance = obstacle_clearance;

    auto global_traj_start = std::chrono::high_resolution_clock::now();
    FSM_LOG_INFO("[TIMING] Starting global trajectory planning");
    MissionPlanResult result = mission_planner_->plan(std::move(request));
    const PlanResult &plan_res = result.status;
    // [PLAN-OUTCOME] the tri-state is the planner contract; the bool below
    // stays the execution gate (DEGRADED flies, loudly).
    last_plan_outcome_ = plan_res.outcome;
    last_plan_reason_ = plan_res.reason;
    if (plan_res.outcome == PlanOutcome::DEGRADED) {
        FSM_LOG_WARN("[PLAN] DEGRADED: %s", plan_res.detail.c_str());
    } else if (plan_res.outcome == PlanOutcome::FAILED &&
               !plan_res.detail.empty()) {
        // One call, both destinations. This used to be a hand-rolled
        // RCLCPP_ERROR plus FSM_LOG_ERROR because the macro could not be
        // trusted to reach the console; now that it always does, keeping
        // both would print the refusal to the console twice.
        FSM_LOG_ERROR("[PLAN] FAILED reason=%d: %s",
                      static_cast<int>(plan_res.reason),
                      plan_res.detail.c_str());
    }
    const bool success = plan_res.hasTrajectory();

    auto global_traj_end = std::chrono::high_resolution_clock::now();
    auto global_traj_duration = std::chrono::duration_cast<std::chrono::milliseconds>(global_traj_end - global_traj_start).count();
    FSM_LOG_INFO("[TIMING] Global trajectory planning took %ld ms", global_traj_duration);

    if (success) {
        pending_plan_ = std::move(result);
        FSM_LOG_INFO("Trajectory planning successful for formation type: %s", current_formation_type_.c_str());

        have_target_ = true;
        last_plan_succeeded_ = true;

        if (exec_state_ == WAIT_POSITION)
            changeFSMExecState(SEQUENTIAL_START, "startMissionPlan");
        else if (exec_state_ == EXEC_TRAJ)
            changeFSMExecState(SEQUENTIAL_START, "startMissionPlan");  // Single-shot: new global plan already has local_traj
        else if (exec_state_ == WAIT_EXTERNAL_RECOVERY)
            // [ABORT] A new mission is how this node leaves the aborted
            // state. Without this branch WAIT_EXTERNAL_RECOVERY was a trap:
            // the plan below would succeed and never be published, because
            // only WAIT_POSITION and EXEC_TRAJ reached SEQUENTIAL_START. The
            // comment on the state claimed a new mission would move it and
            // nothing did.
            //
            // Commanding a mission is the operator (or the execution layer)
            // saying the aircraft is under control again — this node cannot
            // observe that by itself, having no odometry. If a dedicated
            // resume/ACK is wanted instead, it belongs on the same control
            // topic as the abort and this branch becomes its handler.
            changeFSMExecState(SEQUENTIAL_START, "startMissionPlan (recovery)");

        // NOTE: Global trajectory publish removed from the mission-plan path to prevent blocking
        // The global trajectory will be published in computeAndPublishPaths instead
        // This fixes the race condition that caused 20-60 second freezes during formation transitions

        RCLCPP_INFO(node_->get_logger(), "Successfully generated global trajectory for drone %d", drone_id_);
        log_manager_->infof("Successfully generated global trajectory for drone %d", drone_id_);
    }
    else {
        RCLCPP_ERROR(node_->get_logger(), "Unable to generate global trajectory for drone %d!", drone_id_);
        log_manager_->errorf("Unable to generate global trajectory for drone %d!", drone_id_);
    }
}

// [ABORT] Withdraw a trajectory that is already out on the wire.
//
// This publishes a DECLARATION, not a manoeuvre: the named trajectory is no
// longer claimed to be safe to continue. Choosing what the aircraft should do
// instead belongs to the execution layer, which knows the airframe — the only
// stop this node can synthesise is a zero-velocity hold, and this platform's
// cruise minimum is 122 m/s, so building one would be issuing an unflyable
// command in the name of safety.
void ReplanFSM::publishExecutionAbort(const ExecutionRevocation &event)
{
    const auto r = event.reason;
    const auto &hit = event.hit;
    const double t_detected = event.detected_time;
    if (!exec_control_pub_ || !path_manager_) return;
    pending_plan_.reset();
    using Ctl = mmp_traj_msgs::msg::TrajectoryExecutionControl;
    using R = path_manager::PathManager::EnvChangeReason;
    Ctl msg;
    msg.drone_id = drone_id_;
    // The execution owner captured this identity BEFORE invalidating the
    // slot. A consumer executing a different id must ignore this.
    msg.trajectory_id = event.trajectory_id;
    msg.action = Ctl::ACTION_ABORT;
    msg.stamp = rclcpp::Clock(RCL_ROS_TIME).now();
    msg.reason = (r == R::TERRAIN_BLOCKED)     ? Ctl::REASON_TERRAIN_BLOCKED
                 : (r == R::POLICY_UNEVALUATED) ? Ctl::REASON_POLICY_UNEVALUATED
                                                : Ctl::REASON_OBSTACLE_BLOCKED;
    msg.detected_point.x = hit.x();
    msg.detected_point.y = hit.y();
    msg.detected_point.z = hit.z();
    msg.detected_trajectory_time = t_detected;
    // The whole environment, not just the zones: an obstacle or terrain
    // change is exactly what usually causes this abort, and the zone policy
    // generation does not move for either.
    msg.environment_generation = event.environment_generation;
    msg.detail = (r == R::TERRAIN_BLOCKED)
                     ? "a new terrain map blocks the remaining flight"
                 : (r == R::POLICY_UNEVALUATED)
                     ? "risk zones changed; the remaining flight cannot be "
                       "re-judged against the new set"
                     : "an obstacle blocks the remaining flight";
    exec_control_pub_->publish(msg);
    FSM_LOG_WARN(
        "[ABORT] trajectory %lu withdrawn (reason %u) at t=%.2f s, point "
        "(%.2f, %.2f, %.2f) — the execution layer owns the recovery",
        static_cast<unsigned long>(msg.trajectory_id),
        static_cast<unsigned>(msg.reason), t_detected, hit.x(), hit.y(),
        hit.z());
    // Not EMERGENCY_STOP: that state commands a stationary hold this airframe
    // cannot fly. Nothing further is issued from here.
    flag_escape_emergency_ = false;
    have_local_traj_ = false;
    changeFSMExecState(WAIT_EXTERNAL_RECOVERY, "ENV-CHANGE");
}

bool ReplanFSM::callEmergencyStop(const Eigen::Vector3d& stop_pos) {
    if (!path_manager_) {
        RCLCPP_ERROR(node_->get_logger(), "PathManager is not initialized!");
        log_manager_->errorf("PathManager is not initialized!");
        return false;
    }

    pending_plan_.reset();
    path_manager_->EmergencyStop(stop_pos);

    mmp_traj_msgs::msg::PolyTraj msg;
    polyTraj2ROSMsg(msg);
    optimized_path_pub_->publish(msg);

    return true;
}

// trajectoryCommandCallback: receives a trajectory command (target position
// and waypoints) from the RViz MissionConfig panel.
void ReplanFSM::trajectoryCommandCallback(const mmp_mission_msgs::msg::TrajectoryCommand::SharedPtr msg) {
    auto callback_start = std::chrono::high_resolution_clock::now();
    FSM_LOG_INFO("[TRAJECTORY CMD] Received trajectory command (seq: %d, drone: %d) at time %.3f",
                 msg->sequence, msg->drone_id, rclcpp::Clock(RCL_ROS_TIME).now().seconds());

    // Check if this command is for this drone
    if (msg->drone_id != drone_id_) {
        FSM_LOG_DEBUG("Ignoring trajectory command for drone %d (I am drone %d)",
                     msg->drone_id, drone_id_);
        return;
    }

    // Check for duplicate messages using sequence number
    if (msg->sequence <= last_received_sequence_) {
        FSM_LOG_DEBUG("Ignoring duplicate/old trajectory command (seq: %d, last: %d)",
                     msg->sequence, last_received_sequence_);
        return;
    }

    // [INITIAL-STATE] Stage 1: PURE message validation, before any state is
    // consumed or overwritten. The old order validated after mutating — the
    // adoption block below overwrites start_pt_/current_pos_ and clears
    // have_local_traj_, while the rollback at the end restores only the
    // sequence and the mission id — so every refusal downstream of it
    // dropped a flying trajectory and kept the rejected mission's start
    // point. Refusing HERE touches nothing, so a corrected resend just works.
    mission_start_claim_ =
        path_manager::parseStartClaim(*msg, initial_speed_unit_m_);
    if (mission_start_claim_.malformed()) {
        FSM_LOG_ERROR("[INITIAL-STATE] command REJECTED: %s "
                      "(INITIAL_STATE_MALFORMED) — nothing was consumed; fix "
                      "the command and resend the same sequence",
                      mission_start_claim_.problem.c_str());
        return;
    }
    if (path_manager::statedVectorIgnoresScalar(*msg)) {
        FSM_LOG_WARN("[INITIAL-STATE] initial_speed=%.3f is IGNORED: "
                     "use_initial_velocity is set and the vector wins",
                     msg->initial_speed);
    }

    // Capture the pre-command sequencing state: if the plan below fails or is
    // rejected, both are ROLLED BACK at the end of this callback so a resend
    // of the SAME command retries instead of dying in the dedup gate above.
    const int prev_sequence = last_received_sequence_;
    const std::string prev_mission_id = current_mission_id_;
    // ...and the five fields the adoption block mutates. Restoring only the
    // two above is what the comment above the stage-1 refusal already names as
    // the remaining hole: a refusal downstream of adoption dropped a flying
    // trajectory and kept the rejected mission's start point. That used to be
    // reachable only on the very first command, because a constant publisher
    // mission_id made adoption run once per planner lifetime. Once every Run
    // is genuinely a new mission, adoption runs every Run and so does this.
    const Eigen::Vector3d prev_start_pt = start_pt_;
    const Eigen::Vector3d prev_current_pos = current_pos_;
    const bool prev_start_position_received = start_position_received_;
    const bool prev_start_seed_agl_pending = start_seed_agl_pending_;
    const bool prev_have_local_traj = have_local_traj_;

    last_received_sequence_ = msg->sequence;

    // A NEW mission (different mission_id) is not a mid-flight continuation of
    // the current trajectory — its commanded start must be adopted. Capture
    // this BEFORE current_mission_id_ is overwritten below. (Same mission_id =
    // formation change / replan, which keeps the trajectory-continuation path.)
    const bool mission_changed =
        start_position_received_ && !msg->mission_id.empty() &&
        msg->mission_id != current_mission_id_;

    current_mission_id_ = msg->mission_id;
    // All five come from the ONE validated claim. They used to be read
    // straight off the message here, each with its own conversion and its
    // own clamp — including std::max(0.0, initial_speed), which made a
    // clamped -5 and a stated rest start into the same value.
    commanded_initial_speed_ = mission_start_claim_.speed_u;
    use_commanded_initial_velocity_ =
        mission_start_claim_.src == path_manager::StartStateSource::STATED_VECTOR;
    use_commanded_initial_acceleration_ = mission_start_claim_.acc_prescribed;
    commanded_initial_velocity_ = mission_start_claim_.vel_u;
    commanded_initial_acceleration_ = mission_start_claim_.acc_u;
    // [PHASE] mission FINAL boundary (SI -> planner units, same divisor as
    // the initial vectors). Validated at the plan entry, not here.
    mission_tail_ = ego_planner::TailBoundary{};
    if (msg->use_final_velocity) {
        mission_tail_.prescribe_vel = true;
        mission_tail_.vel = Eigen::Vector3d(msg->final_velocity.x,
                                            msg->final_velocity.y,
                                            msg->final_velocity.z) /
                            initial_speed_unit_m_;
    }
    if (msg->use_final_acceleration) {
        mission_tail_.prescribe_acc = true;
        mission_tail_.acc = Eigen::Vector3d(msg->final_acceleration.x,
                                            msg->final_acceleration.y,
                                            msg->final_acceleration.z) /
                            initial_speed_unit_m_;
    }
    if (mission_tail_.anyPrescribed()) {
        FSM_LOG_INFO("[PHASE] mission final boundary: vel %s (%.3f, %.3f, "
                     "%.3f) u/s, acc %s (%.3f, %.3f, %.3f) u/s^2",
                     mission_tail_.prescribe_vel ? "pinned" : "free",
                     mission_tail_.vel.x(), mission_tail_.vel.y(),
                     mission_tail_.vel.z(),
                     mission_tail_.prescribe_acc ? "pinned" : "free",
                     mission_tail_.acc.x(), mission_tail_.acc.y(),
                     mission_tail_.acc.z());
    }
    // The two "Ignoring non-finite ..." WARN-and-downgrade blocks are gone.
    // A non-finite stated value is MALFORMED and was already refused above,
    // before anything was consumed. Downgrading it silently turned a broken
    // command into an UNSPECIFIED one and reported the wrong diagnosis.

    // Adopt the commanded start for the FIRST command AND for every new
    // mission. Previously this was a write-once latch (only the first command
    // ever set the start), so missions 2..N silently planned from the stale
    // first start / previous trajectory end — there is no odometry sub to
    // refresh current_pos_. A new mission drops the previous local trajectory
    // so startMissionPlan plans from the commanded start, not the old
    // trajectory position.
    if (!start_position_received_ || mission_changed) {
        Eigen::Vector3d new_start_pos(
            msg->start_position.x,
            msg->start_position.y,
            msg->start_position.z
        );

        start_pt_ = new_start_pos;
        current_pos_ = new_start_pos;
        start_position_received_ = true;
        start_seed_agl_pending_ = true;  // z is AGL; resolved at first plan
        if (mission_changed) {
            have_local_traj_ = false;    // new mission: do not continue prev traj
        }

        FSM_LOG_INFO("Received start position from TrajectoryCommand: (%.2f, %.2f, %.2f)%s",
                    new_start_pos.x(), new_start_pos.y(), new_start_pos.z(),
                    mission_changed ? " [new mission]" : "");
    }

    FSM_LOG_INFO("Trajectory command (seq: %d): mission=%s, start=(%.2f, %.2f, %.2f), target=(%.2f, %.2f, %.2f)",
                msg->sequence,
                msg->mission_id.c_str(),
                msg->start_position.x, msg->start_position.y, msg->start_position.z,
                msg->target_position.x, msg->target_position.y, msg->target_position.z);

    std::vector<Eigen::Vector3d> waypoints;
    for (const auto& wp : msg->waypoints) {
        waypoints.emplace_back(wp.x, wp.y, wp.z);
    }

    Eigen::Vector3d target_position(
        msg->target_position.x,
        msg->target_position.y,
        msg->target_position.z
    );

    // Waypoint-less command: the TARGET is the mission. The old message path
    // substituted current_formation_center_ for an empty waypoint list —
    // (0,0,0) on a fresh node — so a valid headless/CLI command (target set,
    // waypoints omitted) planned a flight to the map corner while logging
    // success. The RViz panel always fills waypoints[], which is why that
    // stayed dormant; filling the route here keeps the target authoritative.
    if (waypoints.empty()) {
        waypoints.push_back(target_position);
        FSM_LOG_INFO("Trajectory command has no waypoints — using target_position "
                     "(%.2f, %.2f, %.2f) as the single waypoint",
                     target_position.x(), target_position.y(), target_position.z());
    }

    // Extract formation offset (for reference/logging)
    Eigen::Vector3d formation_offset(
        msg->formation_offset.x,
        msg->formation_offset.y,
        msg->formation_offset.z
    );

    std::vector<Eigen::Vector3d> formation_pattern;
    formation_pattern.reserve(msg->formation_pattern.size());
    for (const auto& pt : msg->formation_pattern) {
        formation_pattern.emplace_back(pt.x, pt.y, pt.z);
    }

    current_formation_pattern_ = formation_pattern;

    // Update formation parameters (for compatibility with existing code)
    current_formation_type_ = msg->formation_type;
    current_formation_scale_ = msg->formation_scale;

    FSM_LOG_INFO("Drone %d: target=(%.2f, %.2f, %.2f), offset=(%.2f, %.2f, %.2f), %zu waypoints",
                drone_id_,
                target_position.x(), target_position.y(), target_position.z(),
                formation_offset.x(), formation_offset.y(), formation_offset.z(),
                waypoints.size());

    last_plan_succeeded_ = false;  // also covers early returns before triggerGlobalPlan
    startMissionPlan(target_position, waypoints,
                     msg->length_per_piece, msg->obstacle_clearance);

    if (!last_plan_succeeded_) {
        // Plan failed or was rejected (e.g. the optimizer's collision audit).
        // Un-consume the sequencing state so a resend of the SAME command
        // retries; without this the dedup gate silently dropped it and the
        // mission was stranded with no reject signal.
        last_received_sequence_ = prev_sequence;
        current_mission_id_ = prev_mission_id;
        // The adoption block's five fields go back too. Without this the
        // refused mission's start point survives as the next plan's origin
        // and the flight that was in the air is gone — the command was
        // refused, so nothing it stated may outlive it.
        start_pt_ = prev_start_pt;
        current_pos_ = prev_current_pos;
        start_position_received_ = prev_start_position_received;
        start_seed_agl_pending_ = prev_start_seed_agl_pending;
        have_local_traj_ = prev_have_local_traj;
        FSM_LOG_ERROR("[PLAN REJECTED] mission '%s' (seq %d) produced no "
                      "trajectory — sequence rolled back, a resend will retry",
                      msg->mission_id.c_str(), msg->sequence);
    }

    auto callback_end = std::chrono::high_resolution_clock::now();
    auto callback_duration = std::chrono::duration_cast<std::chrono::milliseconds>(callback_end - callback_start).count();
    FSM_LOG_INFO("[TRAJECTORY CMD] Callback completed (took %ld ms) at time %.3f",
                 callback_duration, rclcpp::Clock(RCL_ROS_TIME).now().seconds());
}

void ReplanFSM::terrainCallback(const grid_map_msgs::msg::GridMap::SharedPtr msg) {
    if (path_manager_) {
        const auto update = path_manager_->setTerrainData(msg);
        if (!update.accepted()) {
            FSM_LOG_WARN("Terrain update rejected; retaining the previous terrain receipt");
            return;
        }
        FSM_LOG_INFO("Terrain data received and forwarded to PathManager");
        // [ENV-CHANGE] A new DEM can put terrain under a flight that was
        // planned over open air. Same check as the obstacle path.
        path_manager_->revalidateAfterEnvChange(
            "a new terrain map",
            path_manager::PathManager::EnvChangeReason::TERRAIN_BLOCKED);
        // [TERRAIN-READY] Ingestion receipt for command gating: the panel's
        // Run flow must not race a corridor the planner is still digesting
        // (LoadMap replying only proves the map was PUBLISHED). Latched
        // [resolution_u, origin_x_u, origin_y_u, length_x_u, length_y_u] of
        // what was actually ingested — the panel matches it against the
        // LoadMap response before it releases the mission command. Extent is
        // included so two corridors sharing a corner cannot alias (review
        // find).
        //
        // EVERY terrain state transition emits one, because the receipt is
        // the panel's only view of what the planner holds. There are three
        // outcomes inside setTerrainData and they are not interchangeable:
        // a good map (ingested -> full receipt), a malformed one (early
        // return above, the previous receipt remains accurate), and an EMPTY one
        // (world=none: the explicit clear verb, which wipes the DEM, the
        // SDF and the dynamic obstacles). The clear is why the resolution-0
        // receipt below exists — see there.
        const bool ingested = update.kind == TerrainUpdateKind::REPLACED;
        const bool cleared = update.kind == TerrainUpdateKind::CLEARED;
        if (terrain_ready_pub_ && (ingested || cleared)) {
            std_msgs::msg::Float64MultiArray ready;
            if (ingested) {
                ready.data = {msg->info.resolution,
                              msg->info.pose.position.x -
                                  0.5 * msg->info.length_x,
                              msg->info.pose.position.y -
                                  0.5 * msg->info.length_y,
                              msg->info.length_x, msg->info.length_y};
            } else {
                // An EMPTY map is not a malformed one setTerrainData
                // ignores — it is the explicit clear verb (world=none), and
                // PathManager wipes the DEM, the SDF and the dynamic
                // obstacles for it. Publishing nothing here used to be
                // harmless only because the panel discarded its cached
                // receipt whenever it armed the gate. It no longer does, so
                // silence would leave the last good corridor's receipt
                // standing as a certificate for a map the planner has
                // thrown away — and a re-run of that same mission would
                // match it on the first tick and plan with no terrain at
                // all. A resolution of 0 fails the panel's `res > 0` match
                // by construction, so the gate goes back to waiting for a
                // real ingestion instead of trusting a stale one.
                ready.data = {0.0, 0.0, 0.0, 0.0, 0.0};
            }
            terrain_ready_pub_->publish(ready);
        }
    }
}

// Applies a dynamic-obstacle batch. msg->replace clears the live set first, so
// an EMPTY array with replace=true is the "clear all obstacles" verb (the old
// /dynamic_obstacles/clear std_msgs/Empty topic was retired in its favor).
void ReplanFSM::loadObstaclesCallback(
    const mmp_mission_msgs::msg::DynamicObstacleArray::SharedPtr msg)
{
    if (!path_manager_) return;
    if (msg->replace) {
        path_manager_->clearDynamicObstacles();
    }
    size_t added = 0;
    size_t skipped = 0;
    size_t deferred = 0;  // queued until the SDF exists (no cache on first run)
    for (const auto& spec : msg->obstacles) {
        const Eigen::Vector3d c(spec.center.x, spec.center.y, spec.center.z);
        int id = -1;
        if (spec.kind == mmp_mission_msgs::msg::DynamicObstacleSpec::KIND_CUBE) {
            const Eigen::Vector3d size(spec.size.x, spec.size.y, spec.size.z);
            id = path_manager_->addDynamicBox(c, size, spec.model);
            if (id == -1) {
                FSM_LOG_WARN(
                    "loadObstacles: addDynamicBox rejected at (%.2f,%.2f,%.2f) size=(%.2f,%.2f,%.2f)",
                    c.x(), c.y(), c.z(), size.x(), size.y(), size.z());
            }
        } else if (spec.kind == mmp_mission_msgs::msg::DynamicObstacleSpec::KIND_SPHERE) {
            id = path_manager_->addDynamicSphere(c, spec.radius, spec.model);
            if (id == -1) {
                FSM_LOG_WARN(
                    "loadObstacles: addDynamicSphere rejected at (%.2f,%.2f,%.2f) r=%.2f",
                    c.x(), c.y(), c.z(), spec.radius);
            }
        } else {
            FSM_LOG_WARN(
                "loadObstacles: skipping unsupported spec kind=%u",
                spec.kind);
            ++skipped;
            continue;
        }
        if (id == -1) ++skipped; else if (id == -2) ++deferred; else ++added;
    }
    FSM_LOG_INFO("loadObstacles: added=%zu deferred=%zu skipped=%zu (total in msg=%zu)",
                 added, deferred, skipped, msg->obstacles.size());

    // [ENV-CHANGE] The world under the flight just changed. EXEC_TRAJ does
    // not replan — it is single-shot and only waits for the stored trajectory
    // to finish — so without this the mission would keep flying a route that
    // was cleared against a different obstacle set. Nothing here re-plans
    // either: it asks whether what is LEFT of the current trajectory is still
    // flyable, and if it is not, invalidates it. EXEC_TRAJ already treats an
    // invalidated trajectory as "the plan was REFUSED, this is not arrival"
    // and parks in WAIT_POSITION.
    //
    // Only when something was actually installed: a batch that added nothing
    // cannot have blocked anything, and a clear-all (replace with an empty
    // array) only ever removes obstacles.
    if (added > 0) {
        const double t_cur =
            (path_manager_->executionTrajectory().start_time > 0.0)
                ? rclcpp::Clock(RCL_ROS_TIME).now().seconds() -
                      path_manager_->executionTrajectory().start_time
                : 0.0;
        Eigen::Vector3d hit;
        if (!path_manager_->revalidateStoredTrajectory(
                t_cur, &hit,
                path_manager::PathManager::EnvChangeReason::OBSTACLE_BLOCKED)) {
            FSM_LOG_WARN(
                "loadObstacles: the flight in progress is blocked from t=%.2f s "
                "at (%.2f, %.2f, %.2f) — trajectory invalidated",
                t_cur, hit.x(), hit.y(), hit.z());
        }
    }
}

// Applies a risk-zone batch. msg->replace mirrors DynamicObstacleArray:
// true overwrites the active set, false appends to it. The FSM owns the
// accumulated set (active_risk_zones_) because setRiskZonesRuntime is
// replace-only — before this, Append silently dropped previously loaded zones.
// An EMPTY array with replace=true is therefore the "clear all zones" verb.
void ReplanFSM::loadRiskZonesCallback(
    const mmp_mission_msgs::msg::RiskZoneArray::SharedPtr msg)
{
    if (!path_manager_) return;
    // [ENV-CHANGE] Zones are NOT obstacles and must not be re-checked with the
    // obstacle predicate: the same volume is HARD_AVOID on one leg and a
    // SOFT_ENDPOINT containment exemption on another, so "is this point
    // occupied" has no answer without the per-leg policy the flight was
    // planned under. Re-auditing a flight in progress per piece is the right
    // fix and is not built.
    //
    // Until it is, a zone update while a trajectory is executing is fail
    // closed: the flight cannot be re-judged against the new set, so it stops
    // being treated as cleared. "We could not check" must not read as "it is
    // still fine" — that is the same rule the whole-flight audit follows.
    // ...but only if the set actually CHANGES. A periodic republish of the
    // same zones changes nothing about the flight, and withdrawing on it
    // would ground every mission that had a zone anywhere — the fail-closed
    // rule is about the world moving, not about a message arriving. Compared
    // by content fingerprint after the new set is installed, below.
    const uint64_t zones_before = path_manager_->riskZoneFingerprint();
    // Convert the wire format to PathManager's internal RiskZone struct.
    std::vector<path_manager::RiskZone> zones;
    zones.reserve(msg->zones.size());
    // [PA-7] This used to DROP an offending zone and keep the rest: a hazard
    // the mission declared silently left the field and the planner routed
    // straight through it. ATOMIC REJECTION now — the set is refused whole and
    // the previously active set stays in force.
    //
    // peak > 1 is rejected too. It used to be accepted on the grounds that it
    // "saturates at the moat cap" -- which is exactly the damage: a saturated
    // zone is gradient-free over most of its volume, so avoidance shaping is
    // gone and only the barrier still acts.
    size_t bad = 0;
    for (const auto& z : msg->zones) {
        if (!std::isfinite(z.center.x) ||
            !std::isfinite(z.center.y) ||
            !std::isfinite(z.center.z) ||
            !std::isfinite(z.reach) ||
            z.reach <= 0.0 ||
            !mmp::risk::isValidPeak(z.peak)) {
            ++bad;
            FSM_LOG_ERROR(
                "loadRiskZones: zone REJECTED center=(%.3f,%.3f,%.3f) "
                "reach=%.3f peak=%.3f — peak must be finite and in (0, 1], "
                "reach must be finite and > 0",
                z.center.x, z.center.y, z.center.z, z.reach, z.peak);
            continue;
        }
        path_manager::RiskZone tz;
        tz.center = Eigen::Vector3d(z.center.x, z.center.y, z.center.z);
        tz.reach = z.reach;
        tz.peak = z.peak;
        zones.push_back(tz);
    }
    if (bad > 0) {
        FSM_LOG_ERROR(
            "loadRiskZones: REJECTING the whole update — %zu of %zu zones "
            "invalid. Active set unchanged at %zu; adopting the survivors "
            "would hide %zu declared hazard(s).",
            bad, msg->zones.size(), active_risk_zones_.size(), bad);
        return;
    }

    const size_t previous = active_risk_zones_.size();
    if (msg->replace) {
        active_risk_zones_ = zones;
    } else {
        active_risk_zones_.insert(active_risk_zones_.end(),
                                  zones.begin(), zones.end());
    }
    path_manager_->setRiskZonesRuntime(active_risk_zones_);
    FSM_LOG_INFO(
        "loadRiskZones: %s %zu zones (all valid), active set %zu -> %zu",
        msg->replace ? "replaced with" : "appended", zones.size(),
        previous, active_risk_zones_.size());

    // [ENV-CHANGE] Zones are NOT obstacles and must not be re-checked with the
    // obstacle predicate: the same volume is HARD_AVOID on one leg and a
    // SOFT_ENDPOINT containment exemption on another, so "is this point
    // occupied" has no answer without the per-leg policy the flight was
    // planned under. Re-auditing a flight in progress per piece is the right
    // fix and is not built.
    //
    // Until it is, a zone set that CHANGES while a trajectory executes is
    // fail closed: the remaining flight cannot be re-judged, so it stops
    // being claimed as cleared and an ABORT goes out. "We could not check"
    // must not read as "it is still fine" — the same rule the whole-flight
    // audit follows. An unchanged republish is a no-op, or every periodic
    // re-send would ground the mission.
    if (path_manager_->executionTrajectory().duration > 0.0 &&
        path_manager_->riskZoneFingerprint() != zones_before) {
        path_manager_->invalidateStoredTrajectoryForEnvChange();
        FSM_LOG_WARN(
            "loadRiskZones: the zone set CHANGED while a trajectory was "
            "executing — it cannot be re-judged against the new set (per-leg "
            "policy, not occupancy), so the flight is withdrawn");
    }
}

}  // namespace path_manager

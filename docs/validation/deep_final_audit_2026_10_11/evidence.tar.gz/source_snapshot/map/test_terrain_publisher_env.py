"""Behavior tests for terrain_publisher's staging overrides.

    # in a ROS container (rclpy present):
    python3 -m pytest map/test_terrain_publisher_env.py -q

Skipped automatically where rclpy is absent (the mosaic container) — the
module under test imports it at the top. The overrides under test:

  MMP_FULL_MAP     corridor anchor + world=full_map raster (server.py parity)
  MMP_DEM          corridor_dem parameter default
  MMP_DEM_VRT_RES  pins the warped-DEM grid resolution; unset = old behaviour

The discrimination trick: the synthetic world lives at lon/lat ~10/~10 —
nowhere near Korea — so a corridor that comes back with the synthetic DEM's
values can only have used the OVERRIDDEN anchor; falling back to the shipped
Korea anchor makes the same mission degenerate instead.
"""
import os
import sys

import numpy as np
import pytest

rclpy = pytest.importorskip("rclpy")                          # noqa: F841

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_PKG = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "src", "mmp_terrain")
for _p in (_PKG,):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import rasterio                                               # noqa: E402
import mmp_terrain.terrain_publisher as TP                    # noqa: E402
from builtin_interfaces.msg import Time                       # noqa: E402


class _Log:
    def info(self, m): pass
    def warn(self, m): pass
    def error(self, m): pass


class _Now:
    def to_msg(self): return Time()


class _Clock:
    def now(self): return _Now()


class Shim(TP.TerrainPublisher):
    def __init__(self):
        self._live_zones = []
        self._live_obstacles = []
        self._last_load = (0.0, (0.0, 0.0), (0.0, 0.0))

    def get_logger(self): return _Log()
    def get_clock(self): return _Clock()


def _world(tmp_path):
    """A 60x60 u (6 km) anchor at lon/lat ~10/~10 (EPSG:3857) + a flat
    50 m DEM (EPSG:4326) covering it + a two-point mission inside it."""
    anchor = str(tmp_path / "anchor.tif")
    with rasterio.open(anchor, "w", driver="GTiff", height=60, width=60,
                       count=1, dtype="float32", crs="EPSG:3857",
                       transform=rasterio.Affine(100.0, 0.0, 1113194.9,
                                                 0.0, -100.0, 1113194.9)
                       ) as d:
        d.write(np.full((60, 60), 30.0, dtype="float32"), 1)
    dem = str(tmp_path / "dem.tif")
    with rasterio.open(dem, "w", driver="GTiff", height=140, width=140,
                       count=1, dtype="float32", crs="EPSG:4326",
                       transform=rasterio.Affine(0.001, 0.0, 9.92,
                                                 0.0, -0.001, 10.06)) as d:
        d.write(np.full((140, 140), 50.0, dtype="float32"), 1)
    # Explicit override pairs must carry build provenance (pin_pair
    # require_build): stamp both synthetic rasters with one coverage digest,
    # exactly like the real pipeline does — the gate is NOT weakened for
    # tests.
    import json as _json
    for _p in (anchor, dem):
        _json.dump({"coverage_sha256": "test-cov"},
                   open(_p + ".build.json", "w"))
    mission = str(tmp_path / "m.yaml")
    # lonlat-ONLY authoring (the resolver's documented truth form): frame
    # fields are derived per-anchor at load, so the same yaml resolves inside
    # the synthetic anchor and refuses on the shipped one. (The old frame-only
    # form is now refused by design — these fixtures rotted unseen while the
    # suite ran without rclpy.) The lon/lats are computed through the SAME
    # mirrored-axis mapping the resolver uses, so the derived frame coords
    # land exactly on the old fixture points (10,10) and (40,40).
    from mmp_terrain import frame as FR
    from rasterio.warp import transform as _tf
    fr = FR.load_frame(anchor)
    def _ll(wx, wy):
        e, n, _e2, _n2 = FR.frame_bbox_to_en(wx, wy, wx, wy, fr.anchor)
        lon, lat = _tf(fr.crs, "EPSG:4326", [e], [n])
        return lon[0], lat[0]
    (slon, slat), (glon, glat) = _ll(10.0, 10.0), _ll(40.0, 40.0)
    open(mission, "w").write(
        "mission:\n"
        f"  start_lonlat: [{slon:.7f}, {slat:.7f}, 100.0]\n"
        f"  goal_lonlat:  [{glon:.7f}, {glat:.7f}, 100.0]\n"
        # The resolver now enforces the initial-state policy the panel used
        # to enforce in C++ — a stateless mission is refused by design.
        "  initial_speed_mps: 200.0\n")
    return anchor, dem, mission


def test_mmp_full_map_overrides_the_corridor_anchor(tmp_path, monkeypatch):
    anchor, dem, mission = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    msg = Shim().load_corridor(mission, 5.0, 30.0, dem)
    data = np.array(msg.data[0].data, dtype=np.float32)
    assert np.nanmax(data) == pytest.approx(0.5)   # 50 m = 0.5 u — the synthetic DEM spoke
    # and WITHOUT the override the same mission cannot resolve against the
    # shipped Korea anchor + this far-away DEM:
    monkeypatch.delenv("MMP_FULL_MAP")
    with pytest.raises(Exception):
        Shim().load_corridor(mission, 5.0, 30.0, dem)


def test_mmp_dem_feeds_the_corridor_dem_default(tmp_path, monkeypatch):
    """The parameter default must follow MMP_DEM. Proven at the expression
    the declaration evaluates, through a real declare cycle."""
    anchor, dem, mission = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    monkeypatch.setenv("MMP_DEM", dem)

    class ParamShim(Shim):
        def __init__(self):
            super().__init__()
            self._params = {}

        def has_parameter(self, name):
            return name in self._params

        def declare_parameter(self, name, default, *a):
            self._params[name] = default

        def get_parameter(self, name):
            class _V:
                def __init__(s, v): s.value = v
            return _V(self._params[name])

    node = ParamShim()
    _m, _h, _r, dem_default = node._corridor_params()
    assert dem_default == dem                      # env fed the default
    msg = node.load_corridor(mission, 5.0, 30.0, dem_default)
    assert np.nanmax(np.array(msg.data[0].data)) == pytest.approx(0.5)


class ParamWorldShim(Shim):
    """has/declare/get_parameter backed by a dict — enough for load_tif."""

    def __init__(self, world):
        super().__init__()
        self._params = {"world": world}

    def has_parameter(self, name):
        return name in self._params

    def declare_parameter(self, name, default, *a):
        self._params.setdefault(name, default)

    def get_parameter(self, name):
        v = self._params[name]

        class _V:
            def get_parameter_value(s):
                class _S:
                    string_value = v
                return _S()
            value = v
        return _V()


def test_full_world_load_is_budgeted_and_reports_actual_res(tmp_path,
                                                            monkeypatch):
    """A frame past the corridor cell budget must not be read whole (571 MB
    arrays, a 571 MB DDS message). It is coarsened to fit the SAME budget
    corridor mode enforces, and the message carries the ACTUAL resolution."""
    big = str(tmp_path / "full_map.tif")
    with rasterio.open(big, "w", driver="GTiff", height=4000, width=5000,
                       count=1, dtype="float32", crs="EPSG:3857",
                       transform=rasterio.Affine(100.0, 0.0, 1113194.9,
                                                 0.0, -100.0, 1113194.9)
                       ) as d:
        d.write(np.full((4000, 5000), 77.0, dtype="float32"), 1)
    monkeypatch.setenv("MMP_FULL_MAP", big)
    node = ParamWorldShim("full_map")
    msg = node.load_tif()                       # 20M cells > 16M budget
    n = len(msg.data[0].data)
    assert n <= TP.TerrainPublisher.CORRIDOR_CELL_BUDGET
    assert n == 2500 * 2000                     # coarsened x2, not dropped
    assert msg.info.resolution == pytest.approx(2.0)    # ACTUAL res: 2 u = 200 m
    assert np.nanmax(np.array(msg.data[0].data)) == pytest.approx(0.77)


def test_a_small_world_is_still_read_native(tmp_path, monkeypatch):
    anchor, _dem, _m = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    node = ParamWorldShim("full_map")
    msg = node.load_tif()
    assert len(msg.data[0].data) == 60 * 60     # untouched under budget
    assert msg.info.resolution == pytest.approx(1.0)    # 1 u = 100 m


def test_vrt_res_pin_is_passed_and_off_by_default(tmp_path, monkeypatch):
    anchor, dem, mission = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    seen = []
    import rasterio.vrt
    real = rasterio.vrt.WarpedVRT

    def recorder(src, **kw):
        seen.append(dict(kw))
        return real(src, **kw)

    # load_corridor does `from rasterio.vrt import WarpedVRT` at call time,
    # so patching the rasterio module attribute intercepts it.
    monkeypatch.setattr(rasterio.vrt, "WarpedVRT", recorder)

    Shim().load_corridor(mission, 5.0, 30.0, dem)
    assert "transform" not in seen[-1]             # unset: old behaviour

    monkeypatch.setenv("MMP_DEM_VRT_RES", "50")
    msg = Shim().load_corridor(mission, 5.0, 30.0, dem)
    kw = seen[-1]
    assert kw["transform"].a == pytest.approx(50.0)  # pinned grid
    assert kw["width"] > 0 and kw["height"] > 0
    assert np.nanmax(np.array(msg.data[0].data)) == pytest.approx(0.5)


def test_the_anchor_tag_pins_the_vrt_without_any_env(tmp_path, monkeypatch):
    """The asset carries the knowledge: an anchor stamped with
    MMP_DEM_VRT_RES pins the corridor warp grid with NO environment
    variable set; an untagged (Korea-like) anchor keeps the automatic
    grid; an explicit env still wins over the tag."""
    anchor, dem, mission = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    monkeypatch.delenv("MMP_DEM_VRT_RES", raising=False)
    seen = []
    import rasterio.vrt
    real = rasterio.vrt.WarpedVRT

    def recorder(src, **kw):
        seen.append(dict(kw))
        return real(src, **kw)

    monkeypatch.setattr(rasterio.vrt, "WarpedVRT", recorder)

    Shim().load_corridor(mission, 5.0, 30.0, dem)
    assert "transform" not in seen[-1]          # untagged anchor: automatic

    with rasterio.open(anchor, "r+") as a:
        a.update_tags(MMP_DEM_VRT_RES="40.0")
    Shim().load_corridor(mission, 5.0, 30.0, dem)
    assert seen[-1]["transform"].a == pytest.approx(40.0)   # tag applied

    monkeypatch.setenv("MMP_DEM_VRT_RES", "45")
    Shim().load_corridor(mission, 5.0, 30.0, dem)
    assert seen[-1]["transform"].a == pytest.approx(45.0)   # env beats tag


# ── /terrain/load_map service contract (배치 ④: 해석의 단일 창구) ────────
class ServiceShim(ParamWorldShim):
    """load_map_callback까지 돌릴 수 있는 노드 표면: dict 파라미터 +
    publish 기록. 실제 rclpy 실행기 없이 서비스 계약을 행동으로 검사한다."""

    def __init__(self, world="full_map"):
        super().__init__(world)
        self.published = []

        class _Pub:
            def __init__(s, sink): s._sink = sink
            def publish(s, m): s._sink.append(m)
        self.pub = _Pub(self.published)

    def set_parameters(self, params):
        # Mimics rclpy: applies one by one, returns one result per param.
        class _Ok:
            successful = True
        for p in params:
            self._params[p.name] = p.value
        return [_Ok() for _ in params]


def _svc(tmp_path, monkeypatch, world="full_map"):
    anchor, dem, mission = _world(tmp_path)
    monkeypatch.setenv("MMP_FULL_MAP", anchor)
    monkeypatch.setenv("MMP_DEM", dem)
    from mmp_mission_msgs.srv import LoadMap
    return ServiceShim(world), LoadMap, anchor, dem, mission


def test_resolve_only_answers_frame_truth_and_touches_nothing(tmp_path,
                                                              monkeypatch):
    """lonlat-ONLY 미션이 실제 frame 좌표로 응답되고(권위가 좌표를 만든다),
    resolve_only는 파라미터·로드·발행 어느 것도 건드리지 않는다."""
    import hashlib
    node, LoadMap, anchor, _dem, mission = _svc(tmp_path, monkeypatch,
                                                world="small_island")
    req = LoadMap.Request()
    req.resolve_only = True
    req.mission_path = mission
    req.world = "full_map"                 # 함께 보내도 적용되면 안 된다
    req.request_token = "tok-1"
    resp = node.load_map_callback(req, LoadMap.Response())
    assert resp.success and resp.mission_resolved
    assert resp.request_token == "tok-1"
    # 파일에는 frame 좌표가 한 줄도 없다 — (10,10)/(40,40)은 해석의 산물.
    assert resp.mission.start.x == pytest.approx(10.0, abs=1e-3)
    assert resp.mission.start.y == pytest.approx(10.0, abs=1e-3)
    assert resp.mission.start.z == 100.0            # z는 미터 AGL 원문
    assert resp.mission.goal.x == pytest.approx(40.0, abs=1e-3)
    assert resp.mission.use_initial_speed is True
    assert resp.mission.initial_speed_mps == 200.0
    # 해시한 것 = 파싱한 것, 프레임 정체성은 앵커에서.
    raw = open(mission, "rb").read()
    assert resp.mission.mission_sha256 == hashlib.sha256(raw).hexdigest()
    from mmp_terrain import frame as FR
    assert resp.mission.frame_digest == FR.frame_digest(anchor)
    # 아무것도 바뀌지 않았다: 발행 0, world 파라미터 그대로, 미션 파라미터
    # 미기록(선언 기본값 '' 뿐).
    assert node.published == []
    assert node._params["world"] == "small_island"
    assert node._params.get("corridor_mission", "") == ""


def test_corridor_call_resolves_once_for_bbox_and_response(tmp_path,
                                                           monkeypatch):
    """corridor bbox와 응답 미션이 같은 스냅숏 하나에서 나온다 — 두 번
    해석하면 설치 스왑/파일 재작성이 둘을 가를 수 있다(재열기 TOCTOU)."""
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch)
    calls = []
    orig = node._pin_and_resolve

    def counting(mp, dp):
        calls.append(mp)
        return orig(mp, dp)
    monkeypatch.setattr(node, "_pin_and_resolve", counting)

    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = mission
    req.corridor_halfwidth_u = 5.0
    req.resolution_m = 30.0
    req.request_token = "tok-2"
    resp = node.load_map_callback(req, LoadMap.Response())
    assert resp.success and resp.mission_resolved, resp.message
    assert calls == [mission]              # 정확히 한 번
    assert len(node.published) == 1        # 지형은 발행됐다
    assert resp.request_token == "tok-2"
    assert resp.actual_resolution_m == pytest.approx(30.0)
    # 응답 미션과 corridor bbox가 같은 기하를 본다: 데이터 경계 클램프
    # 안쪽에 있는 goal(40,40)을 bbox가 품는다. (이 픽스처의 DEM은 앵커
    # 남쪽 1/3을 덮지 않아 start(10,10)는 정당하게 클램프 밖이다.)
    assert resp.min_bound_u[0] <= 40.0 <= resp.max_bound_u[0]
    assert resp.min_bound_u[1] <= 40.0 <= resp.max_bound_u[1]
    assert resp.mission.goal.x == pytest.approx(40.0, abs=1e-3)


def test_stateless_mission_fails_closed_before_any_load(tmp_path,
                                                        monkeypatch):
    """초기상태 없는 미션은 로드/발행 전에 전체 호출이 거부된다 — 패널
    C++ 파서가 하던 거부가 이제 권위에서 일어난다."""
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch)
    stateless = mission + ".stateless.yaml"
    lines = [ln for ln in open(mission).read().splitlines(True)
             if "initial_speed" not in ln]
    open(stateless, "w").writelines(lines)
    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = stateless
    resp = node.load_map_callback(req, LoadMap.Response())
    assert not resp.success
    assert not resp.mission_resolved
    assert "initial" in resp.message
    assert node.published == []            # fail-closed: 발행 0


def test_failure_after_resolution_ships_no_half_truths(tmp_path,
                                                       monkeypatch):
    """해석 성공 후 로드가 죽어도 success=false 옆에 해석된 미션이 실려
    가면 안 된다 — mission_resolved만 보는 소비자가 지형 없는 미션을
    날리게 된다."""
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch)

    def boom(ctx=None):
        raise RuntimeError("post-resolution load failure (test)")
    monkeypatch.setattr(node, "load_tif", boom)
    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = mission
    req.request_token = "tok-3"
    resp = node.load_map_callback(req, LoadMap.Response())
    assert not resp.success
    assert not resp.mission_resolved
    assert resp.mission.start.x == 0.0 and resp.mission.mission_sha256 == ""
    assert resp.request_token == "tok-3"   # 실패 응답도 stale 판별 가능
    assert node.published == []


def _stateless_copy(mission):
    stateless = mission + ".stateless.yaml"
    lines = [ln for ln in open(mission).read().splitlines(True)
             if "initial_speed" not in ln]
    open(stateless, "w").writelines(lines)
    return stateless


def test_failed_load_rolls_back_parameters(tmp_path, monkeypatch):
    """A refused request must not leave its mission/world/knobs in the node
    parameters — a later parameter-driven reload would replay the failure."""
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch)
    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = mission
    resp = node.load_map_callback(req, LoadMap.Response())
    assert resp.success, resp.message
    assert node._params["corridor_mission"] == mission   # committed

    bad = LoadMap.Request()
    bad.world = "full_map"
    bad.mission_path = _stateless_copy(mission)
    bad.corridor_halfwidth_u = 77.0
    resp2 = node.load_map_callback(bad, LoadMap.Response())
    assert not resp2.success
    assert node._params["corridor_mission"] == mission   # rolled back
    assert float(node._params["corridor_halfwidth_u"]) == 200.0
    assert node._params["world"] == "full_map"


def test_rejected_parameter_write_fails_closed_and_rolls_back(tmp_path,
                                                             monkeypatch):
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch,
                                                 world="small_island")
    applied = node.set_parameters

    class _Bad:
        successful = False

    # Reject only the FIRST write (the request, values still applied — the
    # partial-apply case); the rollback write goes through.
    calls = {"n": 0}

    def gate(ps):
        calls["n"] += 1
        if calls["n"] == 1:
            applied(ps)
            return [_Bad() for _ in ps]
        return applied(ps)
    monkeypatch.setattr(node, "set_parameters", gate)

    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = mission
    resp = node.load_map_callback(req, LoadMap.Response())
    assert not resp.success
    assert "rejected" in resp.message
    assert node.published == []
    assert node._params["world"] == "small_island"       # restored
    assert node._params["corridor_mission"] == ""


def test_throwing_parameter_write_rolls_back_already_applied_values(tmp_path,
                                                                 monkeypatch):
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch,
                                               world="small_island")
    applied = node.set_parameters
    calls = {"n": 0}

    def throwing_gate(params):
        calls["n"] += 1
        if calls["n"] == 1:
            # Real rclpy applies parameters sequentially. A callback for a
            # later parameter may raise after an earlier one was committed.
            applied(params[:1])
            raise RuntimeError("later parameter callback threw")
        return applied(params)

    monkeypatch.setattr(node, "set_parameters", throwing_gate)
    response = node.load_map_callback(
        LoadMap.Request(world="full_map", mission_path=mission), LoadMap.Response())
    assert not response.success and "later parameter callback threw" in response.message
    assert node.published == []
    assert node._params["world"] == "small_island"
    assert node._params["corridor_mission"] == ""
    assert calls["n"] == 2


def test_pin_and_resolve_opens_the_anchor_exactly_once(tmp_path, monkeypatch):
    """Frame spec and frame digest must come from ONE open of the anchor —
    a second open can straddle an in-place staging replace and pair frame A
    coordinates with frame B identity."""
    node, _LoadMap, anchor, dem, mission = _svc(tmp_path, monkeypatch)
    real_open = rasterio.open
    opens = []

    def counting(path, *a, **kw):
        opens.append(str(path))
        return real_open(path, *a, **kw)
    monkeypatch.setattr(rasterio, "open", counting)

    node._pin_and_resolve(mission, dem)
    target = os.path.realpath(anchor)
    n = sum(1 for p in opens if os.path.realpath(p) == target)
    assert n == 1, f"anchor opened {n} times: {opens}"


def test_whole_corridor_call_opens_the_anchor_exactly_once(tmp_path,
                                                           monkeypatch):
    """The ctx snapshot must feed EVERYTHING the corridor load reads off the
    anchor (spec, digest, VRT-res tag) — any reopen in the load path can
    straddle an in-place replace. (The fine DEM exists here, so the
    documented DEM-fallback reopen is not in play.)"""
    node, LoadMap, anchor, _dem, mission = _svc(tmp_path, monkeypatch)
    real_open = rasterio.open
    opens = []

    def counting(path, *a, **kw):
        opens.append(str(path))
        return real_open(path, *a, **kw)
    monkeypatch.setattr(rasterio, "open", counting)

    req = LoadMap.Request()
    req.world = "full_map"
    req.mission_path = mission
    resp = node.load_map_callback(req, LoadMap.Response())
    assert resp.success, resp.message
    target = os.path.realpath(anchor)
    n = sum(1 for p in opens if os.path.realpath(p) == target)
    assert n == 1, f"anchor opened {n} times: {opens}"


def test_rollback_rejection_is_reported_not_silent(tmp_path, monkeypatch):
    """A restore write refused via SetParametersResult (no exception) must
    still produce the ROLLBACK FAILED report."""
    node, LoadMap, _anchor, _dem, mission = _svc(tmp_path, monkeypatch)
    errors = []

    class _Logger(_Log):
        def error(self, m):
            errors.append(m)
    monkeypatch.setattr(node, "get_logger", lambda: _Logger())

    applied = node.set_parameters

    class _Bad:
        successful = False

    calls = {"n": 0}

    def gate(ps):
        calls["n"] += 1
        applied(ps)
        # First call (the request) succeeds; the ROLLBACK write is refused
        # by result, exactly how a parameter callback rejects.
        if calls["n"] == 1:
            return [type("_Ok", (), {"successful": True})() for _ in ps]
        return [_Bad() for _ in ps]
    monkeypatch.setattr(node, "set_parameters", gate)

    bad = LoadMap.Request()
    bad.world = "full_map"
    bad.mission_path = _stateless_copy(mission)
    resp = node.load_map_callback(bad, LoadMap.Response())
    assert not resp.success
    assert any("ROLLBACK FAILED" in e for e in errors)


def test_resolve_only_without_mission_path_is_refused(tmp_path, monkeypatch):
    node, LoadMap, _anchor, _dem, _mission = _svc(tmp_path, monkeypatch)
    req = LoadMap.Request()
    req.resolve_only = True
    resp = node.load_map_callback(req, LoadMap.Response())
    assert not resp.success and not resp.mission_resolved
    assert "resolve_only" in resp.message
    assert node.published == []


def test_startup_load_refusal_keeps_node_alive_and_service_up(monkeypatch):
    """기동 시 지형 로드가 거부돼도(레거시/스테일 미션, 없는 래스터) 노드는
    죽지 않고 /terrain/load_map 서비스가 살아 있어야 한다 — 단, fail-open
    금지: 지형은 발행되지 않는다(발행은 로드 성공 분기에서만 일어난다).
    수리 전에는 __init__이 예외를 그대로 던져 프로세스가 죽고 서비스도
    함께 사라졌다."""
    def _refuse(self):
        raise RuntimeError("startup terrain load refused (test)")
    monkeypatch.setattr(TP.TerrainPublisher, "load_tif", _refuse)
    published = []
    rclpy.init()
    try:
        node = TP.TerrainPublisher()          # 수리 전: RuntimeError 전파
        assert getattr(node, "load_map_srv", None) is not None, \
            "load_map service must survive a refused startup load"
        # fail-open 금지의 구조적 확인: publish는 성공 분기에서만.
        node.pub.publish = lambda msg: published.append(msg)
        assert published == []
        node.destroy_node()
    finally:
        rclpy.shutdown()
